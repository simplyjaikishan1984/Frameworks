package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamPttPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.PTT;

public class SamPttSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	/*@When("^I click the channel Plus button")
	public void clickPlusIcon() {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		pttPage.clickAddChannel();
	}

	@When("^I click the channel Minus button")
	public void clickMinusIcon() {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		pttPage.clickRemoveChannel();
	}*/

	@When("^I check the \"([^\"]*)\" PTT field$")
	public void checkPttCheckbox(String arg1) throws Throwable {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		if (pttPage.getField(arg1.trim()) != null) {
			pttPage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with label '{}'", arg1);
		}
	}

	@When("^I uncheck the \"([^\"]*)\" PTT field$")
	public void uncheckPttCheckbox(String arg1) throws Throwable {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		if (pttPage.getField(arg1.trim()) != null) {
			pttPage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with label '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" PTT field$")
	public void selectPttMenuOption(String arg1, String arg2) throws Throwable {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		if (pttPage.getField(arg2.trim()) != null) {
			pttPage.getField(arg2.trim()).updateMenuByLabel(arg1.trim());
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" PTT field$")
	public void enterPttFieldValue(String arg1, String arg2) {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		if (pttPage.getField(arg2.trim()) != null) {
			pttPage.getField(arg2.trim()).updateTextbox(arg1.trim());
		} else {
			log.error("No matching field with label '{}'", arg2);
		}
	}

	@When("^I click the \"([^\"]*)\" radio button of the \"([^\"]*)\" PTT field$")
	public void activateDeviceSettingsRadio(String arg1, String arg2) {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		if (pttPage.getField(arg2.trim()) != null) {
			String appendedKey = arg1.trim().toLowerCase() + arg2.trim();
			if (pttPage.getField(appendedKey) != null) {
				pttPage.getField(appendedKey).updateRadioButton();
			} else {
				log.error("No matching radio button value with title '{}'", arg1);
				Assert.fail("SAM Radio Button Not Found");
			}
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the \"([^\"]*)\" PTT setting$")
	public void verifyPttValue(String arg1, String arg2, String arg3) throws Throwable {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(PTT, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(PTT, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(PTT)) phone.loadAppPreferences(PTT);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("No matching field with label '{}'", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("^\"([^\"]*)\" should have the approximate value of \"([^\"]*)\" in the \"([^\"]*)\" PTT setting$")
	public void verifyApproximatePttValue(String arg1, String arg2, String arg3) throws Throwable {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(PTT, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(PTT, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(PTT)) phone.loadAppPreferences(PTT);
				Environment.addScenarioFailure(phone.compareApproximate(fieldKey, arg2.trim(), 2));
			} else {
				log.error("No matching field with label '{}'", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I delete the \"([^\"]*)\" PTT field$")
	public void deletePttSetting(String arg1) throws Throwable {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		pttPage.getField(arg1.trim()).delete();
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the PTT custom attribute \"([^\"]*)\" setting$")
	public void checkPttCustomAttributeSetting(String arg1, String arg2, String arg3) {
		if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
			VersityPhone phone = Environment.getPhone(arg1.trim());
			if (phone != null) {
				if (!phone.getCurrentAppSettings().equals(PTT)) phone.loadAppPreferences(PTT);
				Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
			} else {
				log.error("Phone with label '{}' does not exist", arg1);
				Assert.fail("Specified Phone Not Available");
			}
		} else {
			log.debug("Skipped checking attribute {} since custom attribute testing is turned off", arg1);
		}
	}

	@Then("^the PTT page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyPttPageValue(String arg1, String arg2) {
		SamPttPage pttPage = (SamPttPage) Environment.getCurrentPage();
		if (pttPage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(pttPage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(pttPage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Field with label '{}' does not exist", arg2);
		}
	}
}