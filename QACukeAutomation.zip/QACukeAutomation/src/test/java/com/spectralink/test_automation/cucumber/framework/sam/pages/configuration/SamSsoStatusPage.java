package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.SsoStatusStrings.ENABLE_SSO;
import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.SsoStatusStrings.IDENTITY_SYSTEM;

public class SamSsoStatusPage extends SamConfigurationPage {

	@FindBy(id = "sso-enabled_label")
	private WebElement ssoEnabledLabel;

	@FindBy(id = "sso-enabled")
	private WebElement ssoEnabledCheckbox;

	@FindBy(id = "delete_setting_ssoEnabled")
	private WebElement ssoEnabledDelete;

	@FindBy(id = "edit_setting_ssoEnabled")
	private WebElement ssoEnabledEdit;

	@FindBy(id = "undo_setting_ssoEnabled")
	private WebElement ssoEnabledUndo;

	public ConfigPageField ssoEnabledField = new ConfigPageField(
			ENABLE_SSO,
			ssoEnabledLabel,
			ssoEnabledCheckbox,
			ssoEnabledDelete,
			ssoEnabledEdit,
			ssoEnabledUndo
	);

	@FindBy(id = "sso-magement-system")
	private WebElement managementSystemMenu;

	public ConfigPageField managementSystemField = new ConfigPageField(
			IDENTITY_SYSTEM,
			managementSystemMenu,
			null,
			null
	);

	public SamSsoStatusPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(ssoEnabledField.getTitle(), ssoEnabledField);
				put(managementSystemField.getTitle(), managementSystemField);
			}
		};
	}
}
