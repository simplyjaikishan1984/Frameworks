package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.UsbHost;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.util.List;

public class SamUsbHostSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @Given("^I connect to the USB host at \"([^\"]*)\" with account \"([^\"]*)\" and password \"([^\"]*)\"")
    public void connectToUsbHostWithSpecificCredentials(String hostAddress, String hostAccount, String hostPassword) throws Exception {
        if (Environment.getUsbHost() == null) {
            List<String> requestedPhones;
            List<String> foundPhones;
            if (Environment.getSam() != null) {
                requestedPhones = Environment.getSam().getDeviceSerials();
                Environment.setUsbHost(new UsbHost(hostAddress, hostAccount, hostPassword, requestedPhones));
                foundPhones = Environment.getUsbHost().getVersityPhoneSerials(4);
                if (foundPhones.size() < 2) {
                    log.error("Not enough phones (2) could be found on the USB host");
                    Environment.setSkipRemaining(true);
                    throw new Exception("Not enough test phones to run testing");
                }
            } else {
                requestedPhones = RunDefaults.getArraySetting("testPhones");
                Environment.setUsbHost(new UsbHost(hostAddress, hostAccount, hostPassword, requestedPhones));
                if(requestedPhones.size() > 0)
                    foundPhones = requestedPhones;
                else
                    foundPhones = Environment.getUsbHost().getVersityPhoneSerials(4);
            }
            if (foundPhones.size() > 0) {
                char token = 'A';
                for (String foundPhone : foundPhones) {
                    String phoneLabel = "PHONE " + token;
                    Environment.setPhone(phoneLabel, Environment.getUsbHost().getVersityPhone(foundPhone));
                    log.info("'{}' is set to Versity with serial {}", phoneLabel, foundPhone);
                    token++;
                }
            } else {
                log.error("No phones could be found on the USB host");
                Environment.setSkipRemaining(true);
                throw new Exception("Not enough test phones to run testing");
            }
        }
    }

    @Given("^I connect to the USB host at \"([^\"]*)\" with default credentials$")
    public void connectToUsbHostWithDefaultCredentials(String hostAddress) throws Exception {
        if (Environment.getUsbHost() == null) {
            List<String> requestedPhones;
            List<String> foundPhones;
            String hostAccount = RunDefaults.getDecryptedSetting("usbHostAccount");
            String hostPassword = RunDefaults.getDecryptedSetting("usbHostPassword");
            if (Environment.getSam() != null) {
                requestedPhones = Environment.getSam().getDeviceSerials();
                Environment.setUsbHost(new UsbHost(hostAddress, hostAccount, hostPassword, requestedPhones));
                foundPhones = Environment.getUsbHost().getVersityPhoneSerials(4);
                if (foundPhones.size() < 2) {
                    log.error("Not enough phones (2) could be found on the USB host");
                    Environment.setSkipRemaining(true);
                    throw new Exception("Not enough test phones to run testing");
                }
            } else {
                requestedPhones = RunDefaults.getArraySetting("testPhones");
                Environment.setUsbHost(new UsbHost(hostAddress, hostAccount, hostPassword, requestedPhones));
                if(requestedPhones.size() > 0)
                    foundPhones = requestedPhones;
                else
                    foundPhones = Environment.getUsbHost().getVersityPhoneSerials(4);
            }
            if (foundPhones.size() > 0) {
                char token = 'A';
                for (String foundPhone : foundPhones) {
                    String phoneLabel = "PHONE " + token;
                    Environment.setPhone(phoneLabel, Environment.getUsbHost().getVersityPhone(foundPhone));
                    log.info("'{}' is set to Versity with serial {}", phoneLabel, foundPhone);
                    token++;
                }
            } else {
                log.error("No phones could be found on the USB host");
                Environment.setSkipRemaining(true);
                throw new Exception("Not enough test phones to run testing");
            }
        }
    }

    @Given("^I connect to the default USB host$")
    public void connectToDefaultUsbHost() throws Exception {
        if (Environment.getUsbHost() == null) {
            List<String> requestedPhones;
            List<String> foundPhones;
            String hostAddress = RunDefaults.getStringSetting("usbHostAddress");
            String hostAccount = RunDefaults.getDecryptedSetting("usbHostAccount");
            String hostPassword = RunDefaults.getDecryptedSetting("usbHostPassword");
            if (Environment.getSam() != null) {
                requestedPhones = Environment.getSam().getDeviceSerials();
                Environment.setUsbHost(new UsbHost(hostAddress, hostAccount, hostPassword, requestedPhones));
                foundPhones = Environment.getUsbHost().getVersityPhoneSerials(4);
                if (foundPhones.size() < 2) {
                    log.error("Not enough phones (2) could be found on the USB host");
                    Environment.setSkipRemaining(true);
                    throw new Exception("Not enough test phones to run testing");
                }
            } else {
                requestedPhones = RunDefaults.getArraySetting("testPhones");
                Environment.setUsbHost(new UsbHost(hostAddress, hostAccount, hostPassword, requestedPhones));
                if(requestedPhones.size() > 0)
                    foundPhones = requestedPhones;
                else
                    foundPhones = Environment.getUsbHost().getVersityPhoneSerials(4);
            }
            if (foundPhones.size() > 0) {
                char token = 'A';
                for (String foundPhone : foundPhones) {
                    String phoneLabel = "PHONE " + token;
                    Environment.setPhone(phoneLabel, Environment.getUsbHost().getVersityPhone(foundPhone));
                    log.info("'{}' is set to Versity with serial {}", phoneLabel, foundPhone);
                    token++;
                }
            } else {
                log.error("No phones could be found on the USB host");
                Environment.setSkipRemaining(true);
                throw new Exception("Not enough test phones to run testing");
            }
        }
    }

    @Then("I'm connected to the USB host")
    public void verifyConnection() {
        Assert.assertFalse(Environment.getUsbHost().getAdbDevices().isEmpty(), "USB Host Connection Error");
        log.debug("Verified connected to USB host at {}", Environment.getUsbHost().getHostAddress());
    }

    @Given("^I consider \"([^\"]*)\" to be the Versity phone with serial number \"([^\"]*)\"$")
    public void changePhone(String arg1, String arg2) {
        if (!arg1.trim().isEmpty()) {
            if (Environment.getUsbHost().getVersityPhone(arg2.trim()) != null) {
                Environment.setPhone(arg1.trim(), Environment.getUsbHost().getVersityPhone(arg2));
                log.info("'{}' is set to Versity with serial {}", arg1.trim(), Environment.getUsbHost().getVersityPhone(arg2.trim()).getSerialNumber());
            } else {
                log.error("A phone with serial number '{}' does not exist", arg2);
                Assert.fail("Specified Phone Not Available");
            }
        } else {
            log.error("A phone cannot have an empty label");
            Assert.fail("Specified Label Is Invalid");
        }
    }

    @Then("SAM should have sent the appropriate number of attributes to \"([^\"]*)\"")
    public void verifyAttributeCount(String arg1) {
        log.debug("Using {}", Environment.getPhone(arg1.trim()).getSerialNumber());
        log.debug("SAM sent {} attributes", Environment.getSam().jarvisLog().getLastResponseCount(Environment.getPhone(arg1.trim()).getSerialNumber()));
    }
}