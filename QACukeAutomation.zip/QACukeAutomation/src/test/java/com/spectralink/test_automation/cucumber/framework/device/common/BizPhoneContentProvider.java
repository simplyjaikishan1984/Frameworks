package com.spectralink.test_automation.cucumber.framework.device.common;

import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;

import java.util.regex.Pattern;

public class BizPhoneContentProvider {

    private final VersityPhone phone;
    private String bizPhoneContentProviderCallDetails = "com.spectralink.phone.provider/calls/";
    public static Boolean missedDroppedBizPhone =false;
    private String bizPhoneContentProviderAcctDetails = "com.spectralink.phone.provider/accts/0";
    private final String bizPhoneContentProviderAcctDetailsSaturn = "com.cisco.phone.provider/accts/0";

    public BizPhoneContentProvider(VersityPhone phone) {
        this.phone = phone;
    }

    public String getTxPackets(String callId) {
        return phone.getQueryResult(getAudioStats(callId), Pattern.compile("Tx ([^,]+)"));
    }

    public String getRxPackets(String callId) {
        return phone.getQueryResult(getAudioStats(callId), Pattern.compile("Rx ([^,]+)"));
    }

    public String getMissedPackets(String callId) {
        missedDroppedBizPhone = true;
        return phone.getQueryResult(getAudioStats(callId), Pattern.compile("Missed ([^,]+\\(([^()]*)\\)*%)"));
    }

    public String getDroppedPackets(String callId) {
        missedDroppedBizPhone = true;
        return phone.getQueryResult(getAudioStats(callId), Pattern.compile("Dropped ([^,]+\\(([^()]*)\\)*%)"));
    }

    public String getCallState(String callId) {
        return phone.getQueryResult(bizPhoneContentProviderCallDetails + callId + " --projection callState", Pattern.compile("callState=([^,]+)"));
    }

    public String getMediaState(String callId) {
        return phone.getQueryResult(bizPhoneContentProviderCallDetails + callId + " --projection mediaState", Pattern.compile("mediaState=([^,]+)"));
    }

    public String getCallerName(String callId) {
        return phone.getQueryResult(bizPhoneContentProviderCallDetails + callId + " --projection farDispName", Pattern.compile("farDispName=(.*)"));
    }

    public String getCallMutedState(String callId) {
        return phone.getQueryResult(bizPhoneContentProviderCallDetails + callId + " --projection ismuted", Pattern.compile("ismuted=(.*)"));
    }

    public String getCallDuration(String callId) {
        return phone.getQueryResult(bizPhoneContentProviderCallDetails + callId + " --projection msStartConnect", Pattern.compile("msStartConnect=([^,]+)"));
    }

    public String getRegistrationCode() {
        return phone.getQueryResult(bizPhoneContentProviderAcctDetails + " --projection regCode", Pattern.compile("regCode=([^,]+)"));
    }

    public String getRegistrationUpdate() {
        return phone.getQueryResult(bizPhoneContentProviderAcctDetails + " --projection msRegUpdate", Pattern.compile("msRegUpdate=([^,]+)"));
    }

    public String getRegistrationExpiration() {
        return phone.getQueryResult(bizPhoneContentProviderAcctDetails + " --projection regExpire", Pattern.compile("regExpire=([^,]+)"));
    }

    public String getAudioStats(String callId) {
        return bizPhoneContentProviderCallDetails + callId + " --projection audioStats";
    }

    public String getCallIdFarEndUsername(String extensionNumber) {
        String fetchCallIdWithFarEndUserName;
        if (Util.isWindows())
            fetchCallIdWithFarEndUserName = bizPhoneContentProviderCallDetails + " --projection _id --where 'callState=\\\"CALL_STATE_CONFIRMED\\\" AND farUserName=\\\"" + extensionNumber + "\\\"'";
        else
            fetchCallIdWithFarEndUserName = bizPhoneContentProviderCallDetails + " --projection _id --where \"callState=\'CALL_STATE_CONFIRMED\' AND farUserName=\'" + extensionNumber + "\'\"";
        return phone.getQueryResult(fetchCallIdWithFarEndUserName, Pattern.compile("_id=([^,]+)"));
    }
    public String getCallId() {
        String fetchCallIdActiveCall;
        if (Util.isWindows())
            fetchCallIdActiveCall = bizPhoneContentProviderCallDetails + " --projection _id --where 'callState!=\\\"CALL_STATE_DISCONNECTED\\\"\\ AND\\ callState!=\\\"CALL_STATE_NULL\\\"\\ AND\\ mediaState!=\\\"MEDIA_STATE_LOCAL_HOLD\\\"'";
        else
            fetchCallIdActiveCall = bizPhoneContentProviderCallDetails + " --projection _id --where \"callState!=\'CALL_STATE_DISCONNECTED\' AND callState!=\'CALL_STATE_NULL\' AND mediaState!=\'MEDIA_STATE_LOCAL_HOLD\'\"";

        return phone.getQueryResult(fetchCallIdActiveCall, Pattern.compile("_id=([^,]+)"));
    }

    public String getCallIdIncomingOutgoingCall() {
        String fetchCallIdIncomingOutgoingCall;
        if (Util.isWindows())
            fetchCallIdIncomingOutgoingCall = bizPhoneContentProviderCallDetails + " --projection _id --where \"callState=\\'CALL_STATE_EARLY\\'\"";
        else
            fetchCallIdIncomingOutgoingCall = bizPhoneContentProviderCallDetails + " --projection _id --where \"callState=\'CALL_STATE_EARLY\'\"";
        return phone.getQueryResult(fetchCallIdIncomingOutgoingCall, Pattern.compile("_id=([^,]+)"));
    }
}
