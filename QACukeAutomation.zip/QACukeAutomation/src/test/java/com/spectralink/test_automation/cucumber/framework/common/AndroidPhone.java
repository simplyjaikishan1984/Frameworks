package com.spectralink.test_automation.cucumber.framework.common;

import com.jcraft.jsch.JSchException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.spectralink.test_automation.cucumber.framework.common.Util.qquote;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.common.BizPhoneContentProvider.missedDroppedBizPhone;
import static com.spectralink.test_automation.cucumber.framework.device.common.CiscoPhoneContentProvider.missedDroppedCiscoPhone;

public class AndroidPhone {
	protected UsbHost host;
	private String serialNumber;
	private String status;
	private String path;
	private Integer portNumber;
	private Integer bootstrapPortNumber;
	private String transportId;
	private PhoneType phoneType;
	private AccountDatabase keyDatabase;
	private boolean connectedViaAdb;
	private boolean rooted;
	protected Map<String, Properties> soundFiles;
	protected Map<String, String> systemProperties = new HashMap<String, String>();
	protected Map<String, Map<String, String>> settings = new HashMap<>();
	protected LogcatInspector inspector;
	private final Logger log = LogManager.getLogger(this.getClass().getName());

	public enum PhoneType {
		PIVOT,
		VERSITY,
		OTHER
	}

	public enum Health {
		UNKNOWN("unknown", "1"),
		GOOD("good", "2"),
		OVERHEAT("overheat", "3"),
		DEAD("dead", "4"),
		OVER("over voltage", "5"),
		FAILURE("unspecified failure", "6"),
		COLD("cold", "7");

		private final String classification;
		private final String code;

		Health(String classification, String code) {
			this.classification = classification;
			this.code = code;
		}

		public String getClassification() {
			return classification;
		}

		public String getCode() {
			return code;
		}
	}

	public enum Status {
		UNKNOWN("unknown", "1"),
		CHARGING("charging", "2"),
		DISCHARGING("discharging", "3"),
		NOT_CHARGING("not charging", "4"),
		FULL("fully charged", "5");

		private final String classification;
		private final String code;

		Status(String classification, String code) {
			this.classification = classification;
			this.code = code;
		}

		public String getClassification() {
			return classification;
		}

		public String getCode() {
			return code;
		}
	}

	public enum Application {
		NONE("None", "", null),
		BIZ_PHONE("Biz Phone", "com.spectralink.phone", Activity.BIZ_PHONE_DIALER),
		DEVICE("Device", "com.spectralink.slnkdevicesettings", Activity.DEVICE_SETTINGS),
		WEBAPI("Web API", "com.spectralink.slnkwebapi", Activity.WEBAPI_SETTINGS),
		SYS_UPDATER("Sys Updater", "com.spectralink.slnkota", Activity.SYS_UPDATER_MAIN),
		VQO("VQO", "com.spectralink.slnkvqo", Activity.VQO_SETTINGS),
		LOGGING("Logging", "com.spectralink.slnklogger", Activity.LOGGING_SCREEN),
		BARCODE("Barcode", "com.spectralink.barcode.service", Activity.BARCODE_SERVICE),
		PTT("PTT", "com.spectralink.slnkptt", Activity.PTT_MAIN),
		SAFE("SAFE", "com.spectralink.slnksafe", Activity.SAFE_MAIN),
		APP_URLS("App Urls", "com.spectralink.slnkappurl", null),
		PORT_MANAGER("Port Manager", "com.spectralink.slnkportmanager", null),
		SAM_CLIENT("SAM Client", "com.spectralink.slnksamclient", Activity.SAM_CLIENT_MAIN),
		BATTLIFE("Batt Life", "com.spectralink.battlife", Activity.BATT_LIFE_MAIN),
		LENS_GRID("Lens Grid", "com.spectralink.lensgrid", Activity.LENS_GRID_MAIN),
		BUTTONS("Buttons", "com.spectralink.buttons", Activity.BUTTONS_MAIN),
		AMIE_AGENT("AMIE Agent", "com.spectralink.amieagent", Activity.AMIE_AGENT_DASHBOARD),
		SETTINGS("Settings", "com.android.settings", Activity.SETTINGS_MAIN),
		SETTINGS_BSSID("Settings Bssid", "com.android.settings", Activity.WIFI_STATUS_SCREEN),
		AUTOMATION_HELPER("Automation Helper", "com.spectralink.automationhelper", Activity.AUTOMATION_HELPER_MAIN),
		BARCODE_TEST_APP("Barcode test app", "com.spectralink.example.barcode", Activity.BARCODE_TEST_APP_MAIN),
		LAUNCHER("Launcher", "com.android.launcher3", Activity.LAUNCHER),
		SSO_STATUS("SSO Status", "com.spectralink.sso", Activity.SSO_MAIN),
		ANDROID_CONTACTS("Contacts", "com.android.providers.contacts", Activity.ANDROID_CONTACTS_MAIN),
		CISCO_PHONE("Cisco Phone", "com.cisco.phone", Activity.CISCO_PHONE_DIALER),
		CUSTOM_SETTINGS("Custom Settings", "com.cisco.customsettings", Activity.DEVICE_SETTINGS),
		SATURN_WEBAPI("Saturn Web API", "com.cisco.webapi", Activity.WEBAPI_SETTINGS),
		SATURN_SYS_UPDATER("System Updater", "com.cisco.sysupdater", Activity.SYSTEM_UPDATER_MAIN),
		CALL_QUALITY_SETTINGS("Call Quality Settings", "com.cisco.callquality", Activity.VQO_SETTINGS),
		SATURN_LOGGING("Saturn Logging", "com.cisco.logging", Activity.LOGGING_SCREEN),
		SATURN_BARCODE("Saturn Barcode", "com.cisco.barcode.service", Activity.SATURN_BARCODE_SERVICE),
		SATURN_PTT("Saturn PTT", "com.cisco.ptt", Activity.PTT_MAIN),
		EMERGENCY("Emergency", "com.cisco.emergency", Activity.SAFE_MAIN),
		SATURN_APP_URLS("Saturn App Urls", "com.cisco.appurl", null),
		SATURN_PORT_MANAGER("Saturn Port Manager", "com.cisco.portmanager", null),
		BATTERY_LIFE("Battery Life", "com.cisco.batterylife", Activity.BATT_LIFE_MAIN),
		SATURN_BUTTONS("Saturn Buttons", "com.cisco.buttons", Activity.BUTTONS_MAIN),
		UNKNOWN("Unknown", "", null);

		private final String label;
		private final String packageName;
		private final Activity mainActivity;

		Application(String label, String packageName, Activity activity) {
			this.label = label;
			this.packageName = packageName;
			this.mainActivity = activity;
		}

		public String getPackage() {
			return packageName;
		}

		public String getLabel() {
			return label;
		}

		public String getMainActivity() {
			return mainActivity == null ? "" : mainActivity.getIntent();
		}
	}

	public enum Activity {
		SYSTEM_MAIN("Home", "com.android.systemui"),
		SETTINGS_MAIN("Android Settings", "com.android.settings.Settings"),
		SETTINGS_WIFI("Wifi Settings", ".Settings$NetworkDashboardActivity"),
		SETTINGS_BATTERY("Battery settings", ".Settings$PowerUsageSummaryActivity"),
		DATE_TIME("Android date time settings", "android.settings.DATE_SETTINGS"),
		DEVICE_INFO_SETTINGS("About phone page", "android.settings.DEVICE_INFO_SETTINGS"),
		LANGUAGE_SETTINGS("Android language settings", "android.settings.LOCALE_SETTINGS"),
		WEBAPI_SETTINGS("WebAPI Settings", "com.spectralink.slnkwebapi.settings.SettingsActivity"),
		SAFE_MAIN("SAFE Main", "com.spectralink.SlnkSafe.PanicButtonActivity"),
		BATT_LIFE_MAIN("BattLife Dashboard", "com.spectralink.battlife.activities.LandingPage"),
		BATT_LIFE_CRITICAL("BattLife critical alert", "com.spectralink.battlife.activities.CriticalBatteryAlert"),
		BATT_LIFE_SETTINGS("BattLife Settings", "com.spectralink.battlife.settings.SettingsActivity"),
		BIZ_PHONE_DIALER("Biz Phone Dialer", "com.spectralink.phone.activities.Dialer"),
		AUTOMATION_HELPER_MAIN("Automation Helper Main", "MainActivity"),
		LENS_GRID_MAIN("Lens Grid Settings", "com.spectralink.lensgrid.activities.GridCameraSettingsActivity"),
		BARCODE_SERVICE("Barcode Service", ".activities.BarcodeActivity"),
		SATURN_BARCODE_SERVICE("Saturn Barcode Service", "com.spectralink.barcode.service.activities.BarcodeActivity"),
		BARCODE_TEST_APP_MAIN("Barcode Status", "MainActivity"),
		WIFI_STATUS_SCREEN("WIFI Status", "wifi.WifiStatusTest"),
		PTT_MAIN("PTT Main", "com.spectralink.slnkptt.activities.PTTActivity"),
		SYS_UPDATER_MAIN("Sys Updater Main", "MainActivity"),
		SYSTEM_UPDATER_MAIN("Sys Updater Main", "com.spectralink.slnkota.MainActivity"),
		SYSUPDATER_SETTINGS_SCREEN("Sys Updater Settings", "com.spectralink.slnkota.OTAPreferenceActivity"),
		DEVICE_SETTINGS("Device Settings", "com.spectralink.slnkdevicesettings.DeviceSettingsPreferenceActivity"),
		VQO_SETTINGS("VQO Settings", "com.spectralink.slnkvqo.VQOPreferenceActivity"),
		LOGGING_SCREEN("Logging Main", "com.spectralink.slnklogger.MainActivity"),
		ADVANCED_DEBUGGING("Advanced debugging", "com.spectralink.slnklogger.SlnkLoggerAdvDebug"),
		SAM_CLIENT_MAIN("Sam Client", "com.spectralink.slnksamclient.LauncherActivity"),
		BUTTONS_MAIN("Buttons Main", "com.spectralink.buttons.activity.ButtonActivity"),
		AMIE_AGENT_DASHBOARD("AMIE Agent Main", "com.spectralink.amieagent.activities.AMIEDashboard"),
		ANDROID_CONTACTS_MAIN("Contacts Main", "com.android.providers.contacts.ContactsProvider2"),
		SSO_MAIN("Home", "com.spectralink.sso.SsoStatusActivity"),
		LAUNCHER("Home", "com.android.searchlauncher.SearchLauncher"),
		CISCO_PHONE_DIALER("Biz Phone Dialer", "com.cisco.phone.activities.Dialer");

		private final String label;
		private final String intent;

		Activity(String label, String intent) {
			this.label = label;
			this.intent = intent;
		}

		public String getLabel() {
			return label;
		}

		public String getIntent() {
			return intent;
		}
	}

	public AndroidPhone(UsbHost host, String serialNumber, String status, String path) {
		this.host = host;
		this.serialNumber = serialNumber;
		this.status = status;
		this.path = path;
		this.connectedViaAdb = false;
		this.rooted = false;
		this.inspector = new LogcatInspector(this);
	}

	public static Application findApplication(String appLabel) {
		for (Application strings : Application.values()) {
			if (strings.getLabel().toLowerCase().contentEquals(appLabel.trim().toLowerCase())) {
				return strings;
			}
		}
		return null;
	}

	public static Activity findActivity(String activityLabel) {
		for (Activity strings : Activity.values()) {
			if (strings.getLabel().toLowerCase().contentEquals(activityLabel.trim().toLowerCase())) {
				return strings;
			}
		}
		return null;
	}

	public static Health findHealth(String healthClass) {
		for (Health health : Health.values()) {
			if (health.getClassification().toLowerCase().contentEquals(healthClass.trim().toLowerCase())) {
				return health;
			}
		}
		return null;
	}

	public static Health findHealthCode(String healthCode) {
		for (Health health : Health.values()) {
			if (health.getCode().contentEquals(healthCode.trim())) {
				return health;
			}
		}
		return null;
	}

	public static Status findStatus(String statusClass) {
		for (Status status : Status.values()) {
			if (status.getClassification().toLowerCase().contentEquals(statusClass.trim().toLowerCase())) {
				return status;
			}
		}
		return null;
	}

	public static Status findStatusCode(String statusCode) {
		for (Status status : Status.values()) {
			if (status.getCode().contentEquals(statusCode.trim())) {
				return status;
			}
		}
		return null;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public Integer getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(Integer portNumber) {
		this.portNumber = portNumber;
	}

	public Integer getBootstrapPortNumber() {
		return bootstrapPortNumber;
	}

	public void setBootstrapPortNumber(Integer bootstrapPortNumber) {
		this.bootstrapPortNumber = bootstrapPortNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUsbPath() {
		return path;
	}

	public void setUsbPath(String path) {
		this.path = path;
	}

	public AccountDatabase getKeyDatabase() {
		return keyDatabase;
	}

	public void setKeyDatabase(AccountDatabase keyDatabase) {
		this.keyDatabase = keyDatabase;
	}

	public boolean isConnectedViaAdb() {
		return connectedViaAdb;
	}

	public void setConnectedViaAdb(boolean connectedViaAdb) {
		this.connectedViaAdb = connectedViaAdb;
	}

	public boolean isRooted() {
		return rooted;
	}

	public void setRooted(boolean rooted) {
		this.rooted = rooted;
	}

	public UsbHost getHost() {
		return host;
	}

	public void setHost(UsbHost host) {
		this.host = host;
	}

	public LogcatInspector logcatInspector() {
		return inspector;
	}

	public boolean propertiesLoaded() {
		return systemProperties.size() > 0;
	}

	public PhoneType getPhoneType() {
		return phoneType;
	}

	public void setPhoneType(PhoneType type) {
		this.phoneType = type;
	}

	public String getTransportId() {
		return transportId;
	}

	public void setTransportId(String transportid) {
		this.transportId = transportid;
	}

	public void loadSystemProperties() {
		systemProperties.clear();
		Pattern propPattern = Pattern.compile("^\\[(\\S+)\\]:\\s+\\[(.*)\\]");
		List<String> command = new ArrayList<>(Arrays.asList("shell", "getprop"));
		CliResult result = sendAdbCommand(command);
		if (result.getExitCode() == 0) {
			for (String line : result.getStdoutLines()) {
				Matcher propMatch = propPattern.matcher(line);
				if (line.length() > 0 && propMatch.find()) {
					systemProperties.put(propMatch.group(1), propMatch.group(2));
				}
			}
		}
	}

	public Map<String, String> getProperties() {
		if (!propertiesLoaded()) {
			loadSystemProperties();
		}
		return systemProperties;
	}

	public String getProperty(String propertyName) {
		if (!propertiesLoaded()) {
			loadSystemProperties();
		}
		if (systemProperties.containsKey(propertyName)) {
			return systemProperties.get(propertyName);
		} else {
			log.error("Requested property {} does not exist", propertyName);
			return null;
		}
	}

	public String getBuildNumber() {
		return getProperty("ro.build.version.incremental");
	}

	public String getBuildRelease() {
		return getProperty("ro.build.version.release");
	}

	public String getBuildDisplayId() {
		return getProperty("ro.build.display.id");
	}

	public String getUserAgentBuildId() {
		return getProperty("ro.build.id");
	}

	public String getVmwareName() {
		return String.join(" ", getProperty("ro.product.manufacturer"), getProperty("ro.product.model"));
	}

	public String getHardware() {
		return getProperty("ro.boot.hardware");
	}

	public String getWifiInterface() {
		return getProperty("wifi.interface");
	}

	public String getTimezone() {
		return getProperty("persist.sys.timezone");
	}

	public String getModel() {
		return getProperty("ro.product.model");
	}

	public boolean tableSettingsLoaded(String table) {
		return settings.containsKey(table) && settings.get(table).size() > 0;
	}

	public void loadSettings(String table) {
		HashMap<String, String> tableSettings = new HashMap<>();
		Pattern propPattern = Pattern.compile("name=(\\w+).*value=(.+)");
		String uri = "content://settings/" + table;
		List<String> command = new ArrayList<>(Arrays.asList("shell", "content", "query", "--uri", uri));
		CliResult results = sendAdbCommand(command);
		if (results.getExitCode() == 0) {
			for (String line : results.getStdoutLines()) {
				Matcher propMatch = propPattern.matcher(line);
				if (line.length() > 0 && propMatch.find()) {
					tableSettings.put(propMatch.group(1), propMatch.group(2).trim());
				}
			}
		}
		settings.put(table, tableSettings);
	}

	public Map<String, String> getSettings(String table) {
		if (!tableSettingsLoaded(table)) {
			loadSettings(table);
		}
		return settings.get(table);
	}

	public String getSetting(String table, String settingName) {
		if (!tableSettingsLoaded(table)) {
			loadSettings(table);
		}
		if (settings.get(table).containsKey(settingName)) {
			return settings.get(table).get(settingName);
		} else {
			log.error("Requested setting {} from table {} does not exist", settingName, table);
			return null;
		}
	}

	public JSONObject getSection(String table, String section) {
		Map<String, String> tableSettings = getSettings(table);
		JSONObject outerHash = new JSONObject();
		outerHash.put("array", new JSONArray());
		for (String name : tableSettings.keySet()) {
			if (name.matches("^" + section + ".*")) {
				JSONObject innerHash = new JSONObject();
				innerHash.put("name", name);
				innerHash.put("value", settings.get(name));
				JSONArray innerArray = (JSONArray) outerHash.get("array");
				innerArray.put(innerHash);
			}
		}
		return outerHash;
	}

	private void loadSoundFiles(String uri) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "content", "query", "--uri", uri));
		CliResult results = sendAdbCommand(command);
		String fileList = results.getStdout();
		fileList = fileList.replaceAll("(?s)title_key.*?,", "");
		if (results.getExitCode() == 0  && fileList.contains("Row")) {
			for (String soundFile : fileList.split("\n")) {
				soundFile = soundFile.substring(soundFile.indexOf("_"));
				String cleanProperties = "";
				for (String property : soundFile.split(",")) {
					if (property.indexOf("=") != -1) {
						cleanProperties += property + "\n";
					}
				}
				Properties properties = new Properties();
				StringReader reader = new StringReader(cleanProperties);
				try {
					properties.load(reader);
					if (properties.getProperty("is_alarm").contentEquals("1") || properties.getProperty("is_notification").contentEquals("1")) {
						soundFiles.put(properties.getProperty("title"), properties);
					}
				} catch (IOException ioe) {
					log.error("Failed to read phone properties: {}", ioe.getMessage());
				}
			}
		}
	}

	public Map<String, Properties> getSoundFiles() {
		if (soundFiles == null) {
			soundFiles = new HashMap<>();
			loadSoundFiles("content://media/internal/audio/media");
			loadSoundFiles("content://media/external/audio/media");
		}
		return soundFiles;
	}

	public String getServiceDump(String service) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", service));
		CliResult results = sendAdbCommand(command);
		if (results.commandSucceeded()) {
			return results.getStdout();
		} else {
			return "";
		}
	}

	public Map<String, String> getBatteryServiceDump() {
		Map<String, String> batteryValues = new HashMap<>();
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery"));
		CliResult results = sendAdbCommand(command);
		if (results.commandSucceeded()) {
			for (String line : results.getStdoutLines()) {
				String[] values = line.split(":\\s*");
				if (values.length == 2) {
					batteryValues.put(values[0].trim(), values[1].trim());
				}
			}
		} else {
			log.error("Failed to get battery service dump");
		}
		return batteryValues;
	}

	public Boolean getBatteryAcPowered() {
		Boolean acPowered;
		String stdout = getServiceDump("battery");
		final Pattern digits = Pattern.compile("AC powered:\\s+(\\w+)");
		Matcher matcher = digits.matcher(stdout);
		if (matcher.find()) {
			acPowered = Boolean.valueOf(matcher.group(1));
		} else {
			log.warn("AC power state for phone {} could not be determined", getSerialNumber());
			acPowered = false;
		}
		return acPowered;
	}

	public Boolean getBatteryUsbPowered() {
		boolean usbPowered = false;
		String foundUsbPowered = findValue("USB powered:\\s+(\\w+)", getServiceDump("battery"));
		if (foundUsbPowered != null) {
			usbPowered = Boolean.valueOf(foundUsbPowered);
		} else {
			log.warn("USB power state for phone {} could not be determined", getSerialNumber());
		}
		return usbPowered;
	}

	public int getBatteryLevel() {
		int level = -1;
		String foundLevel = findValue("level:\\s+(\\d+)", getServiceDump("battery"));
		if (foundLevel != null) {
			return Integer.valueOf(foundLevel.trim());
		} else {
			log.warn("Battery level for phone {} could not be determined", getSerialNumber());
		}
		return level;
	}

	public Integer getUptime() {
		Integer seconds = 0;
		List<String> command = new ArrayList<>(Arrays.asList("shell", "cat", "/proc/uptime"));
		CliResult results = sendAdbCommand(command);
		String[] lines = results.getStdout().split("\\s+");
		if (lines.length != 0) {
			seconds = Integer.parseInt(lines[0]);
			log.trace("Uptime for phone {} is {}", getSerialNumber(), seconds);
		} else {
			log.warn("Uptime for phone {} could not be determined", getSerialNumber());
		}
		return seconds;
	}

	public String getScreenSize() {
		String size = "unknown";
		List<String> command = new ArrayList<>(Arrays.asList("shell", "wm", "size"));
		CliResult results = sendAdbCommand(command);
		String foundSize = findValue("Physical size: (\\S+)", results.getStdout());
		if (foundSize != null) {
			size = foundSize;
			log.trace("Screen size for phone {} is {}", getSerialNumber(), size);
		} else {
			log.warn("Screen size for phone {} could not be determined", getSerialNumber());
		}
		return size;
	}

	public String getIpAddress() {
		String ipAddress = "0.0.0.0";
		String wifiInterface = getWifiInterface();
		if (wifiInterface != null && wifiInterface.matches("\\w+")) {
			List<String> command = new ArrayList<>(Arrays.asList("shell", "ip", "addr", "show", wifiInterface));
			CliResult results = sendAdbCommand(command);
			String foundIp = findValue("inet\\s+([0-9\\.]+)", results.getStdout());
			if (foundIp != null) {
				ipAddress = foundIp;
			} else {
				log.error("IP address for phone {} could not be determined", getSerialNumber());
				ipAddress = "0.0.0.0";
			}
		} else {
			log.error("Could not get interface name for phone {}", getSerialNumber());
			ipAddress = "0.0.0.0";
		}
		return ipAddress;
	}

	public String getMacAddress() {
		String macAddress = "unknown";
		String wifiInterface = getWifiInterface();
		if (wifiInterface != null && wifiInterface.matches("\\w+")) {
			List<String> command = new ArrayList<>(Arrays.asList("shell", "ip", "addr", "show", wifiInterface));
			CliResult results = sendAdbCommand(command);
			String foundMac = findValue("link/ether\\s+([a-z0-9:]+)", results.getStdout());
			if (foundMac != null) {
				macAddress = foundMac;
			} else {
				log.error("Mac address for phone {} could not be determined", getSerialNumber());
			}
		} else {
			log.error("Could not get interface name for phone {}", getSerialNumber());
		}
		return macAddress;
	}

	public CliResult pullFileFromDevice(String deviceFile, String localFile) {
		List<String> command = new ArrayList<>(Arrays.asList("pull", qquote(deviceFile), qquote(localFile)));
		return sendAdbCommand(command);
	}

	public CliResult pushFileToDevice(String localFile, String deviceFile) {
		List<String> command = new ArrayList<>(Arrays.asList("push", qquote(localFile), qquote(deviceFile)));
		return sendAdbCommand(command);
	}

	public CliResult sendAdbCommand(List<String> adbParameters) {
		ArrayList<String> command = new ArrayList<>();
		command.add("adb");
		command.add("-s");
		command.add(getSerialNumber());
		command.addAll(adbParameters);
		CliResult result = new CliResult();
		try {
			result = getHost().executeCommand(command);
		} catch (JSchException je) {
			log.error("JSchException: " + je.getMessage());
			je.printStackTrace();
			result.setExitCode(1);
			result.setStderr(je.getMessage());
		} catch (IOException ioe) {
			log.error("IOException: " + ioe.getMessage());
			ioe.printStackTrace();
			result.setExitCode(1);
			result.setStderr(ioe.getMessage());
		}

		if (result.commandFailed()) {
			log.error("ADB command failed: {}", result.getStdout());
			log.error(result.getStderr());
		}
		return result;
	}

	public CliResult sendCommand(String hostCommand) {
		ArrayList<String> command = new ArrayList<>();
		command.add(hostCommand);
		CliResult result = new CliResult();
		try {
			result = getHost().executeCommand(command);
		} catch (JSchException je) {
			log.error("JSchException: " + je.getMessage());
			je.printStackTrace();
			result.setExitCode(1);
			result.setStderr(je.getMessage());
		} catch (IOException ioe) {
			log.error("IOException: " + ioe.getMessage());
			ioe.printStackTrace();
			result.setExitCode(1);
			result.setStderr(ioe.getMessage());
		}

		if (result.commandFailed()) {
			log.error("Host command failed: {}", result.getStdout());
			log.error(result.getStderr());
		}
		return result;
	}

	public String getIdentity() {
		return Util.glue("Using device", getSerialNumber(),
				"-- a model", getModel(), "running", getBuildDisplayId());
	}

	public void rootPhone() {
		List<String> command = new ArrayList<>(Arrays.asList("root"));
		CliResult result = sendAdbCommand(command);
		if (result.commandSucceeded()) {
			command.clear();
			command.add("remount");
			sendAdbCommand(command);
			setRooted(true);
		} else {
			setRooted(false);
		}
	}

	public String getQueryResult(String query, Pattern pattern) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "content", "query", "--uri", "content://" + query));
		CliResult results = sendAdbCommand(command);
		String result = null;
		try {
			if (results.getExitCode() == 0) {
				for (String line : results.getStdoutLines()) {
					Matcher matcher = pattern.matcher(line);
					if (line.length() > 0 && matcher.find()) {
						if(missedDroppedBizPhone || missedDroppedCiscoPhone)
							result = (matcher.group(2));
						else
							result = (matcher.group(1));
					}
				}
			}
			missedDroppedBizPhone = false;
			missedDroppedCiscoPhone = false;
			return result;
		}
		catch (NullPointerException nullException) {
			nullException.printStackTrace();
			Environment.softAssert().fail("Unexpected content query result");
			return "";
		}
	}

	String getQueryResultError(String query, Pattern pattern) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "content", "query", "--uri", "content://" + query));
		CliResult results = sendAdbCommand(command);
		String result = "";
		String prev;
		int diff = 0;
		try {
			if (results.getExitCode() == 0) {
				for (String line : results.getStderrLines()) {
					log.debug("Query Error: " + line);
					Matcher matcher = pattern.matcher(line);
					if (line.length() > 0 && matcher.find()) {
						prev = result;
						result = (matcher.group(1));
						if (!prev.isEmpty()) {
							diff = Integer.parseInt(result) - Integer.parseInt(prev);
						}
						if ((diff > 1)) {
							result = prev;
						}
					}
				}
			}
			return result;
		}
		catch (NumberFormatException numberFormatException) {
			log.debug("Unable to fetch the desired result: " + numberFormatException);
			command = new ArrayList<>(Arrays.asList("shell", "content", "query", "--uri", "content://" + "com.spectralink.phone.provider/accts/0"));
			results = sendAdbCommand(command);
			if (results.getExitCode() == 0) {
				for (String line : results.getStdoutLines()) {
					log.debug("Registration Query result: " + line);
				}
			}
			command = new ArrayList<>(Arrays.asList("shell", "content", "query", "--uri", "content://" + "com.spectralink.phone.provider/calls/"));
			results = sendAdbCommand(command);
			if (results.getExitCode() == 0) {
				for (String line : results.getStdoutLines()) {
					log.debug("Call Query result: " + line);
				}
			}
			Environment.softAssert().fail("Unexpected content query result");
			return "";
		}
		catch (NullPointerException nullException) {
			nullException.printStackTrace();
			Environment.softAssert().fail("Unexpected content query result");
			return "";
		}
	}

	public String getSoftwareVersion() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "getprop", "ro.build.display.id"));
		CliResult results = sendAdbCommand(command);
		String version = results.getStdoutLines()[0].trim();
		log.trace("Version for phone {} is {}", getSerialNumber(), version);
		return version;
	}

	public boolean screenIsDark() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "nfc"));
		CliResult result = sendAdbCommand(command);
		String valueOfSetting = findValue("mScreenState=(\\w+)", result.getStdout());
		if (valueOfSetting != null) {
			return valueOfSetting.contains("OFF_");
		} else {
			return false;
		}
	}

	public boolean isLocked() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "nfc"));
		CliResult result = sendAdbCommand(command);
		String valueOfSetting = findValue("mScreenState=(\\w+)", result.getStdout());
		if (valueOfSetting != null) {
			return valueOfSetting.contains("_LOCKED");
		} else {
			return false;
		}
	}

	public boolean isUnlocked() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "nfc"));
		CliResult result = sendAdbCommand(command);
		String valueOfSetting = findValue("mScreenState=(\\w+)", result.getStdout());
		if (valueOfSetting != null) {
			return valueOfSetting.contains("_UNLOCKED");
		} else {
			return false;
		}
	}

	public void swipeScreen() {
		log.debug("Swiping screen");
		List<String> command = new ArrayList<>(Arrays.asList("shell", "input", "keyevent", "82"));
		sendAdbCommand(command);
		sleepSeconds(1);
	}

	public void typeText(String text) {
		log.debug("Typing '{}'", text);
		String quotedText = String.format("\"%s\"", text);
		List<String> command = new ArrayList<>(Arrays.asList("shell", "input", "text", quotedText));
		sendAdbCommand(command);
		sleepSeconds(1);
	}

	public void tapEnter() {
		log.debug("Tapping Enter");
		List<String> command = new ArrayList<>(Arrays.asList("shell", "input", "keyevent", "66"));
		sendAdbCommand(command);
		sleepSeconds(1);
	}

	public void unlockScreen(String pin) {
		while (screenIsDark()) {
			swipeScreen();
			sleepSeconds(1);
		}
		if (isLocked()) {
			swipeScreen();
			typeText(pin);
			tapEnter();
			log.debug("Unlocked screen of {}", getSerialNumber());
		} else {
			log.debug("Screen of {} was already unlocked", getSerialNumber());
		}
	}

	public boolean installApp(String appName) {
		List<String> command = new ArrayList<>(Arrays.asList("install", "-r", appName));
		CliResult result = sendAdbCommand(command);
		return result.getStdout().contains("Success");
	}

	public boolean installApp(File fileName) {
		List<String> command = new ArrayList<>(Arrays.asList("install", "-r", fileName.getPath()));
		CliResult result = sendAdbCommand(command);
		return result.getStdout().contains("Success");
	}

	public void uninstallApp(String packageName) {
		List<String> command = new ArrayList<>(Arrays.asList("uninstall", packageName));
		CliResult result = sendAdbCommand(command);
	}

	public void rebootPhone() {
		List<String> command = new ArrayList<>(Arrays.asList("reboot"));
		sendAdbCommand(command);
	}

	public void clearAppData(String appName) {
		String fullAppName = String.format("com.spectralink.%s");
		List<String> command = new ArrayList<>(Arrays.asList("shell", "pm", "clear", fullAppName));
		sendAdbCommand(command);
	}

	public void clearAppData(Application application) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "pm", "clear", application.getPackage()));
		sendAdbCommand(command);
	}

	public void batteryUnplug() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery", "unplug"));
		sendAdbCommand(command);
	}

	public void batteryAcPowered() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery", "set", "ac", "1"));
		sendAdbCommand(command);
	}

	public void batteryUsbPowered() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery", "set", "usb", "1"));
		sendAdbCommand(command);
	}

	public void batteryWirelessPowered() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery", "set", "wireless", "1"));
		sendAdbCommand(command);
	}

	public void pressPowerButton() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "input", "keyevent", "KEYCODE_POWER"));
		sendAdbCommand(command);
	}

	public void forceDozeMode() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "deviceidle", "force-idle"));
		sendAdbCommand(command);
	}

	public String checkDozeModeState() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "deviceidle", "get", "deep"));
		return String.valueOf(sendAdbCommand(command));
	}

	public void changeBatteryStatus(String value) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery", "set", "status", value));
		sendAdbCommand(command);
	}

	public void changeBatteryLevel(String value) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery", "set", "level", value));
		sendAdbCommand(command);
	}

	public void batteryReset() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery", "reset"));
		sendAdbCommand(command);
	}

	public String wifiState() {
		Pattern wifiState = Pattern.compile("Wi-Fi is ([^,]+)");
		String regexResult = "";
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "wifi", "|", "grep", "Wi-Fi"));
		CliResult result = sendAdbCommand(command);
		if (result.commandSucceeded()) {
			for (String appInfo : result.getStdoutLines()) {
				Matcher match = wifiState.matcher(appInfo);
				if (match.find()) {
					regexResult = match.group(1);
				}
			}
		}
		return regexResult;
	}

	public String  airplaneModeState() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "settings", "get", "global", "airplane_mode_on"));
		CliResult result  = sendAdbCommand(command);
		return result.getStdout();
	}

	public void takeScreenshot(String testLocation) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "screencap", "-p", "/sdcard/screen.png"));
		sendAdbCommand(command);
		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
		String fileName = testLocation + "-screenshot-" + formatter.format(today) + ".png";
		Path tempScreenshotPath = Paths.get("/tmp",fileName);
		Path finalScreenshotPath = Paths.get(Environment.getProjectDirectory(), "log" ,fileName);
		command = new ArrayList<>(Arrays.asList("pull", "/sdcard/screen.png", tempScreenshotPath.toString()));
		sendAdbCommand(command);
		try {
			Files.copy(tempScreenshotPath, finalScreenshotPath);
			log.debug("Screenshot '{}' was created", finalScreenshotPath);
			sendCommand("rm -f " + tempScreenshotPath);
		} catch (IOException ioe) {
			log.error("Could not copy screenshot {} to {}: {}", tempScreenshotPath, finalScreenshotPath, ioe.getMessage());
		}
	}

	public Map<String, String> getInstalledPackages() {
		Map<String, String> packages = new HashMap<>();
		Pattern packageLine = Pattern.compile("package:/(\\S+)/(\\S+)/(\\S+)/(\\S+)");
		List<String> command = new ArrayList<>(Arrays.asList("shell", "pm", "list", "packages", "-f"));
		CliResult result = sendAdbCommand(command);
		if (result.commandSucceeded()) {
			for (String appInfo : result.getStdoutLines()) {
				Matcher packageInfo = packageLine.matcher(appInfo);
				if (packageInfo.find()) {
					String[] fullPackage = packageInfo.group(4).split("=");
					packages.put(packageInfo.group(3), fullPackage[1]);
				}
			}
		}
		return packages;
	}

	public String getForegroundPackage() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "window", "windows"));
		CliResult result = sendAdbCommand(command);
		String valueOfSetting = findValue("mCurrentFocus=Window\\{\\S+\\s\\S+\\s(\\S+)\\}", result.getStdout());
		if (valueOfSetting != null) {
			String[] appPackage = valueOfSetting.split("/");
			return appPackage[0];
		}
		return null;
	}

	public String getForegroundActivity() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "window", "windows"));
		CliResult result = sendAdbCommand(command);
		String valueOfSetting = findValue("mCurrentFocus=Window\\{\\S+\\s\\S+\\s(\\S+)\\}", result.getStdout());
		if (valueOfSetting != null) {
			String[] appPackage = valueOfSetting.split("/");
			return appPackage[1];
		}
		return null;
	}

	public String batteryStats(String value) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "battery"));
		CliResult result = sendAdbCommand(command);
		return findValue(value + ":\\s+(\\S+)", result.getStdout());
	}

	public String batteryProperties(String value) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "batteryproperties"));
		CliResult result = sendAdbCommand(command);
		return findValue(value + ":\\s+(\\S+)", result.getStdout());
	}

	public String phoneIp() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "ip", "addr", "show", "wlan0"));
		CliResult result = sendAdbCommand(command);
		return findValue("inet\\s+([0-9\\.]+)", result.getStdout());
	}

	public String cellularIp() {
		String[] interfaces = new String[]{"rmnet_data1", "v4-rmnet_data1"};
		for (String eachInterface : interfaces) {
			List<String> command = new ArrayList<>(Arrays.asList("shell", "ip", "addr", "show", eachInterface));
			CliResult result = sendAdbCommand(command);
			String ip = findValue("inet\\s+([0-9\\.]+)", result.getStdout());
			if (ip != null) return ip;
		}
		return null;
	}

	public Boolean isSimPresent() {
		return getProperty("gsm.sim.state").equals("READY");
	}

	public String getCellularIp() {
		if(!isWifiOnly()) {
			String ipAddress = "";
			if (isSimPresent()) {
				List<String> command = new ArrayList<>(Arrays.asList("shell", "ip", "addr", "show", "v4-rmnet_data2"));
				CliResult result = sendAdbCommand(command);
				String ip = findValue("inet\\s+([0-9\\.]+)", result.getStdout());
				if (ip != null)
					ipAddress = ip;
			} else {
				List<String> command = new ArrayList<>(Arrays.asList("shell", "ip", "addr", "show", "rmnet_data2"));
				CliResult result = sendAdbCommand(command);
				String ip = findValue("inet\\s+([0-9\\.]+)", result.getStdout());
				if (ip != null)
					ipAddress = ip;
			}
			return ipAddress;
		}
		else
			return "";
	}

	public String appLoadId() {
		return getBuildRelease().concat(".").concat(getBuildNumber());
	}

	public String bootRom() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "getprop", "ro.boot.bootloader"));
		CliResult result = sendAdbCommand(command);
		return result.getStdout();
	}

	public String currentDateTimeForWebApi() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "date", "+\"%Y-%m-%dT%H:%M\""));
		CliResult result = sendAdbCommand(command);
		return result.getStdout();
	}

	public String currentDateTimeFormatForNtpValidation() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "date", "+%H:%M"));
		CliResult result = sendAdbCommand(command);
		return result.getStdout();
	}

	public String crashApp(String appName) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "am", "crash", appName));
		CliResult result = sendAdbCommand(command);
		return result.getStdout();
	}

	public Boolean appPresentOnPhone(String appName) {
		Map<String, String> apps = getInstalledPackages();
		return apps.keySet().contains(appName);
	}

	public Boolean packagePresentOnPhone(String packageName) {
		Map<String, String> apps = getInstalledPackages();
		return apps.values().contains(packageName);
	}

	public void tapOnScreen(Integer xValue, Integer yValue) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "input", "tap", xValue.toString(), yValue.toString()));
		sendAdbCommand(command);
	}

	public void rapidTapOnScreen(Integer xValue, Integer yValue) {
		List<List<String>> matrix = new ArrayList<>();
		matrix.add(new ArrayList<>(Arrays.asList("1", "330", "1")));
		matrix.add(new ArrayList<>(Arrays.asList("1", "325", "1")));
		matrix.add(new ArrayList<>(Arrays.asList("3", "53", xValue.toString())));
		matrix.add(new ArrayList<>(Arrays.asList("3", "54", yValue.toString())));
		matrix.add(new ArrayList<>(Arrays.asList("3", "49", "3")));
		matrix.add(new ArrayList<>(Arrays.asList("0", "0", "0")));
		matrix.add(new ArrayList<>(Arrays.asList("1", "330", "0")));
		matrix.add(new ArrayList<>(Arrays.asList("1", "325", "0")));
		matrix.add(new ArrayList<>(Arrays.asList("0", "0", "0")));
		for (List<String> events : matrix) {
			List<String> command = new ArrayList<>(Arrays.asList("shell", "sendevent", "/dev/input/event1", events.get(0), events.get(1), events.get(2)));
			sendAdbCommand(command);
		}
	}

	public String findValue(String regex, String searchString) {
		Pattern digits = Pattern.compile(regex);
		Matcher matcher = digits.matcher(searchString);
		if (regex.contains("(") && regex.contains(")")) {
			if (matcher.find()) {
				return matcher.group(1);
			}
		} else {
			log.error("No group defined in regex");
		}
		return null;
	}

	public void removeLeftoverVideosFromPhone() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "rm", "-rf", "/sdcard/*.mp4"));
		sendAdbCommand(command);
	}

	public boolean ifWifiOn() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "wifi", "|", "grep", "\"Wi-Fi is\""));
		CliResult result = sendAdbCommand(command);
		return result.getStdout().contains("enabled");
	}

	public void toggleWifiAppiumSettings(Boolean value) {
		if(value)
			sendAdbCommand(new ArrayList<>(Arrays.asList("shell", "am", "broadcast", "-a", "io.appium.settings.wifi", "--es", "setstatus", "enable")));
		else
			sendAdbCommand(new ArrayList<>(Arrays.asList("shell", "am", "broadcast", "-a", "io.appium.settings.wifi", "--es", "setstatus", "disable")));
	}

	public void toggleWifiSvc(Boolean value) {
		if(value)
			sendAdbCommand(new ArrayList<>(Arrays.asList("shell", "svc", "wifi", "enable")));
		else
			sendAdbCommand(new ArrayList<>(Arrays.asList("shell", "svc", "wifi", "disable")));
	}

	public void toggleBluetooth(Boolean value) {
		if(value)
			sendAdbCommand(new ArrayList<>(Arrays.asList("shell", "am", "broadcast", "-a", "io.appium.settings.bluetooth", "--es", "setstatus", "enable")));
		else
			sendAdbCommand(new ArrayList<>(Arrays.asList("shell", "am", "broadcast", "-a", "io.appium.settings.bluetooth", "--es", "setstatus", "disable")));
	}

	public void toggleData(Boolean value) {
		if(value)
			sendAdbCommand(new ArrayList<>(Arrays.asList("shell", "am", "broadcast", "-a", "io.appium.settings.data_connection", "--es", "setstatus", "enable")));
		else
			sendAdbCommand(new ArrayList<>(Arrays.asList("shell", "am", "broadcast", "-a", "io.appium.settings.data_connection", "--es", "setstatus", "disable")));
	}

	public Boolean isLte() {
		return getModel().toLowerCase().contains("9640") || getModel().toLowerCase().contains("9653");
	}
	public Boolean isWifiOnly() {
		return getModel().toLowerCase().contains("9540") || getModel().toLowerCase().contains("9553");
	}

	public void wakeUpScreen() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "input", "keyevent", "26"));
		sendAdbCommand(command);
	}

	public void startApp(String appName) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "am", "start", "-a", "\"" + appName + "\""));
		sendAdbCommand(command);
	}

	public void forceStopApp(String appName) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "am", "force-stop", "\"" + appName + "\""));
		sendAdbCommand(command);
	}

	public void grantLanguageChangePermission() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "pm", "grant", "net.sanapeli.adbchangelanguage", "android.permission.CHANGE_CONFIGURATION"));
		sendAdbCommand(command);
	}

	public void changeLanguage(String languageCode) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "am", "start", "-n", "net.sanapeli.adbchangelanguage/.AdbChangeLanguage", "-e", "language", "\"" + languageCode + "\""));
		sendAdbCommand(command);
	}

	public String getAppProcessId(Application application) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "pidof", "-s", "\"" + application.getPackage() + "\""));
		CliResult result = sendAdbCommand(command);
		log.debug("Process id of: " + application.getPackage() + ": is: " + result.getStdout());
		return result.getStdout();
	}

	public String getAppCpuUsage(Application application) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "ps", "-p", "\"" + getAppProcessId(application) + "\"", "-o", "%cpu"));
		CliResult tempResult = sendAdbCommand(command);
		String[] split = tempResult.getStdout().split("\\s+");
		String actualResult = split[1];
		log.debug("Cpu usage of: " + application.getPackage() + ": is: " + actualResult);
		return actualResult;
	}

	public String getAppMemoryUsage(Application application) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "ps", "-p", "\"" + getAppProcessId(application) + "\"", "-o", "%mem"));
		CliResult tempResult = sendAdbCommand(command);
		String[] split = tempResult.getStdout().split("\\s+");
		String actualResult = split[1];
		log.debug("Memory usage of: " + application.getPackage() + ": is: " + actualResult);
		return actualResult;
	}

	public void tapButton(String keycode) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "input", "keyevent", "\"" + keycode + "\""));
		sendAdbCommand(command);
		sleepSeconds(1);
	}

	public String getRingVolume() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "settings", "get", "system", "volume_ring_speaker"));
		CliResult result = sendAdbCommand(command);
		return result.getStdout();
	}

	public String getMediaVolume() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "settings", "get", "system", "volume_music_speaker"));
		CliResult result = sendAdbCommand(command);
		return result.getStdout();
	}

	public String getAlarmVolume() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "settings", "get", "system", "volume_alarm_speaker"));
		CliResult result = sendAdbCommand(command);
		return result.getStdout();
	}

	public void longPress(String intent) {
		List<String> command = new ArrayList<>(Arrays.asList("shell",
				"am", "broadcast", "-a" ,"com.apollo.intent.action." + intent + "", "--es" ,"android.intent.extra.TEXT", "\"keypress\"",
				"&&", "am", "broadcast", "-a" ,"com.apollo.intent.action." + intent + "", "--es" ,"android.intent.extra.TEXT", "\"longpress\"",
				"&&", "am", "broadcast", "-a" ,"com.apollo.intent.action." + intent + "", "--es" ,"android.intent.extra.TEXT", "\"keyrelease\""
		));
		sendAdbCommand(command);
	}

	public void longPressKey(String key) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "input", "keyevent", "--longpress", "\"" + key + "\""));
		sendAdbCommand(command);
		sleepSeconds(1);
	}

	public void clearLogcat() {
		List<String> command = new ArrayList<>(Arrays.asList("logcat", "-c"));
		sendAdbCommand(command);
	}

	public boolean parseLogsForString(String targetString) {
		boolean found = false;
		List<String> command = new ArrayList<>(Arrays.asList("logcat", "-d"));
		CliResult result = sendAdbCommand(command);
		File logFile = Paths.get(Environment.getProjectDirectory(), "src/test/resources/test_data/" + getSerialNumber() + "Logs.txt").toFile();
		result.writeFile(logFile);
		for (String line : result.getStdoutLines()){
			if(line.contains(targetString)) {
				found = true;
				break;
			}
		}
		return found;
	}

	public String getAppInfo(String appPackage) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "pm", "list", "packages", "-f", "\"" + appPackage + "\""));
		CliResult result = sendAdbCommand(command);
		return result.getStdout();
	}

	public void turnOffAutoSuggest() {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "settings", "put", "secure", "autofill_service", "null"));
		sendAdbCommand(command);
		sleepSeconds(1);
	}

	public boolean isWhitelisted(String appPackage) {
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "deviceidle", "|", "grep", "\"" + appPackage + "\""));
		CliResult result = sendAdbCommand(command);
		if (result.commandSucceeded()) {
			return result.getStdout().equals(appPackage);
		}
		else
			return false;
	}

}