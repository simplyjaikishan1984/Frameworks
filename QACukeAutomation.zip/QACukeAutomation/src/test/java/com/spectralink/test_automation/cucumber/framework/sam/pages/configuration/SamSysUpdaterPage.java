package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.SysUpdaterStrings.*;

public class SamSysUpdaterPage extends SamConfigurationPage {

	@FindBy(id = "enableOTA")
	private WebElement triggerOtaButton;

	public ConfigPageField triggerOtaField = new ConfigPageField(
			TRIGGER_VALUE,
			triggerOtaButton,
			null,
			null
	);

	@FindBy(id = "ota_auto_reboot")
	private WebElement forceRebootLabel;

	@FindBy(id = "auto_reboot_ota")
	private WebElement forceRebootCheckbox;

	@FindBy(id = "delete_setting_otaAutoReboot")
	private WebElement forceRebootDelete;

	@FindBy(id = "edit_setting_otaAutoReboot")
	private WebElement forceRebootEdit;

	@FindBy(id = "undo_setting_otaAutoReboot")
	private WebElement forceRebootUndo;

	public ConfigPageField forceRebootField = new ConfigPageField(
			FORCE_REBOOT,
			forceRebootLabel,
			forceRebootCheckbox,
			forceRebootDelete,
			forceRebootEdit,
			forceRebootUndo
	);

	@FindBy(id = "allow_metered_network")
	private WebElement otaOverMeteredNetworkLabel;

	@FindBy(id = "allow_on_metered_network")
	private WebElement otaOverMeteredNetworkCheckbox;

	@FindBy(id = "delete_setting_allowOnMeteredNetwork")
	private WebElement otaOverMeteredNetworkDelete;

	@FindBy(id = "edit_setting_allowOnMeteredNetwork")
	private WebElement otaOverMeteredNetworkEdit;

	@FindBy(id = "undo_setting_allowOnMeteredNetwork")
	private WebElement otaOverMeteredNetworkUndo;

	public ConfigPageField otaOverMeteredNetworkField = new ConfigPageField(
			OTA_OVER_METERED,
			otaOverMeteredNetworkLabel,
			otaOverMeteredNetworkCheckbox,
			otaOverMeteredNetworkDelete,
			otaOverMeteredNetworkEdit,
			otaOverMeteredNetworkUndo
	);

	@FindBy(id = "otaServername")
	private WebElement otaServerAddressTextbox;

	@FindBy(id = "delete_setting_otaServername")
	private WebElement otaServerAddressDelete;

	@FindBy(id = "edit_setting_otaServername")
	private WebElement otaServerAddressEdit;

	@FindBy(id = "undo_setting_otaServername")
	private WebElement otaServerAddressUndo;

	public ConfigPageField otaServerAddressField = new ConfigPageField(
			SERVER_ADDRESS,
			null,
			otaServerAddressTextbox,
			otaServerAddressDelete,
			otaServerAddressEdit,
			otaServerAddressUndo
	);

	@FindBy(id = "otaServerport")
	private WebElement otaServerPortTextbox;

	@FindBy(id = "delete_setting_otaServerport")
	private WebElement otaServerPortDelete;

	@FindBy(id = "edit_setting_otaServerport")
	private WebElement otaServerPortEdit;

	@FindBy(id = "undo_setting_otaServerport")
	private WebElement otaServerPortUndo;

	public ConfigPageField otaServerPortField = new ConfigPageField(
			SERVER_PORT,
			null,
			otaServerPortTextbox,
			otaServerPortDelete,
			otaServerPortEdit,
			otaServerPortUndo
	);

	@FindBy(id = "otaRelpath")
	private WebElement relativePathTextbox;

	@FindBy(id = "delete_setting_otaRelpath")
	private WebElement relativePathDelete;

	@FindBy(id = "edit_setting_otaRelpath")
	private WebElement relativePathEdit;

	@FindBy(id = "undo_setting_otaRelpath")
	private WebElement relativePathUndo;

	public ConfigPageField relativePathField = new ConfigPageField(
			OTA_PATH,
			null,
			relativePathTextbox,
			relativePathDelete,
			relativePathEdit,
			relativePathUndo
	);

	@FindBy(id = "otaTransport")
	private WebElement updateTransportMenu;

	@FindBy(id = "delete_setting_otaTransport")
	private WebElement updateTransportDelete;

	@FindBy(id = "edit_setting_otaTransport")
	private WebElement updateTransportEdit;

	@FindBy(id = "undo_setting_otaTransport")
	private WebElement updateTransportUndo;

	public ConfigPageField updateTransportField = new ConfigPageField(
			TRANSPORT_PROTOCOL,
			null,
			updateTransportMenu,
			updateTransportDelete,
			updateTransportEdit,
			updateTransportUndo
	);

	@FindBy(id = "otaCheckfrequency")
	private WebElement checkFrequencyMenu;

	@FindBy(id = "delete_setting_otaCheckfrequency")
	private WebElement checkFrequencyDelete;

	@FindBy(id = "edit_setting_otaCheckfrequency")
	private WebElement checkFrequencyEdit;

	@FindBy(id = "undo_setting_otaCheckfrequency")
	private WebElement checkFrequencyUndo;

	public ConfigPageField checkFrequencyField = new ConfigPageField(
			POLLING_INTERVAL,
			null,
			checkFrequencyMenu,
			checkFrequencyDelete,
			checkFrequencyEdit,
			checkFrequencyUndo
	);

	@FindBy(id = "ota-revert-last-upgrade-password")
	private WebElement revertLastUpgradeTextbox;

	@FindBy(id = "delete_setting_otaRevertLastUpgradePassword")
	private WebElement revertLastUpgradeDelete;

	@FindBy(id = "edit_setting_otaRevertLastUpgradePassword")
	private WebElement revertLastUpgradeEdit;

	@FindBy(id = "undo_setting_otaRevertLastUpgradePassword")
	private WebElement revertLastUpgradeUndo;

	public ConfigPageField revertLastUpgradeField = new ConfigPageField(
			REVERT_PASSWORD,
			null,
			revertLastUpgradeTextbox,
			revertLastUpgradeDelete,
			revertLastUpgradeEdit,
			revertLastUpgradeUndo
	);

	@FindBy(id = "show-password-checkbox-label")
	private WebElement showPasswordLabel;

	@FindBy(id = "show-ota-password-checkbox")
	private WebElement showPasswordCheckbox;

	public ConfigPageField showPasswordField = new ConfigPageField(
			SHOW_PASSWORD,
			showPasswordLabel,
			showPasswordCheckbox,
			null,
			null
	);

	public SamSysUpdaterPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(triggerOtaField.getTitle(), triggerOtaField);
				put(forceRebootField.getTitle(), forceRebootField);
				put(otaOverMeteredNetworkField.getTitle(), otaOverMeteredNetworkField);
				put(otaServerAddressField.getTitle(), otaServerAddressField);
				put(otaServerPortField.getTitle(), otaServerPortField);
				put(relativePathField.getTitle(), relativePathField);
				put(updateTransportField.getTitle(), updateTransportField);
				put(checkFrequencyField.getTitle(), checkFrequencyField);
				put(revertLastUpgradeField.getTitle(), revertLastUpgradeField);
				put(showPasswordField.getTitle(), showPasswordField);
			}
		};
	}
}
