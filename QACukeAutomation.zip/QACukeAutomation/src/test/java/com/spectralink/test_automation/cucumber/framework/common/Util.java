package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.commons.lang3.ClassUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.ITestContext;

import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

public class Util {
	private static final Logger log = LogManager.getLogger(Util.class.getName());
	private static ITestContext savedContext;
	private static Random random = new Random();
	public static String text;
	public static String LogFileDirectory = null;
	private static String videoDirectory = null;

	// executeNoWait runs a single process in the background
	public static Process executeNoWait(String[] args) {
		try {
			return Runtime.getRuntime().exec(args);
		} catch (IOException e) {
			throw new RuntimeException("IOExeption trying to run: " + args);
		}
	}

	// executeShellNoWait runs a command through /bin/sh, in the background
	public static Process executeShellNoWait(String cmd) {
		log.trace("executeShellNoWait: " + cmd);
		return executeNoWait(new String[]{"/bin/sh", "-c", cmd});
	}

	// this one executes a command through /bin/sh, and collects the output
	public static List<String> executeCommand(String cmd) {
		List<String> results = new ArrayList<String>();
		Process process;
		try {
			process = executeShellNoWait(cmd);
			BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line = null;

			while ((line = in.readLine()) != null)
				results.add(line);

			process.waitFor();


		} catch (IOException e) {
			throw new RuntimeException("Failed to execute command: " + cmd);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		log.trace("execute " + cmd + " return status, results=" + results);
		return results;
	}

	public static List<String> executeRemoteCommand(String cmd) {
		List<String> results = new ArrayList<String>();
		Process process;
		try {
			process = executeShellNoWait(cmd);
			BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line = null;

			while ((line = in.readLine()) != null)
				results.add(line);

			process.waitFor();


		} catch (IOException e) {
			throw new RuntimeException("Failed to execute command: " + cmd);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

		log.debug("execute " + cmd + " return status, results=" + results);
		return results;
	}

	public static void sleep(Integer ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public static void sleepSeconds(Integer seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	@Deprecated
	public static String getLogDirectory() {
		if (LogFileDirectory == null) {
			log.debug("Tried to use saved context but none has been saved;  saving to adhoc/");
			LogFileDirectory = "adhoc/";
			// create it in case it isn't there
			executeCommand("mkdir -p " + LogFileDirectory);
			Util.executeCommand("rm -rf \"" + LogFileDirectory + "\"*");
		}
		return LogFileDirectory;
	}

	public static String getVideoDirectory() {
		if (videoDirectory == null) {
			videoDirectory = "videos/";
			// create it in case it isn't there
			executeCommand("mkdir -p " + videoDirectory);
			Util.executeCommand("rm -rf \"" + videoDirectory + "\"*");
		}
		return videoDirectory;
	}

	public static URL getResourceURL(String relPath) {
		ClassLoader classLoader = Util.class.getClassLoader();
		return classLoader.getResource(relPath);
	}

	public static String getResourceFilename(String relPath) {
		ClassLoader classLoader = Util.class.getClassLoader();
		return classLoader.getResource(relPath).getPath();
	}

	public static File getResourceFile(String path) {
		ClassLoader classLoader = Util.class.getClassLoader();
		return new File(getResourceURL(path).getFile());
	}

	public static String getFileToString(File textFile) {
		try {
			return Files.lines(textFile.toPath()).collect(Collectors.joining("\n"));
		} catch (IOException ioe) {
			log.error(glue("Could not open", textFile.getName(), "for reading:", ioe.getMessage()));
		}
		return null;
	}

	public static void dumpParallel(List<String> list1, List<String> list2) {
		for (int i = 0; i < Math.max(list1.size(), list2.size()); i++) {
			String field1;
			String field2;
			if (i < list1.size())
				field1 = list1.get(i);
			else
				field1 = "";

			if (i < list2.size())
				field2 = list2.get(i);
			else
				field2 = "";
			log.debug(String.format("%-50s %-60s", field1, field2));
		}
	}

	public static String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US);
		String formatedDate = sdf.format(new java.sql.Date(System.currentTimeMillis()));
		return formatedDate;
	}


	public static InetAddress getCurrentIp() {
		try {
			Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
			while (networkInterfaces.hasMoreElements()) {
				NetworkInterface ni = networkInterfaces.nextElement();
				Enumeration<InetAddress> nias = ni.getInetAddresses();
				while (nias.hasMoreElements()) {
					InetAddress ia = nias.nextElement();
					if (!ia.isLinkLocalAddress()
							&& !ia.isLoopbackAddress()
							&& ia instanceof Inet4Address
							&& !ia.getHostAddress().contains("192.168.")) {
						log.debug("getCurrentIP() is returning test host IP address of " + ia.toString());
						return ia;
					}
				}
			}
		} catch (SocketException e) {
			log.error("unable to get current IP " + e.getMessage());
		}
		return null;
	}


	public static String generateMacFromSerial(int serialNum) {
		String macOui = "00:90:7a:";//first 3 bytes
		String macNicPad = "";
		String macNic = "";//last 3 bytes
		String mac = "";//full MAC address
		int macLen = 0;

		int numOfZeros;

		int i = 0;

		macNic = Integer.toHexString(serialNum);
		macLen = macNic.length();
		numOfZeros = 6 - macLen;

		//pad the NIC portion of the MAC with 0s
		i = 0;
		do {
			macNicPad = macNicPad + "0";
			i++;
		} while (i < numOfZeros);

		macNic = macNicPad + macNic;
		macNic = macNic.replaceAll("(..)(?!$)", "$1:");//insert colons

		mac = macOui + macNic;

		return mac;
	}

	public static String formatSerialNumber(int serialNum) {
		return String.format("%09d", serialNum);
	}

	public static byte[] textToNumericIp(String ipAddress) {
		String[] address = ipAddress.split("\\.", 4 + 1);
		if (address.length != 4) return null;
		byte[] bytes = new byte[4];
		try {
			for (int index = 0; index < bytes.length; index++) {
				int octet = Integer.parseInt(address[index]);
				bytes[index] = (byte) octet;
			}
		} catch (NumberFormatException ex) {
			return null;
		}
		return bytes;
	}

	public static String random() {
		int minimum = 4;
		int randomLength = random.nextInt((80 - minimum) + 1) + minimum;
		StringBuilder builder = new StringBuilder();
		for (int index = 0; index < randomLength; index++) {
			int ascii;
			do {
				ascii = random.nextInt(93 + 1) + 33;
			} while (ascii == 39); // knock out single quote since xpath can't escape them
			builder.append((char) ascii);
		}
		return builder.toString();
	}

	public static String random(int length) {
		StringBuilder builder = new StringBuilder();
		for (int index = 0; index < length; index++) {
			int ascii;
			do {
				ascii = random.nextInt(93 + 1) + 33;
			} while (ascii == 39); // knock out single quote since xpath can't escape them
			builder.append((char) ascii);
		}
		return builder.toString();
	}

	public static String randomWithSpaces(int length) {
		StringBuilder builder = new StringBuilder();
		int ascii;
		int blocking = random.nextInt(6) + 2;
		while (builder.length() < length) {
			if (blocking < 1) {
				blocking = random.nextInt(6) + 2;
				ascii = 32;
			} else {
				do {
					ascii = random.nextInt(93 + 1) + 33;
				} while (ascii == 39); // knock out single quote since xpath can't escape them
			}
			builder.append((char) ascii);
			blocking -= 1;
		}
		return builder.toString();
	}

	public static int getRandomNumber(int lowBound, int highBound) {
		return random.nextInt((highBound - lowBound) + 1) + lowBound;
	}

	public static String random(int maximumLength, int minimumLength) {
		int randomLength = random.nextInt((maximumLength - minimumLength) + 1) + minimumLength;
		StringBuilder builder = new StringBuilder();
		for (int index = 0; index < randomLength; index++) {
			int ascii;
			do {
				ascii = random.nextInt(93 + 1) + 33;
			} while (ascii == 39); // knock out single quote since xpath can't escape them
			builder.append((char) ascii);
		}
		return builder.toString();
	}

	public static String reverse(String rawString) {
		StringBuilder builder = new StringBuilder(rawString);
		return builder.reverse().toString();
	}

	public static String shift(String rawString) {
		if (rawString.length() > 1) {
			StringBuilder builder = new StringBuilder(rawString);
			int lastCharacter = builder.length() - 1;
			char roller = builder.charAt(lastCharacter);
			builder.deleteCharAt(lastCharacter);
			builder.insert(0, roller);
			return builder.toString();
		} else {
			return rawString;
		}
	}

	public static String unshift(String rawString) {
		if (rawString.length() > 1) {
			StringBuilder builder = new StringBuilder(rawString);
			int firstCharacter = 0;
			char roller = builder.charAt(firstCharacter);
			builder.deleteCharAt(firstCharacter);
			builder.append(roller);
			return builder.toString();
		} else {
			return rawString;
		}
	}

	public static String getRandomHex(int count) {
		char[] universe = "0123456789abcdef".toCharArray();
		String result = "";
		while (count > 0) {
			result += universe[random.nextInt(universe.length)];
			count -= 1;
		}
		return result;
	}

	public static String getRandomChars(int count) {
		char[] universe = "abcdefghijklmnopqrstuvwxyz".toCharArray();
		String result = "";
		while (count > 0) {
			result += universe[random.nextInt(universe.length)];
			count -= 1;
		}
		return result;
	}

	public static String getRandomDecimals(int count) {
		char[] universe = "0123456789".toCharArray();
		String result = "";
		while (count > 0) {
			result += universe[random.nextInt(universe.length)];
			count -= 1;
		}
		return result;
	}

	public static String glue(Object ... chunks) {
		if (chunks.length == 0) {
			return null;
		} else if (chunks.length > 1) {
			StringBuilder builder = new StringBuilder();
			for (int index = 0; index < chunks.length; index++) {
				if (chunks[index] != null) {
					if (index == 0) {
						if (ClassUtils.isPrimitiveWrapper(chunks[index].getClass()))
							builder.append(chunks[index].toString());
						else
							builder.append(chunks[index]);
					} else {
						if (ClassUtils.isPrimitiveWrapper(chunks[index].getClass()))
							builder.append(" " + chunks[index].toString());
						else
							builder.append(" " + chunks[index]);
					}
				}
			}
			return builder.toString();
		} else {
			if (ClassUtils.isPrimitiveWrapper(chunks[0].getClass()))
				return " " + chunks[0].toString();
			else
				return " " + chunks[0];
		}
	}

	public static String quote(Object ... chunks) {
		if (chunks.length == 0) {
			return null;
		} else if (chunks.length > 1) {
			StringBuilder builder = new StringBuilder();
			builder.append("'");
			for (int index = 0; index < chunks.length; index++) {
				if (index == 0) {
					if (ClassUtils.isPrimitiveWrapper(chunks[index].getClass()))
						builder.append(chunks[index].toString());
					else
						builder.append(chunks[index]);
				} else {
					if (ClassUtils.isPrimitiveWrapper(chunks[index].getClass()))
						builder.append(" " + chunks[index].toString());
					else
						builder.append(" " + chunks[index]);
				}
			}
			builder.append("'");
			return builder.toString();
		} else {
			if (ClassUtils.isPrimitiveWrapper(chunks[0].getClass()))
				return "'" + chunks[0].toString() + "'";
			else
				return "'" + chunks[0] + "'";
		}
	}

	public static String qquote(Object ... chunks) {
		if (chunks.length == 0) {
			return null;
		} else if (chunks.length > 1) {
			StringBuilder builder = new StringBuilder();
			builder.append("\"");
			for (int index = 0; index < chunks.length; index++) {
				if (index == 0) {
					if (ClassUtils.isPrimitiveWrapper(chunks[index].getClass()))
						builder.append(chunks[index].toString());
					else
						builder.append(chunks[index]);
				} else {
					if (ClassUtils.isPrimitiveWrapper(chunks[index].getClass()))
						builder.append(" " + chunks[index].toString());
					else
						builder.append(" " + chunks[index]);
				}
			}
			builder.append("\"");
			return builder.toString();
		} else {
			if (ClassUtils.isPrimitiveWrapper(chunks[0].getClass()))
				return "\"" + chunks[0].toString() + "\"";
			else
				return "\"" + chunks[0] + "\"";
		}
	}

	public static String scatter(String rawString, int length) {
		if (rawString.length() > 1) {
			int randomLength = length;
			if (length <= 0) {
				randomLength = random.nextInt(rawString.length());
			}
			StringBuilder builder = new StringBuilder();
			for (int index = 0; index < randomLength; index++) {
				int randomCharacter = random.nextInt(rawString.length());
				builder.append(rawString.charAt(randomCharacter));
			}
			return builder.toString();
		} else {
			return rawString;
		}
	}

	public static String getPrettyDuration(Duration duration) { // only intended for durations less than 1 hour
		long seconds = duration.getSeconds();
		if (seconds > 59) {
			return String.format("%d minutes %d seconds", (seconds / 60), (seconds % 60));
		} else {
			return String.format("%d seconds", seconds);
		}
	}

	public static String getNightlyApps(String appName, Boolean cisco) {
		String appVersionOfInterest = "";
		String interimAppVersion = "";
		File dir = new File(System.getProperty("user.dir"));
		FilenameFilter filter;

		if(cisco)
			filter = (dir1, name) -> (name.startsWith(appName) && name.contains("spp"));

		else
			filter = (dir1, name) -> (name.startsWith(appName) && !name.contains("spp"));

		String[] allAppVersions = dir.list(filter);
		if (allAppVersions == null) {
			log.error("Couldn't find apk for {} to install", appName);
		} else {
			for (String allVersions : allAppVersions) {
				interimAppVersion = appVersionOfInterest;
				appVersionOfInterest = allVersions;
			}
		}
		if(appVersionOfInterest.compareTo(interimAppVersion) < 0) {
			appVersionOfInterest = interimAppVersion;
		}
		return appVersionOfInterest;
	}

	public static boolean isWindows() {
		return System.getProperty("os.name").toLowerCase().contains("win");
	}

	public static boolean isLinux() {
		return System.getProperty("os.name").toLowerCase().contains("nux");
	}
}
