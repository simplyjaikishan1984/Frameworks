package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamAmieAgentPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.AMIE_AGENT;

public class SamAmieAgentSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I check the \"([^\"]*)\" AMiE Agent field$")
	public void checkAmieAgentCheckbox(String arg1) {
		SamAmieAgentPage amiePage = (SamAmieAgentPage) Environment.getCurrentPage();
		if (amiePage.getField(arg1.trim()) != null) {
			amiePage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}

	@When("^I uncheck the \"([^\"]*)\" AMiE Agent field$")
	public void uncheckAmieAgentCheckbox(String arg1) {
		SamAmieAgentPage amiePage = (SamAmieAgentPage) Environment.getCurrentPage();
		if (amiePage.getField(arg1.trim()) != null) {
			amiePage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" AMiE Agent field$")
	public void selectAmieAgentMenuOption(String arg1, String arg2) {
		SamAmieAgentPage amiePage = (SamAmieAgentPage) Environment.getCurrentPage();
		if (amiePage.getField(arg2) != null) {
			amiePage.getField(arg2).updateMenuByLabel(arg1);
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" AMiE Agent field$")
	public void enterAmieAgentText(String arg1, String arg2) {
		SamAmieAgentPage amiePage = (SamAmieAgentPage) Environment.getCurrentPage();
		if (amiePage.getField(arg2.trim()) != null) {
			amiePage.getField(arg2.trim()).updateTextbox(arg1.trim());
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}

	@When("^I delete the \"([^\"]*)\" AMiE Agent field$")
	public void deleteAmieAgentSetting(String arg1) {
		SamAmieAgentPage amiePage = (SamAmieAgentPage) Environment.getCurrentPage();
		if (amiePage.getField(arg1.trim()) != null) {
			amiePage.getField(arg1.trim()).delete();
		} else {
			log.error("No matching field with label '{}'", arg1);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}

	@When("^I undo the \"([^\"]*)\" AMiE Agent field$")
	public void undoAmieAgentSetting(String arg1) {
		SamAmieAgentPage amiePage = (SamAmieAgentPage) Environment.getCurrentPage();
		if (amiePage.getField(arg1.trim()) != null) {
			amiePage.getField(arg1.trim()).undo();
		} else {
			log.error("No matching field with label '{}'", arg1);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}

	@When("^I click the \"([^\"]*)\" radio button of the \"([^\"]*)\" AMiE Agent field$")
	public void activateAmieAgentRadio(String arg1, String arg2) {
		SamAmieAgentPage amiePage = (SamAmieAgentPage) Environment.getCurrentPage();
		if (amiePage.getField(arg2.trim()) != null) {
			String appendedKey = arg1.trim().toLowerCase() + arg2.trim();
			if (amiePage.getField(appendedKey) != null) {
				amiePage.getField(appendedKey).updateRadioButton();
			} else {
				log.error("No matching radio button value with label '{}'", arg1);
				Assert.fail("SAM RADIO BUTTON NOT FOUND");
			}
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the AMiE Agent \"([^\"]*)\" setting$")
	public void verifyAmieAgentValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (SamFields.getStrings(AMIE_AGENT, arg3.trim()) != null) {
			String fieldKey = SamFields.getStrings(AMIE_AGENT, arg3.trim()).attribute();
			if (!phone.getCurrentAppSettings().equals(AMIE_AGENT)) phone.loadAppPreferences(AMIE_AGENT);
			Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
		} else {
			log.error("No matching field with label '{}'", arg1);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the AMiE Agent custom attribute \"([^\"]*)\" setting$")
	public void checkAmieAgentCustomAttributeSetting(String arg1, String arg2, String arg3) {
		if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
			VersityPhone phone = Environment.getPhone(arg1.trim());
			if (!phone.getCurrentAppSettings().equals(AMIE_AGENT)) phone.loadAppPreferences(AMIE_AGENT);
			Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2));
		} else {
			log.debug("Skipped checking attribute {} since custom attribute testing is turned off", arg1);
		}
	}

	@Then("^the AMiE Agent page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyAmieAgentPageValue(String arg1, String arg2) {
		SamAmieAgentPage amiePage = (SamAmieAgentPage) Environment.getCurrentPage();
		if (amiePage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(amiePage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(amiePage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("No matching field with label '{}'", arg1);
			Assert.fail("SAM FIELD NOT FOUND");
		}
	}
}