package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.BizPhoneUi;
import io.appium.java_client.android.connection.ConnectionStateBuilder;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.BIZ_PHONE;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.common.CallServerDetails.SipServerType.*;
import static com.spectralink.test_automation.cucumber.framework.device.common.CallServerDetails.SipServerType.MITEL;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BizPhoneStrings.*;
import static com.spectralink.test_automation.cucumber.stepdefs.DeviceNavigationSteps.inCall;
import static com.spectralink.test_automation.cucumber.stepdefs.DeviceNavigationSteps.phoneOnHomeScreen;

public class DeviceBizPhoneSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    private static final String REG_CODE_OK = "200";
    private static final String CALL_STATE_INCOMING_CALL = "CALL_STATE_EARLY";
    private static final String MEDIA_STATE_DURING_CALL = "MEDIA_STATE_ACTIVE";
    private static final String CALL_STATE_CALL_ANSWERED = "CALL_STATE_CONFIRMED";
    private static final String CALL_STATE_CALL_ENDED = "CALL_STATE_DISCONNECTED";
    private static final String MEDIA_STATE_NOT_IN_ACTIVE_CALL = "MEDIA_STATE_NULL";
    private static final String MEDIA_STATE_DURING_HOLD = "MEDIA_STATE_LOCAL_HOLD";
    private static final String MEDIA_STATE_DURING_HOLD_FAR_END = "MEDIA_STATE_REMOTE_HOLD";
    private static final String CALL_MUTED = "1";
    private static final String CALL_UNMUTED = "0";
    private static Boolean enableAutodial = false;
    private Long callStartTime;
    private String callerNamePhoneA;
    private String callerNamePhoneB;
    private String callerNamePhoneC;

    @When("^I tap the Biz Phone \"([^\"]*)\" on \"([^\"]*)\"$")
    public void tapBizPhoneObject(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading;
        if (field != null) {
            if (field.hasLabelElement()) {
                if(arg1.equals("Voicemail Username")) {
                    phone.flingToEnd();
                    field.scrollIntoExactViewAttributeDifferentInstance("Username", 0);
                }
                else if(arg1.equals("Voicemail Password")) {
                    phone.flingToEnd();
                    field.scrollIntoExactViewAttributeDifferentInstance("Password", 1);
                }
                else if(arg1.endsWith("contact search Username"))
                    field.scrollIntoExactViewAttributeDifferentInstance("Username", 0);
                else if(arg1.endsWith("contact search Password"))
                    field.scrollIntoExactViewAttributeDifferentInstance("Password", 0);
                else {
                    heading = DeviceFields.getStrings(BIZ_PHONE, arg1.trim());
                    field.scrollIntoView(heading);
                }
                if (field.isLabelPresent()) {
                    field.tap();
                } else {
                    log.error("Field '{}' has no label", arg1);
                }
            } else if (field.hasControlElement()) {
                field.tap();
            }
            else {
                log.error("Field '{}' has no control", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @Then("^I verify \"([^\"]*)\" is not present on Biz Phone \"([^\"]*)\"$")
    public void elementNotPresent(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim());
        WebElement targetElement = null;
        if (field.hasLabelElement())
            targetElement = field.getLabelElement();
        else if (field.hasControlElement())
            targetElement = field.getControlElement();
        if (bizPhoneUi.isEntityDisplayed(targetElement)) {
            log.error("'{}' is present on '{}' when it shouldn't have been", arg1, arg2);
            Environment.softAssert().fail("INCORRECT Biz Phone VALUE");
        }
        else
            log.debug("Verified '{}' is not present on '{}'", arg1, arg2);
    }

    @Then("^I verify \"([^\"]*)\" is present on Biz Phone \"([^\"]*)\"$")
    public void elementPresent(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim());
        WebElement targetElement = null;
        if (field.hasLabelElement())
            targetElement = field.getLabelElement();
        else if (field.hasControlElement())
            targetElement = field.getControlElement();
        if (bizPhoneUi.isEntityDisplayed(targetElement))
            log.debug("Verified '{}' is present on '{}'", arg1, arg2);
        else {
            log.error("'{}' is not present on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT Biz Phone VALUE");
        }
    }

    @When("^I tap the Biz Phone Emergency Contact \"([^\"]*)\" on \"([^\"]*)\"$")
    public void tapBizPhoneEmergencyContacts(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        if (field != null) {
            if (field.hasControlElement())
                field.tap();
            else {
                log.error("Field '{}' has no control", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I set the Biz Phone \"([^\"]*)\" switch to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setBizPhoneSwitch(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        if (field.isValueAccessible()) {
            if (!field.getControlElement().getText().toLowerCase().contentEquals(arg2.trim().toLowerCase())) {
                field.tap();
                if (arg1.equals("Enable autodial")) {
                    enableAutodial = arg2.equals("ON");
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg1, arg2);
            }
        }
        else {
            log.error("Field '{}' was not accessible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I select \"([^\"]*)\" from the Biz Phone Ringtone menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectToneBizPhoneMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field;
        if (arg2.equals("Reg 1 ringtone"))
            field = bizPhoneUi.getField(RINGTONE_REG_1);
        else
            field = bizPhoneUi.getField(RINGTONE_REG_2);
        if (field != null) {
            if (arg2.equals("Reg 1 ringtone"))
                field.scrollIntoView(RINGTONE_REG_1);
            else
                field.scrollIntoView(RINGTONE_REG_2);
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectScrollableMenuOption(arg1.trim());
                if (found) {
                    bizPhoneUi.tapOkButton();
                    log.debug("Selected menu option '{}'", arg1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                    bizPhoneUi.tapCancelButton();
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg2, arg1);
            }
        } else {
            if (arg2.equals("Reg 1 ringtone"))
                log.error("No matching field with title '{}'", RINGTONE_REG_1.title());
            else
                log.error("No matching field with title '{}'", RINGTONE_REG_2.title());
        }
    }

    @When("^I select \"([^\"]*)\" from the Biz Phone overflow menu on \"([^\"]*)\"$")
    public void selectOverflowOption(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isControlPresent()) {
            tapBizPhoneObject("More options", arg2);
            found = field.selectTextMenuOption(arg1.trim().toLowerCase());
            if (found) {
                log.debug("Selected menu option '{}'", arg1);
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg2);
        }
    }

    @When("^I select \"([^\"]*)\" feature from the Biz Phone overflow menu on \"([^\"]*)\"$")
    public void selectFeaturesOverflowMenu(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isControlPresent()) {
            tapBizPhoneObject("More options", arg2);
            field.selectTextMenuOption("Features");
            found = field.selectTextMenuOption(arg1.trim().toLowerCase());
            if (found) {
                log.debug("Selected menu option '{}'", arg1);
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg2);
        }
    }

    @Then("^I verify \"([^\"]*)\" feature is present in the Biz Phone Features menu on \"([^\"]*)\"$")
    public void verifyFeaturesMenu(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/title"));
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase(arg1.trim())) {
                found = true;
                break;
            }
        }
        if(found)
            log.debug("'{}' menu option present", arg1);
        else {
            log.error("'{}' menu option not present", arg1);
            Environment.softAssert().fail("INCORRECT Biz Phone APP VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\" feature is not present in the Biz Phone Features menu on \"([^\"]*)\"$")
    public void verifyFeaturesMenuItemNotPresent(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/title"));
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase(arg1.trim())) {
                found = true;
                break;
            }
        }
        if(found) {
            log.error("'{}' menu option found but shouldn't have been there", arg1);
            Environment.softAssert().fail("INCORRECT Biz Phone APP VALUE");
        }
        else
            log.debug("Verified '{}' menu option not present", arg1);
    }

    @Then("^I verify \"([^\"]*)\" is present in the Biz Phone Overflow menu on \"([^\"]*)\"$")
    public void verifyOverflowMenuItems(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        boolean found = false;
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/title"));
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase(arg1.trim())) {
                found = true;
                break;
            }
        }
        if(found) {
            log.debug("Verified '{}' Overflow menu item is present on '{}'", arg1, arg2);
        }
        else {
            log.error("'{}' Overflow menu item is not present on '{}' ", arg1, arg2);
            Environment.softAssert().fail("INCORRECT Biz Phone APP VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\" is not present in the Biz Phone Overflow menu on \"([^\"]*)\"$")
    public void verifyOverflowMenuItemNotPresent(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/title"));
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase(arg1.trim())) {
                found = true;
                break;
            }
        }
        if(found) {
            log.error("'{}' Overflow menu item present when it shouldn't have on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT Biz Phone APP VALUE");
        }
        else
            log.debug("Verified '{}' Overflow menu item is not present on '{}'", arg1, arg2);
    }

    @Then("^I verify Cisco Features is not present in the overflow menu on Biz Phone \"([^\"]*)\"$")
    public void verifyFeaturesMenuNotPresent(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(OVERFLOW_MENU);
        boolean found = false;
        if (field.isControlPresent()) {
            tapBizPhoneObject("More options", arg1);
            List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/title"));
            for (WebElement element : options) {
                if (element.getText().equals("Features")) {
                    found = true;
                    break;
                }
            }
            if(found) {
                log.error("Features menu present when it shouldn't have ");
                Environment.softAssert().fail("INCORRECT Biz Phone APP VALUE");
            }
            else
                log.debug("Verified Features menu option not present on '{}'", arg1);
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @When("^I select \"([^\"]*)\" from the Biz Phone menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg2);
        if (field != null) {
            field.scrollIntoViewAttribute(arg2);
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
                if (found) {
                    log.debug("Selected menu option '{}'", arg1);
                    sleepSeconds(1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg2, arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg2);
        }
    }

    @When("^I select transport type from the Biz Phone menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectMenuOption(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1);
        String transportType = phone.callServerDetails().transportProtocol;
        if (field != null) {
            field.scrollIntoViewAttribute(arg1);
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(transportType.trim().toLowerCase())) {
                field.tap();
                found = field.selectCheckedMenuOption(transportType.trim().toLowerCase());
                if (found) {
                    log.debug("Selected menu option '{}'", transportType);
                    sleepSeconds(1);
                } else {
                    log.error("Could not find menu option '{}'", transportType);
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg1, transportType);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @Then("^I verify there are \"([^\"]*)\" menu items present on Biz Phone \"([^\"]*)\"$")
    public void verifyMenuItems(String arg1, String arg2) {
        int noOfItems = Integer.parseInt(arg1);
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/title"));
        if(options.size() == noOfItems) {
            log.debug("'{}' menu options found on '{}'", arg1, arg2);
        }
        else {
            log.error("'{}' menu options found instead of '{}' on '{}'", options.size(), arg1,arg2);
            Environment.softAssert().fail("INCORRECT Biz Phone APP VALUE");
        }
    }

    @Then("^the Biz Phone \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyBizPhoneValue(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());

        if (field.isValueAccessible()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Biz Phone \"([^\"]*)\" value is not set on \"([^\"]*)\"$")
    public void verifyValueNotSet(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, arg1.trim());

        if (field.hasLabelElement()) {
            assert heading != null;
            field.scrollIntoView(heading);
        }
        if (field.isValuePresent()) {
            log.error("Field '{}' is set on '{}'", arg1, arg2);
            Environment.softAssert().fail("FIELD VALUE PRESENT");
        } else {
            log.debug("Verified Field '{}'s value is not set on '{}'", arg1, arg2);
        }
    }

    @Then("^the Biz Phone Cisco feature \"([^\"]*)\" Username value is not set on \"([^\"]*)\"$")
    public void verifyUsername(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, USERNAME.title().trim());

        if (field.hasLabelElement()) {
            if(arg1.contains("contact search")) {
                field.scrollIntoView(heading);
                if (!field.isValuePresent()) {
                    field.scroll("up", 250);
                }
            }
            else
                field.scrollToEnd();
        }
        if (field.isValuePresent()) {
            log.error("Field '{}' is set on '{}'", arg1, arg2);
            Environment.softAssert().fail("FIELD VALUE PRESENT");
        } else {
            log.debug("Verified Field '{}'s value is not set on '{}'", arg1, arg2);
        }
    }

    @Then("^the Biz Phone Cisco feature \"([^\"]*)\" Username value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyUsernameValueSet(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, USERNAME.title().trim());

        if (field.hasLabelElement()) {
            if(arg1.contains("contact search")) {
                field.scrollIntoView(heading);
                if (!field.isValuePresent()) {
                    field.scroll("up", 250);
                }
            }
            else
                field.scrollToEnd();
        }
        String fieldValue = field.getValueElement().getText().toLowerCase();
        if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
            log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
        } else {
            log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
            Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
        }
    }

    @Then("^the Biz Phone Cisco feature \"([^\"]*)\" Password value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyPasswordValueSet(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, PASSWORD.title().trim());

        if (field.hasLabelElement()) {
            if(arg1.contains("contact search")) {
                field.scrollIntoView(heading);
                if (!field.isValuePresent()) {
                    field.scroll("up", 250);
                }
            }
            else
                field.scrollToEnd();
        }
        String fieldValue = field.getValueElement().getText().toLowerCase();
        if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
            log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
        } else {
            log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
            Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
        }
    }

    @Then("^the Biz Phone Cisco feature \"([^\"]*)\" Password value is not set on \"([^\"]*)\"$")
    public void verifyPassword(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, PASSWORD.title().trim());

        if (field.hasLabelElement()) {
            if(arg1.contains("contact search")) {
                field.scrollIntoView(heading);
                if (!field.isValuePresent()) {
                    field.scroll("up", 250);
                }
            }
            else
                field.scrollToEnd();
        }
        if (field.isValuePresent()) {
            log.error("Field '{}' is set on '{}'", arg1, arg2);
            Environment.softAssert().fail("FIELD VALUE PRESENT");
        } else {
            log.debug("Verified Field '{}'s value is not set on '{}'", arg1, arg2);
        }
    }

    @Then("^the Biz Phone Cisco feature \"([^\"]*)\" Username field is non-interactive on \"([^\"]*)\"$")
    public void verifyUsernameValue(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, USERNAME.title().trim());

        if (field.hasLabelElement()) {
            if(arg1.contains("contact search")) {
                field.scrollIntoView(heading);
                if (!field.isValuePresent()) {
                    field.scroll("up", 250);
                }
            }
            else
                field.scrollToEnd();
        }
        if (field.hasControlElement())
            if (field.getControlElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s control is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s control is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
            }
        if (field.hasLabelElement())
            if (field.getLabelElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s label is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s label is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
            }
        if (field.hasValueElement()) {
            if (field.isValuePresent()) {
                if (field.getValueElement().getAttribute("enabled").equals("false"))
                    log.debug("Verified field '{}'s value is non-interactive '{}'", arg1, arg2);
                else {
                    log.error("Field '{}'s value is interactive on {}", arg1, arg2);
                    Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
                }
            } else {
                log.debug("Field '{}'s value is not set on '{}'", arg1, arg2);
            }
        }
    }

    @Then("^the Biz Phone Cisco feature \"([^\"]*)\" Password field is non-interactive on \"([^\"]*)\"$")
    public void verifyPasswordValue(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, PASSWORD.title().trim());

        if (field.hasLabelElement()) {
            if(arg1.contains("contact search")) {
                field.scrollIntoView(heading);
                if (!field.isValuePresent()) {
                    field.scroll("up", 250);
                }
            }
            else
                field.scrollToEnd();
        }
        if (field.hasControlElement())
            if (field.getControlElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s control is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s control is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
            }
        if (field.hasLabelElement())
            if (field.getLabelElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s label is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s label is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
            }
        if (field.hasValueElement()) {
            if (field.isValuePresent()) {
                if (field.getValueElement().getAttribute("enabled").equals("false"))
                    log.debug("Verified field '{}'s value is non-interactive '{}'", arg1, arg2);
                else {
                    log.error("Field '{}'s value is interactive on {}", arg1, arg2);
                    Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
                }
            } else {
                log.debug("Field '{}'s value is not set on '{}'", arg1, arg2);
            }
        }
    }

    @Then("^the Biz Phone \"([^\"]*)\" field is non-interactive on \"([^\"]*)\"$")
    public void verifyOptionBlocked(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, arg1.trim());
        if (field.hasLabelElement())
            field.scrollIntoView(heading);
        if (field.hasControlElement())
            if (field.getControlElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s control is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s control is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
            }
        if (field.hasLabelElement())
            if (field.getLabelElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s label is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s label is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
            }
        if (field.hasValueElement()) {
            if (field.isValuePresent()) {
                if (field.getValueElement().getAttribute("enabled").equals("false"))
                    log.debug("Verified field '{}'s value is non-interactive '{}'", arg1, arg2);
                else {
                    log.error("Field '{}'s value is interactive on {}", arg1, arg2);
                    Environment.softAssert().fail("INCORRECT Biz Phone FIELD VALUE");
                }
            } else {
                log.debug("Field '{}'s value is not set on '{}'", arg1, arg2);
            }
        }
    }

    @Then("^I verify there are no favorites on Biz Phone \"([^\"]*)\"$")
    public void noFavoritesText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        if (bizPhoneUi.noResultText().equals("No favorites")) {
            log.debug("Verified the \"No favorites text\" is visible on '{}'", arg1);
        } else {
            log.error("the \"No favorites text\" not visible on '{}'", arg1);
            Environment.softAssert().fail("Favorites still present after clearing call logs");
        }
    }

    @When("^I enter \"([^\"]*)\" into the Biz Phone edit box on \"([^\"]*)\"$")
    public void enterInEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = bizPhoneUi.getField(EDIT_TEXT);
            field.enter(arg1.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg2);
        }
    }

    @When("^I enter \"([^\"]*)\" into the Biz Phone search edit box on \"([^\"]*)\"$")
    public void enterInSearchEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(SEARCH_EDIT_TEXT);
        if (field.isControlPresent()) {
            field = bizPhoneUi.getField(SEARCH_EDIT_TEXT);
            field.enter(arg1.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg2);
        }
    }

    @When("^I enter pbx \"([^\"]*)\" into the Biz Phone edit box on \"([^\"]*)\"$")
    public void enterIntoEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(EDIT_TEXT);
        switch (arg1.toLowerCase()) {
            case "server":
                log.debug("Entering: "+ phone.callServerDetails().sipServerAddress + " into edit text box");
                field.enter(phone.callServerDetails().sipServerAddress);
                break;
            case "password":
                log.debug("Entering: "+ phone.callServerDetails().passReg1 + " into edit text box");
                field.enter(phone.callServerDetails().passReg1);
                break;
            case "extension":
                log.debug("Entering: "+ phone.callServerDetails().extensionReg1 + " into edit text box");
                field.enter(phone.callServerDetails().extensionReg1);
                break;
        }
    }

    @When("^I clear the Biz Phone edit box on \"([^\"]*)\"$")
    public void enterEndpointText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            bizPhoneUi.clearEditText();
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @Then("^the Biz Phone verifies Registration is successful on \"([^\"]*)\"$")
    public void registerSipExtension(String arg1) {
        sleepSeconds(15);
        VersityPhone phone = Environment.getPhone(arg1.trim());

        /* REG_CODE */
        assert phone != null;
        String actualRegCode = phone.bizPhoneContentProvider().getRegistrationCode();
        log.debug("Registration Code should be: " + REG_CODE_OK);
        if (REG_CODE_OK.equals(actualRegCode)) {
            log.debug("Registration Code is: " + actualRegCode);
        } else {
            log.error("Registration Code is: " + actualRegCode);
            Environment.softAssert().fail("Incorrect Registration Code");
        }

        /* LAST_REG */
        Long actualLastRegTime = Long.valueOf(phone.bizPhoneContentProvider().getRegistrationUpdate());
        log.debug("Last Registration Time: " + actualLastRegTime);

        /* REG_EXPIRE */
        Long actualRegExpireTime = Long.parseLong(phone.bizPhoneContentProvider().getRegistrationExpiration()) * 1000;
        log.debug("Registration Expire Time: " + actualRegExpireTime);

        Long currentTime = getCurrentTime();
        log.debug("Current Timestamp: " + currentTime);

        if (currentTime < actualLastRegTime + actualRegExpireTime) {
            log.debug("Registration Expiration time condition is met");
        } else {
            log.error("Registration Expiration time condition is not met");
            Environment.softAssert().fail("Current time exceeds last registration time plus the expiration time");
        }
    }

    @Then("^the Biz Phone verifies Registration fails on \"([^\"]*)\"$")
    public void registrationFailure(String arg1) {
        sleepSeconds(40);
        VersityPhone phone = Environment.getPhone(arg1.trim());

        /* REG_CODE */
        assert phone != null;
        String actualRegCode = phone.bizPhoneContentProvider().getRegistrationCode();
        log.debug("Registration Code should not be: " + REG_CODE_OK);
        if (!REG_CODE_OK.equals(actualRegCode)) {
            log.debug("Registration Code is: " + actualRegCode);
        } else {
            log.error("Registration Code is: " + actualRegCode);
            Environment.softAssert().fail("Incorrect Registration Code");
        }
    }

    @When("^I make a Biz Phone call from \"([^\"]*)\" to \"([^\"]*)\"$")
    public void makeACall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        log.debug("Current package on " + arg2 + " is: " + phone2.getForegroundPackage());
        log.debug("Current activity on " + arg2 + " is: " + phone2.getForegroundActivity());
        if (phone2.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone2.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg1 + " to " + arg2);
        assert phone1 != null;
        BizPhoneUi bizPhoneUi = phone1.getBizPhoneUi();
        bizPhoneUi.chooseDialpad();
        log.debug("Dialing extension number: " + phone2.callServerDetails().extensionReg1);
        for (char c : phone2.callServerDetails().extensionReg1.toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Call button", arg1);
        sleepSeconds(4);
        String callIdCallingPhone = getIncomingOutgoingBizPhoneCallId(arg1);
        log.debug("Call Id of the calling phone: " + arg1 + " is: " + callIdCallingPhone);
        String callIdReceivingPhone = getIncomingOutgoingBizPhoneCallId(arg2);
        log.debug("Call Id of the phone receiving the call: " + arg2 + " is: " + callIdReceivingPhone);
    }

    @When("^I answer the Biz Phone call from \"([^\"]*)\" on \"([^\"]*)\"$")
    public void answerCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        BizPhoneUi bizPhoneUi = phone2.getBizPhoneUi();
        sleepSeconds(2);
        log.debug("Phone locked? :" + phone2.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone2.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            bizPhoneUi.answerCall();
        } else {
            log.debug("Phone is either in the BizPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone2.openNotificationBar();
            bizPhoneUi.headsUpAnswer();
        }
        log.debug("Call answered");
        phoneOnHomeScreen = false;
        inCall = false;
        callStartTime = getCurrentTime();

        sleepSeconds(3);

        assert phone1 != null;
        String callIdCallingPhone = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdReceivingPhone = getActiveBizPhoneCallPhone(arg2, arg1);

        log.debug("callIdCallingPhone: " + callIdCallingPhone);
        log.debug("callIdReceivingPhone: " + callIdReceivingPhone);


        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else {
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        }
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I decline Biz Phone call from \"([^\"]*)\" on \"([^\"]*)\"$")
    public void declineCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone1 = getActiveBizPhoneCallPhone(arg1);
        String callIdPhone2 = getActiveBizPhoneCallPhone(arg2);
        assert phone2 != null;
        BizPhoneUi bizPhoneUi2 = phone2.getBizPhoneUi();
        sleepSeconds(2);
        log.debug("Phone locked? :" + phone2.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone2.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            bizPhoneUi2.declineCall();
            log.debug("Call declined");
        } else {
            log.debug("Phone is either in the BizPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone2.openNotificationBar();
            bizPhoneUi2.headsUpDecline();
            log.debug("Call declined");
            phone2.sendKeyEvent(AndroidKey.BACK);
        }
        phoneOnHomeScreen = false;

        try {
            phone1.appium().findElementByAccessibilityId("End call enabled").click();
            log.debug("End call button pressed; call ended");
        }

        catch (Exception exception) {
            log.debug("End call button not visible");
        }

        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdPhone1);
        log.debug("Actual Call State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdPhone2);
        log.debug("Actual Call State for call id: " + callIdPhone2 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone1);
        log.debug("Actual Media State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdPhone2);
        log.debug("Actual Media State for call id: " + callIdPhone2 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I end the Biz Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone12 = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdPhone21 = getActiveBizPhoneCallPhone(arg2, arg1);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);
        assert phone2 != null;
        BizPhoneUi bizPhoneUi = phone2.getBizPhoneUi();
        bizPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I end the unanswered Biz Phone call with \"([^\"]*)\" on \"([^\"]*)\"")
    public void endCallWithoutAnswer(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone12 = getIncomingOutgoingBizPhoneCallId(arg1);
        String callIdPhone21 = getIncomingOutgoingBizPhoneCallId(arg2);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);
        assert phone2 != null;
        BizPhoneUi bizPhoneUi = phone2.getBizPhoneUi();
        bizPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I keep \"([^\"]*)\" and \"([^\"]*)\" in Biz Phone call for \"([^\"]*)\" seconds")
    public void verifyAudioStats(String arg1, String arg2, Integer arg3) {

        sleepSeconds(arg3);
        Long callTime = getCurrentTime();
        long actualCallTime = callTime - callStartTime;

        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdCallingPhone = getActiveBizPhoneCallPhone(arg1);
        String callIdReceivingPhone = getActiveBizPhoneCallPhone(arg2);
        assert phone1 != null;
        int txPacketsPhone1 = Integer.parseInt(phone1.bizPhoneContentProvider().getTxPackets(callIdCallingPhone));
        log.debug("Actual Tx packets for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + txPacketsPhone1);
        assert phone2 != null;
        int txPacketsPhone2 = Integer.parseInt(phone2.bizPhoneContentProvider().getTxPackets(callIdReceivingPhone));

        log.debug("Actual Tx packets for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + txPacketsPhone2);
        int rxPacketsPhone1 = Integer.parseInt(phone1.bizPhoneContentProvider().getRxPackets(callIdCallingPhone));
        log.debug("Actual Rx packets for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + rxPacketsPhone1);
        int rxPacketsPhone2 = Integer.parseInt(phone2.bizPhoneContentProvider().getRxPackets(callIdReceivingPhone));
        log.debug("Actual Rx packets for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + rxPacketsPhone2);
        Double missedPacketsPhone1 = Double.valueOf(phone1.bizPhoneContentProvider().getMissedPackets(callIdCallingPhone));
        log.debug("Actual Missed packets for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + missedPacketsPhone1);
        Double missedPacketsPhone2 = Double.valueOf(phone2.bizPhoneContentProvider().getMissedPackets(callIdReceivingPhone));
        log.debug("Actual Missed packets for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + missedPacketsPhone2);
        Double droppedPacketsPhone1 = Double.valueOf(phone1.bizPhoneContentProvider().getDroppedPackets(callIdCallingPhone));
        log.debug("Actual Dropped packets for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + droppedPacketsPhone1);
        Double droppedPacketsPhone2 = Double.valueOf(phone2.bizPhoneContentProvider().getDroppedPackets(callIdReceivingPhone));
        log.debug("Actual Dropped packets for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + droppedPacketsPhone2);

        /*Convert milliseconds to seconds */
        int seconds = (int) ((actualCallTime / 1000));
        int packetsInTxPhone1 = txPacketsPhone1 / seconds;
        int packetsInTxPhone2 = txPacketsPhone2 / seconds;
        int packetsInRxPhone1 = rxPacketsPhone1 / seconds;
        int packetsInRxPhone2 = rxPacketsPhone2 / seconds;
        double missedAndDroppedPacketsPhone1 = (missedPacketsPhone1 + droppedPacketsPhone1);
        double missedAndDroppedPacketsPhone2 = (missedPacketsPhone2 + droppedPacketsPhone2);

        log.debug("Duration of the call in seconds: " + seconds);
        log.debug("Tx per second for call id: " + callIdCallingPhone + " on : " + arg1 + " is:" + packetsInTxPhone1);
        log.debug("Tx per second for call id: " + callIdReceivingPhone + " on : " + arg2 + " is:" + packetsInTxPhone2);
        log.debug("Rx per second for call id: " + callIdCallingPhone + " on : " + arg1 + " is:" + packetsInRxPhone1);
        log.debug("Rx per second for call id: " + callIdReceivingPhone + " on : " + arg2 + " is:" + packetsInRxPhone2);

        int idealPacketRate = 50;
        int packetErrorMargin = 5;

        if (packetsInTxPhone1 < (idealPacketRate - packetErrorMargin)) {
            log.debug("TX packets are not within margin: " + packetsInTxPhone1);
            Environment.softAssert().fail("Not enough TX packets on : " + arg1);
        } else
            log.debug("TX packets are within margin : " + packetsInTxPhone1);

        if (packetsInTxPhone2 < (idealPacketRate - packetErrorMargin)) {
            log.debug("TX packets are not within margin: " + packetsInTxPhone2);
            Environment.softAssert().fail("Not enough TX packets on : " + arg2);
        } else
            log.debug("TX packets are within margin : " + packetsInTxPhone2);

        if (packetsInRxPhone1 < (idealPacketRate - packetErrorMargin)) {
            log.debug("RX packets are not within margin: " + packetsInRxPhone1);
            Environment.softAssert().fail("Not enough RX packets on : " + arg1);
        } else
            log.debug("RX packets are within margin : " + packetsInRxPhone1);

        if (packetsInRxPhone2 < (idealPacketRate - packetErrorMargin)) {
            log.debug("RX packets are not within margin: " + packetsInRxPhone2);
            Environment.softAssert().fail("Not enough RX packets on : " + arg2);
        } else
            log.debug("RX packets are within margin : " + packetsInRxPhone2);

        if (missedAndDroppedPacketsPhone1 >= 0.75) {
            log.debug("Missed/Dropped packets are not within margin: " + missedAndDroppedPacketsPhone1);
            Environment.softAssert().fail("Too many Missed/Dropped packets on : " + arg1);
        } else
            log.debug("Missed/Dropped packets are within margin: " + missedAndDroppedPacketsPhone1);
        if (missedAndDroppedPacketsPhone2 >= 0.75) {
            log.debug("Missed/Dropped packets are not within margin: " + missedAndDroppedPacketsPhone2);
            Environment.softAssert().fail("Too many Missed/Dropped packets on : " + arg2);
        } else
            log.debug("Missed/Dropped packets are within margin: " + missedAndDroppedPacketsPhone2);

    }

    @When("^I enter the Biz Phone Registration 1 Details on \"([^\"]*)\"$")
    public void enterRegistration1Details(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        tapBizPhoneObject("Registration 1", arg1);
        tapBizPhoneObject("Sip server", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().sipServerAddress);
        tapBizPhoneObject("Ok button", arg1);
        tapBizPhoneObject("Extension number", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().extensionReg1);
        tapBizPhoneObject("Ok button", arg1);
        tapBizPhoneObject("Username", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().userReg1);
        tapBizPhoneObject("Ok button", arg1);
        tapBizPhoneObject("Password", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().passReg1);
        tapBizPhoneObject("Ok button", arg1);
    }

    @When("^I enter the Biz Phone Registration 2 Details on \"([^\"]*)\"$")
    public void enterRegistration2Details(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        tapBizPhoneObject("Registration 2", arg1);
        tapBizPhoneObject("Sip server", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().sipServerAddress);
        tapBizPhoneObject("Ok button", arg1);
        tapBizPhoneObject("Extension number", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().extensionReg2);
        tapBizPhoneObject("Ok button", arg1);
        tapBizPhoneObject("Username", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().userReg2);
        tapBizPhoneObject("Ok button", arg1);
        tapBizPhoneObject("Password", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().passReg2);
        tapBizPhoneObject("Ok button", arg1);
    }

    private Long getCurrentTime() {
        return System.currentTimeMillis();
    }

    private String getIncomingOutgoingBizPhoneCallId(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        return phone.bizPhoneContentProvider().getCallIdIncomingOutgoingCall();
    }

    private String getActiveBizPhoneCallPhone(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        return phone.bizPhoneContentProvider().getCallId();
    }

    private String getActiveBizPhoneCallPhone(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone1 != null;
        assert phone2 != null;
        return phone1.bizPhoneContentProvider().getCallIdFarEndUsername(phone2.callServerDetails().extensionReg1);
    }

    @When("^I enter \"([^\"]*)\" into the Biz Phone edit box for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void enterInEditTextContactName(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field;
        switch (arg2.toLowerCase()) {
            case "emergency contact name":
                field = bizPhoneUi.getField(EMERGENCY_CONTACT_NAME);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(EMERGENCY_CONTACT_NAME);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "emergency contact number":
                field = bizPhoneUi.getField(EMERGENCY_CONTACT_NUMBER);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(EMERGENCY_CONTACT_NUMBER);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "first name":
                field = bizPhoneUi.getField(FIRST_NAME);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(FIRST_NAME);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "last name":
                field = bizPhoneUi.getField(LAST_NAME);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(LAST_NAME);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "company":
                field = bizPhoneUi.getField(COMPANY);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(COMPANY);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "title":
                field = bizPhoneUi.getField(TITLE);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(TITLE);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "phone":
                field = bizPhoneUi.getField(PHONE);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(PHONE);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "email":
                field = bizPhoneUi.getField(EMAIL);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(EMAIL);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
        }
    }

    @When("^I enter server details into the Biz Phone edit box for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void enterInEditTextLoginOut(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field;
        switch (arg1.toLowerCase()) {
            case "login extension":
                field = bizPhoneUi.getField(EXTENSION_EDIT_TEXT);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(EXTENSION_EDIT_TEXT);
                    field.enter(phone.callServerDetails().extensionReg1);
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg2);
                }
                break;
            case "login password":
                field = bizPhoneUi.getField(PASSWORD_EDIT_TEXT);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(PASSWORD_EDIT_TEXT);
                    field.enter(phone.callServerDetails().passReg1);
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg2);
                }
                break;
        }
    }

    @When("^I clear the Biz Phone edit box for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void clearEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field;
        switch (arg1.trim().toLowerCase()) {
            case "contact name":
                field = bizPhoneUi.getField(EMERGENCY_CONTACT_NAME);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(EMERGENCY_CONTACT_NAME);
                    field.clear();
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg2);
                }
                break;
            case "contact number":
                field = bizPhoneUi.getField(EMERGENCY_CONTACT_NUMBER);
                if (field.isControlPresent()) {
                    field = bizPhoneUi.getField(EMERGENCY_CONTACT_NUMBER);
                    field.clear();
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg2);
                }
                break;
        }
    }

    @Then("^the Biz Phone Emergency Contact \"([^\"]*)\" label is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyEmergencyContactName(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        if (field.isLabelPresent()) {
            String fieldValue = field.getLabelElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT BIZ PHONE FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Biz Phone Emergency Contact \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyEmergencyContactNumber(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        if (field.isValuePresent()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT BIZ PHONE FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I unlock the Biz Phone Developer Options option on \"([^\"]*)\"$")
    public void selectOverflowOption(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isControlPresent()) {
            tapBizPhoneObject("More options", arg1);
            found = field.selectTextMenuOption("About");
            if (found) {
                Point position = bizPhoneUi.getBizPhoneIconPosition();
                phone.tapOnScreenFor10Seconds(position.getX(), position.getY());
                bizPhoneUi.clickExposeButton();
                log.debug("Enabled Biz Phone developer options");
                bizPhoneUi.goBack();
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @When("^I place the Biz Phone conference call between \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" on hold on \"([^\"]*)\"$")
    public void holdConferenceCall(String arg1,String arg2,String arg3,String arg4) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        String callIdArg12 = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdArg13 = getActiveBizPhoneCallPhone(arg1, arg3);
        assert phone1 != null;

        BizPhoneUi bizPhoneUi = phone1.getBizPhoneUi();
        log.debug("Placing the conference call on hold on : " + arg1);
        bizPhoneUi.holdResumeButton(true);
        sleepSeconds(8);

        assert phone1 != null;
        String mediaState12 = phone1.bizPhoneContentProvider().getMediaState(callIdArg12);
        log.debug("Actual Media State for call id: " + callIdArg12 + " on : " + arg1 + " with " + arg2 + " is: " + mediaState12);
        String mediaState13 = phone1.bizPhoneContentProvider().getMediaState(callIdArg13);
        log.debug("Actual Media State for call id: " + callIdArg13 + " on : " + arg1 + " with " + arg3 + " is: " + mediaState13);

        if (MEDIA_STATE_DURING_HOLD.equals(mediaState12))
            log.debug("Media States on : " + arg1 + " with " + arg2 + " is matched ");
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1 + " with " + arg2);

        if (MEDIA_STATE_DURING_HOLD.equals(mediaState13))
            log.debug("Media States on : " + arg1 + " with " + arg3 + " is matched ");
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1 + " with " + arg3);

    }

    @When("^I place the Biz Phone conference call between \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" on resume on \"([^\"]*)\"$")
    public void resumeConferenceCall(String arg1,String arg2,String arg3,String arg4) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        String callIdArg12 = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdArg13 = getActiveBizPhoneCallPhone(arg1, arg3);
        assert phone1 != null;

        BizPhoneUi bizPhoneUi = phone1.getBizPhoneUi();
        log.debug("Placing the conference call on resume on : " + arg1);
        bizPhoneUi.holdResumeButton(false);
        sleepSeconds(8);

        String mediaState12 = phone1.bizPhoneContentProvider().getMediaState(callIdArg12);
        log.debug("Actual Media State for call id: " + callIdArg12 + " on : " + arg1 + " with " + arg2 + " is: " + mediaState12);
        String mediaState13 = phone1.bizPhoneContentProvider().getMediaState(callIdArg13);
        log.debug("Actual Media State for call id: " + callIdArg13 + " on : " + arg1 + " with " + arg3 + " is: " + mediaState13);

        if (MEDIA_STATE_DURING_CALL.equals(mediaState12))
            log.debug("Media States on : " + arg1 + " with " + arg2 + " is matched ");
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1 + " with " + arg2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaState13))
            log.debug("Media States on : " + arg1 + " with " + arg3 + " is matched ");
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1 + " with " + arg3);


    }

    @When("^I place the active Biz Phone call between \"([^\"]*)\" and \"([^\"]*)\" on hold on \"([^\"]*)\"$")
    public void holdCall(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String callIdCallingPhone = getActiveBizPhoneCallPhone(arg1);
        String callIdReceivingPhone = getActiveBizPhoneCallPhone(arg2);
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();

        log.debug("Placing the call on hold on : " + arg3);
        bizPhoneUi.holdResumeButton(true);
        sleepSeconds(8);

        assert phone1 != null;
        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        assert phone2 != null;
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        if (arg3.equals(arg1)) {
            if (MEDIA_STATE_DURING_HOLD.equals(mediaStatePhone1))
                log.debug("Media States matched on : " + arg1);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg1);

            if(phone2.callServerDetails().getSipServer().equals(CISCO_SPP) ||
                    phone2.callServerDetails().getSipServer().equals(SATURN) ||
                    phone2.callServerDetails().getSipServer().equals(MITEL)) {
                if (MEDIA_STATE_DURING_HOLD_FAR_END.equals(mediaStatePhone2))
                    log.debug("Media States matched on : " + arg2);
                else
                    Environment.softAssert().fail("Incorrect Media State on : " + arg2);
            }
            else {
                if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
                    log.debug("Media States matched on : " + arg2);
                else
                    Environment.softAssert().fail("Incorrect Media State on : " + arg2);
            }
        } else {
            if(phone1.callServerDetails().getSipServer().equals(CISCO_SPP) ||
                    phone1.callServerDetails().getSipServer().equals(SATURN) ||
                    phone1.callServerDetails().getSipServer().equals(MITEL)) {
                if (MEDIA_STATE_DURING_HOLD_FAR_END.equals(mediaStatePhone1))
                    log.debug("Media States matched on : " + arg1);
                else
                    Environment.softAssert().fail("Incorrect Media State on : " + arg1);
            }
            else {
                if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
                    log.debug("Media States matched on : " + arg1);
                else
                    Environment.softAssert().fail("Incorrect Media State on : " + arg1);
            }
            if (MEDIA_STATE_DURING_HOLD.equals(mediaStatePhone2))
                log.debug("Media States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg2);
        }
    }

    @When("^I place the active Biz Phone call between \"([^\"]*)\" and \"([^\"]*)\" on resume on \"([^\"]*)\"$")
    public void resumeCall(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String callIdCallingPhone = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdReceivingPhone = getActiveBizPhoneCallPhone(arg2, arg1);
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();

        log.debug("Resuming the call from hold on : " + arg3);
        try{
            phone.appium().findElementByAccessibilityId("End call enabled");
            bizPhoneUi.endCall();
        }
        catch(Exception ignored) {}

        bizPhoneUi.holdResumeButton(false);
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        assert phone2 != null;
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I blind transfer the Biz Phone call on \"([^\"]*)\" to \"([^\"]*)\"$")
    public void blindTransfer(String arg1, String arg2) {
        VersityPhone phoneThatTransferredTheCall = Environment.getPhone(arg1.trim());
        VersityPhone phoneCallWasTransferredTo = Environment.getPhone(arg2.trim());

        String callIdActiveCall = getActiveBizPhoneCallPhone(arg1);

        assert phoneThatTransferredTheCall != null;
        BizPhoneUi bizPhoneUi = phoneThatTransferredTheCall.getBizPhoneUi();
        tapBizPhoneObject("Transfer call", arg1);

        String callState = phoneThatTransferredTheCall.bizPhoneContentProvider().getCallState(callIdActiveCall);
        log.debug("Actual Call State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + callState);

        String mediaState = phoneThatTransferredTheCall.bizPhoneContentProvider().getMediaState(callIdActiveCall);
        log.debug("Actual Media State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + mediaState);

        if (CALL_STATE_CALL_ANSWERED.equals(callState))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);

        assert phoneCallWasTransferredTo != null;
        log.debug("Dialing extension number: " + phoneCallWasTransferredTo.callServerDetails().extensionReg1);
        for (char c : phoneCallWasTransferredTo.callServerDetails().extensionReg1.toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Start new call button", arg1);
        sleepSeconds(2);
    }

    @When("^I \"([^\"]*)\" the transferred Biz Phone call on \"([^\"]*)\"$")
    public void answerBlindTransferredCall(String arg1, String arg2) {
        VersityPhone phoneCallWasTransferredTo = Environment.getPhone(arg2.trim());
        String activeCall = getActiveBizPhoneCallPhone(arg2);

        assert phoneCallWasTransferredTo != null;
        BizPhoneUi bizPhoneUi = phoneCallWasTransferredTo.getBizPhoneUi();
        sleepSeconds(4);
        log.debug("Phone locked? :" + phoneCallWasTransferredTo.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phoneCallWasTransferredTo.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            if (arg1.toLowerCase().equals("answer")) {
                bizPhoneUi.answerCall();
                log.debug("Call answered");
            } else {
                bizPhoneUi.declineCall();
                log.debug("Call decline");
            }

        } else {
            log.debug("Phone is either in the BizPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phoneCallWasTransferredTo.openNotificationBar();
            if (arg1.toLowerCase().equals("answer")) {
                bizPhoneUi.headsUpAnswer();
                log.debug("Call answered");
            } else {
                bizPhoneUi.headsUpDecline();
                log.debug("Call declined");
                phoneCallWasTransferredTo.sendKeyEvent(AndroidKey.BACK);
            }
        }
        phoneOnHomeScreen = false;

        sleepSeconds(2);

        if (arg1.toLowerCase().equals("answer")) {

            String callState = phoneCallWasTransferredTo.bizPhoneContentProvider().getCallState(activeCall);
            log.debug("Actual Call State for call id: " + activeCall + " on : " + arg2 + " is: " + callState);

            if (CALL_STATE_CALL_ANSWERED.equals(callState))
                log.debug("Call States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Call State on : " + arg2);

            String mediaState = phoneCallWasTransferredTo.bizPhoneContentProvider().getMediaState(activeCall);
            log.debug("Actual Media State for call id: " + activeCall + " on : " + arg2 + " is: " + mediaState);

            if (MEDIA_STATE_DURING_CALL.equals(mediaState))
                log.debug("Media States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg2);
        } else {
            String callState = phoneCallWasTransferredTo.bizPhoneContentProvider().getCallState(activeCall);
            log.debug("Actual Call State for call id: " + activeCall + " on : " + arg2 + " is: " + callState);

            if (CALL_STATE_CALL_ENDED.equals(callState))
                log.debug("Call States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Call State on : " + arg2);

            String mediaState = phoneCallWasTransferredTo.bizPhoneContentProvider().getMediaState(activeCall);
            log.debug("Actual Media State for call id: " + activeCall + " on : " + arg2 + " is: " + mediaState);

            if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaState))
                log.debug("Media States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg2);
        }
    }

    @When("^I end the transferred Biz Phone call between \"([^\"]*)\" and \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endBlindTransferredCall(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone = Environment.getPhone(arg3.trim());

        String activeCallPhone1 = getActiveBizPhoneCallPhone(arg1, arg2);
        String activeCallPhone2 = getActiveBizPhoneCallPhone(arg2, arg1);

        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.endCall();
        sleepSeconds(2);

        assert phone1 != null;
        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(activeCallPhone1);
        log.debug("Actual Call State for call id: " + activeCallPhone1 + " on : " + arg1 + " is: " + callStatePhone1);
        assert phone2 != null;
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(activeCallPhone2);
        log.debug("Actual Call State for call id: " + activeCallPhone2 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(activeCallPhone1);
        log.debug("Actual Media State for call id: " + activeCallPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(activeCallPhone2);
        log.debug("Actual Media State for call id: " + activeCallPhone2 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I end the rejected Biz Phone call on \"([^\"]*)\"$")
    public void endRejectedBlindTransferredCall(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String activeCallPhone1 = getActiveBizPhoneCallPhone(arg1);
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.endCall();
        sleepSeconds(2);
        String callStatePhone1 = phone.bizPhoneContentProvider().getCallState(activeCallPhone1);
        log.debug("Actual Call State for call id: " + activeCallPhone1 + " on : " + arg1 + " is: " + callStatePhone1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);

        String mediaStatePhone1 = phone.bizPhoneContentProvider().getMediaState(activeCallPhone1);
        log.debug("Actual Media State for call id: " + activeCallPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
    }

    @When("^I toggle Wifi \"([^\"]*)\" on \"([^\"]*)\" with \"([^\"]*)\" and verify BizPhone registration status")
    public void toggleWifi(String arg1, String arg2, String arg3) {
        VersityPhone phone;
        if (arg2.equals("Lte Phone"))
            phone = Environment.getUsbHost().getVersityLtePhone();
        else
            phone = Environment.getUsbHost().getVersityWifiPhone();
        log.debug("Model Number: " + phone.getModel());

        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(OVERFLOW_MENU);
        if (field.isControlPresent()) {
            bizPhoneUi.tapOverflowMenu();
            field.selectTextMenuOption("Settings");
        }
        field = bizPhoneUi.getField(REGISTRATION_1);
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, REGISTRATION_1.title().trim());
        field.scrollIntoView(heading);
        field.tap();
        field = bizPhoneUi.getField(TRANSPORT);
        if (field.isControlPresent()) {
            bizPhoneUi.tapTransportLabel();
            field.selectCheckedMenuOption(arg3.trim());
        }
        bizPhoneUi.goBack();
        bizPhoneUi.goBack();

        if (arg1.equals("Off")) {
            phone.toggleWifiSvc(false);
            if (arg3.equals("TCP"))
                sleepSeconds(35);
            else
                sleepSeconds(300);
            String actualRegCode = phone.bizPhoneContentProvider().getRegistrationCode();
            log.debug("Registration Code should not be: " + REG_CODE_OK);
            if (!REG_CODE_OK.equals(actualRegCode)) {
                log.debug("Registration Code is: " + actualRegCode);
            } else {
                log.error("Registration Code is: " + actualRegCode);
                Environment.softAssert().fail("Incorrect Registration Code");
            }
        } else {
            phone.toggleWifiSvc(true);
            sleepSeconds(35);
            String actualRegCode = phone.bizPhoneContentProvider().getRegistrationCode();
            log.debug("Registration Code should be: " + REG_CODE_OK);
            if (REG_CODE_OK.equals(actualRegCode)) {
                log.debug("Registration Code is: " + actualRegCode);
            } else {
                log.error("Registration Code is: " + actualRegCode);
                Environment.softAssert().fail("Incorrect Registration Code");
            }
        }
    }

    @When("^I announce transfer the Biz Phone call with \"([^\"]*)\" on \"([^\"]*)\" to \"([^\"]*)\"$")
    public void announceTransfer(String arg1, String arg2, String arg3) {
        VersityPhone phoneThatTransferredTheCall = Environment.getPhone(arg2.trim());

        String callIdPhoneInCall21 = getActiveBizPhoneCallPhone(arg2, arg1);
        String callIdPhoneInCall23 = getActiveBizPhoneCallPhone(arg2, arg3);

        assert phoneThatTransferredTheCall != null;
        BizPhoneUi bizPhoneUi = phoneThatTransferredTheCall.getBizPhoneUi();
        tapBizPhoneObject("Transfer call", arg2);

        String callState23 = phoneThatTransferredTheCall.bizPhoneContentProvider().getCallState(callIdPhoneInCall23);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall23 + " on : " + arg2 + "with " + arg3 + " is: " + callState23);

        String mediaState23 = phoneThatTransferredTheCall.bizPhoneContentProvider().getMediaState(callIdPhoneInCall23);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall23 + " on : " + arg2 + "with " + arg3 + " is: " + mediaState23);

        if (CALL_STATE_CALL_ANSWERED.equals(callState23))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState23))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);

        bizPhoneUi.clickHeldCallToMerge(callIdPhoneInCall21);
        log.debug("Transferring the call with : " + arg1 + " to : " + arg3);
        sleepSeconds(2);

        callState23 = phoneThatTransferredTheCall.bizPhoneContentProvider().getCallState(callIdPhoneInCall23);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall23 + " on : " + arg2 + "with " + arg3 + " is: " + callState23);

        mediaState23 = phoneThatTransferredTheCall.bizPhoneContentProvider().getMediaState(callIdPhoneInCall23);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall23 + " on : " + arg2 + "with " + arg3 + " is: " + mediaState23);

        if (CALL_STATE_CALL_ENDED.equals(callState23))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaState23))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);

        String callState21 = phoneThatTransferredTheCall.bizPhoneContentProvider().getCallState(callIdPhoneInCall21);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall21 + " on : " + arg2 + "with " + arg1 + " is: " + callState21);

        String mediaState21 = phoneThatTransferredTheCall.bizPhoneContentProvider().getMediaState(callIdPhoneInCall21);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall21 + " on : " + arg2 + "with " + arg1 + " is: " + mediaState21);

        if (CALL_STATE_CALL_ENDED.equals(callState21))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaState21))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I add a Biz Phone call from \"([^\"]*)\" to \"([^\"]*)\"$")
    public void addCall(String arg1, String arg2) {
        VersityPhone phoneAddingACall = Environment.getPhone(arg1.trim());
        VersityPhone phoneReceivingCall = Environment.getPhone(arg2.trim());

        String callIdActiveCall = getActiveBizPhoneCallPhone(arg1);

        assert phoneAddingACall != null;
        BizPhoneUi bizPhoneUi = phoneAddingACall.getBizPhoneUi();
        tapBizPhoneObject("Add call", arg1);

        String callState = phoneAddingACall.bizPhoneContentProvider().getCallState(callIdActiveCall);
        log.debug("Actual Call State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + callState);

        String mediaState = phoneAddingACall.bizPhoneContentProvider().getMediaState(callIdActiveCall);
        log.debug("Actual Media State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + mediaState);

        if (CALL_STATE_CALL_ANSWERED.equals(callState))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);

        assert phoneReceivingCall != null;
        log.debug("Dialing extension number: " + phoneReceivingCall.callServerDetails().extensionReg1);
        for (char c : phoneReceivingCall.callServerDetails().extensionReg1.toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Start new call button", arg1);
        sleepSeconds(2);
    }

    @When("^I choose to resume Biz Phone call with \"([^\"]*)\" on \"([^\"]*)\" putting the other call with \"([^\"]*)\" on hold")
    public void holdResume(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        String callIdArg21 = getActiveBizPhoneCallPhone(arg2, arg1);
        String callIdArg23 = getActiveBizPhoneCallPhone(arg2, arg3);

        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.clickHeldCallToMerge(callIdArg21);
        log.debug("Resuming call with : " + arg1 + " on " + arg2);

        String callState21 = phone.bizPhoneContentProvider().getCallState(callIdArg21);
        log.debug("Actual Call State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg1 + " is: " + callState21);

        String mediaState21 = phone.bizPhoneContentProvider().getMediaState(callIdArg21);
        log.debug("Actual Media State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg1 + " is: " + mediaState21);

        if (CALL_STATE_CALL_ANSWERED.equals(callState21))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_DURING_CALL.equals(mediaState21))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);

        String callState23 = phone.bizPhoneContentProvider().getCallState(callIdArg23);
        log.debug("Actual Call State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg3 + " is: " + callState23);

        String mediaState23 = phone.bizPhoneContentProvider().getMediaState(callIdArg23);
        log.debug("Actual Media State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg3 + " is: " + mediaState23);

        if (CALL_STATE_CALL_ANSWERED.equals(callState23))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState23))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I merge Biz Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void mergeCall(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callIdArg21 = getActiveBizPhoneCallPhone(arg2, arg1);

        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        tapBizPhoneObject("Conference call", arg2);
        log.debug("Resuming call with : " + arg1 + " on " + arg2);
        bizPhoneUi.clickHeldCallToMerge(callIdArg21);

        sleepSeconds(2);

        String callState21 = phone.bizPhoneContentProvider().getCallState(callIdArg21);
        log.debug("Actual Call State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg1 + " is: " + callState21);

        String mediaState21 = phone.bizPhoneContentProvider().getMediaState(callIdArg21);
        log.debug("Actual Media State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg1 + " is: " + mediaState21);

        if (CALL_STATE_CALL_ANSWERED.equals(callState21))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_DURING_CALL.equals(mediaState21))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I split Biz Phone calls with \"([^\"]*)\" and \"([^\"]*)\" on \"([^\"]*)\"$")
    public void splitCalls(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String callIdArg31 = getActiveBizPhoneCallPhone(arg3, arg1);
        String callIdArg32 = getActiveBizPhoneCallPhone(arg3, arg2);

        sleepSeconds(2);
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        tapBizPhoneObject("Split call", arg3);
        sleepSeconds(2);

        String callState31 = phone.bizPhoneContentProvider().getCallState(callIdArg31);
        log.debug("Actual Call State for call id: " + callIdArg31 + " on : " + arg3 + " with " + arg1 + " is: " + callState31);

        String mediaState31 = phone.bizPhoneContentProvider().getMediaState(callIdArg31);
        log.debug("Actual Media State for call id: " + callIdArg31 + " on : " + arg3 + " with " + arg1 + " is: " + mediaState31);

        if (CALL_STATE_CALL_ANSWERED.equals(callState31))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState31))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);

        String callState32 = phone.bizPhoneContentProvider().getCallState(callIdArg32);
        log.debug("Actual Call State for call id: " + callIdArg32 + " on : " + arg3 + " with " + arg2 + " is: " + callState32);

        String mediaState32 = phone.bizPhoneContentProvider().getMediaState(callIdArg32);
        log.debug("Actual Media State for call id: " + callIdArg32 + " on : " + arg3 + " with " + arg2 + " is: " + mediaState32);

        if (CALL_STATE_CALL_ANSWERED.equals(callState32))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState32))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);
    }

    @When("^I end Biz Phone calls with \"([^\"]*)\" and \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endCalls(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone = Environment.getPhone(arg3.trim());

        String callIdPhone31 = getActiveBizPhoneCallPhone(arg3, arg1);
        String callIdPhone32 = getActiveBizPhoneCallPhone(arg3, arg2);
        String callIdPhone1 = getActiveBizPhoneCallPhone(arg1);
        String callIdPhone2 = getActiveBizPhoneCallPhone(arg2);

        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        String callStatePhone31 = phone.bizPhoneContentProvider().getCallState(callIdPhone31);
        log.debug("Actual Call State for call id: " + callIdPhone31 + " on : " + arg3 + " with " + arg1 + " is: " + callStatePhone31);
        String callStatePhone32 = phone.bizPhoneContentProvider().getCallState(callIdPhone32);
        log.debug("Actual Call State for call id: " + callIdPhone32 + " on : " + arg3 + " with " + arg2 + " is: " + callStatePhone32);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone31))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone32))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);

        String mediaStatePhone31 = phone.bizPhoneContentProvider().getMediaState(callIdPhone31);
        log.debug("Actual Media State for call id: " + callIdPhone31 + " on : " + arg3 + " with " + arg1 + " is: " + mediaStatePhone31);
        String mediaStatePhone32 = phone.bizPhoneContentProvider().getMediaState(callIdPhone32);
        log.debug("Actual Media State for call id: " + callIdPhone32 + " on : " + arg3 + " with " + arg2 + " is: " + mediaStatePhone32);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone31))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone32))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);

        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdPhone1);
        log.debug("Actual Call State for call id: " + callIdPhone1 + " on : " + arg1 + " with " + arg3 + " is: " + callStatePhone1);
        assert phone2 != null;
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdPhone2);
        log.debug("Actual Call State for call id: " + callIdPhone2 + " on : " + arg2 + " with " + arg3 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone1);
        log.debug("Actual Media State for call id: " + callIdPhone1 + " on : " + arg2 + " with " + arg3 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdPhone2);
        log.debug("Actual Media State for call id: " + callIdPhone2 + " on : " + arg2 + " with " + arg3 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @Then("^I verify \"([^\"]*)\"'s call server name/number \"([^\"]*)\" up on index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void favoriteIndexVerification(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        assert phone != null;
        String callServerName = targetPhone.callServerDetails().displayName;
        String entryName = phone.appium().findElementByAccessibilityId("Contact name index " + arg3 + " title").getText();
        switch (arg2.toLowerCase()) {
            case "shows":
                if (callServerName.equals(entryName)) {
                    log.debug("Verified " + callServerName + " shows up on index '{}'", arg3);
                } else {
                    log.error(entryName + " showed up on index '{}'", arg3 + " instead");
                    Environment.softAssert().fail("Item did not show up where it should have");
                }
                break;
            case "does not show":
                if (callServerName.equals(entryName)) {
                    log.error(callServerName + " showed up up on index '{}' when it shouldn't have", arg3);
                    Environment.softAssert().fail("Item showed up where it shouldn't have");
                } else {
                    log.debug("Verified " + callServerName + " did not show up on index '{}'", arg3);
                }
                break;
        }
    }

    @Then("^I verify \"([^\"]*)\" \"([^\"]*)\" up on index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void favoriteCallLogsContactsVerificationAtIndex(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        assert phone != null;
        String entryName = phone.appium().findElementByAccessibilityId("Contact name index " + arg3 + " title").getText();
        switch (arg2.toLowerCase()) {
            case "shows":
                if (arg1.equals(entryName)) {
                    log.debug("Verified " + arg1 + " shows up on index '{}'", arg3);
                } else {
                    log.error(arg1 + " did not show up on index '{}'", arg3);
                    Environment.softAssert().fail("Favorited item did not show up where it should have");
                }
                break;
            case "does not show":
                if (arg1.equals(entryName)) {
                    log.error(arg1 + " showed up up on index '{}' when it shouldn't have", arg3);
                    Environment.softAssert().fail("Favorited item showed up where it shouldn't have");
                } else {
                    log.debug("Verified " + arg1 + " did not show up on index '{}'", arg3);
                }
                break;
        }
    }

    @Then("^I verify \"([^\"]*)\" \"([^\"]*)\" up in the index range \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void favoriteIndex(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        assert phone != null;
        String[] splitIndexRange = arg3.split(",");
        Integer found;
        Integer start = Integer.valueOf(splitIndexRange[0]);
        int end = Integer.parseInt(splitIndexRange[1]);
        switch (arg2.toLowerCase()) {
            case "shows":
                found = selectFromFavoritesContactsList(arg1, phone);
                if (found >= start && found <=end) {
                    log.debug(arg1 + " showed up on index '{}'", found);
                } else {
                    log.debug(arg1 + " showed up at index '{}'", found + " instead");
                    Environment.softAssert().fail("Phone number did not show up at the desired position");
                }
                break;
            case "does not show":
                found = selectFromFavoritesContactsList(arg1, phone);
                if (found >= start && found <=end) {
                    log.debug(arg1 + " showed up at index '{}'", found + " when shouldn't have");
                    Environment.softAssert().fail("Phone number showed up at undesirable position");
                } else {
                    log.debug(arg1 + " showed up on index '{}'", found);
                }
                break;
        }
    }

    @Then("^I select \"([^\"]*)\" from the \"([^\"]*)\" list on Biz Phone \"([^\"]*)\" and make a call")
    public void makeACallFromTheList(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        List<WebElement> options;
        phone.scrollIntoExactViewAttribute(arg1.trim());
        if (arg2.equals("favorites") || arg2.equals("contacts"))
            options = phone.appium().findElements(By.id("com.spectralink.phone:id/contact_name"));
        else
            options = phone.appium().findElements(By.id("com.spectralink.phone:id/caller_text_primary"));
        for (WebElement element : options) {
            if (element.getText().equals(arg1.trim())) {
                sleepSeconds(1);
                bizPhoneUi.clickOnPageEntity(element);
                if(!enableAutodial)
                    tapBizPhoneObject("Call button", arg3);
                return;
            }
        }
        log.error(arg1 + " not found in the " + arg2 + " list");
        Environment.softAssert().fail("Match not found in the " + arg2 + " list");
    }

    /* @Then("^I verify \"([^\"]*)\" was saved as a contact on Biz Phone \"([^\"]*)\"$")
     public void verifyContactSaved(String arg1, String arg2) {
         VersityPhone phone = Environment.getPhone(arg1.trim());
         assert phone != null;
         BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
         if (phone1.userName.equals(bizPhoneUi.entryAtIndex(arg2))) {
             log.debug("Verified " + arg1 + " name/number: " + phone1.userName + " shows up on index '{}'", arg2);
         } else {
             log.error(arg1 + "'s name/number: " + phone1.userName + " did not show up on index '{}'", arg2);
             Environment.softAssert().fail("Favorites not showing up at expected indexes");
         }
     }
 */
    @Then("^I create a local contact \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void createContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone != null;
        String[] splitFirstLastNames = arg1.split("\\s+");
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.tapCreateNewContact();
        bizPhoneUi.enterFirstName(splitFirstLastNames[0]);
        bizPhoneUi.enterLastName(splitFirstLastNames[1]);
        bizPhoneUi.enterPhoneNumber(phone1.callServerDetails().extensionReg1);
        bizPhoneUi.saveContact();
    }

    @When("^I delete contact \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void deleteContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.tapSearchContact();
        bizPhoneUi.enterIntoSearchEditText(arg1);
        if (!bizPhoneUi.noContactFound()) {
            ConfigUiField field = bizPhoneUi.getField("0".trim().toLowerCase());
            field.longPress("index_0");
            selectOverflowOption("Delete", arg2);
            tapBizPhoneObject("Ok button", arg2);
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @When("^I select the contact at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void selectContactAtIndex(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        phone.longPressContentDesc("Contact name index " + arg1 + " title");
    }

    @When("^I select the contact \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void selectContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.tapSearchContact();
        bizPhoneUi.enterIntoSearchEditText(arg1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(2);
        phone.longPressContentDesc("Search contact name index 0 title");
    }

    @When("^I \"([^\"]*)\" the contact on Biz Phone \"([^\"]*)\"$")
    public void starUnstarContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        switch (arg1.toLowerCase()) {
            case "star":
                bizPhoneUi.starContact();
                break;
            case "unstar":
                bizPhoneUi.unstarContact();
                break;
        }
    }

    @When("^I make a Biz Phone call from \"([^\"]*)\" to an invalid number \"([^\"]*)\"$")
    public void makeAnInvalidCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone1 != null;
        BizPhoneUi bizPhoneUi = phone1.getBizPhoneUi();
        bizPhoneUi.chooseDialpad();
        log.debug("Dialing extension number: " + arg2);
        for (char c : arg2.toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Call button", arg1);
        sleepSeconds(1);
        bizPhoneUi.clearDialpad();
    }

    @When("^I end the Biz Phone call dialed to an invalid number on \"([^\"]*)\"")
    public void endCallInvalidNumber(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);
    }

    public Integer selectFromFavoritesContactsList(String option, VersityPhone phone) {
        for (int count = 0; count < 2; count++) {
            List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/contact_name"));
            for (WebElement element : options) {
                if (element.getText().trim().equalsIgnoreCase(option.trim())) {
                    sleepSeconds(1);
                    return options.indexOf(element);
                }
            }
            phone.flingForward();
        }
        return null;
    }

    @Then("^I verify \"([^\"]*)\"'s call server name/number \"([^\"]*)\" up on the \"([^\"]*)\" list on Biz Phone \"([^\"]*)\"$")
    public void listVerification(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        Integer found;
        String callServerName = phone1.callServerDetails().displayName;

        switch (arg2.toLowerCase()) {
            case "shows":
                found = selectFromFavoritesContactsList(callServerName, phone);
                if (found != null) {
                    log.debug(arg1 + "'s call server name: " + callServerName + " showed up in " + arg3 + " list");
                } else {
                    log.error(arg1 + "'s call server name: " + callServerName + " did not show up in " + arg3 + " list");
                    Environment.softAssert().fail("Phone number showed up in " + arg3 + " list when it shouldn't have");
                }
                break;
            case "does not show":
                found = selectFromFavoritesContactsList(callServerName, phone);
                if (found == null) {
                    log.debug(arg1 + "'s call server name: " + callServerName + " did not show up in " + arg3 + " list");
                } else {
                    log.error(arg1 + "'s call server name: " + callServerName + " showed up in " + arg3 + " list");
                    Environment.softAssert().fail("Phone's call server name showed up in " + arg3 + " list when it shouldn't have");
                }
                break;
        }
    }

    @Then("^I verify \"([^\"]*)\" \"([^\"]*)\" up in the \"([^\"]*)\" list on Biz Phone \"([^\"]*)\"$")
    public void listVerificationName(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        Integer found;
        found = selectFromFavoritesContactsList(arg1, phone);

        switch (arg2.toLowerCase()) {
            case "shows":
                if (found != null) {
                    log.debug("Match found for name/number: " + arg1 + " at index " + found);
                } else {
                    log.error(arg1 + " not found in the " + arg3 + " list");
                    Environment.softAssert().fail("Match not found in the " + arg3 + " list");
                }
                break;
            case "does not show":
                if (found == null) {
                    log.debug(arg1 +" did not show up in " + arg3 + " list");
                } else {
                    log.error(arg1 + " showed up in " + arg3 + " list");
                    Environment.softAssert().fail("Phone number showed up in " + arg3 + " list when it shouldn't have");
                }
                break;
        }
    }

    @Then("^I get \"([^\"]*)\"'s caller name on calling Biz phone, \"([^\"]*)\"$")
    public void getCallerName(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        switch (arg1) {
            case "PHONE A":
                callerNamePhoneA =  bizPhoneUi.getCallerNameCalledPhone();
                log.debug("Caller name: PHONE A: " + callerNamePhoneA);
                break;
            case "PHONE B":
                callerNamePhoneB =  bizPhoneUi.getCallerNameCalledPhone();
                log.debug("Caller name: PHONE B: " + callerNamePhoneB);
                break;
            case "PHONE C":
                callerNamePhoneC =  bizPhoneUi.getCallerNameCalledPhone();
                log.debug("Caller name: PHONE C: " + callerNamePhoneC);
                break;
        }
    }

    @Then("^I get \"([^\"]*)\"'s caller name on receiving Biz phone, \"([^\"]*)\"$")
    public void getCallerNameReceivingPhone(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        String callerName;
        log.debug("Phone locked? :" + phone.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            callerName = bizPhoneUi.getCallerNameReceivedCall();
        } else {
            log.debug("Phone is either in the BizPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone.openNotificationBar();
            callerName = bizPhoneUi.getCallerNameFromHeadsUpNotification();
        }
        phoneOnHomeScreen = false;
        inCall = false;

        switch (arg1) {
            case "PHONE A":
                callerNamePhoneA =  callerName;
                log.debug("Caller name: PHONE A: " + callerNamePhoneA);
                break;
            case "PHONE B":
                callerNamePhoneB =  callerName;
                log.debug("Caller name: PHONE B: " + callerNamePhoneB);
                break;
            case "PHONE C":
                callerNamePhoneC =  callerName;
                log.debug("Caller name: PHONE C: " + callerNamePhoneC);
                break;
        }
    }

    @Then("^I verify \"([^\"]*)\" shows up as the caller name on Biz Phone \"([^\"]*)\"$")
    public void callerNameVerification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        if (arg1.equals(bizPhoneUi.getCallerNameCalledPhone())) {
            log.debug("Verified " + arg1 + " shows up as caller name on " + arg2);
        } else {
            log.error(arg1 + " did not show up as caller name on " + arg2);
            Environment.softAssert().fail("Appropriate Caller name did not show up");
        }
    }

    @Then("^I verify \"([^\"]*)\"'s number \"([^\"]*)\" up on index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void listItemVerification(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone != null;
        assert phone1 != null;
        String entryName = phone.appium().findElementByAccessibilityId("Contact name index " + arg3 + " title").getText();
        switch (arg2.toLowerCase()) {
            case "shows":
                if (phone1.callServerDetails().extensionReg1.equals(entryName)) {
                    log.debug("Verified " + phone1.callServerDetails().extensionReg1 + " shows up on index '{}'", arg3);
                } else {
                    log.error(phone1.callServerDetails().extensionReg1 + " did not show up on index '{}'", arg3);
                    Environment.softAssert().fail("Item did not show up where it should have");
                }
                break;
            case "does not show":
                if (phone1.callServerDetails().extensionReg1.equals(entryName)) {
                    log.error(phone1.callServerDetails().extensionReg1 + " showed up up on index '{}' when it shouldn't have", arg3);
                    Environment.softAssert().fail("Item showed up where it shouldn't have");
                } else {
                    log.debug("Verified " + phone1.callServerDetails().extensionReg1 + " did not show up on index '{}'", arg3);
                }
                break;
        }
    }

    @Then("^I verify you cannot have HAC and ANC enabled at the same time on Biz Phone \"([^\"]*)\"$")
    public void checkAncHacBehavior(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.checkAncHacBehavior();
    }

    @When("^I toggle Wifi \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void toggleWifi(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        switch (arg1.trim().toLowerCase()) {

            case "off":
                log.debug("Turning Wi-Fi off");
                phone.toggleWifiSvc(true);
                break;
            case "on":
                log.debug("Turning Wi-Fi on");
                phone.toggleWifiSvc(false);
                break;
        }
    }

    @When("^I dial the number \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void dialNumber(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.chooseDialpad();
        log.debug("Dialing extension number: " + arg2);
        for (char c : arg1.toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Call button", arg2);
        sleepSeconds(1);
        bizPhoneUi.clearDialpad();
    }

    @When("^I dial \"([^\"]*)\"'s number on Biz Phone \"([^\"]*)\"$")
    public void dialNumberExtension(String arg1, String arg2) {
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        BizPhoneUi bizPhoneUi = phone2.getBizPhoneUi();
        String phoneNumber =  phone1.callServerDetails().extensionReg1;
        bizPhoneUi.chooseDialpad();
        log.debug("Dialing extension number: " + phoneNumber);
        for (char c : phoneNumber.toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Call button", arg2);
    }

    @Then("^I verify service unavailable pop up shows up on Biz Phone \"([^\"]*)\"$")
    public void serviceUnavailablePopup(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        if (bizPhoneUi.popUpMessage().equals("Service is not available")) {
            log.debug("Service Unavailable pop up showed up");
        }
        else {
            log.error("Service Unavailable pop up did not show up");
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @When("^I set call forwarding to \"([^\"]*)\"'s extension on Biz Phone \"([^\"]*)\"$")
    public void setCallForwarding(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        String extensionNumberTargetPhone = targetPhone.callServerDetails().extensionReg1;
        selectFeaturesOverflowMenu("Call forwarding", arg2);
        setBizPhoneSwitch("Enable call forwarding", "on", arg2);
        WebElement element = phone.appium().findElement(By.id("com.spectralink.phone:id/forward_edit"));
        bizPhoneUi.typeIntoPageEntity(element,extensionNumberTargetPhone);
        bizPhoneUi.goBack();
    }

    @When("^I disable call forwarding on Biz Phone \"([^\"]*)\"$")
    public void disableCallForwarding(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        selectFeaturesOverflowMenu("Call forwarding", arg1);
        setBizPhoneSwitch("Enable call forwarding", "off", arg1);
        bizPhoneUi.goBack();
    }

    @Then("^I verify call forwarding is set to \"([^\"]*)\"'s extension on Biz Phone \"([^\"]*)\"$")
    public void verifyCallForwarding(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        String extensionNumberTargetPhone = targetPhone.callServerDetails().extensionReg1;
        WebElement element = phone.appium().findElement(By.id("com.spectralink.phone:id/toolbar_summary"));
        if(element.getText().contains("Calls forwarded to " + extensionNumberTargetPhone))
            log.debug("Call forwarding set to '{}' on '{}'", arg1, arg2);
        else {
            log.error("Call forwarding not set to '{}' on '{}'", arg1, arg2);
            Environment.softAssert().fail("BIZ PHONE FAILURE");
        }
    }

    @When("^I make a Biz Phone call from \"([^\"]*)\" to \"([^\"]*)\" but it has call forwarding set to \"([^\"]*)\"$")
    public void makeAForwardedCall(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg3.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        log.debug("Current package on " + arg3 + " is: " + phone2.getForegroundPackage());
        log.debug("Current activity on " + arg3 + " is: " + phone2.getForegroundActivity());
        if (phone2.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone2.getForegroundActivity().equals("com.spectralink.phone.activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg1 + " to " + arg2);
        assert phone1 != null;
        BizPhoneUi bizPhoneUi = phone1.getBizPhoneUi();
        bizPhoneUi.chooseDialpad();
        log.debug("Dialing extension number: " + phone.callServerDetails().extensionReg1);
        for (char c : phone.callServerDetails().extensionReg1.toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Call button", arg1);
        sleepSeconds(4);
        String callIdCallingPhone = getIncomingOutgoingBizPhoneCallId(arg1);
        log.debug("Call Id of the calling phone: " + arg1 + " is: " + callIdCallingPhone);
        String callIdReceivingPhone = getIncomingOutgoingBizPhoneCallId(arg3);
        log.debug("Call Id of the phone receiving the call: " + arg3 + " is: " + callIdReceivingPhone);
    }


    /*@When("^I let the call with \"([^\"]*)\" go to voicemail on Biz Phone \"([^\"]*)\"$")
    public void letCallGoToVoicemail(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);
    }

    @Then("^I verify there were \"([^\"]*)\" missed calls on Biz Phone \"([^\"]*)\"$")
    public void numberMissedCalls(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        numberOfMissedCallsVerification(arg1, phone);
    }

    @Then("^I verify there is a missed call on Biz Phone \"([^\"]*)\"$")
    public void oneMissedCalls(String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        oneMissedCallVerification(phone);
    }

    @Then("^I verify there is no missed call notification on Biz Phone \"([^\"]*)\"$")
    public void noMissedCall(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        noMissedCallNotification(phone);
    }

    @When("^I tap on missed call notification on Biz Phone \"([^\"]*)\"$")
    public void tapMissedCallNotification(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
       // bizPhoneUi.tapOnMissedCallNotification();
    }

    @Then("^I verify \"([^\"]*)\"'s call server name/number shows up at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void verifyCallLogsContact(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        assert phone != null;
        String callServerName = targetPhone.callServerDetails().userName;
        String contactNumber = phone.appium().findElementByAccessibilityId("call_number_at_index_" + arg2).getText();
        if(callServerName.equals(contactNumber)) {
            log.debug("'{}' contact showed up at index '{}'", contactNumber, arg2);
        }
        else {
            log.debug("'{}' contact showed up at index '{}' instead", contactNumber, arg2);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    public boolean numberOfMissedCallsVerification(String numberOfCalls, VersityPhone phone) {
        for (int count = 0; count < 2; count++) {
            List<WebElement> options = phone.appium().findElements(By.id("android:id/header_text"));
            for (WebElement element : options) {
                if (element.getText().contentEquals(numberOfCalls + " Missed calls")) {
                    sleepSeconds(1);
                    return true;
                }
            }
          //  phone.scrollUpCoordinates(500,1550, 500, 550);
        }
        return false;
    }

    public boolean noMissedCallNotification(VersityPhone phone) {
        for (int count = 0; count < 2; count++) {
            List<WebElement> options = phone.appium().findElements(By.id("android:id/header_text"));
            for (WebElement element : options) {
                if (element.getText().contains("Missed call")) {
                    sleepSeconds(1);
                    return false;
                }
            }
           // phone.scrollUpCoordinates(500,1550, 500, 550);
        }
        return true;
    }

    public boolean oneMissedCallVerification(VersityPhone phone) {
        for (int count = 0; count < 2; count++) {
            List<WebElement> options = phone.appium().findElements(By.id("android:id/header_text"));
            for (WebElement element : options) {
                if (element.getText().contentEquals("Missed calls")) {
                    sleepSeconds(1);
                    return true;
                }
            }
           // phone.scrollUpCoordinates(500,1550, 500, 550);
        }
        return false;
    }*/

    @Then("^I verify contact number \"([^\"]*)\" shows up at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void contactNumberAtIndex(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String textAtIndex = phone.appium().findElementByAccessibilityId("Contact number index " + arg2+" title").getText();
        if(arg1.equals(textAtIndex))
            log.debug("Contact number '{}' showed up at index '{}' on '{}'", arg1, arg2, arg3);
        else {
            log.error("Contact number '{}' showed up at index '{}' on '{}' instead", textAtIndex, arg2, arg3);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @Then("^I verify there are no voicemails on Biz Phone \"([^\"]*)\"$")
    public void noVoicemail(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String textAtIndex = phone.appium().findElementById("com.spectralink.phone:id/tv_no_result").getText();
        if(textAtIndex.equals("No voicemails"))
            log.debug("There are no voicemails on '{}'", arg1);
        else {
            log.error("There still are voicemails on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @Then("^I verify contact name \"([^\"]*)\" shows up at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void contactNameAtIndex(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String textAtIndex = phone.appium().findElementByAccessibilityId("Contact name index " + arg2 + " title").getText();
        if(arg1.equals(textAtIndex))
            log.debug("Contact name '{}' showed up at index '{}' on '{}'", arg1, arg2, arg3);
        else {
            log.error("Contact name '{}' showed up at index '{}' on '{}' instead", textAtIndex, arg2, arg3);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @Then("^I verify the voicemail messages count at index \"([^\"]*)\" is \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void noOfVoicemailMessages(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String textAtIndex = phone.appium().findElementByAccessibilityId("Unread count index " + arg1+" title").getText();
        if(arg2.equals(textAtIndex))
            log.debug("'{}' no of messages showed up at index '{}' on '{}'", arg2, arg1, arg3);
        else {
            log.error("'{}' messages showed up at index '{}' on '{}' instead", textAtIndex, arg1, arg3);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @Then("^I tap the contact name \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void tapName(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElementsById("com.spectralink.phone:id/contact_name");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                log.debug("Tapping contact name '{}'", arg1);
                element.click();
            }
        }
    }

    @Then("^I tap the contact at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void tapNameByIndex(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("Contact name index " + arg1 + " title").click();
    }

    @Then("^I tap the contact number \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void tapNumber(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElementsById("com.spectralink.phone:id/contact_number");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                log.debug("Tapping contact name '{}'", arg1);
                element.click();
            }
        }
    }

    @When("^I delete voicemail at index \"([^\"]*)\" from device on Biz Phone \"([^\"]*)\"$")
    public void deleteVoicemailMessagesFromDevice(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("voicemail_delete_at_index_" + arg1).click();
        tapBizPhoneObject("From device button", arg2);
    }

    @When("^I delete voicemail at index \"([^\"]*)\" from server on Biz Phone \"([^\"]*)\"$")
    public void deleteVoicemailMessagesFromServer(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("voicemail_delete_at_index_" + arg1).click();
        tapBizPhoneObject("From server button", arg2);
    }

    @When("^I decline the Biz Phone call on \"([^\"]*)\" and let it go to voicemail")
    public void declineCallForVoicemail(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        sleepSeconds(2);
        log.debug("Phone locked? :" + phone.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            bizPhoneUi.declineCall();
            log.debug("Call declined");
        } else {
            log.debug("Phone is either in the BizPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone.openNotificationBar();
            bizPhoneUi.headsUpDecline();
            log.debug("Call declined");
            phone.sendKeyEvent(AndroidKey.BACK);
        }
        phoneOnHomeScreen = false;
    }

    @Then("^I verify voicemail notification exists on Biz Phone \"([^\"]*)\"$")
    public void voicemailNotification(String arg1) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("android:id/title");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("Voicemail waiting")) {
                found = true;
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            }
        }
        if(found)
            log.debug("Voicemail notification present on '{}'", arg1);
        else {
            log.error("Voicemail notification not present on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT BIZ PHONE APP VALUE");
        }
    }

    @Then("^I verify voicemail notification does not exist on Biz Phone \"([^\"]*)\"$")
    public void voicemailNotificationDoesNotExist(String arg1) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("android:id/title");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("Voicemail waiting")) {
                found = true;
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            }
        }
        if(found) {
            log.error("Voicemail notification present on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT BIZ PHONE APP VALUE");
        }
        else
            log.debug("Voicemail notification not present on '{}'", arg1);
    }

    @Then("^I verify call park notification does not exist on Biz Phone \"([^\"]*)\"$")
    public void callParkDoesNotExist(String arg1) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("android:id/header_text");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("Parked call")) {
                found = true;
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            }
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        if(found) {
            log.error("Voicemail notification present on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT BIZ PHONE APP VALUE");
        }
        else
            log.debug("Voicemail notification not present on '{}'", arg1);
    }


    @Then("^I verify tapping voicemail notification dials the voicemail number on Biz Phone \"([^\"]*)\"$")
    public void voicemailNotificationDial(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("android:id/title");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("Voicemail waiting")) {
                element.click();
                sleepSeconds(5);
                if(phone.appium().findElementByAccessibilityId("Caller name title").getText().equals("VoiceMail"))
                    log.debug("VoiceMail called on '{}'", arg1);
                else {
                    log.error("VoiceMail not called on'{}'", arg1);
                    Environment.softAssert().fail("INCORRECT BIZ PHONE APP VALUE");
                }
                tapBizPhoneObject("End call", arg1);
            }
        }
    }

    @When("^I change the audio path to Speaker mode on Biz Phone \"([^\"]*)\"$")
    public void changeAudioPath(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        tapBizPhoneObject("Audio path", arg1);
        phone.appium().findElement(By.id("com.spectralink.phone:id/aud_button_1")).click();
    }

    @Then("^I play the voicemail message at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void playVoicemailAtIndex(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("voicemail_arrival_time_at_index_" + arg1).click();
    }

    @Then("^I verify Message waiting notification is present on lock screen on Biz Phone \"([^\"]*)\"$")
    public void mwNotificationOnLockScreen(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("voicemail_arrival_time_at_index_" + arg1).click();
    }

    @Then("^I verify \"([^\"]*)\" shows up as caller Name on Biz Phone \"([^\"]*)\"$")
    public void verifyCallIsSentToVoicemail(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if(phone.appium().findElementByAccessibilityId("Caller name").getText().equals(arg1))
            log.debug("VoiceMail called on '{}'", arg1);
        else {
            log.error("VoiceMail not called on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT BIZ PHONE APP VALUE");
        }
    }

    @Then("^I verify the Biz Phone call between \"([^\"]*)\" and \"([^\"]*)\" is in two way audio")
    public void twoWayAudio(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        callStartTime = getCurrentTime();
        sleepSeconds(2);
        String callIdCallingPhone = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdReceivingPhone = getActiveBizPhoneCallPhone(arg2, arg1);

        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else {
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        }
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I park the Biz Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void parkCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg2.trim());
        VersityPhone phone2 = Environment.getPhone(arg1.trim());
        String callIdPhone12 = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdPhone21 = getActiveBizPhoneCallPhone(arg2, arg1);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);

        selectOverflowOption("Park call", arg2);

        sleepSeconds(5);

        String callStatePhone1 = phone2.bizPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone1.bizPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone2.bizPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_HOLD_FAR_END.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I resume the parked Biz Phone call with \"([^\"]*)\" by tapping the notification on \"([^\"]*)\"$")
    public void resumeParkedCallFromNotification(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());

        phone2.openNotificationBar();
        phone2.appium().findElementByAccessibilityId("Caller number").click();
        sleepSeconds(5);

        String callIdPhone12 = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdPhone21 = getActiveBizPhoneCallPhone(arg2, arg1);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);

        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I resume the parked Biz Phone call with \"([^\"]*)\" by \"([^\"]*)\" on another phone \"([^\"]*)\"$")
    public void resumeParkedCallFromAnotherPhone(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone3 = Environment.getPhone(arg3.trim());

        phone2.openNotificationBar();
        String callParkNumber = phone2.appium().findElementByAccessibilityId("Caller number").getText();
        phone2.sendKeyEvent(AndroidKey.BACK);

        log.debug("Current package on " + arg1 + " is: " + phone1.getForegroundPackage());
        log.debug("Current activity on " + arg1 + " is: " + phone1.getForegroundActivity());
        if (phone1.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone1.getForegroundActivity().equals("com.spectralink.phone.activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg3 + " to " + arg1);

        BizPhoneUi bizPhoneUi = phone3.getBizPhoneUi();
        bizPhoneUi.chooseDialpad();
        log.debug("Dialing call park number: " + callParkNumber);
        for (char c : callParkNumber.toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Call button", arg3);

        sleepSeconds(5);

        String callIdPhone13 = getActiveBizPhoneCallPhone(arg1, arg3);
        String callIdPhone31 = getActiveBizPhoneCallPhone(arg3, arg1);
        log.debug("callIdPhone13: " + callIdPhone13);
        log.debug("callIdPhone31: " + callIdPhone31);

        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdPhone13);
        log.debug("Actual Call State for call id: " + callIdPhone13 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone3 = phone3.bizPhoneContentProvider().getCallState(callIdPhone31);
        log.debug("Actual Call State for call id: " + callIdPhone31 + " on : " + arg3 + " is: " + callStatePhone3);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone3))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone13);
        log.debug("Actual Media State for call id: " + callIdPhone13 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone3 = phone3.bizPhoneContentProvider().getMediaState(callIdPhone31);
        log.debug("Actual Media State for call id: " + callIdPhone31 + " on : " + arg3 + " is: " + mediaStatePhone3);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone3))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);
    }

    @When("^I end the parked Biz Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endParkedCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone1 = getActiveBizPhoneCallPhone(arg1);
        String callIdPhone2 = getActiveBizPhoneCallPhone(arg2);
        log.debug("callIdPhone1: " + callIdPhone1);
        log.debug("callIdPhone2: " + callIdPhone2);
        assert phone2 != null;
        BizPhoneUi bizPhoneUi = phone2.getBizPhoneUi();
        bizPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdPhone1);
        log.debug("Actual Call State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdPhone2);
        log.debug("Actual Call State for call id: " + callIdPhone2 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone1);
        log.debug("Actual Media State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdPhone2);
        log.debug("Actual Media State for call id: " + callIdPhone2 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I answer the park reversion Biz Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void answerParkReversionCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg2.trim());
        VersityPhone phone2 = Environment.getPhone(arg1.trim());
        BizPhoneUi bizPhoneUi = phone1.getBizPhoneUi();
        sleepSeconds(2);
        phone1.openNotificationBar();
        bizPhoneUi.headsUpAnswer();
        log.debug("Call answered");
        callStartTime = getCurrentTime();
        sleepSeconds(2);
        String callIdCallingPhone = getActiveBizPhoneCallPhone(arg1, arg2);
        String callIdReceivingPhone = getActiveBizPhoneCallPhone(arg2, arg1);

        log.debug("callIdCallingPhone: " + callIdCallingPhone);
        log.debug("callIdReceivingPhone: " + callIdReceivingPhone);


        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else {
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        }
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I make a Biz Phone hunt group call from \"([^\"]*)\" to \"([^\"]*)\"$")
    public void makeAHuntGroupCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        log.debug("Current package on " + arg2 + " is: " + phone2.getForegroundPackage());
        log.debug("Current activity on " + arg2 + " is: " + phone2.getForegroundActivity());
        if (phone2.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone2.getForegroundActivity().equals("com.spectralink.phone.activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg1 + " to " + arg2);
        assert phone1 != null;
        BizPhoneUi bizPhoneUi = phone1.getBizPhoneUi();
        bizPhoneUi.chooseDialpad();
        log.debug("Dialing extension number: 2995");
        for (char c : "2995".toCharArray()) {
            bizPhoneUi.clickDialNumber(c);
        }
        tapBizPhoneObject("Call button", arg1);
        sleepSeconds(4);
        String callIdCallingPhone = getIncomingOutgoingBizPhoneCallId(arg1);
        log.debug("Call Id of the calling phone: " + arg1 + " is: " + callIdCallingPhone);
        String callIdReceivingPhone = getIncomingOutgoingBizPhoneCallId(arg2);
        log.debug("Call Id of the phone receiving the call: " + arg2 + " is: " + callIdReceivingPhone);
    }

    @When("^I answer the Biz Phone hunt group call from \"([^\"]*)\" on \"([^\"]*)\"$")
    public void answerHuntGroupCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        BizPhoneUi bizPhoneUi = phone2.getBizPhoneUi();
        sleepSeconds(2);
        log.debug("Phone locked? :" + phone2.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone2.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            bizPhoneUi.answerCall();
        } else {
            log.debug("Phone is either in the BizPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone2.openNotificationBar();
            bizPhoneUi.headsUpAnswer();
        }
        log.debug("Call answered");
        phoneOnHomeScreen = false;
        inCall = false;
        callStartTime = getCurrentTime();

        sleepSeconds(2);

        assert phone1 != null;
        String callIdCallingPhone = getActiveBizPhoneCallPhone(arg1);
        String callIdReceivingPhone = getActiveBizPhoneCallPhone(arg2);

        log.debug("callIdCallingPhone: " + callIdCallingPhone);
        log.debug("callIdReceivingPhone: " + callIdReceivingPhone);

        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else {
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        }
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I end the Biz Phone hunt group call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endHuntGroupCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone12 = getActiveBizPhoneCallPhone(arg1);
        String callIdPhone21 = getActiveBizPhoneCallPhone(arg2);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);
        assert phone2 != null;
        BizPhoneUi bizPhoneUi = phone2.getBizPhoneUi();
        bizPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.bizPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.bizPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.bizPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.bizPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @Then("^I verify contact name \"([^\"]*)\" shows up at index \"([^\"]*)\" in Biz Phone contact search on \"([^\"]*)\"$")
    public void contactNameAtIndexSearch(String arg1, String arg2, String arg3) {
        int index = Integer.parseInt(arg2);
        VersityPhone phone = Environment.getPhone(arg3.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/contact_name"));
        String elementText = options.get(index).getText();
        if(arg1.equals(options.get(index).getText()))
            log.debug("Contact name '{}' showed up at index '{}' on '{}'", arg1, arg2, arg3);
        else {
            log.error("Contact name '{}' showed up at index '{}' on '{}' instead", elementText, arg2, arg3);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @Then("^I verify contact name \"([^\"]*)\" does not show up in Biz Phone contact search on \"([^\"]*)\"$")
    public void contactNameDoesNotShowUpAtIndexSearch(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/contact_name"));
        for (WebElement element : options) {
            if(element.getText().trim().equals(arg1)) {
                found = true;
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            }
        }
        if(found) {
            log.error("Contact name '{}' showed up at index on '{}' instead", arg1, arg2);
            Environment.softAssert().fail("INCORRECT BIZ PHONE APP VALUE");
        }
        else
            log.debug("Contact name '{}' did not show up on '{}'", arg1, arg2);
    }

    @Then("^I verify contact number \"([^\"]*)\" shows up at index \"([^\"]*)\" in Biz Phone contact search on \"([^\"]*)\"$")
    public void contactNumberAtIndexSearch(String arg1, String arg2, String arg3) {
        int index = Integer.parseInt(arg2);
        VersityPhone phone = Environment.getPhone(arg3.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/contact_number"));
        String elementText = options.get(index).getText();
        if(arg1.equals(options.get(index).getText()))
            log.debug("Contact number '{}' showed up at index '{}' on '{}'", arg1, arg2, arg3);
        else {
            log.error("Contact number '{}' showed up at index '{}' on '{}' instead", elementText, arg2, arg3);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @When("^I long press the Biz Phone contact \"([^\"]*)\" on \"([^\"]*)\"$")
    public void longPressBizSearchResult(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String contentDescription = null;
        List<WebElement> options = phone.appium().findElements(By.id("com.spectralink.phone:id/contact_name"));
        for (WebElement element : options) {
            if(element.getText().trim().equals(arg1)) {
                contentDescription = element.getAttribute("content-desc");
                break;
            }
        }
        phone.longPressContentDesc(contentDescription);
    }

    @Then("^I verify Biz Phone call is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyCallState(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callState = phone.appium().findElementById("com.spectralink.phone:id/toolbar_title").getText();
        if(arg1.equals(callState))
            log.debug("Call Sate is '{}' on '{}'", arg1, arg2);
        else {
            log.error("Call Sate is '{}' instead on '{}'", callState, arg2);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @Then("^I verify Biz Phone call with \"([^\"]*)\" is muted on \"([^\"]*)\"$")
    public void verifyPhoneIsMuted(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callIdPhone = getActiveBizPhoneCallPhone(arg2, arg1);
        log.debug("callIdPhone: " + callIdPhone);

        String mediaStatePhone1 = phone.bizPhoneContentProvider().getCallMutedState(callIdPhone);
        log.debug("Actual Mute State for call id: " + callIdPhone + " on : " + arg2 + " is: " + mediaStatePhone1);

        if (CALL_MUTED.equals(mediaStatePhone1))
            log.debug("Call is muted on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Mute State on : " + arg2);
    }

    @Then("^I verify Biz Phone call with \"([^\"]*)\" is unmuted on \"([^\"]*)\"$")
    public void verifyPhoneIsUnmuted(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callIdPhone = getActiveBizPhoneCallPhone(arg2, arg1);
        log.debug("callIdPhone: " + callIdPhone);

        String mediaStatePhone1 = phone.bizPhoneContentProvider().getCallMutedState(callIdPhone);
        log.debug("Actual Mute State for call id: " + callIdPhone + " on : " + arg2 + " is: " + mediaStatePhone1);

        if (CALL_UNMUTED.equals(mediaStatePhone1))
            log.debug("Call is unmuted on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Mute State on : " + arg2);
    }

    @When("^I select the call log entry at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void selectCallLogEntryAtIndex(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        phone.longPressContentDesc("Caller name index " + arg1 + " title");
    }

    @Then("^I verify \"([^\"]*)\"'s caller name and number on Call details screen on Biz Phone \"([^\"]*)\"$")
    public void callerNameAndNumberVerification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        String nameOnCallLog = bizPhoneUi.getCallerNameCalledPhone().toLowerCase();
        String numberOnCallLog = bizPhoneUi.getCallerNumber().toLowerCase();
        String name = targetPhone.callServerDetails().displayName;
        String number = targetPhone.callServerDetails().extensionReg1;
        if (nameOnCallLog.equals(name.trim().toLowerCase())) {
            if (numberOnCallLog.equals(number.trim().toLowerCase())) {
                log.info("Call details verified successfully");
            } else {
                Environment.softAssert().fail("Caller number "+number+" is not matching with "+numberOnCallLog+" on callLog screen");
            }
        } else {
            Environment.softAssert().fail("Caller name " +name+" is not matching with "+nameOnCallLog +" on callLog screen");
        }

    }
    @When("^I enter the Biz Phone voicemail setting Details on \"([^\"]*)\"$")
    public void voicemailSettings(String arg1){
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        tapBizPhoneObject("Registration 1", arg1);
        tapBizPhoneObject("Voicemail retrieval address", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().voicemailRetrievalAddress);
        tapBizPhoneObject("Ok button", arg1);
        tapBizPhoneObject("Call server features", arg1);
        setBizPhoneSwitch("Voicemail enable","on",arg1);
        tapBizPhoneObject("Cisco Unity server address (primary)", arg1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().voicemailPrimaryServerAddress);
        tapBizPhoneObject("Ok button", arg1);
        tapDuplicateBizPhoneObject("Voicemail Username", arg1,1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().voicemailUsername);
        tapBizPhoneObject("Ok button", arg1);
        tapDuplicateBizPhoneObject("Voicemail Password", arg1,1);
        bizPhoneUi.enterInEditText(phone.callServerDetails().voicemailPassword);
        tapBizPhoneObject("Ok button", arg1);
        tapBizPhoneObject("Back arrow",arg1);
        tapBizPhoneObject("Back arrow",arg1);
        tapBizPhoneObject("Back arrow",arg1);
    }

    @Then("^I verify the Biz Phone server certificate on \"([^\"]*)\"$")
    public void verifyCertificate(String arg1){
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.clickOkButtonOnCertificate();

    }

    public void tapDuplicateBizPhoneObject(String arg1, String arg2,int instance){
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        ConfigUiField field = bizPhoneUi.getField(arg1.trim().toLowerCase());
        String[] list = arg1.split(" ");
        if (field != null) {
            if (field.hasLabelElement()) {
                field.scrollIntoExactViewAttributeDifferentInstance(list[1],instance);
                if (field.isLabelPresent()) {
                    field.tap();
                } else {
                    log.error("Field '{}' has no label", arg1);
                }
            } else if (field.hasControlElement()) {
                field.tap();
            }
            else {
                log.error("Field '{}' has no control", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @Then("^I verify \"([^\"]*)\"'s pbx display name shows up at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void verifyContactNameAtIndex(String arg1, String arg2,String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg3.trim());
        String textAtIndex = phone2.appium().findElementByAccessibilityId("Contact name index " + arg2 + " title").getText();
        String contactName = phone1.callServerDetails().displayName;
        if(contactName.equals(textAtIndex))
            log.debug("Contact name '{}' showed up at index '{}' on '{}'", contactName, arg2, arg3);
        else {
            log.error("Contact name '{}' showed up at index '{}' on '{}' instead", textAtIndex, arg2, arg3);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\"'s pbx extension number shows up at index \"([^\"]*)\" on Biz Phone \"([^\"]*)\"$")
    public void verifyContactNumberAtIndex(String arg1, String arg2,String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg3.trim());
        String textAtIndex = phone2.appium().findElementByAccessibilityId("Contact number index " + arg2+" title").getText();
        String contactNumber = phone1.callServerDetails().extensionReg1;
        if(contactNumber.equals(textAtIndex))
            log.debug("Contact number '{}' showed up at index '{}' on '{}'", contactNumber, arg2, arg3);
        else {
            log.error("Contact number '{}' showed up at index '{}' on '{}' instead", textAtIndex, arg2, arg3);
            Environment.softAssert().fail("INCORRECT BIZ PHONE VALUE");
        }
    }
}
