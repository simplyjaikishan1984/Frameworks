package com.spectralink.test_automation.cucumber.framework.sam.pages;

import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamConfigurationPage;
import org.apache.commons.text.WordUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.common.Html5DragAndDrop.Position.Center;
import static com.spectralink.test_automation.cucumber.framework.common.Html5DragAndDrop.html5_DragAndDrop;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamManageGroupsPage extends SamBasePage {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	public enum GroupSearchMenu {
		GROUP_NAME("Group Name"),
		DEVICE_COUNT("Number of devices"),
		DEVICE_SERIALS("Device Serials"),
		USER_NAME("User Name");

		private final String menuText;

		public String title() {
			return menuText;
		}

		GroupSearchMenu(String level) {
			this.menuText = level;
		}
	}

	public enum DeviceSearchMenu {
		MAC("Device MAC Address"),
		SERIAL_NUMBER("Device Serial"),
		MODEL("Device Model"),
		SIP_1_EXTENSION("SIP Extension"),
		DEVICE_INFO_1("Device Info 1"),
		DEVICE_INFO_2("Device Info 2"),
		DEVICE_INFO_3("Device Info 3"),
		DEVICE_INFO_4("Device Info 4");

		private final String title;

		public String title() {
			return title;
		}

		DeviceSearchMenu(String title) {
			this.title = title;
		}
	}

	public enum Grid {
		Groups(1),
		Devices(3);

		private final Integer canvasIndex;

		public Integer index() {
			return canvasIndex;
		}

		Grid(Integer canvasIndex) {
			this.canvasIndex = canvasIndex;
		}
	}

	@FindBy(xpath = "//a[@id=\"leftPanel-Groups\"]")
	private WebElement groups;

	@FindBy(id = "groupName")
	private WebElement groupName;

	@FindBy(xpath = "//button[@ng-click=\"saveSelectedDevice()\"]")
	private WebElement selectDeviceButton;

	@FindBy(xpath = "//button[@ng-click=\"selectDevice()\"]")
	private WebElement selectDevicesButton;

	@FindBy(xpath = "//button[@ng-click=\"saveGroup()\"]")
	private WebElement saveButton;

	@FindBy(xpath = "//button[@ng-click=\"reset()\"]")
	private WebElement resetButton;

	@FindBy(xpath = "//select[@ng-click=\"emptySearchField()\"]")
	private WebElement searchDropDown;

	@FindBy(xpath = "//input[@ng-model=\"searchTextValue\"]")
	private List<WebElement> searchInputbox;

	@FindBy(id = "groups-drop-down")
	private WebElement actionMenu;

	@FindBy(id = "groupslist-actions-groups")
	private WebElement deleteGroups;

	@FindBy(id = "groupslist-actions-editGroup")
	private WebElement editGroup;

	@FindBy(id = "groupslist-actions-changeConfig")
	private WebElement changeConfigs;

	@FindBy(xpath = "//div[@ng-click=\"headerButtonClick($event)\"]")
	private List<WebElement> headerCheckbox;

	@FindBy(xpath = "//div[@ng-click=\"selectButtonClick(row, $event)\"]")
	private List<WebElement> checkboxes;

	@FindBy(xpath = "//*[starts-with(@id, \"associatedGroup-grid-selection\")]")
	private List<WebElement> deviceCheckboxes;

	@FindBy(id = "associatedGroup-grid-selection-0")
	private WebElement selectAllDevicesCheckbox;

	@FindBy(xpath = "//*[starts-with(@id, \"group-grid-selection\")]")
	private List<WebElement> groupCheckboxes;

	@FindBy(id = "group-grid-selection-0")
	private WebElement selectAllGroupsCheckbox;

	@FindBy(xpath = "//select[@ng-click=\"emptySearchField()\"]")
	private List<WebElement> searchMenus;

	@FindBy(id = "leftPanel-icon-expand")
	private WebElement expandMenuBtn;

	@FindBy(css = ".selectGroupDeviceSelect")
	private WebElement selectGroupDeviceSelect;

	@FindBy(className = "txtBoxGroupDeviceSelect")
	private WebElement txtBoxGroupDeviceSelect;

	@FindBy(xpath = "//div[contains(@class, 'ui-grid-cell-contents') and @role='gridcell']")
	private List<WebElement> groupList;

	@FindBy(id = "searchclear")
	private WebElement clearButton;

	@FindBy(xpath = "//span[contains(text(), 'Group Name')]")
	private WebElement sortByGroupName;

	@FindBy(xpath = "//span[contains(text(), 'Device Serials')]")
	private WebElement sortByDeviceSerials;

	@FindBy(xpath = "//span[contains(text(), 'User Name')]")
	private WebElement sortByUserName;

	@FindBy(xpath = "//div[@aria-sort='descending']")
	private WebElement descendingOrder;

	@FindBy(xpath = "//div[@aria-sort='none']")
	private WebElement noneOrder;

	@FindBy(xpath = "//div[@aria-sort='ascending']")
	private WebElement ascendingOrder;

	@FindBy(xpath = "//button[@ng-click=\"ok()\"]")
	private WebElement okButton;

	@FindBy(className = "ui-grid-draggable-row")
	private List<WebElement> draggableRow;

	@FindBy(className = "selected-associated-devices")
	private List<WebElement> deviceSerials;

	@FindBy(xpath = "//span[@ng-click=\"removeSelectedAssociateDevice(deviceList.deviceMac)\"]")
	private List<WebElement> deviceRemove;

	@FindBy(id = "device-for-group-head")
	private WebElement deviceDialog;

	@FindBy(xpath = "//img[@ng-click=\"cancelModal()\"]")
	private WebElement cancelDeviceDialog;

	@FindBy(className = "badge")
	private List<WebElement> tallies;

	public SamManageGroupsPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public WebElement getGroupCheckBox(int index) {
		return groupCheckboxes.get(index);
	}

	public WebElement getDeviceCheckBox(int index) {
		return deviceCheckboxes.get(index);
	}

	public void selectAllGroups() {
		clickOnPageEntity(selectAllGroupsCheckbox);
	}

	public void selectAllDevices() {
		clickOnPageEntity(selectAllDevicesCheckbox);
	}

	public void clickSelectDevicesButton() {
		clickOnPageEntity(selectDevicesButton);
	}

	public void clickSelectDeviceSaveButton() {
		clickOnPageEntity(selectDeviceButton);
		sleepSeconds(2);
	}

	public void clickSaveButton() {
		clickOnPageEntity(saveButton);
		sleepSeconds(2);
	}

	public void clickResetButton() {
		clickOnPageEntity(resetButton);
	}

	public void enterGroupName(String newName) {
		typeIntoPageEntity(groupName, newName);
	}

	public SamConfigurationPage selectChangeConfig() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(changeConfigs);
		return new SamConfigurationPage();
	}

	public void selectDeleteGroups() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(deleteGroups);
	}

	public void selectEditGroup() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(editGroup);
	}

	public void clickSearchClearButton() {
		clickOnPageEntity(clearButton);
		sleepSeconds(1);
	}

	public Map<String, WebElement> getDeviceBubbles() {
        Map<String, WebElement> bubbles = new HashMap<>();
        for (WebElement bubble : deviceSerials) {
            String bubbleText = bubble.getAttribute("innerText").trim();
            String serial = bubbleText.substring(0, bubbleText.indexOf(" "));
            bubbles.put(serial, bubble);
        }
        return bubbles;
    }

    public void closeDeviceBubble(String serial) {
        Map<String, WebElement> bubbles = getDeviceBubbles();
        if (isBubblePresent(serial)) {
            WebElement closeButton = bubbles.get(serial).findElement(By.tagName("span"));
            clickOnPageEntity(closeButton);
        }
    }

    public boolean isBubblePresent(String serial) {
        List<String> bubbleSerials = new ArrayList<>(getDeviceBubbles().keySet());
        return bubbleSerials.contains(serial);
    }

	public boolean deviceSelectDialogShowing() {
		return isPresent(By.id("device-for-group-head"));
	}

	public boolean groupIsVisible(String name) {
		int rowIndex = getRowIndexOfColumnValue(name, 1, Grid.Groups.index());
		return rowIndex != -1;
	}

	public boolean deviceIsVisible(String mac) {
		int rowIndex = getRowIndexOfColumnValue(mac, 1, Grid.Devices.index());
		return rowIndex != -1;
	}

	public boolean phoneIsVisibleInGroup(String name, String serial) {
		int rowIndex = getRowIndexOfColumnValue(name, 1, Grid.Groups.index());
		if (rowIndex != -1) {
			String cellContents = getGridCellValue((rowIndex + 1), 2, Grid.Groups.index());
			return cellContents.contains(serial);
		}
		return false;
	}

	public void dragGroupToTop(String groupName) {
		int rowIndex = getRowIndexOfColumnValue(groupName, 1, Grid.Groups.index());
		if (rowIndex > 0) {
			WebElement row = getRowElement((rowIndex + 1), Grid.Groups.index());
			WebElement firstrow = getRowElement(1, Grid.Groups.index());
			html5_DragAndDrop(driver, row, firstrow, Center, Center);
			sleepSeconds(1);
			log.debug("Moved group '{}' to top priority", groupName);
		}
	}

	public void deleteSelectedGroup() {
		setTemporaryWait(1);
		if (isEntityClickable(clearButton)) clickSearchClearButton();
		selectDeleteGroups();
		clickOnPageEntity(okButton);
		removeTemporaryWait();
		sleepSeconds(2);
	}

	public void deleteAllGroups() {
		setTemporaryWait(1);
		if (isEntityClickable(clearButton)) clickSearchClearButton();
		selectAllGroups();
		selectDeleteGroups();
		clickOnPageEntity(okButton);
		removeTemporaryWait();
		sleepSeconds(2);
	}

	public void selectSearchType(GroupSearchMenu option) {
		selectMenuByText(searchMenus.get(0), option.title());
	}

	public void enterSearchValue(String value) {
		typeIntoPageEntity(searchInputbox.get(0), value);
	}

	public int getGroupRowCount() {
		return getRowCount(Grid.Groups.index());
	}

	public int getDeviceRowCount() {
		if (deviceSelectDialogShowing()) {
			return getRowCount(Grid.Devices.index());
		}
		return -1;
	}

	public void selectGroupByName(String groupName) {
		int rowIndex = getRowIndexOfColumnValue(groupName, 1, Grid.Groups.index());
		WebElement checkbox = getGroupCheckBox(rowIndex + 1);
		if (!checkbox.getAttribute("class").contains("ui-grid-row-selected")) {
			clickOnPageEntity(checkbox);
		}
	}

	public void clickDeviceByMac(String macAddress) {
		if (deviceSelectDialogShowing()) {
			int rowIndex = getRowIndexOfColumnValue(macAddress, 1, Grid.Devices.index());
			clickOnPageEntity(getGroupCheckBox(rowIndex + 1));
		}
	}

	public void clickDeviceBySerial(String serial) {
		if (deviceSelectDialogShowing()) {
			int rowIndex = getRowIndexOfColumnValue(serial, 2, Grid.Devices.index());
			clickOnPageEntity(getGroupCheckBox(rowIndex + 1));
		}
	}

	public int getDeviceCount(String groupName) {
		int rowIndex = getRowIndexOfColumnValue(groupName, 1, Grid.Groups.index());
		if (rowIndex != -1) {
			String cellContents = getGridCellValue((rowIndex + 1), 2, Grid.Groups.index());
			return Integer.parseInt(cellContents);
		}
		return rowIndex;
	}

	public void selectDevice(String serial) {
		int rowIndex = getRowIndexOfColumnValue(serial, 2, Grid.Devices.index());
		WebElement checkbox = getDeviceCheckBox(rowIndex + 1);
		if (!checkbox.getAttribute("class").contains("ui-grid-row-selected")) {
			clickOnPageEntity(checkbox);
		}
	}

	public void selectDeviceSearchType(DeviceSearchMenu option) {
		if (deviceSelectDialogShowing()) {
			selectMenuByText(searchMenus.get(1), option.title());
		}
	}

	public void enterDeviceSearchValue(String value) {
		if (deviceSelectDialogShowing()) {
			typeIntoPageEntity(searchInputbox.get(2), value);
			sleepSeconds(1);
		}
	}

	public void clickDeviceCloseButton() {
		if (deviceSelectDialogShowing()) {
			clickOnPageEntity(cancelDeviceDialog);
		}
	}

	public void unselectDevice(String serial) {
		int rowIndex = getRowIndexOfColumnValue(serial, 2, Grid.Devices.index());
		WebElement checkbox = getDeviceCheckBox(rowIndex + 1);
		if (checkbox.getAttribute("class").contains("ui-grid-row-selected")) {
			clickOnPageEntity(checkbox);
		}
	}

	public GroupSearchMenu getGroupMenuOption(String title) {
		for (GroupSearchMenu option : GroupSearchMenu.values()) {
			if (option.title().toLowerCase().contentEquals(title.trim().toLowerCase())) {
				return option;
			}
		}
		return null;
	}

	public DeviceSearchMenu getDeviceMenuOption(String title) {
		for (DeviceSearchMenu option : DeviceSearchMenu.values()) {
			if (option.title().toLowerCase().contentEquals(title.trim().toLowerCase())) {
				return option;
			}
		}
		return null;
	}

	public int getDeviceTally(String name) {
		if (deviceSelectDialogShowing()) {
			for (WebElement badge : tallies) {
				String badgeText = badge.getAttribute("innerText");
				if (badgeText.contains(WordUtils.capitalize(name))) {
					String count = badgeText.substring(0, badgeText.indexOf(" ")).trim();
					return Integer.parseInt(count);
				}
			}
		}
		return 0;
	}
}
