package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BizPhoneStrings.EDIT_TEXT;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BizPhoneStrings.OK_BUTTON;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.SafeStrings.*;

public class SafeUi extends AppiumUi {

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    public ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            overflowButton,
            overflowButton,
            null
    );

    @AndroidFindBy(accessibility = "Motion sensor configuration title")
    private WebElement motionSensorConfigLabel;

    @AndroidFindBy(accessibility = "Motion sensor configuration summary")
    private WebElement motionSensorConfigValue;

    public ConfigUiField motionSensorConfigField = new ConfigUiField(
            driver,
            MOTION_SENSOR_CONFIGURATION,
            motionSensorConfigLabel,
            motionSensorConfigLabel,
            motionSensorConfigValue
    );

    @AndroidFindBy(accessibility = "Panic button configuration title")
    private WebElement panicButtonConfigLabel;

    @AndroidFindBy(accessibility = "Panic button configuration summary")
    private WebElement panicButtonConfigValue;

    public ConfigUiField panicButtonConfigField = new ConfigUiField(
            driver,
            PANIC_BUTTON_CONFIGURATION,
            panicButtonConfigLabel,
            panicButtonConfigLabel,
            panicButtonConfigValue
    );

    @AndroidFindBy(accessibility = "Emergency call configuration title")
    private WebElement emergencyConfigLabel;

    @AndroidFindBy(accessibility = "Emergency call configuration summary")
    private WebElement emergencyConfigValue;

    public ConfigUiField emergencyConfigField = new ConfigUiField(
            driver,
            EMERGENCY_CALL_CONFIGURATION,
            emergencyConfigLabel,
            emergencyConfigLabel,
            emergencyConfigValue
    );

    @AndroidFindBy(accessibility = "SAFE tone configuration title")
    private WebElement safeToneConfigLabel;

    @AndroidFindBy(accessibility = "SAFE tone configuration summary")
    private WebElement safeToneConfigValue;

    public ConfigUiField safeToneConfigField = new ConfigUiField(
            driver,
            SAFE_TONE_CONFIGURATION,
            safeToneConfigLabel,
            safeToneConfigLabel,
            safeToneConfigValue
    );

    @AndroidFindBy(accessibility = "Emergency tone configuration title")
    private WebElement emergencyToneConfigLabel;

    @AndroidFindBy(accessibility = "Emergency tone configuration summary")
    private WebElement emergencyToneConfigValue;

    public ConfigUiField emergencyToneConfigField = new ConfigUiField(
            driver,
            EMERGENCY_TONE_CONFIGURATION,
            emergencyToneConfigLabel,
            emergencyToneConfigLabel,
            emergencyToneConfigValue
    );

    @AndroidFindBy(accessibility = "Monitoring title")
    private WebElement monitoringEnabledLabel;

    @AndroidFindBy(accessibility = "Monitoring summary")
    private WebElement monitoringEnabledValue;

    @AndroidFindBy(accessibility = "Monitoring switch")
    private WebElement monitoringEnabledControl;

    public ConfigUiField monitoringEnabledField = new ConfigUiField(
            driver,
            MONITORING,
            monitoringEnabledLabel,
            monitoringEnabledValue,
            monitoringEnabledControl
    );

    @AndroidFindBy(accessibility = "No movement sensitivity title")
    private WebElement noMoveSensitivityLabel;

    @AndroidFindBy(accessibility = "No movement sensitivity summary")
    private WebElement noMoveSensitivityValue;

    public ConfigUiField noMoveSensitivityField = new ConfigUiField(
            driver,
            NO_MOVEMENT_SENSITIVITY,
            noMoveSensitivityLabel,
            noMoveSensitivityLabel,
            noMoveSensitivityValue
    );

    @AndroidFindBy(accessibility = "No movement timeout (seconds) title")
    private WebElement noMoveTimeoutLabel;

    @AndroidFindBy(accessibility = "No movement timeout (seconds) summary")
    private WebElement noMoveTimeoutValue;

    public ConfigUiField noMoveTimeoutField = new ConfigUiField(
            driver,
            NO_MOVEMENT_TIMEOUT,
            noMoveTimeoutLabel,
            noMoveTimeoutLabel,
            noMoveTimeoutValue
    );

    @AndroidFindBy(accessibility = "Tilt sensitivity title")
    private WebElement tiltSensitivityLabel;

    @AndroidFindBy(accessibility = "Tilt sensitivity summary")
    private WebElement tiltSensitivityValue;

    public ConfigUiField tiltSensitivityField = new ConfigUiField(
            driver,
            TILT_SENSITIVITY,
            tiltSensitivityLabel,
            tiltSensitivityLabel,
            tiltSensitivityValue
    );

    @AndroidFindBy(accessibility = "Tilt timeout (seconds) title")
    private WebElement tiltTimeoutLabel;

    @AndroidFindBy(accessibility = "Tilt timeout (seconds) summary")
    private WebElement tiltTimeoutValue;

    public ConfigUiField tiltTimeoutField = new ConfigUiField(
            driver,
            TILT_TIMEOUT,
            tiltTimeoutLabel,
            tiltTimeoutLabel,
            tiltTimeoutValue
    );

    @AndroidFindBy(accessibility = "Running sensitivity title")
    private WebElement runningSensitivityLabel;

    @AndroidFindBy(accessibility = "Running sensitivity summary")
    private WebElement runningSensitivityValue;

    public ConfigUiField runningSensitivityField = new ConfigUiField(
            driver,
            RUNNING_SENSITIVITY,
            runningSensitivityLabel,
            runningSensitivityLabel,
            runningSensitivityValue
    );

    @AndroidFindBy(accessibility = "Running timeout (seconds) title")
    private WebElement runningTimeoutLabel;

    @AndroidFindBy(accessibility = "Running timeout (seconds) summary")
    private WebElement runningTimeoutValue;

    public ConfigUiField runningTimeoutField = new ConfigUiField(
            driver,
            RUNNING_TIMEOUT,
            runningTimeoutLabel,
            runningTimeoutLabel,
            runningTimeoutValue
    );

    @AndroidFindBy(accessibility = "Snooze timeout (seconds) title")
    private WebElement snoozeTimeoutLabel;

    @AndroidFindBy(accessibility = "Snooze timeout (seconds) summary")
    private WebElement snoozeTimeoutValue;

    public ConfigUiField snoozeTimeoutField = new ConfigUiField(
            driver,
            SNOOZE_TIMEOUT,
            snoozeTimeoutLabel,
            snoozeTimeoutLabel,
            snoozeTimeoutValue
    );

    @AndroidFindBy(accessibility = "Warning timeout (seconds) title")
    private WebElement warningTimeoutLabel;

    @AndroidFindBy(accessibility = "Warning timeout (seconds) summary")
    private WebElement warningTimeoutValue;

    public ConfigUiField warningTimeoutField = new ConfigUiField(
            driver,
            WARNING_TIMEOUT,
            warningTimeoutLabel,
            warningTimeoutLabel,
            warningTimeoutValue
    );

    @AndroidFindBy(accessibility = "Panic button title")
    private WebElement panicButtonLabel;

    @AndroidFindBy(accessibility = "Panic button summary")
    private WebElement panicButtonValue;

    public ConfigUiField panicButtonField = new ConfigUiField(
            driver,
            PANIC_BUTTON,
            panicButtonLabel,
            panicButtonLabel,
            panicButtonValue
    );

    @AndroidFindBy(accessibility = "Panic button silent alarm title")
    private WebElement panicButtonSilentAlarmLabel;

    @AndroidFindBy(accessibility = "Panic button silent alarm summary")
    private WebElement panicButtonSilentAlarmValue;

    @AndroidFindBy(accessibility = "Panic button silent alarm switch")
    private WebElement panicButtonSilentAlarmControl;

    public ConfigUiField panicButtonSilentAlarmField = new ConfigUiField(
            driver,
            PANIC_BUTTON_SILENT_ALARM,
            panicButtonSilentAlarmLabel,
            panicButtonSilentAlarmControl,
            panicButtonSilentAlarmValue
    );

    @AndroidFindBy(accessibility = "Emergency call title")
    private WebElement emergencyCallLabel;

    @AndroidFindBy(accessibility = "Emergency call summary")
    private WebElement emergencyCallValue;

    @AndroidFindBy(accessibility = "Emergency call switch")
    private WebElement emergencyCallControl;

    public ConfigUiField emergencyCallField = new ConfigUiField(
            driver,
            EMERGENCY_CALL,
            emergencyCallLabel,
            emergencyCallControl,
            emergencyCallValue
    );

    @AndroidFindBy(accessibility = "Emergency dial force speaker title")
    private WebElement emergencyDialForceSpeakerLabel;

    @AndroidFindBy(accessibility = "Emergency dial force speaker summary")
    private WebElement emergencyDialForceSpeakerValue;

    @AndroidFindBy(accessibility = "Emergency dial force speaker switch")
    private WebElement emergencyDialForceSpeakerControl;

    public ConfigUiField emergencyDialForceSpeakerField = new ConfigUiField(
            driver,
            EMERGENCY_DIAL_FORCE_SPEAKER,
            emergencyDialForceSpeakerLabel,
            emergencyDialForceSpeakerControl,
            emergencyDialForceSpeakerValue
    );

    @AndroidFindBy(accessibility = "Emergency dial number title")
    private WebElement emergencyDialNumberLabel;

    @AndroidFindBy(accessibility = "Emergency dial number summary")
    private WebElement emergencyDialNumberValue;

    public ConfigUiField emergencyDialNumberField = new ConfigUiField(
            driver,
            EMERGENCY_DIAL_NUMBER,
            emergencyDialNumberLabel,
            emergencyDialNumberLabel,
            emergencyDialNumberValue
    );

    @AndroidFindBy(accessibility = "Alarm timeout title")
    private WebElement alarmTimeoutLabel;

    @AndroidFindBy(accessibility = "Alarm timeout summary")
    private WebElement alarmTimeoutValue;

    public ConfigUiField alarmTimeoutField = new ConfigUiField(
            driver,
            ALARM_TIMEOUT,
            alarmTimeoutLabel,
            alarmTimeoutLabel,
            alarmTimeoutValue
    );

    @AndroidFindBy(accessibility = "Alarm tone title")
    private WebElement alarmToneLabel;

    @AndroidFindBy(accessibility = "Alarm tone summary")
    private WebElement alarmToneValue;

    public ConfigUiField alarmToneField = new ConfigUiField(
            driver,
            ALARM_TONE,
            alarmToneLabel,
            alarmToneLabel,
            alarmToneValue
    );

    @AndroidFindBy(accessibility = "Warning tone title")
    private WebElement warningToneLabel;

    @AndroidFindBy(accessibility = "Warning tone summary")
    private WebElement warningToneValue;

    public ConfigUiField warningToneField = new ConfigUiField(
            driver,
            WARNING_TONE,
            warningToneLabel,
            warningToneLabel,
            warningToneValue
    );

    @AndroidFindBy(id = "android:id/edit")
    private WebElement editText;

    private final ConfigUiField editTextField = new ConfigUiField(
            driver,
            EDIT_TEXT,
            null,
            editText,
            null
    );

    @AndroidFindBy(id = "android:id/button1")
    private WebElement okButton;

    private final ConfigUiField okButtonField = new ConfigUiField(
            driver,
            OK_BUTTON,
            null,
            okButton,
            null
    );

    @AndroidFindBy(accessibility = "Navigate up")
    private WebElement backButton;

    public ConfigUiField backButtonField = new ConfigUiField(
            driver,
            BACK_ARROW,
            null,
            backButton,
            null
    );

    @AndroidFindBy(accessibility = "Alarm type title")
    private WebElement alarmType;

    @AndroidFindBy(accessibility = "Event type title")
    private WebElement eventType;

    @AndroidFindBy(accessibility = "Cancel textview title")
    private WebElement cancelText;

    @AndroidFindBy(accessibility = "Alarm timer textview title")
    private WebElement alarmTimer;

    @AndroidFindBy(accessibility = "Panic button enabled")
    private WebElement panicButtonIcon;

    @AndroidFindBy(accessibility = "Swipe arrow")
    private WebElement terminateAlarm;


    public SafeUi (AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(OVERFLOW_MENU.title().toLowerCase(), overflowButtonField);
                put(MOTION_SENSOR_CONFIGURATION.title().toLowerCase(), motionSensorConfigField);
                put(PANIC_BUTTON_CONFIGURATION.title().toLowerCase(), panicButtonConfigField);
                put(EMERGENCY_CALL_CONFIGURATION.title().toLowerCase(), emergencyConfigField);
                put(SAFE_TONE_CONFIGURATION.title().toLowerCase(), safeToneConfigField);
                put(EMERGENCY_TONE_CONFIGURATION.title().toLowerCase(), emergencyToneConfigField);
                put(MONITORING.title().toLowerCase(), monitoringEnabledField);
                put(NO_MOVEMENT_SENSITIVITY.title().toLowerCase(), noMoveSensitivityField);
                put(NO_MOVEMENT_TIMEOUT.title().toLowerCase(), noMoveTimeoutField);
                put(TILT_SENSITIVITY.title().toLowerCase(), tiltSensitivityField);
                put(TILT_TIMEOUT.title().toLowerCase(), tiltTimeoutField);
                put(RUNNING_SENSITIVITY.title().toLowerCase(), runningSensitivityField);
                put(RUNNING_TIMEOUT.title().toLowerCase(), runningTimeoutField);
                put(SNOOZE_TIMEOUT.title().toLowerCase(), snoozeTimeoutField);
                put(WARNING_TIMEOUT.title().toLowerCase(), warningTimeoutField);
                put(PANIC_BUTTON.title().toLowerCase(), panicButtonField);
                put(PANIC_BUTTON_SILENT_ALARM.title().toLowerCase(), panicButtonSilentAlarmField);
                put(BACK_ARROW.title().toLowerCase(), backButtonField);
                put(EMERGENCY_CALL.title().toLowerCase(), emergencyCallField);
                put(EMERGENCY_DIAL_FORCE_SPEAKER.title().toLowerCase(), emergencyDialForceSpeakerField);
                put(EMERGENCY_DIAL_NUMBER.title().toLowerCase(), emergencyDialNumberField);
                put(WARNING_TONE.title().toLowerCase(), warningToneField);
                put(ALARM_TONE.title().toLowerCase(), alarmToneField);
                put(EDIT_TEXT.title().toLowerCase(), editTextField);
                put(OK_BUTTON.title().toLowerCase(), okButtonField);
                put(ALARM_TIMEOUT.title().toLowerCase(),alarmTimeoutField);
            }
        };
    }

    public void enterInEditText(String editTextValue) {
        editText.sendKeys(editTextValue);
    }

    public void goBack() {
        backButton.click();
    }

    public String getEventType() {
        return eventType.getText();
    }

    public String getCancelText() {
        return cancelText.getText();
    }

    public void getAlarmTimer() {
        alarmTimer.getText();
    }

    public String getAlarmType() {
        return alarmType.getText();
    }

    public void clearEditText() {
        editText.clear();
    }

    public void enterEmergencyConfigSettings() {
        emergencyConfigLabel.click();
    }

    public void enterMonitoringSettings() {
        motionSensorConfigLabel.click();
    }

    public void enterPanicButtonSettings() {
        panicButtonConfigLabel.click();
    }

    public void enterSafeTonesSettings() {
        safeToneConfigLabel.click();
    }

    public Point getPanicButtonIconPosition() {
        int centerX = panicButtonIcon.getLocation().getX() + panicButtonIcon.getSize().getWidth() / 2;
        int centerY = panicButtonIcon.getLocation().getY() + panicButtonIcon.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }

    public Point getTerminateAlarmIconPosition() {
        int centerX = terminateAlarm.getLocation().getX() + terminateAlarm.getSize().getWidth() / 2;
        int centerY = terminateAlarm.getLocation().getY() + terminateAlarm.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }
}
