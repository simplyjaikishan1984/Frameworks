package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ButtonPressThread;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.PttUi;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.PTT;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.PttStrings.*;

public class DevicePttSteps {

	interface Comparison {
		boolean compare(VersityPhone dut, String target);
	}

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I tap the PTT \"([^\"]*)\" field on device \"([^\"]*)\"$")
	public void tapPttObject(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(arg1.trim().toLowerCase());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(field.getKey());
			field.tap();
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I tap the PTT \"([^\"]*)\" channel on device \"([^\"]*)\"$")
	public void tapChannel(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		List<Map<String, Object>> channels = pttUi.getChannels();
		boolean found = false;
		for (Map<String, Object> eachChannel : channels) {
			if (eachChannel.get("name").toString().contentEquals(arg1.trim())) {
				WebElement channelOption = (WebElement) eachChannel.get("element");
				pttUi.clickOnPageEntity(channelOption);
				found = true;
				break;
			}
		}
		if (!found) {
			log.error("No matching channel with title '{}'", arg1);
		}
	}

	@When("^I tap the PTT back arrow on device \"([^\"]*)\"$")
	public void tapBackArrow(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(BACK_ARROW);
		if (field.isLabelPresent()) {
			field.tap();
		} else {
			log.error("Back arrow was not visible on '{}'", arg1);
		}
	}

	@When("^I enter \"([^\"]*)\" into the PTT Username edit box on device \"([^\"]*)\"$")
	public void enterNameAddressText(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(EDIT_BOX);
		if (field.isLabelPresent()) {
			field.enter(arg1.trim());
		} else {
			log.error("Could not enter text into edit box on {}", arg2);
		}
	}

	@When("^I enter \"([^\"]*)\" into the PTT channel label edit box on device \"([^\"]*)\"$")
	public void enterChannelLabelText(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(CHANNEL_NAME_EDIT);
		if (field.isLabelPresent()) {
			field.enter(arg1.trim());
		} else {
			log.error("Could not enter text into edit box on {}", arg2);
		}
	}

	@When("^I print the last PTT activity on device \"([^\"]*)\"$")
	public void printActivity(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		PttUi pttUi = phone.getPttUi();
		List<Map<String, String>> activities = pttUi.getActivities();
		for (Map<String, String> eachActivity : activities) {
			log.debug("Channel: {}; Sender: {}; Timestamp: {}", eachActivity.get("channel"), eachActivity.get("sender"), eachActivity.get("timestamp"));
		}
		Map<String, String> activity = pttUi.getActivity(2);
		log.debug("Activity 2");
		log.debug("Channel: {}; Sender: {}; Timestamp: {}", activity.get("channel"), activity.get("sender"), activity.get("timestamp"));
	}

	@When("^I print the PTT subscribed channels on device \"([^\"]*)\"$")
	public void printChannels(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		PttUi pttUi = phone.getPttUi();
		List<Map<String, Object>> channels = pttUi.getChannels();
		for (Map<String, Object> eachChannel : channels) {
			log.debug("Subscribed: {}; Name: {}; Default: {}", eachChannel.get("subscribed"), eachChannel.get("name"), eachChannel.get("default"));
		}
		log.debug("Default channel = {}", pttUi.getDefaultChannel());
		log.debug("Current channel = {}", pttUi.getCurrentChannel());
	}

	@When("^I print the PTT channel setup on device \"([^\"]*)\"$")
	public void printChannelSetup(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		PttUi pttUi = phone.getPttUi();
		List<Map<String, String>> channels = pttUi.getFullChannelSetup();
		for (Map<String, String> eachChannel : channels) {
			log.debug("Name: {}; Transmit: {}; Subscribed: {}", eachChannel.get("name"), eachChannel.get("transmit"), eachChannel.get("subscribed"));
		}
	}

	@When("^I tap the PTT \"([^\"]*)\" tab on device \"([^\"]*)\"$")
	public void tapPttTab(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(arg1.trim().toLowerCase());
		FieldData heading = DeviceFields.getStrings(PTT, arg1.trim());
		if (field != null) {
			if (field.isLabelPresent()) {
				field.tap();
			} else {
				log.error("Field '{}' has no label", arg1);
			}
		} else {
			log.error("No matching tab with title '{}'", arg1);
		}
	}

	@When("^I set the PTT \"([^\"]*)\" switch to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void setPttSwitch(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(arg1.trim().toLowerCase());
		FieldData heading = DeviceFields.getStrings(PTT, arg1.trim());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(heading);
			if (!field.getControlElement().getText().toLowerCase().contentEquals(arg2.trim().toLowerCase())) {
				field.tap();
				sleepSeconds(2);
			} else {
				log.debug("Field '{}' was already set to '{}'", arg1, arg2);
			}
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I select \"([^\"]*)\" from the PTT overflow menu on device \"([^\"]*)\"$")
	public void selectPttOverflowOption(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(OVERFLOW_MENU);
		boolean found;
		if (field != null && field.isLabelPresent()) {
			pttUi.tapOverflowMenu();
			found = field.selectTextMenuOption(arg1.trim().toLowerCase());
			if (found) {
				log.debug("Selected menu option '{}'", arg1);
			} else {
				log.error("Could not find menu option '{}'", arg1);
			}
		} else {
			log.debug("The overflow menu was not visible on '{}'", arg1);
		}
	}

	@When("^I select \"([^\"]*)\" from the PTT menu \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void selectPttMenuOption(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(arg2.trim());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(field.getKey());
			boolean found;
			if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
				field.tap();
				found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
				if (found) {
					log.debug("Selected menu option '{}'", arg1);
					sleepSeconds(1);
				} else {
					log.error("Could not find menu option '{}'", arg1);
				}
			} else {
				log.debug("Field '{}' was already set to '{}'", arg3, arg1);
			}
		} else {
			log.error("No matching field with title '{}'", arg2);
		}
	}

	@When("^I slide the PTT 'PTT volume' slider to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void slidePttVolume(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(PTT_VOLUME);
		if (field != null) {
			field.updateSliderValue(Integer.parseInt(arg1.trim()), 0, 100);
		} else {
			log.error("No matching field with title '{}'", PTT_VOLUME.title());
		}
	}

	@When("^I tap the PTT 'Cancel' button on device \"([^\"]*)\"$")
	public void tapCancel(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		PttUi pttUi = phone.getPttUi();
		pttUi.tapCancelButton();
	}

	@When("^I tap the PTT 'OK' button on device \"([^\"]*)\"$")
	public void tapOk(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		PttUi pttUi = phone.getPttUi();
		pttUi.tapOkButton();
	}

	@When("^I delay \"([^\"]*)\" seconds then press and hold the PTT 'TRANSMIT' button for \"([^\"]*)\" seconds on device \"([^\"]*)\"$")
	public void pressAndHold(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(TRANSMIT);
		ButtonPressThread buttonPress = new ButtonPressThread(field, Integer.parseInt(arg1.trim()), Integer.parseInt(arg2.trim()), 12);
		Environment.setThread(new Thread(buttonPress));
		Environment.getThread().start();
	}

	@When("^I monitor the PTT states on device \"([^\"]*)\"$")
	public void monitorState(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (Environment.getThread() != null && Environment.getThread().isAlive()) {
			phone.pttContentProvider().recordStates(Environment.getThread());
		} else {
			log.error("No transmission was started before monitoring PTT states");
		}
	}

	@Then("^the PTT \"([^\"]*)\" states change appropriately on device \"([^\"]*)\"$")
	public void verifyStateChanges(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		List<String> columns = phone.pttContentProvider().getStatChanges("channelState");
		if (columns.size() > 0) {
			String[] expectedStates = new String[]{};
			if (arg1.trim().toLowerCase().contentEquals("receive")) {
				expectedStates = new String[]{"PTT_CHAN_STATE_IDLE", "PTT_CHAN_STATE_RECEIVE", "PTT_CHAN_STATE_WAITING", "PTT_CHAN_STATE_IDLE"};
			} else if (arg1.trim().toLowerCase().contentEquals("transmit")) {
				expectedStates = new String[]{"PTT_CHAN_STATE_IDLE", "PTT_CHAN_STATE_ALERT", "PTT_CHAN_STATE_TRANSMIT", "PTT_CHAN_STATE_EOT", "PTT_CHAN_STATE_WAITING", "PTT_CHAN_STATE_IDLE"};
			} else {
				log.error("No matching state with value '{}'", arg1);
			}
			int stateIndex = 0;
			int lastFoundIndex = 0;
			int foundStates = 0;
			while (stateIndex < expectedStates.length) {
				String targetState = expectedStates[stateIndex];
				int initialStateCount = foundStates;
				for (int searchIndex = lastFoundIndex; searchIndex < columns.size(); searchIndex++) {
					if (columns.get(searchIndex).contains(targetState)) {
						log.debug("Found expected {} state {} on {}", arg1.trim(), columns.get(searchIndex), arg2);
						lastFoundIndex = searchIndex;
						foundStates += 1;
						break;
					}
				}
				if (foundStates != initialStateCount + 1)
					log.fatal("Could not find state {} in {} broadcast on {}", targetState, arg1, arg2);
				stateIndex += 1;
			}
			Environment.softAssert().assertEquals(foundStates, expectedStates.length, "DID NOT FIND ALL EXPECTED " + arg1.toUpperCase() + " STATES");
		} else {
			log.error("No transmission was started before verifying PTT states");
		}
	}

	@Then("^the PTT \"([^\"]*)\" value is set to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifyPttValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(arg1.trim().toLowerCase());
		if (field.isValueAccessible()) {
			String fieldValue = field.getValueElement().getText().toLowerCase();
			if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
				log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
			} else {
				log.fatal("Field '{}' was set to '{}' rather than '{}' on device {}", arg1, fieldValue, arg2, arg3);
				Environment.softAssert().fail("INCORRECT BATT LIFE FIELD VALUE");
			}
		} else {
			log.error("Field '{}' was not accessible", arg1);
			Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
		}
	}

	@Then("^the PTT 'Current channel' value is set to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifyCurrentChannelValue(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(CURRENT_CHANNEL);
		if (field.isLabelPresent()) {
			String fieldValue = field.getValueElement().getText().toLowerCase();
			if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
				log.debug("Verified current channel was set to '{}'", arg1);
			} else {
				log.fatal("Current channel was set to '{}' rather than '{}' on device {}", fieldValue, arg1, arg2);
				Environment.softAssert().fail("INCORRECT CURRENT CHANNEL VALUE");
			}
		} else {
			log.error("Current channel field was not accessible");
			Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
		}
	}

	@Then("^the 'PTT service is running' banner is visible on device \"([^\"]*)\"$")
	public void verifyPttBannerVisible(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		PttUi pttUi = phone.getPttUi();
		ConfigUiField field = pttUi.getField(RUNNING_BANNER);
		String banner = "PTT service is running";
		if (field.isLabelPresent()) {
			String fieldValue = field.getValueElement().getText();
			if (fieldValue.contentEquals(banner)) {
				log.debug("Verified service banner was set to '{}' on device {}", banner, arg1);
			} else {
				log.fatal("Service banner was set to '{}' rather than '{}' on device {}", fieldValue, banner, arg1);
				Environment.softAssert().fail("INCORRECT PTT SERVICE BANNER");
			}
		} else {
			log.error("Service banner was not visible on device {}", arg1);
			Environment.softAssert().fail("BANNER NOT VISIBLE");
		}
	}

	@Then("^the last activity was from a \"([^\"]*)\" user named \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifyLastUser(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		if (phone.pttContentProvider().areStatesRecorded()) {
			Map<String, Object> activity = phone.pttContentProvider().getLastActivity();
			if (activity.size() > 0) {
				if (arg1.trim().toLowerCase().contentEquals("local")) {
					String foundUser = phone.pttContentProvider().getLocalUserName(activity).toLowerCase();
					Environment.softAssert().assertEquals(foundUser, arg2.trim().toLowerCase(), "INCORRECT LOCAL USER");
					log.debug("Last {} activity was from user {}", arg1, arg2);
				} else if (arg1.trim().toLowerCase().contentEquals("remote")) {
					String foundUser = phone.pttContentProvider().getRemoteUserName(activity).toLowerCase();
					Environment.softAssert().assertEquals(foundUser, arg2.trim().toLowerCase(), "INCORRECT REMOTE USER");
					log.debug("Last {} activity was from user {}", arg1, arg2);
				} else {
					log.error("User of type '{}' is invalid", arg1);
					Environment.softAssert().fail("INVALID USER TYPE");
				}
			} else {
				log.error("No {} was recorded on device {}", arg1, arg3);
				Environment.softAssert().fail("NO ACTIVITY WAS RECORDED");
			}
		} else {
			log.error("No states were recorded on device {}", arg3);
			Environment.softAssert().fail("NO ACTIVITIES WERE RECORDED");
		}
	}

	@Then("^the last activity was on channel \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifyLastChannelUser(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		if (phone.pttContentProvider().areStatesRecorded()) {
			Map<String, Object> activity = phone.pttContentProvider().getLastActivity();
			if (activity.size() > 0) {
				Integer focusChannel = phone.pttContentProvider().getFocusChannel(activity);
				log.debug("Last activity found was transmitted on channel {}", focusChannel);
				Environment.softAssert().assertEquals(focusChannel, Integer.valueOf(arg1.trim()), "INCORRECT FOCUS CHANNEL");
			} else {
				log.error("No activity was recorded on device {}", arg2);
				Environment.softAssert().fail("NO ACTIVITY WAS RECORDED");
			}
		} else {
			log.error("No states were recorded on device {}", arg2);
			Environment.softAssert().fail("NO STATES WERE RECORDED");
		}
	}

	@Then("^the PTT channel \"([^\"]*)\" is visible on device \"([^\"]*)\"$")
	public void verifyChannelVisible(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		try {
			pttUi.scrollIntoView(arg1.trim());
			log.debug("Found channel '{}' listed on device {}", arg1, arg2);
		} catch(NoSuchElementException nsee) {
			log.fatal("Channel '{}' was not visible on device {}", arg1, arg2);
			Environment.softAssert().fail("COULD NOT LOCATE CHANNEL");
		}
	}

	@Then("^transmit for PTT channel \"([^\"]*)\" is disabled on device \"([^\"]*)\"$")
	public void verifyChannelTransmitDisabled(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		Map<String, Object> channel = pttUi.getChannelInfo(arg1.trim());
		boolean transmitEnabled = channel.containsKey("transmit") && Boolean.parseBoolean(channel.get("transmit").toString());
		if (!transmitEnabled) {
			log.debug("Channel '{}' cannot transmit", arg1);
		} else {
			log.fatal("Channel '{}' transmit is enabled on device {}", arg1, arg2);
			Environment.softAssert().fail("CHANNEL TRANSMIT IS ENABLED");
		}
	}

	@Then("^transmit for PTT channel \"([^\"]*)\" is enabled on device \"([^\"]*)\"$")
	public void verifyChannelTransmitEnabled(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		Map<String, Object> channel = pttUi.getChannelInfo(arg1.trim());
		boolean transmitEnabled = channel.containsKey("transmit") && Boolean.parseBoolean(channel.get("transmit").toString());
		if (transmitEnabled) {
			log.debug("Channel '{}' can transmit", arg1);
		} else {
			log.fatal("Channel '{}' transmit is disabled on device {}", arg1, arg2);
			Environment.softAssert().fail("CHANNEL TRANSMIT IS DISABLED");
		}
	}

	@When("^the PTT 'Current channel' is set to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void getState(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		PttUi pttUi = phone.getPttUi();
		String currentChannel = pttUi.getCurrentChannel();
		if (currentChannel.contentEquals(arg1.trim())) {
			log.debug("Current channel was '{}' on device {}", arg1, arg2);
		} else {
			log.fatal("Current channel was '{}' instead of expected '{}' on device {}", currentChannel, arg1, arg2);
			Environment.softAssert().fail("INCORRECT CHANNEL NAME");
		}
	}
}