package com.spectralink.test_automation.cucumber.framework.device.common;

import com.spectralink.test_automation.cucumber.framework.common.CliResult;
import com.spectralink.test_automation.cucumber.framework.common.Shell;
import com.spectralink.test_automation.cucumber.framework.common.Util;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServerHasNotBeenStartedLocallyException;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;
import org.apache.commons.exec.ExecuteWatchdog;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class AppiumService {
    private Integer port;
    private String serial;
    private boolean running = false;
    private final long serverStartupTimeout = 180000L;
    private final long serverRuntimeLimit = 3600000L;
    private ExecuteWatchdog watchdog;

    private AppiumServiceBuilder builder;
    private AppiumDriverLocalService service;
    private DesiredCapabilities capabilities;

    private AppiumDriver driver;

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    public AppiumService(String serial, Integer port) {
        this.serial = serial;
        this.port = port;
    }

    public Integer getPort() {
        return port;
    }

    public String getSerial() {
        return serial;
    }

    public boolean isRunning() {
        return running;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }

    public boolean start() {
        builder = new AppiumServiceBuilder();
        builder.withIPAddress("127.0.0.1");
        builder.usingPort(getPort());
        builder.withCapabilities(capabilities);
        builder.withArgument(GeneralServerFlag.SESSION_OVERRIDE);
        builder.withArgument(GeneralServerFlag.LOG_LEVEL,"error");
        builder.withArgument(GeneralServerFlag.RELAXED_SECURITY);
        builder.withLogFile(new File("appium-" + getPort() + ".log"));
        service = AppiumDriverLocalService.buildService(builder);
        try {
            service.start();
            log.debug("Started Appium server for phone {} on port {}", getSerial(), getPort());
            return true;
        } catch (AppiumServerHasNotBeenStartedLocallyException shnbs) {
            log.error("Failed to start Appium server: {}", shnbs.getMessage());
            return false;
        }
    }

    public void stopNode() {
        ArrayList<String> killCommand = new ArrayList<>();
        if (Util.isLinux()) {
            killCommand.add("killall");
            killCommand.add("node");
        } else {
            killCommand.add("taskkill");
            killCommand.add("/F");
            killCommand.add("/IM");
            killCommand.add("node.exe");
        }

        Shell shell = new Shell();
        CliResult result = shell.executeCommand(killCommand);
        if (result.commandSucceeded()) {
            log.debug("Node process was killed");
        } else {
            log.debug("Node process may have been killed already: exit code {}", result.getExitCode());
        }
    }

    public void stopAdb() {
        ArrayList<String> killCommand = new ArrayList<>();
        killCommand.add("adb");
        killCommand.add("kill-server");

        Shell shell = new Shell();
        CliResult result = shell.executeCommand(killCommand);
        if (result.commandSucceeded()) {
            log.debug("ADB process was killed");
        } else {
            log.debug("ADB process may have been killed already: exit code {}", result.getExitCode());
        }
    }

    public boolean stopServer() {
        boolean success = false;
        if (service != null) {
            service.stop();
            if (!service.isRunning()) {
                success = true;
                setRunning(false);
                log.info("Appium server was shut down");
            } else {
                log.warn("Appium server was not stopped");
            }
        } else {
            log.warn("Appium server was never started");
            return false;
        }
        return service.isRunning();
    }
}
