package com.spectralink.test_automation.cucumber.framework.sam.common;

import com.spectralink.test_automation.cucumber.framework.common.*;
import org.apache.commons.exec.ExecuteWatchdog;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.*;
import static com.spectralink.test_automation.cucumber.framework.sam.common.Simulator.DeviceFileColumns.*;

public class Simulator {

	public enum DeviceFileColumns implements CSVHeading {
		MODEL("model"),
		SERIAL("serial"),
		MAC("mac");

		private final String title;

		public String getTitle() {
			return title;
		}

		DeviceFileColumns(String title) {
			this.title = title;
		}
	}

	public enum DefaultPhones {
		DefaultPhone1("10:11:11:11:11:11", "4187890779"),
		DefaultPhone2("22:22:22:22:22:22", "64005690"),
		DefaultPhone3("32:33:33:33:33:33", "1256156251"),
		DefaultPhone4("44:44:44:44:44:44", "1427238458"),
		DefaultPhone5("54:55:55:55:55:55", "2619389019"),
		DefaultPhone6("66:66:66:66:66:66", "2790471226"),
		DefaultPhone7("76:77:77:77:77:77", "3982621787"),
		DefaultPhone8("88:88:88:88:88:88", "4153703994"),
		DefaultPhone9("98:99:99:99:99:99", "1050887259");


		private final String mac;
		private final String serial;

		public String getMac() {
			return mac;
		}

		public String getSerial() {
			return serial;
		}

		DefaultPhones(String macAddress, String serialNumber) {
			this.mac = macAddress;
			this.serial = serialNumber;
		}
	}

	private Logger log = LogManager.getLogger(this.getClass().getName());
	private final String spectralinkRealm = "00:90:7a";
	private final long defaultTimeout = 21600000L;
	private String simulatorPath = "bin/ironmanLoadTest-jar-with-dependencies.jar";
	private String deviceFileName = "simulator_devices.csv";
	private String msAddress;
	private String msAccountKey;
	private Boolean ackConfig;
	private File deviceFile;
	private Integer deviceHttpTimeout;
	private String deviceModel;
	private Integer deviceCount;
	private String deviceType;
	private Integer deviceHearbeatInterval = 20;
	private File phoenixConfigFile;
	private Boolean keepConfig;
	private Integer maxThreads;
	private Boolean pullConfig;
	private Integer runTime = 0;
	private String serverUrl;
	private Integer simulatorHttpTimeout;
	private ExecuteWatchdog watchdog;
	private CSVStructuredFile deviceCsv;
	private List<String> modelNumbers = new ArrayList<>();
	private Integer modelNumberIndex;
	private boolean running = false;

	public Simulator(String msAddress, String msAccountKey) {
		this.msAddress = msAddress;
		this.msAccountKey = msAccountKey;
	}

	public String getSimulatorPath() {
		return simulatorPath;
	}

	public void setSimulatorPath(String simulatorPath) {
		this.simulatorPath = simulatorPath;
	}

	public String getDeviceFileName() {
		return deviceFileName;
	}

	public void setDeviceFileName(String deviceFileName) {
		this.deviceFileName = deviceFileName;
	}

	public String getMsAddress() {
		return msAddress;
	}

	public void setMsAddress(String msAddress) {
		this.msAddress = msAddress;
	}

	public String getMsAccountKey() {
		return msAccountKey;
	}

	public void setMsAccountKey(String msAccountKey) {
		this.msAccountKey = msAccountKey;
	}

	public Boolean getAckConfig() {
		return ackConfig;
	}

	public void setAckConfig(Boolean ackConfig) {
		this.ackConfig = ackConfig;
	}

	public File getDeviceFile() {
		return deviceFile;
	}

	public void setDeviceFile(File deviceFile) {
		this.deviceFile = deviceFile;
	}

	public void clearDeviceFile() {
		this.deviceFile = null;
	}

	public Integer getDeviceHttpTimeout() {
		return deviceHttpTimeout;
	}

	public void setDeviceHttpTimeout(Integer deviceHttpTimeout) {
		this.deviceHttpTimeout = deviceHttpTimeout;
	}

	public String getDeviceModel() {
		return deviceModel;
	}

	public void setDeviceModel(String deviceModel) {
		this.deviceModel = Util.quote(deviceModel);
	}

	public Integer getDeviceCount() {
		return deviceCount;
	}

	public void setDeviceCount(Integer deviceCount) {
		this.deviceCount = deviceCount;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public Integer getDeviceHearbeatInterval() {
		return deviceHearbeatInterval;
	}

	public void setDeviceHearbeatInterval(Integer deviceHearbeatInterval) {
		this.deviceHearbeatInterval = deviceHearbeatInterval;
	}

	public File getPhoenixConfigFile() {
		return phoenixConfigFile;
	}

	public void setPhoenixConfigFile(File phoenixConfigFile) {
		this.phoenixConfigFile = phoenixConfigFile;
	}

	public Boolean getKeepConfig() {
		return keepConfig;
	}

	public void setKeepConfig(Boolean keepConfig) {
		this.keepConfig = keepConfig;
	}

	public Integer getMaxThreads() {
		return maxThreads;
	}

	public void setMaxThreads(Integer maxThreads) {
		this.maxThreads = maxThreads;
	}

	public Boolean getPullConfig() {
		return pullConfig;
	}

	public void setPullConfig(Boolean pullConfigs) {
		this.pullConfig = pullConfigs;
	}

	public Integer getRunTime() {
		return runTime;
	}

	public void setRunTime(Integer runTime) {
		this.runTime = runTime;
	}

	public String getServerUrl() {
		return serverUrl;
	}

	public void setServerUrl(String serverUrl) {
		this.serverUrl = serverUrl;
	}

	public Integer getSimulatorHttpTimeout() {
		return simulatorHttpTimeout;
	}

	public void setSimulatorHttpTimeout(Integer simulatorHttpTimeout) {
		this.simulatorHttpTimeout = simulatorHttpTimeout;
	}

	public void setWatchdog(ExecuteWatchdog watchdog) {
		this.watchdog = watchdog;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}

	public boolean isRunning() {
		return running;
	}

	public CSVStructuredFile getCsvData() {
		return deviceCsv;
	}

	public boolean start() {
		ArrayList<String> cmdParameters = new ArrayList<>();
		cmdParameters.add("java");
		cmdParameters.add("-jar");
		cmdParameters.add(simulatorPath);
		cmdParameters.add("-serverUrl");
		cmdParameters.add(msAddress);
		cmdParameters.add("-accountKey");
		cmdParameters.add(msAccountKey);

		if (ackConfig != null) {
			cmdParameters.add("-ackConfig");
			cmdParameters.add(ackConfig.toString());
		}
		if (deviceFile != null) {
			cmdParameters.add("-deviceFile");
			cmdParameters.add(deviceFile.getPath());
		}
		if (deviceHttpTimeout != null) {
			cmdParameters.add("-deviceHttpTimeout");
			cmdParameters.add(deviceHttpTimeout.toString());
		}
		if (deviceModel != null) {
			cmdParameters.add("-deviceModel");
			cmdParameters.add(deviceModel);
		}
		if (deviceCount != null) {
			cmdParameters.add("-devices");
			cmdParameters.add(deviceCount.toString());
		}
		if (deviceType != null) {
			cmdParameters.add("-deviceType");
			cmdParameters.add(deviceType);
		}
		if (deviceHearbeatInterval != null) {
			cmdParameters.add("-heartbeatInterval");
			cmdParameters.add(deviceHearbeatInterval.toString());
		}
		if (phoenixConfigFile != null) {
			cmdParameters.add("-ftp");
			cmdParameters.add(phoenixConfigFile.getPath());
		}
		if (keepConfig != null) {
			cmdParameters.add("-keepConfig");
			cmdParameters.add(keepConfig.toString());
		}
		if (maxThreads != null) {
			cmdParameters.add("-maxThreads");
			cmdParameters.add(maxThreads.toString());
		}
		if (pullConfig != null) {
			cmdParameters.add("-pullConfig");
			cmdParameters.add(pullConfig.toString());
		}
		if (runTime != null) {
			cmdParameters.add("-runTime");
			cmdParameters.add(runTime.toString());
		}
		if (simulatorHttpTimeout != null) {
			cmdParameters.add("-simulatorHttpTimeout");
			cmdParameters.add(simulatorHttpTimeout.toString());
		}

		Shell shell = new Shell();
		long timeLimit = runTime != null && !runTime.equals(0) ? (runTime * 60000) + 1000 : defaultTimeout;
		CliResult result = shell.executeAsynchronousCommand(cmdParameters, timeLimit);
		if (result.commandFailed()) {
			setRunning(false);
			log.error("Simulator failed to start:\n{}", result.getStderr());
		} else {
			setRunning(true);
			log.info("Simulator started up with timeout of {} minutes", (timeLimit / 60 / 60 / 1000));
		}
		setWatchdog((ExecuteWatchdog) result.getCallback());
		return result.commandSucceeded();
	}

	public boolean stop() {
		if (watchdog != null) {
			watchdog.destroyProcess();
			if (watchdog.killedProcess()) {
				watchdog.stop();
				setRunning(false);
				log.info("Simulator was shut down");
				return true;
			} else {
				log.info("Simulator had already shut down");
				return true;
			}
		} else {
			log.warn("Simulator was not running");
			return false;
		}
	}

	private String getVersitySerialNumber() {
		StringBuilder serial = new StringBuilder();
		serial.append(getRandomChars(4));
		serial.append(getRandomDecimals(2));
		serial.append(getRandomChars(5));
		serial.append("00");
		serial.append(getRandomHex(2));
		return serial.toString();
	}

	private String getMacAddress() {
		StringBuilder address = new StringBuilder(spectralinkRealm);
		address.append(":" + getRandomHex(2));
		address.append(":" + getRandomHex(2));
		address.append(":" + getRandomHex(2));
		return address.toString();
	}

	private String getModelNumber() {
		modelNumberIndex = (modelNumberIndex + 1) % modelNumbers.size();
		return modelNumbers.get(modelNumberIndex);
	}

	public void createVersityDeviceFile(int count) {
		File versityDevices = new File(deviceFileName);
		deviceCsv = new CSVStructuredFile(DeviceFileColumns.class);
		deviceCsv.setHeadings(MODEL, SERIAL, MAC);
		modelNumbers.clear();
		modelNumbers.add("Versity 9553");
		modelNumbers.add("Versity 9640");
		modelNumbers.add("Versity 9653");
		modelNumbers.add("Versity 9540");
		modelNumberIndex = 0;
		for (int rowIndex = 0; rowIndex < count; rowIndex++) {
			deviceCsv.addRow();
			deviceCsv.setCellInRow(rowIndex, MODEL, getModelNumber());
			deviceCsv.setCellInRow(rowIndex, SERIAL, getVersitySerialNumber());
			deviceCsv.setCellInRow(rowIndex, MAC, getMacAddress());
		}
		deviceCsv.includeOutputHeadings(false);
		deviceCsv.setOutputPath(versityDevices.toPath());
		deviceCsv.writeFile();
		setDeviceFile(versityDevices);
	}
}
