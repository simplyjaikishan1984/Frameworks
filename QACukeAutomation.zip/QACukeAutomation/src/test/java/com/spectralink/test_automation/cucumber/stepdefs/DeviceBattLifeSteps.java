package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.AndroidPhone;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.BattLifeUi;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.BATTLIFE;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BattLifeStrings.*;

public class DeviceBattLifeSteps {

	interface Comparison {
		boolean compare(VersityPhone dut, String target);
	}

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I tap the Batt Life \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void tapBattLifeObject(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(arg1.trim().toLowerCase());
		FieldData heading = DeviceFields.getStrings(BATTLIFE, arg1.trim());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(heading);
			if (field.isLabelPresent()) {
				field.tap();
			} else {
				log.error("Field '{}' has no label", arg1);
			}
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I set the Batt Life \"([^\"]*)\" switch to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void setBattLifeSwitch(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(arg1.trim().toLowerCase());
		FieldData heading = DeviceFields.getStrings(BATTLIFE, arg1.trim());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(heading);
			if (!field.getControlElement().getText().toLowerCase().contentEquals(arg2.trim().toLowerCase())) {
				field.tap();
			} else {
				log.debug("Field '{}' was already set to '{}'", arg1, arg2);
			}
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I select \"([^\"]*)\" from the Batt Life menu 'Alarm tone' on device \"([^\"]*)\"$")
	public void selectToneBattLifeMenuOption(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(LOW_ALARM_TONE);
		if (field != null) {
			field.scrollIntoView(LOW_ALARM_TONE);
			boolean found;
			if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
				field.tap();
				found = field.selectScrollableMenuOption(arg1.trim());
				if (found) {
					battlifeUi.tapOkButton();
					log.debug("Selected menu option '{}'", arg1);
				} else {
					log.error("Could not find menu option '{}'", arg1);
					battlifeUi.tapCancelButton();
				}
			} else {
				log.debug("Field '{}' was already set to '{}'", arg2, arg1);
			}
		} else {
			log.error("No matching field with title '{}'", LOW_ALARM_TONE.title());
		}
	}

	@When("^I select \"([^\"]*)\" from the Batt Life menu 'Low battery threshold' on device \"([^\"]*)\"$")
	public void selectThresholdBattLifeMenuOption(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(LOW_THRESHOLD_LEVEL);
		if (field != null) {
			field.scrollIntoView(LOW_THRESHOLD_LEVEL);
			boolean found;
			if (field.isValueAccessible()) {
				if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
					field.tap();
					found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
					if (found) {
						log.debug("Selected menu option '{}'", arg1);
						sleepSeconds(1);
					} else {
						log.error("Could not find menu option '{}'", arg1);
					}
				} else {
					log.debug("Field '{}' was already set to '{}'", arg2, arg1);
				}
			} else {
				log.error("No matching field with title '{}'", LOW_THRESHOLD_LEVEL.title());
			}
		}
		else {
			log.error("Field '{}' was not visible", arg1);
			Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
		}
	}

	@When("^I select \"([^\"]*)\" from the Batt Life menu 'Snooze time' on device \"([^\"]*)\"$")
	public void selectSnoozeBattLifeMenuOption(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(LOW_WARNING_SNOOZE_TIME);
		if (field != null) {
			field.scrollIntoView(LOW_WARNING_SNOOZE_TIME);
			boolean found;
			if (field.isValueAccessible()) {
				if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
					field.tap();
					found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
					if (found) {
						log.debug("Selected menu option '{}'", arg1);
					} else {
						log.error("Could not find menu option '{}'", arg1);
					}
				} else {
					log.debug("Field '{}' was already set to '{}'", arg2, arg1);
				}
			} else {
				log.error("No matching field with title '{}'", LOW_WARNING_SNOOZE_TIME.title());
			}
		}
		else {
			log.error("Field '{}' was not visible", arg1);
			Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
		}
	}

	@When("^I select \"([^\"]*)\" from the Batt Life overflow menu on device \"([^\"]*)\"$")
	public void selectOverflowOption(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(OVERFLOW_MENU);
		boolean found;
		if (field.isLabelPresent()) {
			battlifeUi.clickOverflowMenu();
			found = field.selectTextMenuOption(arg1.trim().toLowerCase());
			if (found) {
				log.debug("Selected menu option '{}'", arg1);
			} else {
				log.error("Could not find menu option '{}'", arg1);
			}
		} else {
			log.debug("The overflow menu was not visible on '{}'", arg1);
		}
	}


	@When("^I slide the Batt Life 'Alarm volume' slider to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void slideBattLifeAlarmVolume(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(ALARM_VOLUME);
		if (field != null) {
			if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
				field.updateSliderValue(Integer.valueOf(arg1.trim()), 0, 100);
			} else {
				log.debug("Field '{}' was already set to '{}'", arg2, arg1);
			}
		} else {
			log.error("No matching field with title '{}'", ALARM_VOLUME.title());
		}
	}

	@When("^I force the battery charge level to \"([^\"]*)\" on device \"([^\"]*)\"")
	public void forceBatteryCharge(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		String chargeLevel = arg1.trim();
		chargeLevel = chargeLevel.indexOf("%") > -1 ? chargeLevel.substring(0, chargeLevel.indexOf("%")) : chargeLevel;
		phone.changeBatteryLevel(chargeLevel);
		log.debug("Changed power level to {}", arg1);
		sleepSeconds(1);
	}

	@When("^I force the battery status to \"([^\"]*)\" on device \"([^\"]*)\"")
	public void forceBatteryStatus(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		AndroidPhone.Status status = AndroidPhone.findStatus(arg1.trim());
		if (status != null) {
			phone.changeBatteryStatus(status.getCode());
			sleepSeconds(1);
		} else {
			log.error("Status '{}' is invalid", arg1);
			Environment.softAssert().fail("INVALID BATTERY STATUS");
		}
	}

	@When("^I force the powered state to \"([^\"]*)\" on device \"([^\"]*)\"")
	public void forceBatteryPowerState(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		switch(arg1.trim().toLowerCase()) {
			case "unplugged":
				phone.batteryUnplug();
				log.debug("Set the power state to unplugged");
				break;
			case "usb":
				phone.batteryUsbPowered();
				log.debug("Set the power state to USB");
				break;
			case "ac":
				phone.batteryAcPowered();
				log.debug("Set the power state to AC");
				break;
			case "wireless":
				phone.batteryWirelessPowered();
				log.debug("Set the power state to wireless");
				break;
			default:
				log.error("Invalid power source specified");
				Environment.softAssert().fail("APP UI ERROR");
		}
		sleepSeconds(1);
	}

	@When("^I force a battery alarm state on device \"([^\"]*)\"")
	public void forceBatteryAlarm(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		String charge = "10";
		String status = "discharging";
		String power = "unplugged";
		forceBatteryCharge(charge, arg1);
		forceBatteryStatus(status, arg1);
		forceBatteryPowerState(power, arg1);
		log.debug("Set battery charge = {}; state = {}; power = {}", charge, status, power);
		sleepSeconds(2);
	}

	@When("^I swipe the Batt Life snooze icon on device \"([^\"]*)\"")
	public void snoozeBatteryAlarm(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		//phone.swipeScreen();
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(WARNING_SNOOZE_MESSAGE);
		field.swipeUp();
	}

	@Then("^I reset the battery state on device \"([^\"]*)\"")
	public void resetBatteryCharge(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		phone.batteryReset();
		log.debug("Reset battery state on device {}", arg1);
	}

	@Then("^the plug icon is visible on device \"([^\"]*)\"")
	public void verifyPlugVisible(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		if (battlifeUi.getField(USB_CONNECTOR).isValuePresent()) {
			log.debug("Plug connector icon was present");
		} else {
			log.fatal("Plug connector icon was not visible while powered");
			Environment.softAssert().fail("POWER INDICATION NOT FOUND");
		}
	}

	@Then("^the plug icon is not visible on device \"([^\"]*)\"")
	public void verifyPlugNotVisible(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		if (!battlifeUi.getField(USB_CONNECTOR).isValuePresent()) {
			log.debug("Plug connector icon was not present");
		} else {
			log.fatal("Plug connector icon was visible while not powered");
			Environment.softAssert().fail("POWER INDICATION INCORRECT");
		}
	}

	@Then("^the Batt Life \"([^\"]*)\" value is set to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifyBattLifeValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(arg1.trim().toLowerCase());
		FieldData heading = DeviceFields.getStrings(BATTLIFE, arg1.trim());
		if (field.hasLabelElement()) field.scrollIntoView(heading);
		if (field.isValueAccessible()) {
			String fieldValue = field.getValueElement().getText().toLowerCase();
			if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
				log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
			} else {
				log.fatal("Field '{}' was set to '{}' rather than '{}' on device {}", arg1, fieldValue, arg2, arg3);
				Environment.softAssert().fail("INCORRECT BATT LIFE FIELD VALUE");
			}
		} else {
			log.error("Field '{}' was not visible", arg1);
			Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
		}
	}

	public boolean checkValue(VersityPhone phone, String inspectValue, Comparison validate) {
		return (validate.compare(phone, inspectValue));
	}

	@Then("^the Batt Life \"([^\"]*)\" value is valid on device \"([^\"]*)\"$")
	public void verifyInternalValues(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		BattLifeUi battlifeUi = phone.getBattLifeUi();
		ConfigUiField field = battlifeUi.getField(arg1.trim().toLowerCase());
		if (field != null) {
			DeviceFields.BattLifeStrings heading = (DeviceFields.BattLifeStrings) DeviceFields.getStrings(BATTLIFE, arg1.trim());
			if (field.hasLabelElement()) field.scrollIntoView(heading);
			if (field.hasValueElement() && field.isValuePresent()) {
				Comparison comparison = null;
				switch (heading) {
					case BATTERY_SERIAL:
						comparison = (VersityPhone dut, String uiValue) -> uiValue.trim().matches("GS\\d{11}");
						break;
					case BATTERY_CAPACITY:
						comparison = (VersityPhone dut, String uiValue) -> uiValue.trim().matches("\\d{3,4} mAh");
						break;
					case SECONDARY_BATTERY_CHARGE:
						comparison = (VersityPhone dut, String uiValue) -> uiValue.trim().matches("\\d{2,3}%");
						break;
					case BATTERY_TEMPERATURE:
						comparison = (VersityPhone dut, String uiValue) -> {
							Integer temp = Integer.valueOf(dut.getBatteryServiceDump().get("temperature"));
							Integer uiTemp = Integer.valueOf(uiValue.replaceAll("[^\\d]", ""));
							return uiTemp < temp + 10 && uiTemp > temp - 10;
						};
						break;
					case BATTERY_HEALTH:
						comparison = (VersityPhone dut, String uiValue) -> {
							String health = dut.getBatteryServiceDump().get("health");
							return uiValue.toLowerCase().contentEquals(AndroidPhone.findHealthCode(health).getClassification());
						};
						break;
					case BATTERY_STATUS:
						comparison = (VersityPhone dut, String uiValue) -> {
							String status = dut.getBatteryServiceDump().get("status");
							return uiValue.toLowerCase().contentEquals(AndroidPhone.findStatusCode(status).getClassification());
						};
						break;
					case BATTERY_VOLTAGE:
						comparison = (VersityPhone dut, String uiValue) -> {
							Integer voltage = Integer.valueOf(dut.getBatteryServiceDump().get("voltage"));
							Integer uiVoltage = Integer.valueOf(uiValue.replaceAll("[^\\d]", ""));
							return uiVoltage < voltage + 100 && uiVoltage > voltage - 100;
						};
						break;
					case BATTERY_TYPE:
						comparison = (VersityPhone dut, String uiValue) -> {
							String type = dut.getBatteryServiceDump().get("technology");
							return uiValue.toLowerCase().contentEquals(type.toLowerCase());
						};
						break;
					case BATTERY_CHARGE_CYCLE:
						comparison = (VersityPhone dut, String uiValue) -> uiValue.trim().matches("\\d+");
						break;
					default:
						log.error("Batt Life field '{}' cannot be checked for validity", arg1);
						Environment.softAssert().fail("INVALID FIELD SPECIFIED");
				}
				if (comparison != null) {
					Boolean success = checkValue(phone, field.getValue(), comparison);
					if (success) {
						log.debug("Batt Life Field '{}' was valid", arg1);
					} else {
						log.fatal("Batt Life field '{}' had incorrect value of {}", arg1, field.getValue());
						Environment.softAssert().fail("PRODUCT FAILURE: INCORRECT BATT LIFE VALUE");
					}
				}
			} else {
				log.error("Field '{}' was not visible", arg1);
				Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
			}
		} else {
			log.error("No matching field with title '{}'", arg1);
			Environment.softAssert().fail("INVALID FIELD SPECIFIED");
		}
	}

	@Then("^the Batt Life \"([^\"]*)\" screen is displayed on device \"([^\"]*)\"")
	public void verifyBatteryWarning(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		if (phone.getForegroundPackage().contains(BATTLIFE.getPackage())) {
			if (phone.getForegroundActivity().contains(AndroidPhone.Activity.BATT_LIFE_CRITICAL.getIntent())) {
				log.debug("Batt Life warning screen appeared in foreground as expected");
			} else {
				log.fatal("Batt Life alarm screen was not visible");
				Environment.softAssert().fail("BATT LIFE ALARM NOT VISIBLE");
			}
		} else {
			log.fatal("Batt Life screen was not visible");
			Environment.softAssert().fail("BATT LIFE NOT IN FOREGROUND");
		}
	}
}