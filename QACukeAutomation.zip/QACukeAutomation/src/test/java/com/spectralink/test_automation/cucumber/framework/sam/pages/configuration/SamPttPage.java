package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.PttStrings.*;

public class SamPttPage extends SamConfigurationPage {

	@FindBy(id = "ptt-channel-info-add-more")
	private WebElement addChannel;

	@FindBy(id = "remove_dynamic_ptt_channel")
	private WebElement removeChannel;


	@FindBy(id = "enable_disable_ptt_label")
	private WebElement enablePttLabel;

	@FindBy(id = "enable_disable_ptt")
	private WebElement enablePttCheckbox;

	@FindBy(id = "edit_setting_pttEnableDisable")
	private WebElement enablePttEdit;

	@FindBy(id = "delete_setting_pttEnableDisable")
	private WebElement enablePttDelete;

	@FindBy(id = "undo_setting_pttEnableDisable")
	private WebElement enablePttUndo;

	public ConfigPageField enablePttField = new ConfigPageField(
			ENABLE_PTT,
			enablePttLabel,
			enablePttCheckbox,
			enablePttDelete,
			enablePttEdit,
			enablePttUndo
	);

	@FindBy(id = "pttUsername")
	private WebElement userNameTextbox;

	@FindBy(id = "delete_setting_pttUsername")
	private WebElement userNameDelete;

	@FindBy(id = "edit_setting_pttUsername")
	private WebElement userNameEdit;

	@FindBy(id = "undo_setting_pttUsername")
	private WebElement userNameUndo;

	public ConfigPageField userNameField = new ConfigPageField(
			USERNAME,
			null,
			userNameTextbox,
			userNameDelete,
			userNameEdit,
			userNameUndo
	);

	@FindBy(id = "pttMulticastAddress")
	private WebElement multicastAddressTextbox;

	@FindBy(id = "delete_setting_pttMulticastAddress")
	private WebElement multicastAddressDelete;

	@FindBy(id = "edit_setting_pttMulticastAddress")
	private WebElement multicastAddressEdit;

	@FindBy(id = "undo_setting_pttMulticastAddress")
	private WebElement multicastAddressUndo;

	public ConfigPageField multicastAddressField = new ConfigPageField(
			MULTICAST_ADDRESS,
			null,
			multicastAddressTextbox,
			multicastAddressDelete,
			multicastAddressEdit,
			multicastAddressUndo
	);

	@FindBy(id = "pttCodec")
	private WebElement codecMenu;

	@FindBy(id = "delete_setting_pttCodec")
	private WebElement codecMenuDelete;

	@FindBy(id = "edit_setting_pttCodec")
	private WebElement codecMenuEdit;

	@FindBy(id = "undo_setting_pttCodec")
	private WebElement codecMenuUndo;

	public ConfigPageField codecMenuField = new ConfigPageField(
			CODEC,
			null,
			codecMenu,
			codecMenuDelete,
			codecMenuEdit,
			codecMenuUndo
	);

	@FindBy(id = "channelInfo-channelName_channel_1")
	private WebElement channel1Textbox;

	@FindBy(id = "delete_setting_channel_1")
	private WebElement channel1Delete;

	@FindBy(id = "edit_setting_channel_1")
	private WebElement channel1Edit;

	@FindBy(id = "undo_setting_channel_1")
	private WebElement channel1Undo;

	public ConfigPageField channel1TextField = new ConfigPageField(
			CHANNEL_1,
			null,
			channel1Textbox,
			channel1Delete,
			channel1Edit,
			channel1Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_1")
	private WebElement channel1TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_1")
	private WebElement channel1TransmitCheckbox;

	public ConfigPageField channel1TransmitField = new ConfigPageField(
			CHANNEL_1_TRANSMIT,
			channel1TransmitLabel,
			channel1TransmitCheckbox,
			channel1Delete,
			channel1Edit,
			channel1Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_1")
	private WebElement channel1SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_1")
	private WebElement channel1SubscribeCheckbox;

	public ConfigPageField channel1SubscribeField = new ConfigPageField(
			CHANNEL_1_SUBSCRIBE,
			channel1SubscribeLabel,
			channel1SubscribeCheckbox,
			channel1Delete,
			channel1Edit,
			channel1Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_2")
	private WebElement channel2Textbox;

	@FindBy(id = "delete_setting_channel_2")
	private WebElement channel2Delete;

	@FindBy(id = "edit_setting_channel_2")
	private WebElement channel2Edit;

	@FindBy(id = "undo_setting_channel_2")
	private WebElement channel2Undo;

	public ConfigPageField channel2TextField = new ConfigPageField(
			CHANNEL_2,
			null,
			channel2Textbox,
			channel2Delete,
			channel2Edit,
			channel2Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_2")
	private WebElement channel2TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_2")
	private WebElement channel2TransmitCheckbox;

	public ConfigPageField channel2TransmitField = new ConfigPageField(
			CHANNEL_2_TRANSMIT,
			channel2TransmitLabel,
			channel2TransmitCheckbox,
			channel2Delete,
			channel2Edit,
			channel2Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_2")
	private WebElement channel2SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_2")
	private WebElement channel2SubscribeCheckbox;

	public ConfigPageField channel2SubscribeField = new ConfigPageField(
			CHANNEL_2_SUBSCRIBE,
			channel2SubscribeLabel,
			channel2SubscribeCheckbox,
			channel2Delete,
			channel2Edit,
			channel2Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_3")
	private WebElement channel3Textbox;

	@FindBy(id = "delete_setting_channel_3")
	private WebElement channel3Delete;

	@FindBy(id = "edit_setting_channel_3")
	private WebElement channel3Edit;

	@FindBy(id = "undo_setting_channel_3")
	private WebElement channel3Undo;

	public ConfigPageField channel3TextField = new ConfigPageField(
			CHANNEL_3,
			null,
			channel3Textbox,
			channel3Delete,
			channel3Edit,
			channel3Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_3")
	private WebElement channel3TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_3")
	private WebElement channel3TransmitCheckbox;

	public ConfigPageField channel3TransmitField = new ConfigPageField(
			CHANNEL_3_TRANSMIT,
			channel3TransmitLabel,
			channel3TransmitCheckbox,
			channel3Delete,
			channel3Edit,
			channel3Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_3")
	private WebElement channel3SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_3")
	private WebElement channel3SubscribeCheckbox;

	public ConfigPageField channel3SubscribeField = new ConfigPageField(
			CHANNEL_3_SUBSCRIBE,
			channel3SubscribeLabel,
			channel3SubscribeCheckbox,
			channel3Delete,
			channel3Edit,
			channel3Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_4")
	private WebElement channel4Textbox;

	@FindBy(id = "delete_setting_channel_4")
	private WebElement channel4Delete;

	@FindBy(id = "edit_setting_channel_4")
	private WebElement channel4Edit;

	@FindBy(id = "undo_setting_channel_4")
	private WebElement channel4Undo;

	public ConfigPageField channel4TextField = new ConfigPageField(
			CHANNEL_4,
			null,
			channel4Textbox,
			channel4Delete,
			channel4Edit,
			channel4Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_4")
	private WebElement channel4TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_4")
	private WebElement channel4TransmitCheckbox;

	public ConfigPageField channel4TransmitField = new ConfigPageField(
			CHANNEL_4_TRANSMIT,
			channel4TransmitLabel,
			channel4TransmitCheckbox,
			channel4Delete,
			channel4Edit,
			channel4Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_4")
	private WebElement channel4SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_4")
	private WebElement channel4SubscribeCheckbox;

	public ConfigPageField channel4SubscribeField = new ConfigPageField(
			CHANNEL_4_SUBSCRIBE,
			channel4SubscribeLabel,
			channel4SubscribeCheckbox,
			channel4Delete,
			channel4Edit,
			channel4Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_5")
	private WebElement channel5Textbox;

	@FindBy(id = "delete_setting_channel_5")
	private WebElement channel5Delete;

	@FindBy(id = "edit_setting_channel_5")
	private WebElement channel5Edit;

	@FindBy(id = "undo_setting_channel_5")
	private WebElement channel5Undo;

	public ConfigPageField channel5TextField = new ConfigPageField(
			CHANNEL_5,
			null,
			channel5Textbox,
			channel5Delete,
			channel5Edit,
			channel5Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_5")
	private WebElement channel5TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_5")
	private WebElement channel5TransmitCheckbox;

	public ConfigPageField channel5TransmitField = new ConfigPageField(
			CHANNEL_5_TRANSMIT,
			channel5TransmitLabel,
			channel5TransmitCheckbox,
			channel5Delete,
			channel5Edit,
			channel5Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_5")
	private WebElement channel5SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_5")
	private WebElement channel5SubscribeCheckbox;

	public ConfigPageField channel5SubscribeField = new ConfigPageField(
			CHANNEL_5_SUBSCRIBE,
			channel5SubscribeLabel,
			channel5SubscribeCheckbox,
			channel5Delete,
			channel5Edit,
			channel5Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_6")
	private WebElement channel6Textbox;

	@FindBy(id = "delete_setting_channel_6")
	private WebElement channel6Delete;

	@FindBy(id = "edit_setting_channel_6")
	private WebElement channel6Edit;

	@FindBy(id = "undo_setting_channel_6")
	private WebElement channel6Undo;

	public ConfigPageField channel6TextField = new ConfigPageField(
			CHANNEL_6,
			null,
			channel6Textbox,
			channel6Delete,
			channel6Edit,
			channel6Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_6")
	private WebElement channel6TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_6")
	private WebElement channel6TransmitCheckbox;

	public ConfigPageField channel6TransmitField = new ConfigPageField(
			CHANNEL_6_TRANSMIT,
			channel6TransmitLabel,
			channel6TransmitCheckbox,
			channel6Delete,
			channel6Edit,
			channel6Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_6")
	private WebElement channel6SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_6")
	private WebElement channel6SubscribeCheckbox;

	public ConfigPageField channel6SubscribeField = new ConfigPageField(
			CHANNEL_6_SUBSCRIBE,
			channel6SubscribeLabel,
			channel6SubscribeCheckbox,
			channel6Delete,
			channel6Edit,
			channel6Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_7")
	private WebElement channel7Textbox;

	@FindBy(id = "delete_setting_channel_7")
	private WebElement channel7Delete;

	@FindBy(id = "edit_setting_channel_7")
	private WebElement channel7Edit;

	@FindBy(id = "undo_setting_channel_7")
	private WebElement channel7Undo;

	public ConfigPageField channel7TextField = new ConfigPageField(
			CHANNEL_7,
			null,
			channel7Textbox,
			channel7Delete,
			channel7Edit,
			channel7Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_7")
	private WebElement channel7TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_7")
	private WebElement channel7TransmitCheckbox;

	public ConfigPageField channel7TransmitField = new ConfigPageField(
			CHANNEL_7_TRANSMIT,
			channel7TransmitLabel,
			channel7TransmitCheckbox,
			channel7Delete,
			channel7Edit,
			channel7Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_7")
	private WebElement channel7SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_7")
	private WebElement channel7SubscribeCheckbox;

	public ConfigPageField channel7SubscribeField = new ConfigPageField(
			CHANNEL_7_SUBSCRIBE,
			channel7SubscribeLabel,
			channel7SubscribeCheckbox,
			channel7Delete,
			channel7Edit,
			channel7Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_8")
	private WebElement channel8Textbox;

	@FindBy(id = "delete_setting_channel_8")
	private WebElement channel8Delete;

	@FindBy(id = "edit_setting_channel_8")
	private WebElement channel8Edit;

	@FindBy(id = "undo_setting_channel_8")
	private WebElement channel8Undo;

	public ConfigPageField channel8TextField = new ConfigPageField(
			CHANNEL_8,
			null,
			channel8Textbox,
			channel8Delete,
			channel8Edit,
			channel8Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_8")
	private WebElement channel8TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_8")
	private WebElement channel8TransmitCheckbox;

	public ConfigPageField channel8TransmitField = new ConfigPageField(
			CHANNEL_8_TRANSMIT,
			channel8TransmitLabel,
			channel8TransmitCheckbox,
			channel8Delete,
			channel8Edit,
			channel8Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_8")
	private WebElement channel8SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_8")
	private WebElement channel8SubscribeCheckbox;

	public ConfigPageField channel8SubscribeField = new ConfigPageField(
			CHANNEL_8_SUBSCRIBE,
			channel8SubscribeLabel,
			channel8SubscribeCheckbox,
			channel8Delete,
			channel8Edit,
			channel8Undo

	);

	@FindBy(id = "channelInfo-channelName_channel_9")
	private WebElement channel9Textbox;

	@FindBy(id = "delete_setting_channel_9")
	private WebElement channel9Delete;

	@FindBy(id = "edit_setting_channel_9")
	private WebElement channel9Edit;

	@FindBy(id = "undo_setting_channel_9")
	private WebElement channel9Undo;

	public ConfigPageField channel9TextField = new ConfigPageField(
			CHANNEL_9,
			null,
			channel9Textbox,
			channel9Delete,
			channel9Edit,
			channel9Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_9")
	private WebElement channel9TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_9")
	private WebElement channel9TransmitCheckbox;

	public ConfigPageField channel9TransmitField = new ConfigPageField(
			CHANNEL_9_TRANSMIT,
			channel9TransmitLabel,
			channel9TransmitCheckbox,
			channel9Delete,
			channel9Edit,
			channel9Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_9")
	private WebElement channel9SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_9")
	private WebElement channel9SubscribeCheckbox;

	public ConfigPageField channel9SubscribeField = new ConfigPageField(
			CHANNEL_9_SUBSCRIBE,
			channel9SubscribeLabel,
			channel9SubscribeCheckbox,
			channel9Delete,
			channel9Edit,
			channel9Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_10")
	private WebElement channel10Textbox;

	@FindBy(id = "delete_setting_channel_10")
	private WebElement channel10Delete;

	@FindBy(id = "edit_setting_channel_10")
	private WebElement channel10Edit;

	@FindBy(id = "undo_setting_channel_10")
	private WebElement channel10Undo;

	public ConfigPageField channel10TextField = new ConfigPageField(
			CHANNEL_10,
			null,
			channel10Textbox,
			channel10Delete,
			channel10Edit,
			channel10Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_10")
	private WebElement channel10TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_10")
	private WebElement channel10TransmitCheckbox;

	public ConfigPageField channel10TransmitField = new ConfigPageField(
			CHANNEL_10_TRANSMIT,
			channel10TransmitLabel,
			channel10TransmitCheckbox,
			channel10Delete,
			channel10Edit,
			channel10Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_10")
	private WebElement channel10SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_10")
	private WebElement channel10SubscribeCheckbox;

	public ConfigPageField channel10SubscribeField = new ConfigPageField(
			CHANNEL_10_SUBSCRIBE,
			channel10SubscribeLabel,
			channel10SubscribeCheckbox,
			channel10Delete,
			channel10Edit,
			channel10Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_11")
	private WebElement channel11Textbox;

	@FindBy(id = "delete_setting_channel_11")
	private WebElement channel11Delete;

	@FindBy(id = "edit_setting_channel_11")
	private WebElement channel11Edit;

	@FindBy(id = "undo_setting_channel_11")
	private WebElement channel11Undo;

	public ConfigPageField channel11TextField = new ConfigPageField(
			CHANNEL_11,
			null,
			channel11Textbox,
			channel11Delete,
			channel11Edit,
			channel11Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_11")
	private WebElement channel11TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_11")
	private WebElement channel11TransmitCheckbox;

	public ConfigPageField channel11TransmitField = new ConfigPageField(
			CHANNEL_11_TRANSMIT,
			channel11TransmitLabel,
			channel11TransmitCheckbox,
			channel11Delete,
			channel11Edit,
			channel11Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_11")
	private WebElement channel11SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_11")
	private WebElement channel11SubscribeCheckbox;

	public ConfigPageField channel11SubscribeField = new ConfigPageField(
			CHANNEL_11_SUBSCRIBE,
			channel11SubscribeLabel,
			channel11SubscribeCheckbox,
			channel11Delete,
			channel11Edit,
			channel11Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_12")
	private WebElement channel12Textbox;

	@FindBy(id = "delete_setting_channel_12")
	private WebElement channel12Delete;

	@FindBy(id = "edit_setting_channel_12")
	private WebElement channel12Edit;

	@FindBy(id = "undo_setting_channel_12")
	private WebElement channel12Undo;

	public ConfigPageField channel12TextField = new ConfigPageField(
			CHANNEL_12,
			null,
			channel12Textbox,
			channel12Delete,
			channel12Edit,
			channel12Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_12")
	private WebElement channel12TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_12")
	private WebElement channel12TransmitCheckbox;

	public ConfigPageField channel12TransmitField = new ConfigPageField(
			CHANNEL_12_TRANSMIT,
			channel12TransmitLabel,
			channel12TransmitCheckbox,
			channel12Delete,
			channel12Edit,
			channel12Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_12")
	private WebElement channel12SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_12")
	private WebElement channel12SubscribeCheckbox;

	public ConfigPageField channel12SubscribeField = new ConfigPageField(
			CHANNEL_12_SUBSCRIBE,
			channel12SubscribeLabel,
			channel12SubscribeCheckbox,
			channel12Delete,
			channel12Edit,
			channel12Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_13")
	private WebElement channel13Textbox;

	@FindBy(id = "delete_setting_channel_13")
	private WebElement channel13Delete;

	@FindBy(id = "edit_setting_channel_13")
	private WebElement channel13Edit;

	@FindBy(id = "undo_setting_channel_13")
	private WebElement channel13Undo;

	public ConfigPageField channel13TextField = new ConfigPageField(
			CHANNEL_13,
			null,
			channel13Textbox,
			channel13Delete,
			channel13Edit,
			channel13Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_13")
	private WebElement channel13TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_13")
	private WebElement channel13TransmitCheckbox;

	public ConfigPageField channel13TransmitField = new ConfigPageField(
			CHANNEL_13_TRANSMIT,
			channel13TransmitLabel,
			channel13TransmitCheckbox,
			channel13Delete,
			channel13Edit,
			channel13Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_13")
	private WebElement channel13SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_13")
	private WebElement channel13SubscribeCheckbox;

	public ConfigPageField channel13SubscribeField = new ConfigPageField(
			CHANNEL_13_SUBSCRIBE,
			channel13SubscribeLabel,
			channel13SubscribeCheckbox,
			channel13Delete,
			channel13Edit,
			channel13Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_14")
	private WebElement channel14Textbox;

	@FindBy(id = "delete_setting_channel_14")
	private WebElement channel14Delete;

	@FindBy(id = "edit_setting_channel_14")
	private WebElement channel14Edit;

	@FindBy(id = "undo_setting_channel_14")
	private WebElement channel14Undo;

	public ConfigPageField channel14TextField = new ConfigPageField(
			CHANNEL_14,
			null,
			channel14Textbox,
			channel14Delete,
			channel14Edit,
			channel14Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_14")
	private WebElement channel14TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_14")
	private WebElement channel14TransmitCheckbox;

	public ConfigPageField channel14TransmitField = new ConfigPageField(
			CHANNEL_14_TRANSMIT,
			channel14TransmitLabel,
			channel14TransmitCheckbox,
			channel14Delete,
			channel14Edit,
			channel14Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_14")
	private WebElement channel14SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_14")
	private WebElement channel14SubscribeCheckbox;

	public ConfigPageField channel14SubscribeField = new ConfigPageField(
			CHANNEL_14_SUBSCRIBE,
			channel14SubscribeLabel,
			channel14SubscribeCheckbox,
			channel14Delete,
			channel14Edit,
			channel14Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_15")
	private WebElement channel15Textbox;

	@FindBy(id = "delete_setting_channel_15")
	private WebElement channel15Delete;

	@FindBy(id = "edit_setting_channel_15")
	private WebElement channel15Edit;

	@FindBy(id = "undo_setting_channel_15")
	private WebElement channel15Undo;

	public ConfigPageField channel15TextField = new ConfigPageField(
			CHANNEL_15,
			null,
			channel15Textbox,
			channel15Delete,
			channel15Edit,
			channel15Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_15")
	private WebElement channel15TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_15")
	private WebElement channel15TransmitCheckbox;

	public ConfigPageField channel15TransmitField = new ConfigPageField(
			CHANNEL_15_TRANSMIT,
			channel15TransmitLabel,
			channel15TransmitCheckbox,
			channel15Delete,
			channel15Edit,
			channel15Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_15")
	private WebElement channel15SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_15")
	private WebElement channel15SubscribeCheckbox;

	public ConfigPageField channel15SubscribeField = new ConfigPageField(
			CHANNEL_15_SUBSCRIBE,
			channel15SubscribeLabel,
			channel15SubscribeCheckbox,
			channel15Delete,
			channel15Edit,
			channel15Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_16")
	private WebElement channel16Textbox;

	@FindBy(id = "delete_setting_channel_16")
	private WebElement channel16Delete;

	@FindBy(id = "edit_setting_channel_16")
	private WebElement channel16Edit;

	@FindBy(id = "undo_setting_channel_16")
	private WebElement channel16Undo;

	public ConfigPageField channel16TextField = new ConfigPageField(
			CHANNEL_16,
			null,
			channel16Textbox,
			channel16Delete,
			channel16Edit,
			channel16Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_16")
	private WebElement channel16TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_16")
	private WebElement channel16TransmitCheckbox;

	public ConfigPageField channel16TransmitField = new ConfigPageField(
			CHANNEL_16_TRANSMIT,
			channel16TransmitLabel,
			channel16TransmitCheckbox,
			channel16Delete,
			channel16Edit,
			channel16Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_16")
	private WebElement channel16SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_16")
	private WebElement channel16SubscribeCheckbox;

	public ConfigPageField channel16SubscribeField = new ConfigPageField(
			CHANNEL_16_SUBSCRIBE,
			channel16SubscribeLabel,
			channel16SubscribeCheckbox,
			channel16Delete,
			channel16Edit,
			channel16Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_17")
	private WebElement channel17Textbox;

	@FindBy(id = "delete_setting_channel_17")
	private WebElement channel17Delete;

	@FindBy(id = "edit_setting_channel_17")
	private WebElement channel17Edit;

	@FindBy(id = "undo_setting_channel_17")
	private WebElement channel17Undo;

	public ConfigPageField channel17TextField = new ConfigPageField(
			CHANNEL_17,
			null,
			channel17Textbox,
			channel17Delete,
			channel17Edit,
			channel17Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_17")
	private WebElement channel17TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_17")
	private WebElement channel17TransmitCheckbox;

	public ConfigPageField channel17TransmitField = new ConfigPageField(
			CHANNEL_17_TRANSMIT,
			channel17TransmitLabel,
			channel17TransmitCheckbox,
			channel17Delete,
			channel17Edit,
			channel17Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_17")
	private WebElement channel17SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_17")
	private WebElement channel17SubscribeCheckbox;

	public ConfigPageField channel17SubscribeField = new ConfigPageField(
			CHANNEL_17_SUBSCRIBE,
			channel17SubscribeLabel,
			channel17SubscribeCheckbox,
			channel17Delete,
			channel17Edit,
			channel17Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_18")
	private WebElement channel18Textbox;

	@FindBy(id = "delete_setting_channel_18")
	private WebElement channel18Delete;

	@FindBy(id = "edit_setting_channel_18")
	private WebElement channel18Edit;

	@FindBy(id = "undo_setting_channel_18")
	private WebElement channel18Undo;

	public ConfigPageField channel18TextField = new ConfigPageField(
			CHANNEL_18,
			null,
			channel18Textbox,
			channel18Delete,
			channel18Edit,
			channel18Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_18")
	private WebElement channel18TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_18")
	private WebElement channel18TransmitCheckbox;

	public ConfigPageField channel18TransmitField = new ConfigPageField(
			CHANNEL_18_TRANSMIT,
			channel18TransmitLabel,
			channel18TransmitCheckbox,
			channel18Delete,
			channel18Edit,
			channel18Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_18")
	private WebElement channel18SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_18")
	private WebElement channel18SubscribeCheckbox;

	public ConfigPageField channel18SubscribeField = new ConfigPageField(
			CHANNEL_18_SUBSCRIBE,
			channel18SubscribeLabel,
			channel18SubscribeCheckbox,
			channel18Delete,
			channel18Edit,
			channel18Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_19")
	private WebElement channel19Textbox;

	@FindBy(id = "delete_setting_channel_19")
	private WebElement channel19Delete;

	@FindBy(id = "edit_setting_channel_19")
	private WebElement channel19Edit;

	@FindBy(id = "undo_setting_channel_19")
	private WebElement channel19Undo;

	public ConfigPageField channel19TextField = new ConfigPageField(
			CHANNEL_19,
			null,
			channel19Textbox,
			channel19Delete,
			channel19Edit,
			channel19Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_19")
	private WebElement channel19TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_19")
	private WebElement channel19TransmitCheckbox;

	public ConfigPageField channel19TransmitField = new ConfigPageField(
			CHANNEL_19_TRANSMIT,
			channel19TransmitLabel,
			channel19TransmitCheckbox,
			channel19Delete,
			channel19Edit,
			channel19Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_19")
	private WebElement channel19SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_19")
	private WebElement channel19SubscribeCheckbox;

	public ConfigPageField channel19SubscribeField = new ConfigPageField(
			CHANNEL_19_SUBSCRIBE,
			channel19SubscribeLabel,
			channel19SubscribeCheckbox,
			channel19Delete,
			channel19Edit,
			channel19Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_20")
	private WebElement channel20Textbox;

	@FindBy(id = "delete_setting_channel_20")
	private WebElement channel20Delete;

	@FindBy(id = "edit_setting_channel_20")
	private WebElement channel20Edit;

	@FindBy(id = "undo_setting_channel_20")
	private WebElement channel20Undo;

	public ConfigPageField channel20TextField = new ConfigPageField(
			CHANNEL_20,
			null,
			channel20Textbox,
			channel20Delete,
			channel20Edit,
			channel20Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_20")
	private WebElement channel20TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_20")
	private WebElement channel20TransmitCheckbox;

	public ConfigPageField channel20TransmitField = new ConfigPageField(
			CHANNEL_20_TRANSMIT,
			channel20TransmitLabel,
			channel20TransmitCheckbox,
			channel20Delete,
			channel20Edit,
			channel20Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_20")
	private WebElement channel20SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_20")
	private WebElement channel20SubscribeCheckbox;

	public ConfigPageField channel20SubscribeField = new ConfigPageField(
			CHANNEL_20_SUBSCRIBE,
			channel20SubscribeLabel,
			channel20SubscribeCheckbox,
			channel20Delete,
			channel20Edit,
			channel20Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_21")
	private WebElement channel21Textbox;

	@FindBy(id = "delete_setting_channel_21")
	private WebElement channel21Delete;

	@FindBy(id = "edit_setting_channel_21")
	private WebElement channel21Edit;

	@FindBy(id = "undo_setting_channel_21")
	private WebElement channel21Undo;

	public ConfigPageField channel21TextField = new ConfigPageField(
			CHANNEL_21,
			null,
			channel21Textbox,
			channel21Delete,
			channel21Edit,
			channel21Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_21")
	private WebElement channel21TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_21")
	private WebElement channel21TransmitCheckbox;

	public ConfigPageField channel21TransmitField = new ConfigPageField(
			CHANNEL_21_TRANSMIT,
			channel21TransmitLabel,
			channel21TransmitCheckbox,
			channel21Delete,
			channel21Edit,
			channel21Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_21")
	private WebElement channel21SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_21")
	private WebElement channel21SubscribeCheckbox;

	public ConfigPageField channel21SubscribeField = new ConfigPageField(
			CHANNEL_21_SUBSCRIBE,
			channel21SubscribeLabel,
			channel21SubscribeCheckbox,
			channel21Delete,
			channel21Edit,
			channel21Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_22")
	private WebElement channel22Textbox;

	@FindBy(id = "delete_setting_channel_22")
	private WebElement channel22Delete;

	@FindBy(id = "edit_setting_channel_22")
	private WebElement channel22Edit;

	@FindBy(id = "undo_setting_channel_22")
	private WebElement channel22Undo;

	public ConfigPageField channel22TextField = new ConfigPageField(
			CHANNEL_22,
			null,
			channel22Textbox,
			channel22Delete,
			channel22Edit,
			channel22Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_22")
	private WebElement channel22TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_22")
	private WebElement channel22TransmitCheckbox;

	public ConfigPageField channel22TransmitField = new ConfigPageField(
			CHANNEL_22_TRANSMIT,
			channel22TransmitLabel,
			channel22TransmitCheckbox,
			channel22Delete,
			channel22Edit,
			channel22Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_22")
	private WebElement channel22SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_22")
	private WebElement channel22SubscribeCheckbox;

	public ConfigPageField channel22SubscribeField = new ConfigPageField(
			CHANNEL_22_SUBSCRIBE,
			channel22SubscribeLabel,
			channel22SubscribeCheckbox,
			channel22Delete,
			channel22Edit,
			channel22Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_23")
	private WebElement channel23Textbox;

	@FindBy(id = "delete_setting_channel_23")
	private WebElement channel23Delete;

	@FindBy(id = "edit_setting_channel_23")
	private WebElement channel23Edit;

	@FindBy(id = "undo_setting_channel_23")
	private WebElement channel23Undo;

	public ConfigPageField channel23TextField = new ConfigPageField(
			CHANNEL_23,
			null,
			channel23Textbox,
			channel23Delete,
			channel23Edit,
			channel23Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_23")
	private WebElement channel23TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_23")
	private WebElement channel23TransmitCheckbox;

	public ConfigPageField channel23TransmitField = new ConfigPageField(
			CHANNEL_23_TRANSMIT,
			channel23TransmitLabel,
			channel23TransmitCheckbox,
			channel23Delete,
			channel23Edit,
			channel23Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_23")
	private WebElement channel23SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_23")
	private WebElement channel23SubscribeCheckbox;

	public ConfigPageField channel23SubscribeField = new ConfigPageField(
			CHANNEL_23_SUBSCRIBE,
			channel23SubscribeLabel,
			channel23SubscribeCheckbox,
			channel23Delete,
			channel23Edit,
			channel23Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_24")
	private WebElement channel24Textbox;

	@FindBy(id = "delete_setting_channel_24")
	private WebElement channel24Delete;

	@FindBy(id = "edit_setting_channel_24")
	private WebElement channel24Edit;

	@FindBy(id = "undo_setting_channel_24")
	private WebElement channel24Undo;

	public ConfigPageField channel24TextField = new ConfigPageField(
			CHANNEL_24,
			null,
			channel24Textbox,
			channel24Delete,
			channel24Edit,
			channel24Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_24")
	private WebElement channel24TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_24")
	private WebElement channel24TransmitCheckbox;

	public ConfigPageField channel24TransmitField = new ConfigPageField(
			CHANNEL_24_TRANSMIT,
			channel24TransmitLabel,
			channel24TransmitCheckbox,
			channel24Delete,
			channel24Edit,
			channel24Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_24")
	private WebElement channel24SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_24")
	private WebElement channel24SubscribeCheckbox;

	public ConfigPageField channel24SubscribeField = new ConfigPageField(
			CHANNEL_24_SUBSCRIBE,
			channel24SubscribeLabel,
			channel24SubscribeCheckbox,
			channel24Delete,
			channel24Edit,
			channel24Undo
	);

	@FindBy(id = "channelInfo-channelName_channel_25")
	private WebElement channel25Textbox;

	@FindBy(id = "delete_setting_channel_25")
	private WebElement channel25Delete;

	@FindBy(id = "edit_setting_channel_25")
	private WebElement channel25Edit;

	@FindBy(id = "undo_setting_channel_25")
	private WebElement channel25Undo;

	public ConfigPageField channel25TextField = new ConfigPageField(
			CHANNEL_25,
			null,
			channel25Textbox,
			channel25Delete,
			channel25Edit,
			channel25Undo
	);

	@FindBy(id = "channelInfo-canTransmit-checkbox-label-can_transmit_25")
	private WebElement channel25TransmitLabel;

	@FindBy(id = "channelInfo-canTransmit-checkbox-can_transmit_25")
	private WebElement channel25TransmitCheckbox;

	public ConfigPageField channel25TransmitField = new ConfigPageField(
			CHANNEL_25_TRANSMIT,
			channel25TransmitLabel,
			channel25TransmitCheckbox,
			channel25Delete,
			channel25Edit,
			channel25Undo
	);

	@FindBy(id = "channelInfo-subscribe-checkbox-label-can_subscribe_25")
	private WebElement channel25SubscribeLabel;

	@FindBy(id = "channelInfo-subscribe-checkbox-can_subscribe_25")
	private WebElement channel25SubscribeCheckbox;

	public ConfigPageField channel25SubscribeField = new ConfigPageField(
			CHANNEL_25_SUBSCRIBE,
			channel25SubscribeLabel,
			channel25SubscribeCheckbox,
			channel25Delete,
			channel25Edit,
			channel25Undo
	);

	@FindBy(xpath = "//*[contains(text(), 'Custom Attributes')]")
	private WebElement customAttributeSection;

	public void clickCustomAttributes() {
		clickOnPageEntity(customAttributeSection);
	}

	public SamPttPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(enablePttField.getTitle(), enablePttField);
				put(userNameField.getTitle(), userNameField);
				put(multicastAddressField.getTitle(), multicastAddressField);
				put(codecMenuField.getTitle(), codecMenuField);
				put(channel1TextField.getTitle(), channel1TextField);
				put(channel1TransmitField.getTitle(), channel1TransmitField);
				put(channel1SubscribeField.getTitle(), channel1SubscribeField);
				put(channel2TextField.getTitle(), channel2TextField);
				put(channel2TransmitField.getTitle(), channel2TransmitField);
				put(channel2SubscribeField.getTitle(), channel2SubscribeField);
				put(channel3TextField.getTitle(), channel3TextField);
				put(channel3TransmitField.getTitle(), channel3TransmitField);
				put(channel3SubscribeField.getTitle(), channel3SubscribeField);
				put(channel4TextField.getTitle(), channel4TextField);
				put(channel4TransmitField.getTitle(), channel4TransmitField);
				put(channel4SubscribeField.getTitle(), channel4SubscribeField);
				put(channel5TextField.getTitle(), channel5TextField);
				put(channel5TransmitField.getTitle(), channel5TransmitField);
				put(channel5SubscribeField.getTitle(), channel5SubscribeField);
				put(channel6TextField.getTitle(), channel6TextField);
				put(channel6TransmitField.getTitle(), channel6TransmitField);
				put(channel6SubscribeField.getTitle(), channel6SubscribeField);
				put(channel7TextField.getTitle(), channel7TextField);
				put(channel7TransmitField.getTitle(), channel7TransmitField);
				put(channel7SubscribeField.getTitle(), channel7SubscribeField);
				put(channel8TextField.getTitle(), channel8TextField);
				put(channel8TransmitField.getTitle(), channel8TransmitField);
				put(channel8SubscribeField.getTitle(), channel8SubscribeField);
				put(channel9TextField.getTitle(), channel9TextField);
				put(channel9TransmitField.getTitle(), channel9TransmitField);
				put(channel9SubscribeField.getTitle(), channel9SubscribeField);
				put(channel10TextField.getTitle(), channel10TextField);
				put(channel10TransmitField.getTitle(), channel10TransmitField);
				put(channel10SubscribeField.getTitle(), channel10SubscribeField);
				put(channel11TextField.getTitle(), channel11TextField);
				put(channel11TransmitField.getTitle(), channel11TransmitField);
				put(channel11SubscribeField.getTitle(), channel11SubscribeField);
				put(channel12TextField.getTitle(), channel12TextField);
				put(channel12TransmitField.getTitle(), channel12TransmitField);
				put(channel12SubscribeField.getTitle(), channel12SubscribeField);
				put(channel13TextField.getTitle(), channel13TextField);
				put(channel13TransmitField.getTitle(), channel13TransmitField);
				put(channel13SubscribeField.getTitle(), channel13SubscribeField);
				put(channel14TextField.getTitle(), channel14TextField);
				put(channel14TransmitField.getTitle(), channel14TransmitField);
				put(channel14SubscribeField.getTitle(), channel14SubscribeField);
				put(channel15TextField.getTitle(), channel15TextField);
				put(channel15TransmitField.getTitle(), channel15TransmitField);
				put(channel15SubscribeField.getTitle(), channel15SubscribeField);
				put(channel16TextField.getTitle(), channel16TextField);
				put(channel16TransmitField.getTitle(), channel16TransmitField);
				put(channel16SubscribeField.getTitle(), channel16SubscribeField);
				put(channel17TextField.getTitle(), channel17TextField);
				put(channel17TransmitField.getTitle(), channel17TransmitField);
				put(channel17SubscribeField.getTitle(), channel17SubscribeField);
				put(channel18TextField.getTitle(), channel18TextField);
				put(channel18TransmitField.getTitle(), channel18TransmitField);
				put(channel18SubscribeField.getTitle(), channel18SubscribeField);
				put(channel19TextField.getTitle(), channel19TextField);
				put(channel19TransmitField.getTitle(), channel19TransmitField);
				put(channel19SubscribeField.getTitle(), channel19SubscribeField);
				put(channel20TextField.getTitle(), channel20TextField);
				put(channel20TransmitField.getTitle(), channel20TransmitField);
				put(channel20SubscribeField.getTitle(), channel20SubscribeField);
				put(channel21TextField.getTitle(), channel21TextField);
				put(channel21TransmitField.getTitle(), channel21TransmitField);
				put(channel21SubscribeField.getTitle(), channel21SubscribeField);
				put(channel22TextField.getTitle(), channel22TextField);
				put(channel22TransmitField.getTitle(), channel22TransmitField);
				put(channel22SubscribeField.getTitle(), channel22SubscribeField);
				put(channel23TextField.getTitle(), channel23TextField);
				put(channel23TransmitField.getTitle(), channel23TransmitField);
				put(channel23SubscribeField.getTitle(), channel23SubscribeField);
				put(channel24TextField.getTitle(), channel24TextField);
				put(channel24TransmitField.getTitle(), channel24TransmitField);
				put(channel24SubscribeField.getTitle(), channel24SubscribeField);
				put(channel25TextField.getTitle(), channel25TextField);
				put(channel25TransmitField.getTitle(), channel25TransmitField);
				put(channel25SubscribeField.getTitle(), channel25SubscribeField);
			}
		};

	}

	/*public void clickAddChannel() {
		setTemporaryWait(0);
		if (isEntityClickable(addChannel)) {
			clickOnPageEntity(addChannel);
			sleep(500);
		}
		removeTemporaryWait();
	}

	public void clickRemoveChannel() {
		setTemporaryWait(0);
		if (isEntityClickable(removeChannel)) {
			clickOnPageEntity(removeChannel);
			sleep(500);
		}
		removeTemporaryWait();
	}*/
}
