package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.WebApiUi;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.*;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.WebApiStrings.*;
import static com.spectralink.test_automation.cucumber.stepdefs.DeviceNavigationSteps.inCall;
import static com.spectralink.test_automation.cucumber.stepdefs.DeviceNavigationSteps.phoneOnHomeScreen;
import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofSeconds;

public class DeviceWebApiSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    public static final String pollingPassword = "456";
    public static final String pollingUserName = "spectra";
    public static final String incorrectUserName = "spectralink";
    public static final String incorrectPassword = "123456";
    public static final String REG_CODE_OK = "200";
    public static final String REG_CODE_NOT_OK = "401";
    public static final String SERVICE_UNAVAILABLE = "503";
    public static final String RESPONSE_MESSAGE = "OK";
    public static final String RESPONSE_MESSAGE_INCORRECT = "Unauthorized";
    public static final String RESPONSE_MESSAGE_SERVICE_UNAVAILABLE = "Service Unavailable";
    public static final String SUCCESSFUL_PUSH = "HTTP/1.1 200 OK";
    public static Boolean failPush = false;
    private File output;
    private final ArrayList<String> results = new ArrayList<>();
    private final ArrayList<String> jsonResults = new ArrayList<>();
    private String[] tempArray;
    private final String delimiter = ",";
    ProcessBuilder processBuilder;
    Process process;
    String bizPhonecallId;
    String ciscoPhonecallId;
    String dhcpServer;
    String subnetMask;
    String defaultRouter;
    String dns1;
    String dns2;
    String dhcpEnabled;

    @When("^I tap the Web Api \"([^\"]*)\" on \"([^\"]*)\"$")
    public void tapWebApiObject(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(WEBAPI, arg1.trim());
        if (field != null) {
            if (field.hasLabelElement()) {
                assert heading != null;
                field.scrollIntoView(heading);
                if (field.isLabelPresent()) {
                    field.tap();
                } else {
                    log.error("Field '{}' has no label", arg1);
                }
            } else if (field.hasControlElement())
                field.tap();
            else {
                log.error("Field '{}' has no control", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I set the Web Api \"([^\"]*)\" switch to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setWebApiSwitch(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        WebApiUi WebApiUi = phone.getWebApiUi();
        ConfigUiField field = WebApiUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(WEBAPI, arg1.trim());
        if (field != null) {
            if (field.hasLabelElement()) field.scrollIntoView(heading);
            if (!field.getControlElement().getText().toLowerCase().contentEquals(arg2.trim().toLowerCase())) {
                field.tap();
            } else {
                log.debug("Field '{}' was already set to '{}'", arg1, arg2);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I set the Web Api \"([^\"]*)\" checkbox to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setWebApiCheckbox(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        WebApiUi WebApiUi = phone.getWebApiUi();
        ConfigUiField field = WebApiUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(WEBAPI, arg1.trim());
        if (field != null) {
            if (field.hasLabelElement()) field.scrollIntoView(heading);
            switch (arg2.toLowerCase()) {
                case "on":
                    if (!field.getControlElement().getAttribute("checked").equals("true"))
                        field.tap();
                    else
                        log.debug("Field '{}' was already set to '{}'", arg1, arg2);
                    break;
                case "off":
                    if (!field.getControlElement().getAttribute("checked").equals("false"))
                        field.tap();
                    else
                        log.debug("Field '{}' was already set to '{}'", arg1, arg2);
                    break;
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @Then("^the Web Api \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyWebApiValue(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        WebApiUi WebApiUi = phone.getWebApiUi();
        ConfigUiField field = WebApiUi.getField(arg1.trim().toLowerCase());

        if (field.isValueAccessible()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT WEB API FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I select \"([^\"]*)\" from the Web Api menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(arg2);
        if (field != null) {
            field.scrollIntoViewAttribute(arg2);
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
                if (found) {
                    log.debug("Selected menu option '{}'", arg1);
                    sleepSeconds(1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg2, arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg2);
        }
    }

    @When("^I enter \"([^\"]*)\" into the Web Api edit box on \"([^\"]*)\"$")
    public void enterInEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = webApiUi.getField(EDIT_TEXT);
            field.enter(arg1.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg2);
        }
    }

    @When("^I enter the host server address into the Web Api edit box on \"([^\"]*)\"$")
    public void enterServerInEditText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        String hostAddress = "http://"+ Environment.getUsbHost().getHostAddress() + ":8000";
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = webApiUi.getField(EDIT_TEXT);
            field.enter(hostAddress.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @When("^I enter the host https server address into the Web Api edit box on \"([^\"]*)\"$")
    public void enterHttpsServerInEditText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        String hostAddress = "https://"+ Environment.getUsbHost().getHostAddress() + ":4443";
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = webApiUi.getField(EDIT_TEXT);
            field.enter(hostAddress.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @When("^I enter the host server address into the Web Api notification Url field on \"([^\"]*)\"$")
    public void enterServerAddressInEditText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        String hostAddress = "http://"+ Environment.getUsbHost().getHostAddress() + ":8000";
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(NOTIFICATION_URL);
        if (field.isControlPresent()) {
            field = webApiUi.getField(NOTIFICATION_URL);
            field.enter(hostAddress.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @When("^I enter the host https server address into the Web Api notification Url field on \"([^\"]*)\"$")
    public void enterServerAddressHttpsInEditText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        String hostAddress = "https://"+ Environment.getUsbHost().getHostAddress() + ":4443";
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(NOTIFICATION_URL);
        if (field.isControlPresent()) {
            field = webApiUi.getField(NOTIFICATION_URL);
            field.enter(hostAddress.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @When("^I clear the Web Api edit box on \"([^\"]*)\"$")
    public void enterEndpointText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            webApiUi.clearEditText();
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @When("^I slide the Web Api 'Web API volume' slider to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void slideWebApiVolume(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(WEB_API_VOLUME);
        phone.flingToEnd();
        if (field != null) {
            field.updateSliderValue(Integer.parseInt(arg1.trim()), 0, 100);
        } else {
            log.error("No matching field with title '{}'", WEB_API_VOLUME.title());
        }
    }

    @Then("^I verify the Web Api 'Web API volume' slider is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyWebApiVolume(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(WEB_API_VOLUME);
        phone.flingToEnd();
        if (field != null) {
            float volumeSeekbar = Float.parseFloat(field.getEntityText(field.getControlElement()));
            if (volumeSeekbar == Float.parseFloat(arg1))
                log.debug("'Web API volume' is set to '{}' on '{}'", arg1, arg2);
            else {
                log.error("'Web API volume' is not set to '{}' on '{}'", arg1, arg2);
                Environment.softAssert().fail("INCORRECT WEB API VALUE");
            }
        } else {
            log.error("No matching field with title '{}'", WEB_API_VOLUME.title());
        }
    }

    static class MyAuthenticator extends Authenticator {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            char[] pwdChar;
            pwdChar = pollingPassword.toCharArray();
            return new PasswordAuthentication(pollingUserName, pwdChar);

        }
    }

    static class IncorrectAuthentication extends Authenticator {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
            char[] pwdChar;
            pwdChar = incorrectPassword.toCharArray();
            return new PasswordAuthentication(incorrectUserName, pwdChar);

        }
    }

    @When("^I add Web Api Widget on \"([^\"]*)\"$")
    public void addWebApiWidget(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        phone.sendKeyEvent(AndroidKey.HOME);
        if (phone.getModel().toLowerCase().contains("saturn"))
            phone.appium().findElementByAccessibilityId("Folder: Cisco").click();
        else
            phone.appium().findElementByAccessibilityId("Folder: Spectralink").click();

        Point position = webApiUi.getWebApiAppIconCenterPosition();
        Dimension size = phone.appium().manage().window().getSize();
        int startX = size.getWidth() / 2;
        int startY = size.getHeight() / 4;
        TouchAction touchAction = new TouchAction(phone.appium());
        touchAction.press(point(position.getX(), position.getY())).waitAction(waitOptions(ofSeconds(1))).release().perform();
        webApiUi.tapOnWidgetText();
        position = webApiUi.getWebApiAppWidgetIconPosition();
        touchAction.press(point(position.getX(), position.getY())).moveTo(point(startX, startY)).release().perform();
    }

    @When("^I expand Web Api Widget on \"([^\"]*)\"$")
    public void expandWebApiWidget(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        Dimension size = phone.appium().manage().window().getSize();
        int startX = size.getWidth() / 2;
        int startY = size.getHeight() / 2;
        WebElement widget = phone.appium().findElementByAccessibilityId("No shortcuts defined");
        int centerX = widget.getLocation().getX() + widget.getSize().getWidth() / 2;
        int centerY = widget.getLocation().getY() + widget.getSize().getHeight();
        Point widgetPosition = new Point(centerX, centerY);

        TouchAction touchAction = new TouchAction(phone.appium());
        touchAction.press(point(widgetPosition.getX(), widgetPosition.getY())).waitAction(waitOptions(ofSeconds(1))).release().perform();

        touchAction = new TouchAction(phone.appium());
        touchAction.press(point(widgetPosition.getX(), widgetPosition.getY())).moveTo(point(startX, startY)).release().perform();

        widget.click();
    }

    @When("^I remove empty Web Api Widget from \"([^\"]*)\"$")
    public void removeEmptyWebApiWidget(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        Dimension size = phone.appium().manage().window().getSize();
        int startX = size.getWidth() / 2;
        int startY = size.getHeight() / 10;
        WebElement widget = phone.appium().findElementByAccessibilityId("No shortcuts defined");
        int centerWidgetX = widget.getLocation().getX() + widget.getSize().getWidth() / 2;
        int centerWidgetY = widget.getLocation().getY() + widget.getSize().getHeight() / 2;
        Point widgetPosition = new Point(centerWidgetX, centerWidgetY);

        TouchAction touchAction = new TouchAction(phone.appium());
        touchAction.press(point(widgetPosition.getX(), widgetPosition.getY())).moveTo(point(startX, startY)).release().perform();
    }

    @When("^I remove Web Api Widget from \"([^\"]*)\"$")
    public void removeWebApiWidget(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        Dimension size = phone.appium().manage().window().getSize();
        int startX = size.getWidth() / 2;
        int startY = size.getHeight() / 10;
        WebElement widget = phone.appium().findElementByAccessibilityId("Webapi shortcuts gridview");
        int centerWidgetX = widget.getLocation().getX() + widget.getSize().getWidth() / 2;
        int centerWidgetY = widget.getLocation().getY() + widget.getSize().getHeight() / 2;
        Point widgetPosition = new Point(centerWidgetX, centerWidgetY);

        TouchAction touchAction = new TouchAction(phone.appium());
        touchAction.press(point(widgetPosition.getX(), widgetPosition.getY())).moveTo(point(startX, startY)).release().perform();
    }

    @When("^I clear the Web Api edit box for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void clearEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field;
        switch (arg1.trim().toLowerCase()) {
            case "web application shortcut title":
                field = webApiUi.getField(WEB_APPLICATION_SHORTCUT_TITLE);
                if (field.isControlPresent()) {
                    field = webApiUi.getField(WEB_APPLICATION_SHORTCUT_TITLE);
                    field.clear();
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg2);
                }
                break;
            case "web application shortcut url":
                field = webApiUi.getField(WEB_APPLICATION_SHORTCUT_URL);
                if (field.isControlPresent()) {
                    field = webApiUi.getField(WEB_APPLICATION_SHORTCUT_URL);
                    field.clear();
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg2);
                }
                break;
        }
    }

    @Then("^the Web Api Shortcut \"([^\"]*)\" label is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyEmergencyContactName(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(arg1.trim().toLowerCase());
        if (field.isValueAccessible()) {
            String fieldValue = field.getLabelElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' label was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' label was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT WEB API FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Web Api Shortcut \"([^\"]*)\" Url is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyEmergencyContactNumber(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(arg1.trim().toLowerCase());
        if (field.isValueAccessible()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' Url was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' Url was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT WEB API FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I enter \"([^\"]*)\" into the Web APi edit box for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void enterInEditTextContactName(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field;
        switch (arg2.toLowerCase()) {
            case "web application shortcut title":
                field = webApiUi.getField(WEB_APPLICATION_SHORTCUT_TITLE);
                if (field.isControlPresent()) {
                    field = webApiUi.getField(WEB_APPLICATION_SHORTCUT_TITLE);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "web application shortcut url":
                field = webApiUi.getField(WEB_APPLICATION_SHORTCUT_URL);
                if (field.isControlPresent()) {
                    field = webApiUi.getField(WEB_APPLICATION_SHORTCUT_URL);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;

            case "notification name":
                field = webApiUi.getField(NOTIFICATION_NAME);
                if (field.isControlPresent()) {
                    field = webApiUi.getField(NOTIFICATION_NAME);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "notification url":
                field = webApiUi.getField(NOTIFICATION_URL);
                if (field.isControlPresent()) {
                    field = webApiUi.getField(NOTIFICATION_URL);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
        }
    }

    @Then("^the Web Api Shortcut \"([^\"]*)\" label is set to \"([^\"]*)\" on the widget on \"([^\"]*)\"$")
    public void verifyShortcutLabel(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        if (phone.appium().findElementByAccessibilityId(arg1 + " title").getText().equals(arg2))
            log.debug("Verified field '{}' label was set to '{}'", arg1, arg2);
        else {
            log.error("Field '{}' label was not set to '{}' on {}", arg1, arg2, arg3);
            Environment.softAssert().fail("INCORRECT WEB API FIELD VALUE");
        }
    }

    @Then("^the Web Api Shortcut \"([^\"]*)\" favicon is set to \"([^\"]*)\" on the widget on \"([^\"]*)\"$")
    public void verifyShortcutUrl(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        try  {
            phone.appium().findElementByAccessibilityId(arg1 + " summary " + arg2);
            log.debug("Verified field '{}' favicon was set to '{}'", arg1, arg2);
        }
        catch (Exception exception) {
            log.error("Field '{}' favicon was not set to '{}' on {}", arg1, arg2, arg3);
            Environment.softAssert().fail("INCORRECT WEB API FIELD VALUE");
        }
    }

    @Then("^the Web Api Status is set as \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyWebApiStatus(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        if (webApiUi.webApiStatus().equals(arg1))
            log.debug("Verified Web Api Status is set as '{}' on '{}'", arg1, arg2);
        else {
            log.error("Web Api Status is not set as '{}' on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT WEB API FIELD VALUE");
        }
    }

    @When("^I tap the Web Api Shortcut \"([^\"]*)\" on the widget on \"([^\"]*)\"$")
    public void tapShortcut(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        phone.appium().findElementByAccessibilityId(arg1 + " title").click();
    }

    @Then("^I verify soft keys are visible on the Spectralink Web View on \"([^\"]*)\"$")
    public void softKeysVisible(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        if (webApiUi.softKeysVisibility())
            log.debug("Soft keys are visible on '{}'", arg1);
        else {
            log.error("Soft keys are not visible on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT WEB API FIELD VALUE");
        }
    }

    @Then("^I verify soft keys are not visible on the Spectralink Web View on \"([^\"]*)\"$")
    public void softKeysInvisible(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        if (webApiUi.softKeysVisibility()) {
            log.error("Soft keys are visible on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT WEB API FIELD VALUE");
        } else
            log.debug("Soft keys are not visible on '{}'", arg1);
    }

    @When("^I tap on 'Show Softkeys' function on the Spectralink Web View on \"([^\"]*)\"$")
    public void showSoftKeys(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.showSoftKeys();
    }

    @When("^I reset all soft key labels on the Spectralink Web View on \"([^\"]*)\"$")
    public void resetSoftKeyLabels(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.resetAllSoftKeyLabels();
    }

    @When("^I reset Buttons on the Spectralink Web View on \"([^\"]*)\"$")
    public void resetButtons(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.reset();
    }

    @When("^I reset Button \"([^\"]*)\" on the Spectralink Web View on \"([^\"]*)\"$")
    public void resetButton(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        int button = Integer.parseInt(arg1);
        button = button - 1;
        phone.appium().findElementByXPath("//android.widget.Button[(@text ='Reset " + button + "')]").click();
    }

    @When("^I tap on 'Hide Softkeys' function on the Spectralink Web View on \"([^\"]*)\"$")
    public void hideSoftKeys(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.hideSoftKeys();
    }

    @When("^I set Soft key index \"([^\"]*)\" on the Spectralink Web View on \"([^\"]*)\"$")
    public void setSoftKey(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        WebElement setSoftKeyLabel = phone.appium().findElementByXPath("//android.widget.Spinner[(@resource-id ='set_button_label_index')]");
        if (!setSoftKeyLabel.getText().equals(arg1)) {
            setSoftKeyLabel.click();
            webApiUi.selectMenuOption(arg1);
        } else {
            log.debug("Field '{}' was already set to '{}'", arg2, arg1);
        }
    }

    @When("^I reset Soft key index \"([^\"]*)\" on the Spectralink Web View on \"([^\"]*)\"$")
    public void resetSoftKey(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        WebElement resetSoftKeyLabel = phone.appium().findElementByXPath("//android.widget.Spinner[(@resource-id ='reset_button_label_index')]");
        if (!resetSoftKeyLabel.getText().equals(arg1)) {
            resetSoftKeyLabel.click();
            webApiUi.selectMenuOption(arg1);
        } else {
            log.debug("Field '{}' was already set to '{}'", arg2, arg1);
        }
    }

    @When("^I enter \"([^\"]*)\" in Soft key label on the Spectralink Web View on \"([^\"]*)\"$")
    public void enterSoftKeyLabel(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        WebElement setSoftKeyLabel = phone.appium().findElementByXPath("//android.widget.EditText[(@resource-id ='set_button_label')]");
        log.debug("Entering '{}' in the 'New Label' field on '{}'", arg1, arg2);
        setSoftKeyLabel.clear();
        setSoftKeyLabel.sendKeys(arg1);
    }

    @When("^I set the Soft key label on the Spectralink Web View on \"([^\"]*)\"$")
    public void tapShortcut(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.setKeyLabel();
    }

    @When("^I reset the Soft key label on the Spectralink Web View on \"([^\"]*)\"$")
    public void resetLabel(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.resetSoftKey();
    }

    @Then("^I verify Button \"([^\"]*)\" is set to \"([^\"]*)\" on the Spectralink Web View on \"([^\"]*)\"$")
    public void tapShortcut(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        WebElement button = phone.appium().findElementByAccessibilityId("Button " + arg1);
        if (button.getText().toUpperCase().equals(arg2.toUpperCase()))
            log.debug("Button '{}' is set as '{}' on '{}'", arg1, arg2, arg3);
        else {
            log.debug("Button '{}' is not set as '{}' on '{}'", arg1, arg2, arg3);
            Environment.softAssert().fail("INCORRECT WEB API VALUE");
        }
    }

    @When("^I long press Button \"([^\"]*)\" on the Spectralink Web View on \"([^\"]*)\"$")
    public void longPressButton(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        WebElement button = phone.appium().findElementByAccessibilityId("Button " + arg1);
        TouchAction action = new TouchAction(phone.appium());
        action.longPress(longPressOptions().withElement(element(button)).withDuration(Duration.ofSeconds(10))).perform();
    }

    @When("^I press Button \"([^\"]*)\" on the Spectralink Web View on \"([^\"]*)\"$")
    public void tapButton(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        WebElement button = phone.appium().findElementByAccessibilityId("Button " + arg1);
        button.click();
    }

    @Then("^I verify Button \"([^\"]*)\" was pressed on the Spectralink Web View on \"([^\"]*)\"$")
    public void verifyButtonPress(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        try {
            phone.appium().findElement(By.xpath("//android.view.View[(@text ='Event Value: released')]"));
            phone.appium().findElement(By.xpath("//android.view.View[(@text ='Last Click: SK " + arg1 + " was pressed')]"));
        } catch (Exception exception) {
            log.error("Button '{}' not pressed on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT WEB API VALUE");
        }
    }

    @Then("^I verify Button \"([^\"]*)\" was long pressed on the Spectralink Web View on \"([^\"]*)\"$")
    public void verifyButtonLongPress(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        try {
            phone.appium().findElement(By.xpath("//android.view.View[(@text ='Event Value: pressed')]"));
            log.debug("Button '{}' long pressed on '{}'", arg1, arg2);
        } catch (Exception exception) {
            log.error("Button '{}' not long pressed on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT WEB API VALUE");
        }
    }

    public static void killStaleProcess(String process) {
        Logger log = LogManager.getLogger("Shell Process");

        String staleProcess;
        String processesToKill = "";

        try {
            Runtime runtime = Runtime.getRuntime();
            Process p = runtime.exec("ps -o pid -C " + process);
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            reader.readLine();
            while ((staleProcess = reader.readLine()) != null) {
                log.info("Stale process instance " + staleProcess);
                processesToKill = processesToKill.concat(staleProcess);
            }
            if (processesToKill.length() > 0) {
                log.info("Killing " + processesToKill);
                runtime.exec("kill " + processesToKill);
            }
        } catch (IOException ioe) {
            log.error("IO Exception in killStaleProcessInstances()");
        }
    }

    @When("^I send a push request of type \"([^\"]*)\" with priority \"([^\"]*)\" with data \"([^\"]*)\" on \"([^\"]*)\"$")
    public void pushRequest(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        int responseCode;
        String responseMessage;

        String urlString = "http://" + phone.phoneIp() + "/push";
        String androidXmlString;

        if (arg1.equals("url"))
            androidXmlString = "<SpectralinkIPPhone><URL priority='" + arg2 + "'>" + arg3 + "</URL></SpectralinkIPPhone>";
        else if (arg1.equals("data"))
            androidXmlString = "<SpectralinkIPPhone><Data priority='" + arg2 + "'>" + arg3 + "</Data></SpectralinkIPPhone>";
        else
            androidXmlString = "<SpectralinkIPPhone><Apps><Item package='com.spectralink.slnksafe' event='REMOTE_CANCEL_SAFE_ALERT'></Item></Apps></SpectralinkIPPhone>";

        try {
            URL url1 = new URL(urlString);
            URLConnection connection = url1.openConnection();
            HttpURLConnection httpURLConnection = (HttpURLConnection) connection;
            Authenticator.setDefault(new MyAuthenticator());
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestProperty("Connection", "Keep-Alive");

            if (arg1.equals("url"))
                httpURLConnection.setRequestProperty("Content-type", "text/xml; charset=" + "UTF-8");
            else
                httpURLConnection.setRequestProperty("Content-type", "application/x-com-spectralink-webx");

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream(), StandardCharsets.UTF_8));
            out.write(androidXmlString);
            out.close();

            responseCode = httpURLConnection.getResponseCode();
            responseMessage = httpURLConnection.getResponseMessage();
            ArrayList<List<String>> headerFields = new ArrayList<>();
            Map<String, List<String>> map = httpURLConnection.getHeaderFields();
            for (Map.Entry<String, List<String>> entry : map.entrySet())
                headerFields.add(entry.getValue());
            if (failPush) {
                Environment.softAssert().assertEquals(Integer.toString(responseCode), SERVICE_UNAVAILABLE, "Response Code not 503");
                Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE_SERVICE_UNAVAILABLE, "Response Message not OK");
            } else {
                Environment.softAssert().assertEquals(Integer.toString(responseCode), REG_CODE_OK, "Response Code not 200");
                Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE, "Response Message not OK");
                Environment.softAssert().assertTrue(String.valueOf(headerFields.get(0)).contains(SUCCESSFUL_PUSH), "Push request unsuccessful");
            }
            ((HttpURLConnection) connection).disconnect();
        } catch (MalformedURLException e) {
            log.info("MalformedURLException exception");
        } catch (Exception e) {
            log.info("pushURL exception");
        }
        sleepSeconds(1);
    }

    @When("^I send a push request of type \"([^\"]*)\" with priority \"([^\"]*)\" with data \"([^\"]*)\" on \"([^\"]*)\" with No Digest Authentication")
    public void pushRequestNoDigestAuthentication(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        int responseCode;
        String responseMessage;

        String urlString = "http://" + phone.phoneIp() + "/push";
        String androidXmlString;

        if (arg1.equals("url"))
            androidXmlString = "<SpectralinkIPPhone><URL priority='" + arg2 + "'>" + arg3 + "</URL></SpectralinkIPPhone>";
        else if (arg1.equals("data"))
            androidXmlString = "<SpectralinkIPPhone><Data priority='" + arg2 + "'>" + arg3 + "</Data></SpectralinkIPPhone>";
        else
            androidXmlString = "<SpectralinkIPPhone><Apps><Item package='com.spectralink.slnksafe' event='REMOTE_CANCEL_SAFE_ALERT'></Item></Apps></SpectralinkIPPhone>";

        try {
            URL url1 = new URL(urlString);
            URLConnection connection = url1.openConnection();
            HttpURLConnection httpURLConnection = (HttpURLConnection) connection;
            Authenticator.setDefault(null);
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestProperty("Connection", "Keep-Alive");

            if (arg1.equals("url"))
                httpURLConnection.setRequestProperty("Content-type", "text/xml; charset=" + "UTF-8");
            else
                httpURLConnection.setRequestProperty("Content-type", "application/x-com-spectralink-webx");

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream(), StandardCharsets.UTF_8));
            out.write(androidXmlString);
            out.close();

            responseCode = httpURLConnection.getResponseCode();
            responseMessage = httpURLConnection.getResponseMessage();
            ArrayList<List<String>> headerFields = new ArrayList<>();
            Map<String, List<String>> map = httpURLConnection.getHeaderFields();
            for (Map.Entry<String, List<String>> entry : map.entrySet())
                headerFields.add(entry.getValue());
            Environment.softAssert().assertEquals(Integer.toString(responseCode), REG_CODE_NOT_OK, "Response Code not 401");
            Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE_INCORRECT, "Response Message not OK");

            ((HttpURLConnection) connection).disconnect();
        } catch (MalformedURLException e) {
            log.info("MalformedURLException exception");
        } catch (Exception e) {
            log.info("pushURL exception");
        }
        sleepSeconds(1);
    }

    @When("^I send a push request of type \"([^\"]*)\" with priority \"([^\"]*)\" with data \"([^\"]*)\" on \"([^\"]*)\" with Incorrect/Misconfigured Digest Authentication")
    public void pushRequestIncorrectDigestAuthentication(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        int responseCode;
        String responseMessage;

        String urlString = "http://" + phone.phoneIp() + "/push";
        String androidXmlString;

        if (arg1.equals("url"))
            androidXmlString = "<SpectralinkIPPhone><URL priority='" + arg2 + "'>" + arg3 + "</URL></SpectralinkIPPhone>";
        else if (arg1.equals("data"))
            androidXmlString = "<SpectralinkIPPhone><Data priority='" + arg2 + "'>" + arg3 + "</Data></SpectralinkIPPhone>";
        else
            androidXmlString = "<SpectralinkIPPhone><Apps><Item package='com.spectralink.slnksafe' event='REMOTE_CANCEL_SAFE_ALERT'></Item></Apps></SpectralinkIPPhone>";

        try {
            URL url1 = new URL(urlString);
            URLConnection connection = url1.openConnection();
            HttpURLConnection httpURLConnection = (HttpURLConnection) connection;
            Authenticator.setDefault(new IncorrectAuthentication());
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestProperty("Connection", "Keep-Alive");

            if (arg1.equals("url"))
                httpURLConnection.setRequestProperty("Content-type", "text/xml; charset=" + "UTF-8");
            else
                httpURLConnection.setRequestProperty("Content-type", "application/x-com-spectralink-webx");

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream(), StandardCharsets.UTF_8));
            out.write(androidXmlString);
            out.close();

            responseCode = httpURLConnection.getResponseCode();
            responseMessage = httpURLConnection.getResponseMessage();
            ArrayList<List<String>> headerFields = new ArrayList<>();
            Map<String, List<String>> map = httpURLConnection.getHeaderFields();
            for (Map.Entry<String, List<String>> entry : map.entrySet())
                headerFields.add(entry.getValue());
            Environment.softAssert().assertEquals(Integer.toString(responseCode), REG_CODE_NOT_OK, "Response Code not 401");
            Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE_INCORRECT, "Response Message not OK");
            ((HttpURLConnection) connection).disconnect();
        } catch (MalformedURLException e) {
            log.info("MalformedURLException exception");
        } catch (Exception e) {
            log.info("pushURL exception");
        }
        sleepSeconds(1);
    }

    @Then("^I verify push with priority \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPushContent(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        WebApiUi webApiUi = phone.getWebApiUi();
        sleepSeconds(2);
        phone.appium().openNotifications();

        String notificationTitle = phone.appium().findElementByAccessibilityId("Push Notification Title").getText();
        String notificationContent = phone.appium().findElementByAccessibilityId("Push Notification Content").getText();

        if(phone.getModel().toLowerCase().contains("saturn"))
            Environment.softAssert().assertEquals(notificationTitle, "Cisco alert", "Mismatch in Alert title");
        else
            Environment.softAssert().assertEquals(notificationTitle, "Spectralink alert", "Mismatch in Alert title");

        Environment.softAssert().assertEquals(notificationContent, "New alert received - " + arg1, "Mismatch in Alert text");

        if (arg1.equals("Critical")) {
            phone.appium().pressKey(new KeyEvent(AndroidKey.BACK));
            sleepSeconds(5);
        } else {
            webApiUi.viewAlert();
            sleepSeconds(2);
        }
        Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), arg1 + " 1", "Mismatch in Alert text");
        webApiUi.dismissWebView();
    }

    @Then("^I verify push priority is followed on \"([^\"]*)\"$")
    public void verifyLowToHighPushContent(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        WebApiUi webApiUi = phone.getWebApiUi();
        sleepSeconds(5);
        phone.appium().openNotifications();
        sleepSeconds(2);
        List<WebElement> elementList = phone.appium().findElementsByAccessibilityId("Alert Type");
        if (!elementList.isEmpty()) {
            Environment.softAssert().assertEquals(elementList.get(0).getText(), "High - 1", "Mismatch in Alert text");
            Environment.softAssert().assertEquals(elementList.get(1).getText(), "Important - 1", "Mismatch in Alert text");
            Environment.softAssert().assertEquals(elementList.get(2).getText(), "Normal - 1", "Mismatch in Alert text");

            webApiUi.viewAlert();
            sleepSeconds(5);
            Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "High 1", "Mismatch in Alert text");
            webApiUi.dismissWebView();
            sleepSeconds(5);
            Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Important 1", "Mismatch in Alert text");
            webApiUi.dismissWebView();
            sleepSeconds(5);
            Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Normal 1", "Mismatch in Alert text");
            webApiUi.dismissWebView();
        } else {
            Environment.softAssert().fail("No alerts displayed");
        }
    }

    @Then("^I verify priority queueing is followed on \"([^\"]*)\"$")
    public void verifyPriorityQueueing(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        WebApiUi webApiUi = phone.getWebApiUi();
        sleepSeconds(5);
        phone.appium().openNotifications();
        sleepSeconds(2);
        List<WebElement> elementList = phone.appium().findElementsByAccessibilityId("Alert Type");
        try {
            if (!elementList.isEmpty()) {
                Environment.softAssert().assertEquals(elementList.get(0).getText(), "Critical - 3", "Mismatch in Alert text");
                Environment.softAssert().assertEquals(elementList.get(1).getText(), "High - 3", "Mismatch in Alert text");
                Environment.softAssert().assertEquals(elementList.get(2).getText(), "Important - 3", "Mismatch in Alert text");
                Environment.softAssert().assertEquals(elementList.get(3).getText(), "Normal - 3", "Mismatch in Alert text");

                phone.appium().pressKey(new KeyEvent(AndroidKey.BACK));

                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Critical 1", "Mismatch in Alert text");
                webApiUi.dismissWebView();
                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Critical 3", "Mismatch in Alert text");
                webApiUi.dismissWebView();
                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Critical 2", "Mismatch in Alert text");
                webApiUi.dismissWebView();

                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "High 3", "Mismatch in Alert text");
                webApiUi.dismissWebView();
                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "High 2", "Mismatch in Alert text");
                webApiUi.dismissWebView();
                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "High 1", "Mismatch in Alert text");
                webApiUi.dismissWebView();

                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Important 3", "Mismatch in Alert text");
                webApiUi.dismissWebView();
                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Important 2", "Mismatch in Alert text");
                webApiUi.dismissWebView();
                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Important 1", "Mismatch in Alert text");
                webApiUi.dismissWebView();

                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Normal 3", "Mismatch in Alert text");
                webApiUi.dismissWebView();
                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Normal 2", "Mismatch in Alert text");
                webApiUi.dismissWebView();
                sleepSeconds(5);
                Environment.softAssert().assertEquals(webApiUi.getWebViewInlineText(), "Normal 1", "Mismatch in Alert text");
                webApiUi.dismissWebView();
            } else {
                Environment.softAssert().fail("No alerts displayed");
            }
        } finally {
            phone.appium().openNotifications();
            sleepSeconds(2);
            phone.appium().pressKey(new KeyEvent(AndroidKey.BACK));
            sleepSeconds(5);
            webApiUi.dismissStaleAlerts();
        }
    }

    @When("^I start server for push request")
    public void startServerForPushRequest() throws IOException {
        killStaleProcess("python");
        ProcessBuilder pb = new ProcessBuilder("python", "simpleserverpush.py");
        pb.directory(new File(Environment.getProjectDirectory(), "src/test/resources/test_data/WebApi/"));
        pb.start();
    }

    @When("^I start https server for push request")
    public void startHttpsServerForPushRequest() throws IOException {
        killStaleProcess("python");
        ProcessBuilder pb = new ProcessBuilder("python", "simplehttpsserver_push.py");
        pb.directory(new File(Environment.getProjectDirectory(), "src/test/resources/test_data/WebApi/"));
        pb.start();
    }

    @When("^I kill all stale instances of python")
    public void killServer() {
        killStaleProcess("python");
    }

    @When("^I send a push request to make a call from \"([^\"]*)\" to \"([^\"]*)\" of \"([^\"]*)\" priority")
    public void makeCall(String arg1, String arg2, String arg3) {
        VersityPhone callReceivingPhone = Environment.getPhone(arg2.trim());

        log.debug("Current package on " + arg2 + " is: " + callReceivingPhone.getForegroundPackage());
        log.debug("Current activity on " + arg2 + " is: " + callReceivingPhone.getForegroundActivity());
        if (callReceivingPhone.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (callReceivingPhone.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
        pushRequest("data", arg3, "tel:" + callReceivingPhone.callServerDetails().extensionReg1, arg1);
    }

    @When("^I send a failed push request to make a call from \"([^\"]*)\" to \"([^\"]*)\" of \"([^\"]*)\" priority")
    public void failPush(String arg1, String arg2, String arg3) {
        failPush = true;
        VersityPhone callReceivingPhone = Environment.getPhone(arg2.trim());

        log.debug("Current package on " + arg2 + " is: " + callReceivingPhone.getForegroundPackage());
        log.debug("Current activity on " + arg2 + " is: " + callReceivingPhone.getForegroundActivity());
        if (callReceivingPhone.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (callReceivingPhone.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
        pushRequest("data", arg3, "tel:" + callReceivingPhone.callServerDetails().extensionReg1, arg1);
        failPush = false;
    }

    @When("^I send a push request to cancel safe alarm on \"([^\"]*)\"$")
    public void pushRequestSafe(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        int responseCode;
        String responseMessage;

        String urlString = "http://" + phone.phoneIp() + "/push";
        String androidXmlString = "<SpectralinkIPPhone><Apps><Item package='com.spectralink.slnksafe' event='REMOTE_CANCEL_SAFE_ALERT'></Item></Apps></SpectralinkIPPhone>";

        try {
            URL url1 = new URL(urlString);
            URLConnection connection = url1.openConnection();
            HttpURLConnection httpURLConnection = (HttpURLConnection) connection;
            Authenticator.setDefault(new MyAuthenticator());
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestProperty("Connection", "Keep-Alive");
            httpURLConnection.setRequestProperty("Content-type", "application/x-com-spectralink-webx");

            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream(), StandardCharsets.UTF_8));
            out.write(androidXmlString);
            out.close();
            responseCode = httpURLConnection.getResponseCode();
            responseMessage = httpURLConnection.getResponseMessage();
            ArrayList<List<String>> headerFields = new ArrayList<>();
            Map<String, List<String>> map = httpURLConnection.getHeaderFields();
            for (Map.Entry<String, List<String>> entry : map.entrySet())
                headerFields.add(entry.getValue());
            Environment.softAssert().assertEquals(Integer.toString(responseCode), REG_CODE_OK, "Response Code not 200");
            Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE, "Response Message not OK");
            Environment.softAssert().assertTrue(String.valueOf(headerFields.get(0)).contains(SUCCESSFUL_PUSH), "Push request unsuccessful");
            ((HttpURLConnection) connection).disconnect();
        } catch (MalformedURLException e) {
            log.info("MalformedURLException exception");
        } catch (Exception e) {
            log.info("pushURL exception");
        }
        sleepSeconds(1);
    }

    public void checkResponse() throws IOException {
        String inputLine;
        BufferedReader bufferedReader = new BufferedReader(new FileReader(output));
        try {
            process.waitFor(10, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        results.clear();
        while ((inputLine = bufferedReader.readLine()) != null) {
            log.info("WebApi output: " + inputLine);
            inputLine = inputLine.trim();
            results.add(inputLine);
        }
    }

    @When("^I start server for event notification")
    public void startServerEvent() throws IOException {
        process = startServer();
    }

    @When("^I start https server for event notification")
    public void startHttpsServerEvent() throws IOException {
        process = startHttpsServer();
    }

    public Process startServer() throws IOException {

        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        output = new File(System.getProperty("user.dir"), "src/test/resources/test_data/WebApi/responseModeUrl.txt");
        File error = new File(System.getProperty("user.dir"), "src/test/resources/test_data/WebApi/responseModeUrlError.txt");
        PrintWriter writer = new PrintWriter(output);
        writer.print("");
        writer.close();
        processBuilder = new ProcessBuilder("python", "simpleserver.py").inheritIO();
        processBuilder.directory(new File(Environment.getProjectDirectory(), "src/test/resources/test_data/WebApi/"));
        processBuilder.redirectOutput(output);
        processBuilder.redirectError(error);
        return processBuilder.start();
    }

    public Process startHttpsServer() throws IOException {

        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        output = new File(System.getProperty("user.dir"), "src/test/resources/test_data/WebApi/responseModeUrl.txt");
        File error = new File(System.getProperty("user.dir"), "src/test/resources/test_data/WebApi/responseModeUrlError.txt");
        PrintWriter writer = new PrintWriter(output);
        writer.print("");
        writer.close();
        processBuilder = new ProcessBuilder("python", "simplehttpsserver.py").inheritIO();
        processBuilder.directory(new File(Environment.getProjectDirectory(), "src/test/resources/test_data/WebApi/"));
        processBuilder.redirectOutput(output);
        processBuilder.redirectError(error);
        return processBuilder.start();
    }

    @When("^I tap the Web Api Notification \"([^\"]*)\" on \"([^\"]*)\"$")
    public void tapWebApiNotification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        WebApiUi webApiUi = phone.getWebApiUi();
        ConfigUiField field = webApiUi.getField(arg1.trim().toLowerCase());
        if (field != null) {
            if (field.isLabelPresent())
                field.tap();
            else
                log.error("Field '{}' has no label", arg1);
        } else
            log.error("No matching field with title '{}'", arg1);
    }

    @Then("^I verify Xml State change event for Outgoing call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyStateChangeEventOutgoingXml(String arg1, String arg2) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());

        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);

        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<CallStateChangeEvent  CallReference=\"" + callIdCallingPhone + "\" CallState=\"Setup\">"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<LineNumber>1</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>Setup</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>" + callIdCallingPhone + "</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone + "</CallReference>"));
            Environment.softAssert().assertTrue(results.contains("</CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("</CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("</CallStateChangeEvent >"));

            String timestamp = findValue(">(.*)<", results.get(14));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml State change event for Connected call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyStateChangeEventConnectedXml(String arg1, String arg2) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());

        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<CallStateChangeEvent  CallReference=\"" + callIdCallingPhone + "\" CallState=\"Connected\">"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<LineNumber>1</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>Connected</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>" + callIdCallingPhone + "</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + otherPhone.callServerDetails().displayName + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone + "</CallReference>"));
            Environment.softAssert().assertTrue(results.contains("</CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("</CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("</CallStateChangeEvent >"));

            String timestamp = findValue(">(.*)<", results.get(14));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml State change event for terminated call was received on \"([^\"]*)\"$")
    public void verifyStateChangeTerminatedCallEventXml(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            if(phone.getModel().toLowerCase().contains("saturn"))
                Environment.softAssert().assertTrue(results.contains("<CallStateChangeEvent  CallReference=\"" + ciscoPhonecallId + "\" CallState=\"Disconnected\">"));
            else
                Environment.softAssert().assertTrue(results.contains("<CallStateChangeEvent  CallReference=\"" + bizPhonecallId + "\" CallState=\"Disconnected\">"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<LineNumber>1</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("</CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("</CallStateChangeEvent >"));
            String timestamp = findValue(">(.*)<", results.get(14));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml State change event for Incoming call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyStateChangeIncomingEventXml(String arg1, String arg2) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<CallStateChangeEvent  CallReference=\"" + callIdCallingPhone + "\" CallState=\"Offering\">"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<LineNumber>1</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>Offering</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Incoming</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>" + callIdCallingPhone + "</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>Offering</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Incoming</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>" + callIdCallingPhone + "</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + phone.callServerDetails().extensionReg1 + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + otherPhone.callServerDetails().displayName + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone + "</CallReference>"));
            Environment.softAssert().assertTrue(results.contains("</CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("</CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("</CallStateChangeEvent >"));
            String timestamp = findValue(">(.*)<", results.get(14));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json State change event for Outgoing call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyStateChangeEventOutgoingJson(String arg1, String arg2) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());

        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for State change event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"callstatechangeevent \""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"lineinfo\":{\"keynum\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"dirnum\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callinfo\":{\"callstate\":\"Setup\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"type\":\"Outgoing\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"reference\":\"" + callIdCallingPhone + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartyname\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartydirnum\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartyname\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartydirnum\":\"" + phone.callServerDetails().extensionReg1 + "\"}}}"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json State change event for Connected call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyStateChangeEventConnectedJson(String arg1, String arg2) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());

        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for State change event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"callstatechangeevent \""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"lineinfo\":{\"keynum\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"dirnum\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callinfo\":{\"callstate\":\"Connected\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"type\":\"Outgoing\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"reference\":\"" + callIdCallingPhone + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartyname\":\"" + otherPhone.callServerDetails().displayName + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartydirnum\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartyname\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartydirnum\":\"" + phone.callServerDetails().extensionReg1 + "\"}}}"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json State change event for Incoming call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyStateChangeIncomingEventJson(String arg1, String arg2) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for State change event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"callstatechangeevent \""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"lineinfo\":{\"keynum\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"dirnum\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callinfo\":{\"callstate\":\"Offering\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"type\":\"Incoming\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"reference\":\"" + callIdCallingPhone + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartyname\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartydirnum\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartyname\":\"" + otherPhone.callServerDetails().displayName + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartydirnum\":\"" + otherPhone.callServerDetails().extensionReg1 + "\"}}}"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json State change event for terminated call was received on \"([^\"]*)\"$")
    public void verifyStateChangeTerminatedCallEventJson(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for State change event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"callstatechangeevent \""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"lineinfo\":{\"keynum\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"dirnum\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callinfo\":{\"callstate\":\"Disconnected\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"type\":\"Outgoing\""));
            if(phone.getModel().toLowerCase().contains("saturn"))
                Environment.softAssert().assertTrue(jsonResults.contains("\"reference\":\"" + ciscoPhonecallId + "\""));
            else
                Environment.softAssert().assertTrue(jsonResults.contains("\"reference\":\"" + bizPhonecallId + "\""));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Registration event was received on \"([^\"]*)\"$")
    public void verifyRegistrationEventXml(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<LineRegistrationEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>1</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</LineRegistrationEvent>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Registration event was received on \"([^\"]*)\"$")
    public void verifyRegistrationEventJson(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            jsonResults.clear();
            tempArray = result.split(delimiter);
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Registration event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"lineregistrationevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":1}"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Unregistration event was received on \"([^\"]*)\"$")
    public void verifyUnregistrationEventXml(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<LineUnregistrationEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>1</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</LineUnregistrationEvent>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Unregistration event was received on \"([^\"]*)\"$")
    public void verifyUnregistrationEventJson(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Unregistration event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"lineunregistrationevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":1}"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Incoming call event with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyIncomingEventXml(String arg1, String arg2) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<IncomingCallEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + otherPhone.callServerDetails().displayName + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyNumber>" + otherPhone.callServerDetails().extensionReg1 + "</CallingPartyNumber>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + phone.callServerDetails().extensionReg1 + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyNumber>" + phone.callServerDetails().extensionReg1 + "</CalledPartyNumber>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>1</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</IncomingCallEvent>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Incoming call event with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyIncomingEventJson(String arg1, String arg2) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Incoming event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"incomingcallevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartyname\":\"" + otherPhone.callServerDetails().displayName + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartynumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartyname\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartynumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"1\"}"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Outgoing call event with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyOutgoingEventXml(String arg1, String arg2) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<OutgoingCallEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyNumber>" + phone.callServerDetails().extensionReg1 + "</CallingPartyNumber>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyNumber>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyNumber>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>1</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</OutgoingCallEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Outgoing call event with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyOutgoingEventJson(String arg1, String arg2) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Outgoing event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"outgoingcallevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartyname\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingpartynumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartyname\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledpartynumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"1\"}"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Login event was received on \"([^\"]*)\"$")
    public void verifyLoginXml(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<UserLogInOutEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("</CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<UserLoggedIn />"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 2));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("</UserLogInOutEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Login event was received on \"([^\"]*)\"$")
    public void verifyLoginJson(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Login/out event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"userloginoutevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"lineNum\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"login\":\"UserLoggedIn\"}"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Logout event was received on \"([^\"]*)\"$")
    public void verifyLogoutXml(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<UserLogInOutEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("</CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<UserLoggedOut />"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 2));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("</UserLogInOutEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Logout event was received on \"([^\"]*)\"$")
    public void verifyLogoutJson(String arg1) throws IOException, ParseException {
        checkResponse();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Login/out event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"userloginoutevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"1\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"lineNum\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"login\":\"UserLoggedOut\"}"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Panic event was received on \"([^\"]*)\"$")
    public void verifyPanicXml(String arg1) throws IOException, ParseException {

        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<SafeEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<BSSID>" + bssid + "</BSSID>"));
            Environment.softAssert().assertTrue(results.contains("<AlertType>Alarm</AlertType>"));
            Environment.softAssert().assertTrue(results.contains("<DuressAlarm>1</DuressAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<StillAlarm>0</StillAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<TiltAlarm>0</TiltAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<RunningAlarm>0</RunningAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<LineNumber>0</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</SafeEvent>"));

            String timestamp = findValue(">(.*)<", results.get(results.size() - 5));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Panic event was received on \"([^\"]*)\"$")
    public void verifyPanicJson(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Safe event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");

            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"0\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"safeevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bssid\":\"" + bssid + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"duressalarm\":true"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"stillalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"tiltalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"runningalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"alerttype\":\"Alarm\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml No Move Alarm event was received on \"([^\"]*)\"$")
    public void verifyNoMoveXml(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<SafeEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<BSSID>" + bssid + "</BSSID>"));
            Environment.softAssert().assertTrue(results.contains("<AlertType>Alarm</AlertType>"));
            Environment.softAssert().assertTrue(results.contains("<DuressAlarm>0</DuressAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<StillAlarm>1</StillAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<TiltAlarm>0</TiltAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<RunningAlarm>0</RunningAlarm>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 5));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>0</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</SafeEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml No Move Warning Alarm event was received on \"([^\"]*)\"$")
    public void verifyNoMoveWarningXml(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<SafeEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<BSSID>" + bssid + "</BSSID>"));
            Environment.softAssert().assertTrue(results.contains("<AlertType>Warning</AlertType>"));
            Environment.softAssert().assertTrue(results.contains("<DuressAlarm>0</DuressAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<StillAlarm>1</StillAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<TiltAlarm>0</TiltAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<RunningAlarm>0</RunningAlarm>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 5));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>0</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</SafeEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json No Move Alarm event was received on \"([^\"]*)\"$")
    public void verifyNoMoveJson(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Safe event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"0\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"safeevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bssid\":\"" + bssid + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"duressalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"stillalarm\":true"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"tiltalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"runningalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"alerttype\":\"Alarm\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json No Move Warning Alarm event was received on \"([^\"]*)\"$")
    public void verifyNoMoveWarningJson(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Safe event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"0\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"safeevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bssid\":\"" + bssid + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"duressalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"stillalarm\":true"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"tiltalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"runningalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"alerttype\":\"Warning\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Tilt Alarm event was received on \"([^\"]*)\"$")
    public void verifyTiltXml(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<SafeEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<BSSID>" + bssid + "</BSSID>"));
            Environment.softAssert().assertTrue(results.contains("<AlertType>Alarm</AlertType>"));
            Environment.softAssert().assertTrue(results.contains("<DuressAlarm>0</DuressAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<StillAlarm>0</StillAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<TiltAlarm>1</TiltAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<RunningAlarm>0</RunningAlarm>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 5));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>0</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</SafeEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Tilt Warning Alarm event was received on \"([^\"]*)\"$")
    public void verifyTiltWarningXml(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<SafeEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<BSSID>" + bssid + "</BSSID>"));
            Environment.softAssert().assertTrue(results.contains("<AlertType>Warning</AlertType>"));
            Environment.softAssert().assertTrue(results.contains("<DuressAlarm>0</DuressAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<StillAlarm>0</StillAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<TiltAlarm>1</TiltAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<RunningAlarm>0</RunningAlarm>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 5));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>0</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</SafeEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Tilt Alarm event was received on \"([^\"]*)\"$")
    public void verifySafeJson(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Safe event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"0\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"safeevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bssid\":\"" + bssid + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"duressalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"stillalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"tiltalarm\":true"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"runningalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"alerttype\":\"Alarm\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Tilt Warning Alarm event was received on \"([^\"]*)\"$")
    public void verifySafeWarningJson(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Safe event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"0\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"safeevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bssid\":\"" + bssid + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"duressalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"stillalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"tiltalarm\":true"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"runningalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"alerttype\":\"Warning\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    public String findValue(String regex, String searchString) {
        Pattern digits = Pattern.compile(regex);
        Matcher matcher = digits.matcher(searchString);
        if (regex.contains("(") && regex.contains(")")) {
            if (matcher.find()) {
                return matcher.group(1);
            }
        } else {
            log.error("No group defined in regex");
        }
        return null;
    }

    @Then("^I verify Xml Panic event - Terminated was received on \"([^\"]*)\"$")
    public void verifyPanicXmlTerminated(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<SafeEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<BSSID>" + bssid + "</BSSID>"));
            Environment.softAssert().assertTrue(results.contains("<AlertType>Monitor</AlertType>"));
            Environment.softAssert().assertTrue(results.contains("<DuressAlarm>0</DuressAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<StillAlarm>0</StillAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<TiltAlarm>0</TiltAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<RunningAlarm>0</RunningAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<LineNumber>0</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</SafeEvent>"));

            String timestamp = findValue(">(.*)<", results.get(results.size() - 5));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Panic event - Terminated was received on \"([^\"]*)\"$")
    public void verifyPanicJsonTerminated(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Safe event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"0\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"safeevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bssid\":\"" + bssid + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"duressalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"stillalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"tiltalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"runningalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"alerttype\":\"Monitor\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml No Move Alarm event - Terminated was received on \"([^\"]*)\"$")
    public void verifyNoMoveXmlTerminated(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<SafeEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<BSSID>" + bssid + "</BSSID>"));
            Environment.softAssert().assertTrue(results.contains("<AlertType>Monitor</AlertType>"));
            Environment.softAssert().assertTrue(results.contains("<DuressAlarm>0</DuressAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<StillAlarm>0</StillAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<TiltAlarm>0</TiltAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<RunningAlarm>0</RunningAlarm>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 5));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>0</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</SafeEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json No Move Alarm event - Terminated was received on \"([^\"]*)\"$")
    public void verifyNoMoveJsonTerminated(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Safe event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"0\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"safeevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bssid\":\"" + bssid + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"duressalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"stillalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"tiltalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"runningalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"alerttype\":\"Monitor\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Xml Tilt Alarm event - Terminated was received on \"([^\"]*)\"$")
    public void verifyTiltXmlTerminated(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("User-Agent: Dalvik/2.1.0 (Linux; U; Android " + phone.getBuildRelease() + "; " + phone.getModel() + " Build/" + phone.getUserAgentBuildId() + ")"));
            Environment.softAssert().assertTrue(results.contains("<SafeEvent>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneIP>" + phone.phoneIp() + "</PhoneIP>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<BSSID>" + bssid + "</BSSID>"));
            Environment.softAssert().assertTrue(results.contains("<AlertType>Monitor</AlertType>"));
            Environment.softAssert().assertTrue(results.contains("<DuressAlarm>0</DuressAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<StillAlarm>0</StillAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<TiltAlarm>0</TiltAlarm>"));
            Environment.softAssert().assertTrue(results.contains("<RunningAlarm>0</RunningAlarm>"));
            String timestamp = findValue(">(.*)<", results.get(results.size() - 5));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(results.contains("<LineNumber>0</LineNumber>"));
            Environment.softAssert().assertTrue(results.contains("</SafeEvent>"));

        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify Json Tilt Alarm event - Terminated was received on \"([^\"]*)\"$")
    public void verifySafeJsonTerminated(String arg1) throws IOException, ParseException {
        VersityPhone phone = Environment.getPhone(arg1.trim());

        phone.bringAppToForeground(SETTINGS_BSSID);
        WebApiUi webApiUi = phone.getWebApiUi();
        webApiUi.clickRefreshButton();
        String bssid = webApiUi.getBssid();
        phone.sendKeyEvent(AndroidKey.BACK);
        checkResponse();

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for Safe event : " + jsonResult);
            Environment.softAssert().assertTrue(jsonResults.contains("{\"PhoneIp\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            log.info(jsonResults.get(3));
            String timestamp = findValue("\"timestamp\":\"([^,]+)\"", jsonResults.get(3));
            long timeDifference = getEpochDifference(timestamp);
            if(timeDifference <= 60)
                log.debug("Event was received in less than a minute");
            else
                Environment.softAssert().fail("Event took too long to receive");
            Environment.softAssert().assertTrue(jsonResults.contains("\"line\":\"0\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"event\":\"safeevent\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bssid\":\"" + bssid + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"duressalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"stillalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"tiltalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"runningalarm\":false"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"alerttype\":\"Monitor\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    public long getEpochDifference(String timestamp) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
        Date eventTime = simpleDateFormat.parse(timestamp);
        Date currentTime = Calendar.getInstance().getTime();
        log.debug("currentTime.getTime(): " + currentTime.getTime());
        log.debug("eventTime.getTime(): " + eventTime.getTime());
        long difference = currentTime.getTime() - eventTime.getTime();
        log.debug("difference: " + difference);
        long diffSeconds = difference / 1000 % 60;
        log.debug("diffSeconds: " + diffSeconds);
        return diffSeconds;
    }

    private String getActiveBizPhoneCall(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        return phone.bizPhoneContentProvider().getCallId();
    }

    private String getActiveBizPhoneCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone1 != null;
        assert phone2 != null;
        return phone1.bizPhoneContentProvider().getCallIdFarEndUsername(phone2.callServerDetails().extensionReg1);
    }

    private String getActiveCiscoPhoneCall(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        return phone.ciscoPhoneContentProvider().getCallId();
    }

    private String getActiveCiscoPhoneCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone1 != null;
        assert phone2 != null;
        return phone1.ciscoPhoneContentProvider().getCallIdFarEndUsername(phone2.callServerDetails().extensionReg1);
    }

    public String getActiveCiscoPhoneCallConferenceHold(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        return phone.ciscoPhoneContentProvider().getCallIdOfHoldCall();
    }

    @When("^I get active Biz Phone call id for active call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void callIdBizPhone(String arg1, String arg2) {
        bizPhonecallId = getActiveBizPhoneCall(arg2, arg1);
    }

    @When("^I get active Cisco Phone call id for active call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void callIdCiscoPhone(String arg1, String arg2) {
        ciscoPhonecallId = getActiveCiscoPhoneCall(arg2, arg1);
    }

    @Then("^I verify xml device poll request was received on \"([^\"]*)\"$")
    public void verifyPollDeviceXml(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<DeviceInformation>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<PhoneDN>Line1:" + phone.callServerDetails().extensionReg1 + "</PhoneDN>"));
            Environment.softAssert().assertTrue(results.contains("<AppLoadID>" + phone.appLoadId() + "</AppLoadID>"));
            Environment.softAssert().assertTrue(results.contains("<BootROM>" + phone.bootRom() + "</BootROM>"));
            Environment.softAssert().assertTrue(results.contains("<ModelNumber>" + phone.getModel() + "</ModelNumber>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json device poll request was received on \"([^\"]*)\"$")
    public void verifyPollDeviceJson(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output for State change event : " + jsonResult);

            Environment.softAssert().assertTrue(jsonResults.contains("{\"event\":\"deviceinfo\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"phonedn\":\"Line1:" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"appid\":\"" + phone.appLoadId() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"bootrom\":\"" + phone.bootRom() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"model\":\"" + phone.getModel() + "\""));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify xml call poll request for inactive call was received on \"([^\"]*)\"$")
    public void verifyPollCallStateNoActiveCallXml(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify xml call poll request for unregistered extension was received on \"([^\"]*)\"$")
    public void verifyPollCallStateNotRegisteredXml(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertFalse(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertFalse(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify xml call poll request for outgoing call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateOutgoingXml(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2);
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone + "</CallReference>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>Ringback</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + otherPhone.callServerDetails().displayName + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
            /*for (Long aCallDuration : callDuration)
                if (results.contains("<CallDuration>" + aCallDuration + "</CallDuration>"))
                    Environment.softAssert().assertTrue(results.contains("<CallDuration>" + aCallDuration + "</CallDuration>"));*/
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify xml call poll request for incoming call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateReceivingCallXml(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2);
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone + "</CallReference>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>Offering</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Incoming</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + phone.callServerDetails().extensionReg1 + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + otherPhone.callServerDetails().displayName + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify xml call poll request for incoming connected call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateReceivingConnectedCallXml(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2);
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone + "</CallReference>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>Connected</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Incoming</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + phone.callServerDetails().extensionReg1 + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + otherPhone.callServerDetails().displayName + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify xml call poll request for outgoing connected call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateOutgoingConnectedCallXml(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);
        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone + "</CallReference>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>Connected</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + otherPhone.callServerDetails().displayName + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify xml call poll request for outgoing hold call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateOutgoingHoldCallXml(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
            Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
            Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
            Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone + "</CallReference>"));
            Environment.softAssert().assertTrue(results.contains("<CallState>CallHold</CallState>"));
            Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
            Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + otherPhone.callServerDetails().displayName + "</CalledPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
            Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify xml call poll request for conference call with \"([^\"]*)\" and \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateCallConferenceXml(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());

        if(phone.getModel().toLowerCase().contains("saturn")) {
            if (!results.isEmpty()) {
                Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
                Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
                Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
                Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
                Environment.softAssert().assertTrue(results.contains("<CallReference>" + getActiveCiscoPhoneCall(arg3) + "</CallReference>"));
                Environment.softAssert().assertTrue(results.contains("<CallState>CallConference</CallState>"));
                Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
                Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyName>Conference</CalledPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum></CalledPartyDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
            } else {
                Environment.softAssert().fail("No Web Api output");
            }
        }
        else {

            VersityPhone otherPhone = Environment.getPhone(arg1.trim());
            VersityPhone thirdPhone = Environment.getPhone(arg2.trim());

            String callIdCallingPhone31 = getActiveBizPhoneCall(arg3, arg2);
            String callIdCallingPhone32 = getActiveBizPhoneCall(arg3, arg1);

            if (!results.isEmpty()) {

                Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
                Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
                Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
                Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
                Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone31 + "</CallReference>"));
                Environment.softAssert().assertTrue(results.contains("<CallState>CallConference</CallState>"));
                Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
                Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + otherPhone.callServerDetails().displayName + "</CalledPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone32 + "</CallReference>"));
                Environment.softAssert().assertTrue(results.contains("<CallState>CallConference</CallState>"));
                Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
                Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + thirdPhone.callServerDetails().displayName + "</CalledPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + thirdPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
            } else {
                Environment.softAssert().fail("No Web Api output");
            }
        }
    }

    @Then("^I verify xml call poll request for conference hold call with \"([^\"]*)\" and \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateCallConferenceHoldXml(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());

        if(phone.getModel().toLowerCase().contains("saturn")) {
            if (!results.isEmpty()) {

                Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
                Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
                Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
                Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
                Environment.softAssert().assertTrue(results.contains("<CallReference>" + getActiveCiscoPhoneCallConferenceHold(arg3) + "</CallReference>"));
                Environment.softAssert().assertTrue(results.contains("<CallState>CallConfHold</CallState>"));
                Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
                Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyName>Conference</CalledPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum></CalledPartyDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
            } else {
                Environment.softAssert().fail("No Web Api output");
            }
        }
        else {
            VersityPhone otherPhone = Environment.getPhone(arg1.trim());
            VersityPhone thirdPhone = Environment.getPhone(arg2.trim());
            String callIdCallingPhone31 = getActiveBizPhoneCall(arg3, arg2);
            String callIdCallingPhone32 = getActiveBizPhoneCall(arg3, arg1);

            if (!results.isEmpty()) {

                Environment.softAssert().assertTrue(results.contains("<CallLineInfo>"));
                Environment.softAssert().assertTrue(results.contains("<LineKeyNum>1</LineKeyNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineDirNum>" + phone.callServerDetails().extensionReg1 + "</LineDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineState>OK</LineState>"));
                Environment.softAssert().assertTrue(results.contains("<LineKeyNum>4</LineKeyNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineDirNum></LineDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<LineState></LineState>"));
                Environment.softAssert().assertTrue(results.contains("<CallInfo>"));
                Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone31 + "</CallReference>"));
                Environment.softAssert().assertTrue(results.contains("<CallState>CallConfHold</CallState>"));
                Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
                Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + otherPhone.callServerDetails().displayName + "</CalledPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + otherPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<CallReference>" + callIdCallingPhone32 + "</CallReference>"));
                Environment.softAssert().assertTrue(results.contains("<CallState>CallConfHold</CallState>"));
                Environment.softAssert().assertTrue(results.contains("<UIAppearanceIndex>1</UIAppearanceIndex>"));
                Environment.softAssert().assertTrue(results.contains("<CallType>Outgoing</CallType>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyName>" + thirdPhone.callServerDetails().displayName + "</CalledPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CalledPartyDirNum>" + thirdPhone.callServerDetails().extensionReg1 + "</CalledPartyDirNum>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyName>" + phone.callServerDetails().extensionReg1 + "</CallingPartyName>"));
                Environment.softAssert().assertTrue(results.contains("<CallingPartyDirNum>" + phone.callServerDetails().extensionReg1 + "</CallingPartyDirNum>"));
            } else {
                Environment.softAssert().fail("No Web Api output");
            }
        }

    }

    @Then("^I verify json call poll request for inactive call was received on \"([^\"]*)\"$")
    public void verifyPollCallStateNoActiveCallJson(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if (!results.isEmpty()) {

            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
            Environment.softAssert().assertTrue(jsonResults.contains("{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json call poll request for unregistered extension was received on \"([^\"]*)\"$")
    public void verifyPollCallStateNotRegisteredJson(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertFalse(jsonResults.contains("\"linekey\":1"));
            Environment.softAssert().assertFalse(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json call poll request for outgoing call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateOutgoingJson(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2);

        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if (!results.isEmpty()) {

            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[{\"callReference\":" + callIdCallingPhone));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"Ringback\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + otherPhone.callServerDetails().displayName + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json call poll request for outgoing connected call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateOutgoingConnectedJson(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2);

        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if (!results.isEmpty()) {

            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[{\"callReference\":" + callIdCallingPhone));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"Connected\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + otherPhone.callServerDetails().displayName + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json call poll request for outgoing hold call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateOutgoingHoldJson(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;

        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2, arg1);

        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if (!results.isEmpty()) {

            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[{\"callReference\":" + callIdCallingPhone));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"CallHold\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + otherPhone.callServerDetails().displayName + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json call poll request for incoming call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateReceivingCallJson(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2);

        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if (!results.isEmpty()) {

            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[{\"callReference\":" +callIdCallingPhone));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"Offering\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Incoming\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + otherPhone.callServerDetails().displayName + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json call poll request for incoming connected call with \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateReceivingCallConnectedJson(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        String callIdCallingPhone;
        if(phone.getModel().toLowerCase().contains("saturn"))
            callIdCallingPhone = getActiveCiscoPhoneCall(arg2);
        else
            callIdCallingPhone = getActiveBizPhoneCall(arg2);

        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if (!results.isEmpty()) {

            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[{\"callReference\":" +callIdCallingPhone));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"Connected\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Incoming\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + otherPhone.callServerDetails().displayName + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
            Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json call poll request for conference call with \"([^\"]*)\" and \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateCallConferenceJson(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        VersityPhone thirdPhone = Environment.getPhone(arg2.trim());

        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if(phone.getModel().toLowerCase().contains("saturn")) {
            if (!results.isEmpty()) {
                Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"CallConference\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"Conference\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
            } else {
                Environment.softAssert().fail("No Web Api output");
            }
        }
        else{
            if (!results.isEmpty()) {

                Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"CallConference\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + otherPhone.callServerDetails().displayName + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"CallConference\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + thirdPhone.callServerDetails().displayName + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + thirdPhone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
            } else {
                Environment.softAssert().fail("No Web Api output");
            }
        }
    }

    @Then("^I verify json call poll request for conference hold call with \"([^\"]*)\" and \"([^\"]*)\" was received on \"([^\"]*)\"$")
    public void verifyPollCallStateCallConferenceHoldJson(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        VersityPhone otherPhone = Environment.getPhone(arg1.trim());
        VersityPhone thirdPhone = Environment.getPhone(arg2.trim());

        String result = results.get(results.size() - 1);
        tempArray = result.split(delimiter);
        jsonResults.clear();
        Collections.addAll(jsonResults, tempArray);
        for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

        if(phone.getModel().toLowerCase().contains("saturn")) {

            if (!results.isEmpty()) {

                Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"CallConfHold\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"Conference\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
            } else {
                Environment.softAssert().fail("No Web Api output");
            }
        }
        else {
            if (!results.isEmpty()) {

                Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":1"));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linestate\":\"OK\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"CallConfHold\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + otherPhone.callServerDetails().displayName + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + otherPhone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callState\":\"CallConfHold\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callType\":\"Outgoing\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyName\":\"" + thirdPhone.callServerDetails().displayName + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"calledPartyNumber\":\"" + thirdPhone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyName\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"callingPartyNumber\":\"" + phone.callServerDetails().extensionReg1 + "\""));
                Environment.softAssert().assertTrue(jsonResults.contains("[{\"event\":\"callstate\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linekey\":4"));
                Environment.softAssert().assertTrue(jsonResults.contains("\"linedir\":\"\""));
                Environment.softAssert().assertTrue(jsonResults.contains("\"activecallinfo\":[]}]"));
            } else {
                Environment.softAssert().fail("No Web Api output");
            }
        }
    }

    @Then("^I verify xml network poll request was received on \"([^\"]*)\"$")
    public void verifyPollNetworkXml(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        fetchNetworkInfo(phone);

        if (!results.isEmpty()) {
            Environment.softAssert().assertTrue(results.contains("<NetworkConfiguration>"));
            Environment.softAssert().assertTrue(results.contains("<DHCPServer>" + dhcpServer + "</DHCPServer>"));
            Environment.softAssert().assertTrue(results.contains("<MACAddress>" + phone.getMacAddress().replace(":", "").toUpperCase() + "</MACAddress>"));
            Environment.softAssert().assertTrue(results.contains("<DNSSuffix></DNSSuffix>"));
            Environment.softAssert().assertTrue(results.contains("<IPAddress>" + phone.phoneIp() + "</IPAddress>"));
            Environment.softAssert().assertTrue(results.contains("<CellularIP>" + phone.getCellularIp() + "</CellularIP>"));
            Environment.softAssert().assertTrue(results.contains("<SubnetMask>" + subnetMask + "</SubnetMask>"));
            Environment.softAssert().assertTrue(results.contains("<ProvServer>SlnkSettings.Spectralink.CONFIG_MGNT_SERVER_URL</ProvServer>"));
            Environment.softAssert().assertTrue(results.contains("<DefaultRouter>" + defaultRouter + "</DefaultRouter>"));
            Environment.softAssert().assertTrue(results.contains("<DNSServer1>" + dns1 + "</DNSServer1>"));
            Environment.softAssert().assertTrue(results.contains("<DNSServer2>" + dns2 + "</DNSServer2>"));
            Environment.softAssert().assertTrue(results.contains("<DHCPEnabled>" + dhcpEnabled + "</DHCPEnabled>"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @Then("^I verify json network poll request was received on \"([^\"]*)\"$")
    public void verifyPollNetworkJson(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        fetchNetworkInfo(phone);

        if (!results.isEmpty()) {
            String result = results.get(results.size() - 1);
            tempArray = result.split(delimiter);
            jsonResults.clear();
            Collections.addAll(jsonResults, tempArray);
            for (String jsonResult : jsonResults) log.info("Phone output : " + jsonResult);

            Environment.softAssert().assertTrue(jsonResults.contains("{\"event\":\"networkconfig\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"mac\":\"" + phone.getMacAddress().replace(":", "").toUpperCase() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"dnssuffix\":\"\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"ip\":\"" + phone.phoneIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"DHCPServer\":\"" + dhcpServer + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"CellularIp\":\"" + phone.getCellularIp() + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"subnetmask\":\"" + subnetMask + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"provserver\":\"SlnkSettings.Spectralink.CONFIG_MGNT_SERVER_URL\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"defaultrouter\":\"" + defaultRouter + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"dnsserver1\":\"" + dns1 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"dnsserver2\":\"" + dns2 + "\""));
            Environment.softAssert().assertTrue(jsonResults.contains("\"dhcpenabled\":\"" + dhcpEnabled + "\"}"));
        } else {
            Environment.softAssert().fail("No Web Api output");
        }
    }

    @When("^I send a device poll request with Requester Respond mode on \"([^\"]*)\" with No Digest Authentication")
    public void devicePollNoDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/deviceHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestNoDigestAuthentication(pollingUrl);
    }

    @When("^I send a call poll request with Requester Respond mode on \"([^\"]*)\" with No Digest Authentication")
    public void callPollNoDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/callstateHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestNoDigestAuthentication(pollingUrl);
    }

    @When("^I send a network poll request with Requester Respond mode on \"([^\"]*)\" with No Digest Authentication")
    public void networkPollNoDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/networkHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestNoDigestAuthentication(pollingUrl);
    }

    @When("^I send a device poll request with Requester Respond mode on \"([^\"]*)\" with Incorrect Digest Authentication")
    public void devicePollIncorrectDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/deviceHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestIncorrectDigestAuthentication(pollingUrl);
    }

    @When("^I send a call poll request with Requester Respond mode on \"([^\"]*)\" with Incorrect Digest Authentication")
    public void callPollIncorrectDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/callstateHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestIncorrectDigestAuthentication(pollingUrl);
    }

    @When("^I send a network poll request with Requester Respond mode on \"([^\"]*)\" with Incorrect Digest Authentication")
    public void networkPollIncorrectDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/networkHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestIncorrectDigestAuthentication(pollingUrl);
    }

    @When("^I send a device poll request with Requester Respond mode on \"([^\"]*)\"$")
    public void pollDeviceDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/deviceHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestDigestAuthentication(pollingUrl);
    }

    @When("^I send a call poll request with Requester Respond mode on \"([^\"]*)\"$")
    public void pollCallDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/callstateHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestDigestAuthentication(pollingUrl);
    }

    @When("^I send a network poll request with Requester Respond mode on \"([^\"]*)\"$")
    public void pollNetworkDigestAuthentication(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/networkHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        pollRequestDigestAuthentication(pollingUrl);
    }

    @When("^I send a device poll request with Url Respond mode on \"([^\"]*)\"$")
    public void pollDigestAuthenticationRespond(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/deviceHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        File output = new File(System.getProperty("user.dir"), "src/test/resources/test_data/WebApi/responseModeUrl.txt");
        PrintWriter writer = new PrintWriter(output);
        writer.print("");
        writer.close();
        ProcessBuilder pb = new ProcessBuilder("python", "simpleserver.py").inheritIO();
        pb.directory(new File(Environment.getProjectDirectory(), "src/test/resources/test_data/WebApi/"));
        pb.redirectOutput(output);
        Process pr = pb.start();
        pollUrlDigestAuthentication(pollingUrl, output, pr);
    }

    @When("^I send an https device poll request with Url Respond mode on \"([^\"]*)\"$")
    public void pollDigestAuthenticationRespondHttps(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/deviceHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        File output = new File(System.getProperty("user.dir"), "src/test/resources/test_data/WebApi/responseModeUrl.txt");
        PrintWriter writer = new PrintWriter(output);
        writer.print("");
        writer.close();
        ProcessBuilder pb = new ProcessBuilder("python", "simplehttpsserver.py").inheritIO();
        pb.directory(new File(Environment.getProjectDirectory(), "src/test/resources/test_data/WebApi/"));
        pb.redirectOutput(output);
        Process pr = pb.start();
        pollUrlDigestAuthentication(pollingUrl, output, pr);
    }

    @When("^I send a call poll request with Url Respond mode on \"([^\"]*)\"$")
    public void pollCallDigestAuthenticationUrl(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/callstateHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        File output = new File(System.getProperty("user.dir"), "src/test/resources/test_data/WebApi/responseModeUrl.txt");
        PrintWriter writer = new PrintWriter(output);
        writer.print("");
        writer.close();
        ProcessBuilder pb = new ProcessBuilder("python", "simpleserver.py").inheritIO();
        pb.directory(new File(Environment.getProjectDirectory(), "src/test/resources/test_data/WebApi/"));
        pb.redirectOutput(output);
        Process pr = pb.start();
        pollUrlDigestAuthentication(pollingUrl, output, pr);
    }

    @When("^I send a network poll request with Url Respond mode on \"([^\"]*)\"$")
    public void pollNetworkDigestAuthenticationUrl(String arg1) throws IOException {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String pollingUrl = "http://" + phone.phoneIp() + "/polling/networkHandler";
        log.info("Checking for any other active python instances, and killing them");
        killStaleProcess("python");
        File output = new File(System.getProperty("user.dir"), "src/test/resources/test_data/WebApi/responseModeUrl.txt");
        PrintWriter writer = new PrintWriter(output);
        writer.print("");
        writer.close();
        ProcessBuilder pb = new ProcessBuilder("python", "simpleserver.py").inheritIO();
        pb.directory(new File(Environment.getProjectDirectory(), "src/test/resources/test_data/WebApi/"));
        pb.redirectOutput(output);
        Process pr = pb.start();
        pollUrlDigestAuthentication(pollingUrl, output, pr);
    }

    private void pollRequestNoDigestAuthentication(String url) throws IOException {

        URL phoneURL = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) phoneURL.openConnection();
        try {
            connection.connect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int responseCode = connection.getResponseCode();
        String responseMessage = connection.getResponseMessage();
        log.info(Integer.toString(responseCode));
        log.info(responseMessage);
        Environment.softAssert().assertEquals(Integer.toString(responseCode), REG_CODE_NOT_OK, "Response Code not 401");
        Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE_INCORRECT, "Response Message not Unauthorized");
    }

    private void pollRequestIncorrectDigestAuthentication(String url) throws IOException {

        Authenticator.setDefault(new IncorrectAuthentication());
        URL phoneURL = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) phoneURL.openConnection();
        try {
            connection.connect();
        } catch (IOException e) {
            e.printStackTrace();
        }
        int responseCode = connection.getResponseCode();
        String responseMessage = connection.getResponseMessage();
        log.info(Integer.toString(responseCode));
        log.info(responseMessage);
        Environment.softAssert().assertEquals(Integer.toString(responseCode), REG_CODE_NOT_OK, "Response Code not 401");
        Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE_INCORRECT, "Response Message not Unauthorized");
    }

    private void pollRequestDigestAuthentication(String url) throws IOException {
        String inputLine;
        Authenticator.setDefault(new MyAuthenticator());
        URL phoneURL = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) phoneURL.openConnection();
        connection.connect();
        int responseCode = connection.getResponseCode();
        String responseMessage = connection.getResponseMessage();
        log.info(Integer.toString(responseCode));
        log.info(responseMessage);
        Environment.softAssert().assertEquals(Integer.toString(responseCode), REG_CODE_OK, "Response Code not 200");
        Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE, "Response Message not OK");
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        results.clear();
        while ((inputLine = bufferedReader.readLine()) != null) {
            log.info("WebApi output: " + inputLine);
            inputLine = inputLine.trim();
            results.add(inputLine);
        }
    }

    private void pollUrlDigestAuthentication(String url, File output, Process pr) throws IOException {
        String inputLine;
        Authenticator.setDefault(new MyAuthenticator());
        URL phoneURL = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) phoneURL.openConnection();
        connection.connect();
        int responseCode = connection.getResponseCode();
        String responseMessage = connection.getResponseMessage();
        log.info(Integer.toString(responseCode));
        log.info(responseMessage);
        Environment.softAssert().assertEquals(Integer.toString(responseCode), REG_CODE_OK, "Response Code not 200");
        Environment.softAssert().assertEquals(responseMessage, RESPONSE_MESSAGE, "Response Message not OK");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(output));
        try {
            pr.waitFor(10, TimeUnit.SECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        results.clear();
        while ((inputLine = bufferedReader.readLine()) != null) {
            log.info("WebApi output: " + inputLine);
            inputLine = inputLine.trim();
            results.add(inputLine);
        }
    }

    private String getNetworkInfoSetting(String value, WebApiUi webApiUi) {

        String result = "";
        Pattern propPattern = Pattern.compile("(?<=" +value+ ": ).*");
        Matcher propMatch = null;
        switch (value) {

            case "Subnet Mask":
                propMatch = propPattern.matcher(webApiUi.getNetmask());
                break;
            case "DNS 1":
                propMatch = propPattern.matcher(webApiUi.getDns1());
                break;
            case "DNS 2":
                propMatch = propPattern.matcher(webApiUi.getDns2());
                break;
            case "DHCP":
                propMatch = propPattern.matcher(webApiUi.getDhcp());
                break;
            case "Default Gateway":
                propMatch = propPattern.matcher(webApiUi.getDefaultGateway());
                break;
        }

        if (Objects.requireNonNull(propMatch).find())
            result = propMatch.group();
        return result;
    }

    public void fetchNetworkInfo(VersityPhone phone) {
        WebApiUi webApiUi = phone.getWebApiUi();
        phone.bringAppToForeground(AUTOMATION_HELPER);
        subnetMask = getNetworkInfoSetting("Subnet Mask", webApiUi);
        defaultRouter = getNetworkInfoSetting("Default Gateway",webApiUi);
        dns1 = getNetworkInfoSetting("DNS 1",webApiUi);
        dns2 = getNetworkInfoSetting("DNS 2",webApiUi);
        dhcpServer = getNetworkInfoSetting("DHCP",webApiUi);
        if(dhcpServer.equals("0.0.0.0"))
            dhcpEnabled = "No";
        else
            dhcpEnabled = "Yes";
        phone.sendKeyEvent(AndroidKey.BACK);
    }

}
