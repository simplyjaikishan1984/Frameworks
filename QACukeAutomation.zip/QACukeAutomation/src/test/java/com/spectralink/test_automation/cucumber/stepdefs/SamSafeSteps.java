package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamSafePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.SAFE;

public class SamSafeSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I click the Monitoring tab")
	public void clickMonitoringTab() {
		SamSafePage safePage = (SamSafePage) Environment.getCurrentPage();
		safePage.clickMonitoringTab();
	}

	@When("^I click the Panic Alarm tab")
	public void clickPanicTab() {
		SamSafePage safePage = (SamSafePage) Environment.getCurrentPage();
		safePage.clickPanicAlarmTab();
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" SAFE field$")
	public void selectSafeMenuOption(String arg1, String arg2) throws Throwable {
		SamSafePage safePage = (SamSafePage) Environment.getCurrentPage();
		if (safePage.getField(arg2) != null) {
			safePage.getField(arg2.trim()).updateMenuByLabel(arg1.trim());
		} else {
			log.error("Field with label '{}' does not exist", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I click the \"([^\"]*)\" radio button of the \"([^\"]*)\" SAFE field$")
	public void activateSafeRadio(String arg1, String arg2) {
		SamSafePage safePage = (SamSafePage) Environment.getCurrentPage();
		if (safePage.getField(arg2.trim()) != null) {
			String appendedKey = arg1.trim().toLowerCase() + arg2.trim();
			if (safePage.getField(appendedKey) != null) {
				safePage.getField(appendedKey).updateRadioButton();
			} else {
				log.error("No matching radio button value with title '{}'", arg1);
				Assert.fail("SAM Radio Button Not Found");
			}
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" SAFE field$")
	public void enterPttFieldValue(String arg1, String arg2) {
		SamSafePage safePage = (SamSafePage) Environment.getCurrentPage();
		if (safePage.getField(arg2.trim()) != null) {
			safePage.getField(arg2.trim()).updateTextbox(arg1.trim());
		} else {
			log.error("No matching field with label '{}'", arg2);
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the \"([^\"]*)\" SAFE setting$")
	public void verifySafeValue(String arg1, String arg2, String arg3) throws Throwable {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(SAFE, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(SAFE, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(SAFE)) phone.loadAppPreferences(SAFE);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("Field with label '{}' does not exist", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I delete the \"([^\"]*)\" SAFE field$")
	public void deleteSafeSetting(String arg1) throws Throwable {
		SamSafePage safePage = (SamSafePage) Environment.getCurrentPage();
		safePage.getField(arg1.trim()).delete();
	}

	@Then("^\"([^\"]*)\" should have the value for the sound \"([^\"]*)\" in the \"([^\"]*)\" SAFE setting$")
	public void verifySafeToneValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			String fieldKey = SamFields.getStrings(SAFE, arg3.trim()).attribute();
			if (!phone.getCurrentAppSettings().equals(SAFE)) phone.loadAppPreferences(SAFE);
			Environment.addScenarioFailure(phone.compareSound(fieldKey, arg2));
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the custom attribute \"([^\"]*)\" SAFE setting$")
	public void checkSafeCustomAttributeSetting(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (!phone.getCurrentAppSettings().equals(SAFE)) phone.loadAppPreferences(SAFE);
			Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("^the SAFE page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyPttPageValue(String arg1, String arg2) {
		SamSafePage safePage = (SamSafePage) Environment.getCurrentPage();
		if (safePage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(safePage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(safePage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Field with label '{}' does not exist", arg2);
		}
	}
}