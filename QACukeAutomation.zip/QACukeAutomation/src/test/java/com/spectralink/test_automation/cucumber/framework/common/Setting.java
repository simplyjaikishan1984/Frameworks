package com.spectralink.test_automation.cucumber.framework.common;

public class Setting {
	private Object uiValue;
	private String parameter;
	private String parameterValue;

	public Setting() {
		this.parameter = "Unset";
	}

	public Setting(Object uiValue, String parameter, String value) {
		this.uiValue = uiValue;
		this.parameter = parameter;
		this.parameterValue = value;
	}

	public Setting(String parameter, String value) {
		this.uiValue = uiValue;
		this.parameter = parameter;
		this.parameterValue = value;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public String getValue() {
		return parameterValue;
	}

	public void setValue(String value) {
		this.uiValue = value;
	}

	public Object getUiValue() {
		return uiValue;
	}

	public Boolean getBooleanUiValue() {
		return (Boolean) uiValue;
	}

	public String getStringUiValue() {
		return (String) uiValue;
	}

	public Integer getIntegerUiValue() {
		return (Integer) uiValue;
	}

	public void setUiValue(Object uiValue) {
		this.uiValue = uiValue;
	}
}
