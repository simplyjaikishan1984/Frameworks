package com.spectralink.test_automation.cucumber.framework.sam.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamFeatureLicensePage extends SamBasePage {

	private static final int grid = 0;

	public enum LicenseCount {
		Valid("valid licenses"),
		Available("available");

		private final String licenseType;

		public String text() {
			return licenseType;
		}

		LicenseCount(String licenseType) {
			this.licenseType = licenseType;
		}
	}

	public enum SearchMenu {
		Identifier("Identifier"),
		FromDate("From Date"),
		ToDate("To Date"),
		NumberDevices("Number Of Device(s)"),
		IsValid("Is Valid ?");

		private final String menuText;

		public String text() {
			return menuText;
		}

		SearchMenu(String level) {
			this.menuText = level;
		}
	}

	@FindBy(id = "serialNumber")
	private WebElement licenseKeyTextbox;

	@FindBy(id = "send")
	private WebElement saveButton;

	@FindBy(xpath = "//h3[contains(text(), 'Valid licenses')]")
	private WebElement licenseInfo;

	@FindBy(id = "global-search-column-select")
	private WebElement searchDropDown;

	@FindBy(id = "searchinput")
	private WebElement searchInputbox;

	@FindBy(id = "searchclear")
	private WebElement clearButton;

	@FindBy(xpath = "//span[contains(text(), 'Identifier')]")
	private WebElement identifierHeading;

	@FindBy(xpath = "//span[contains(text(), 'From Date')]")
	private WebElement fromDateHeading;

	@FindBy(xpath = "//span[contains(text(), 'To Date')]")
	private WebElement toDateHeading;

	@FindBy(xpath = "//span[contains(text(), 'Number Of Device(s)')]")
	private WebElement numberDevicesHeading;

	@FindBy(xpath = "//span[contains(text(), 'Is Valid ?')]")
	private WebElement validHeading;

	@FindBy(xpath = "//div[@aria-sort='descending']")
	private WebElement descendingOrder;

	@FindBy(xpath = "//div[@aria-sort='none']")
	private WebElement noneOrder;

	@FindBy(xpath = "//div[@aria-sort='ascending']")
	private WebElement ascendingOrder;

	@FindBy(xpath = "//span[contains(text(), 'Error in saving license')]")
	private WebElement toastMessage;

	@FindBy(xpath = "//div[@role=\"columnheader\"]")
	private List<WebElement> headings;


	public SamFeatureLicensePage() {
		super();
		PageFactory.initElements(driver, this);
	}

    public String getBodyText() {
        return locateElement(By.tagName("body")).getText();
    }

	public void clickColumnHeading(String title) {
		for (WebElement heading : headings) {
			if (heading.getAttribute("innerText").contains(title)) {
				clickOnPageEntity(heading);
				sleepSeconds(1);
				break;
			}
		}
	}

	public LicenseCount getCountType(String countType) {
        for (LicenseCount counts : LicenseCount.values()) {
            if (counts.text().toLowerCase().contentEquals(countType.trim().toLowerCase())) {
                return counts;
            }
        }
        return null;
	}

	public SearchMenu getSearchType(String type) {
		for (SearchMenu thisType : SearchMenu.values()) {
			if (thisType.text().toLowerCase().contentEquals(type.trim().toLowerCase())) {
				return thisType;
			}
		}
		return null;
	}

	public boolean columnIsVisible(String title) {
		for (WebElement heading : headings) {
			if (heading.getAttribute("innerText").contains(title)) return true;
		}
		return false;
	}

	public void enterLicenseKey(String key) {
		typeIntoPageEntity(licenseKeyTextbox, key);
	}

	public void clickSaveButton() {
		clickOnPageEntity(saveButton);
        sleepSeconds(1);
	}

	public Map<String, Integer> getLicenseInfo() {
		Map<String, Integer> counts = new HashMap<>();
		String licenseTally = licenseInfo.getText();
		String available = licenseTally.substring(licenseTally.indexOf(",") + 1).trim();
		Integer availableCount = Integer.valueOf(available.substring(available.indexOf(":") + 1).trim());
		counts.put(LicenseCount.Available.text(), availableCount);
		String licenses = licenseTally.substring(0, licenseTally.indexOf(",")).trim();
		Integer licenseCount = Integer.valueOf(licenses.substring(licenses.indexOf(":") + 1).trim());
		counts.put(LicenseCount.Valid.text(), licenseCount);
		return counts;
	}

	public void selectSearchType(SearchMenu option) {
		selectMenuByText(searchDropDown, option.text());
	}

	public void enterSearchValue(String matchThis) {
		typeIntoPageEntity(searchInputbox, matchThis);
		sleepSeconds(1);
	}

	public void clickClearSearchButton() {
		clickOnPageEntity(clearButton);
	}

	public int getLicenseRowCount() {
		return getRowCount(grid);
	}

	public boolean licenseIsVisible(String name) {
		int rowIndex = getRowIndexOfColumnValue(name, 1, grid);
		return rowIndex != -1;
	}

	public String getErrorMessage() {
		setTemporaryWait(5);
		String message = getToastMessage();
		removeTemporaryWait();
		return message;
	}

	public String getSortDirection(String title) {
		for (WebElement heading : headings) {
			if (heading.getAttribute("innerText").contains(title)) {
				return heading.getAttribute("aria-sort");
			}
		}
		return "unknown";
	}
}
