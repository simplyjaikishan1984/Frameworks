package com.spectralink.test_automation.cucumber.framework.sam.common;

import com.spectralink.test_automation.cucumber.framework.common.RemoteShell;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import org.apache.commons.io.input.ReversedLinesFileReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HeartbeatInspector {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private String hostAddress;
	private String hostAccount;
	private String hostPassword;
	private String logPath;
	private File jarvisLog;
	private String localLogName;
	private Boolean autoReload;

	public HeartbeatInspector(String hostAddress, String account, String password) {
		this.hostAddress = hostAddress;
		this.hostAccount = account;
		this.hostPassword = password;
		this.logPath = RunDefaults.getStringSetting("samJarvisLog");
		localLogName = logPath.substring(logPath.lastIndexOf('/') + 1);
		jarvisLog = new File(localLogName);
		autoReload = true;
	}

	private void deletePreviousLog() {
		if (jarvisLog.exists()) {
			if (!jarvisLog.delete()) {
				log.error("Could not delete previous log file {}", localLogName);
			}
		}
	}

	public void reloadLog() {
		if (!jarvisLog.exists() || autoReload) {
			deletePreviousLog();
			RemoteShell sftp = new RemoteShell(hostAddress, hostAccount, hostPassword);
			sftp.getFile(logPath);
		}
	}

	public Boolean getAutoReload() {
		return autoReload;
	}

	public void setAutoReload(Boolean autoReload) {
		this.autoReload = autoReload;
	}

	private String findMatchingEntry(Pattern pattern) {
		String line = null;
		try {
			ReversedLinesFileReader reverseReader = new ReversedLinesFileReader(jarvisLog, StandardCharsets.UTF_8);
			do {
				line = reverseReader.readLine();
				Matcher matcher = pattern.matcher(line);
				if (matcher.find()) {
					break;
				}
			} while (line != null);
			reverseReader.close();
		} catch (IOException ioe) {
			log.error("Error while reading {}: {}", jarvisLog.getName(), ioe.getMessage());
		}
		return line;
	}

	public String getLastResponse(String serial) {
		Pattern pattern = Pattern.compile(serial + ".*heartbeat response:\\s+\\{");
		reloadLog();
		String matchingLine = findMatchingEntry(pattern);
		if (matchingLine == null) log.error("Could not find last response for {}", serial);
		return matchingLine;
	}

	public String getLastFullResponse(String serial) {
		Pattern pattern = Pattern.compile(serial + ".*heartbeat response: \\{[^\\}]");
		reloadLog();
		String matchingLine = findMatchingEntry(pattern);
		if (matchingLine == null) log.error("Could not find last response for {}", serial);
		return matchingLine;
	}

	public void storeResponseHeaders(String heartbeatResponse, Map<String, String> responseValues) {
		if (heartbeatResponse != null) {
			String[] chunks = heartbeatResponse.split("\\s+");
			responseValues.put("+date+", chunks[0]);
			responseValues.put("+time+", chunks[1]);
			responseValues.put("+level+", chunks[2]);
			responseValues.put("+found_serial+", chunks[4].substring(1, chunks[4].length() - 1));
		}
	}

	public Map<String, String> getLastResponseJson(Boolean full, String serial) {
		Map<String, String> responseValues = new HashMap<>();
		String response = full ? getLastFullResponse(serial) : getLastResponse(serial);
		storeResponseHeaders(response, responseValues);
		if (response != null) {
			JSONParser jsonParser = new JSONParser();
			Pattern jsonPattern = Pattern.compile("heartbeat response: (\\{.*\\}$)");
			Matcher matcher = jsonPattern.matcher(response);
			if (matcher.find()) {
				String cleanJson = matcher.group(1);
				JSONObject payload = null;
				try {
					payload = (JSONObject) jsonParser.parse(cleanJson);
					if (payload != null && !payload.isEmpty()) {
						JSONArray config = (JSONArray) payload.get("config");
						Iterator attributes = config.iterator();
						String name = "";
						String value = "";
						while (attributes.hasNext()) {
							JSONObject attributeInfo = (JSONObject) attributes.next();
							name = (String) attributeInfo.get("uri");
							name = name.substring(name.lastIndexOf("/") + 1);
							value = (String) attributeInfo.get("value");
							responseValues.put(name, value);
						}
					}
				} catch (ParseException pe) {
					log.error("Failed to parse: {}", cleanJson);
				}
			} else {
				log.error("Found no payload match: {}", response);
			}
		} else {
			log.error("Last response was not found");
		}
		return responseValues;
	}

	public void logLastResponse(String serial) {
		Map<String, String> lastResponse = getLastResponseJson(false, serial);
		log.fatal("Last heartbeat response values for {} logged at {} {}:", lastResponse.get("+found_serial+"), lastResponse.get("+date+"), lastResponse.get("+time+"));
		Object[] keys = lastResponse.keySet().toArray();
		Arrays.sort(keys);
		boolean foundKeys = false;
		for (Object attributeName : keys) {
			if (!attributeName.toString().matches("\\+.*\\+")) {
				log.fatal(String.format("%-40s = %s", attributeName.toString(), lastResponse.get(attributeName)));
				foundKeys = true;
			}
		}
		if (!foundKeys) {
			log.fatal("EMPTY heartbeat response!");
		}
	}

	public void logLastFullResponse(String serial) {
		Map<String, String> lastResponse = getLastResponseJson(true, serial);
		log.fatal("Last heartbeat response values for {} logged at {} {}:", lastResponse.get("+found_serial+"), lastResponse.get("+date+"), lastResponse.get("+time+"));
		Object[] keys = lastResponse.keySet().toArray();
		Arrays.sort(keys);
		for (Object attributeName : keys) {
			if (!attributeName.toString().matches("\\+.*\\+")) log.fatal(String.format("%-40s = %s", attributeName.toString(), lastResponse.get(attributeName)));
		}
	}

	public void logLastResponseValue(String serial, String attribute) {
		Map<String, String> lastResponse = getLastResponseJson(true, serial);
		if (lastResponse.containsKey(attribute)) {
			log.fatal("SAM response sent: {} => '{}'", attribute, lastResponse.get(attribute));
		} else {
			log.fatal("Response did not include the key {}", attribute);
		}
	}

	public int getLastResponseCount(String serial) {
		Map<String, String> lastResponse = getLastResponseJson(false, serial);
		return lastResponse.size();
	}

	public String getLastHeartbeat(String serial) {
		Pattern pattern = Pattern.compile(serial + ".*Heartbeat message: \\{.*cmsconfig\":\\[\\{");
		reloadLog();
		String matchingLine = findMatchingEntry(pattern);
		if (matchingLine == null) log.error("Could not find last heartbeat for {}", serial);
		return matchingLine;
	}

	public void storeMessageHeaders(String heartbeatMessage, Map<String, String> messageValues) {
		String[] chunks = heartbeatMessage.split("\\s+");
		messageValues.put("+date+", chunks[0]);
		messageValues.put("+time+", chunks[1]);
		messageValues.put("+level+", chunks[2]);
		messageValues.put("+found_serial+", chunks[4].substring(1, chunks[4].length() - 1));
	}

	public Map<String, String> getLastHeartbeatJson(String serial) {
		Map<String, String> heartbeatValues = new HashMap<>();
		String heartBeat = getLastHeartbeat(serial);
		storeMessageHeaders(heartBeat, heartbeatValues);
		if (heartBeat != null) {
			JSONParser jsonParser = new JSONParser();
			Pattern jsonPattern = Pattern.compile("Heartbeat message: (\\{.*\\}$)");
			Matcher matcher = jsonPattern.matcher(heartBeat);
			if (matcher.find()) {
				String cleanJson = matcher.group(1).replace("\\/", "/");
				JSONObject payload = null;
				try {
					payload = (JSONObject) jsonParser.parse(cleanJson);
					if (payload != null) {
						JSONArray config = (JSONArray) payload.get("cmsconfig");
						Iterator attributes = config.iterator();
						String name = "";
						String value = "";
						while (attributes.hasNext()) {
							JSONObject attributeInfo = (JSONObject) attributes.next();
							name = (String) attributeInfo.get("name");
							value = (String) attributeInfo.get("value");
							heartbeatValues.put(name, value);
						}
					}
				} catch (ParseException pe) {
					log.error("Failed to parse: {}", cleanJson);
				}
			} else {
				log.error("Found no payload match: {}", heartBeat);
			}
		} else {
			log.error("Last heartbeat was not found");
		}
		return heartbeatValues;
	}

	public void logLastHeartbeat(String serial) {
		Map<String, String> lastHeartbeat = getLastHeartbeatJson(serial);
		log.debug("Last heartbeat values values for {} logged at {} {}:", lastHeartbeat.get("+found_serial+"), lastHeartbeat.get("+date+"), lastHeartbeat.get("+time+"));
		Object[] keys = lastHeartbeat.keySet().toArray();
		Arrays.sort(keys);
		for (Object attributeName : keys) {
			if (!attributeName.toString().matches("\\+.*\\+")) log.debug(String.format("%-40s = %s", attributeName.toString(), lastHeartbeat.get(attributeName)));
		}
	}

	public void logLastHeartbeatValue(String serial, String attribute) {
		Map<String, String> lastHeartbeat = getLastHeartbeatJson(serial);
		if (lastHeartbeat.containsKey(attribute)) {
			log.fatal("Heartbeat sent: {} => {}", attribute, lastHeartbeat.get(attribute));
		} else {
			log.fatal("Heartbeat did not include the key {}", attribute);
		}
	}

	public int getLastHeartbeatCount(String serial) {
		Map<String, String> lastHeartbeat = getLastHeartbeatJson(serial);
		return lastHeartbeat.size();
	}
}
