package com.spectralink.test_automation.cucumber.framework.common;

import com.jcraft.jsch.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Properties;

public class RemoteShell {
    private final Logger log = LogManager.getLogger(this.getClass().getName());
    final String ipAddress;
    final String account;
    final String password;
    JSch jsch;

    public RemoteShell(String ipAddress, String account, String password) {
        this.ipAddress = ipAddress;
        this.account = account;
        this.password = password;
        this.jsch = new JSch();
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public String getAccount() {
        return account;
    }

    public String getPassword() {
        return password;
    }

    private void drainInputStream(BufferedReader reader, StringBuilder record) {
        String message;
        try {
            while ((message = reader.readLine()) != null) {
                record.append(message + "\n");
                log.trace(message);
            }
        } catch (IOException ioe) {
            log.error("Exception occurred while reading stream: {}", ioe.getMessage());
        }
    }

    public CliResult executeCommand(List<String> command) throws JSchException, IOException {
        if (command.isEmpty()) throw new IllegalArgumentException();
        CliResult result = new CliResult();
        int triesLeft = 3;
        while (triesLeft > 0) {
            Session session = jsch.getSession(getAccount(), getIpAddress(), 22);
            session.setPassword(getPassword());
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();

            StringBuilder output = new StringBuilder();
            StringBuilder errors = new StringBuilder();
            BufferedReader inputReader = null;
            BufferedReader errorReader = null;
            ChannelExec channel = (ChannelExec) session.openChannel("exec");

            try {
                channel.setCommand(String.join(" ", command));
                channel.setPtySize(140, 24, 140, 80);
                result.setCommand(command);
                log.trace("Running command '{}'", String.join(" ", command));
                channel.setPty(true);
                channel.setInputStream(null);

                inputReader = new BufferedReader(new InputStreamReader(channel.getInputStream()));
                errorReader = new BufferedReader(new InputStreamReader(channel.getErrStream()));
                channel.connect();

                int count = 0;
                while (true && count < 60) {
                    drainInputStream(inputReader, output);
                    drainInputStream(errorReader, errors);
                    if (channel.isClosed()) {
                        result.setExitCode(channel.getExitStatus());
                        result.setStdout(output.toString());
                        result.setStderr(errors.toString());
                        if (result.getExitCode() != 1) return result;
                    }

                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    count += 1;
                }

            } catch (JSchException e) {
                log.error("SSH exception {}", e.getMessage());
            } catch (IOException ioe) {
                log.error("IO exception {}", ioe.getMessage());
            } finally {
                try {
                    inputReader.close();
                    errorReader.close();
                    channel.disconnect();
                    session.disconnect();
                } catch (Exception e) {
                    log.error("Exception during SSH cleanup: {}", e.getMessage());
                }
            }
            triesLeft -= 1;
        }
        return result;
    }

    public void getFile(String remotePath) {
        Session session = null;
        ChannelSftp sftpChannel = null;
        try {
            session = jsch.getSession(getAccount(), getIpAddress(), 22);
            session.setPassword(getPassword());
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();

            Channel channel = session.openChannel("sftp");
            channel.connect();

            String[] filePathPieces = remotePath.split("/");
            sftpChannel = (ChannelSftp) channel;
            sftpChannel.get(remotePath, filePathPieces[filePathPieces.length - 1], (SftpProgressMonitor) null, ChannelSftp.OVERWRITE);
        } catch (JSchException jse) {
            log.error("Connection exception: {}", jse.getMessage());
        } catch (SftpException se) {
            log.error("SFTP exception: {}", se.getMessage());
        } finally {
            if (sftpChannel != null) sftpChannel.exit();
            if (session != null) session.disconnect();
        }
    }

    public void putFile(String localPath, String remotePath) {
        Session session = null;
        ChannelSftp sftpChannel = null;
        try {
            session = jsch.getSession(getAccount(), getIpAddress(), 22);
            session.setPassword(getPassword());
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();

            Channel channel = session.openChannel("sftp");
            channel.connect();

            sftpChannel = (ChannelSftp) channel;
            sftpChannel.put(localPath, remotePath, (SftpProgressMonitor) null, ChannelSftp.OVERWRITE);
        } catch (JSchException jse) {
            log.error("Connection exception: {}", jse.getMessage());
        } catch (SftpException se) {
            log.error("SFTP exception: {}", se.getMessage());
        } finally {
            if (sftpChannel != null) sftpChannel.exit();
            if (session != null) session.disconnect();
        }
    }
}
