package com.spectralink.test_automation.cucumber.framework.sam.common;

import com.spectralink.test_automation.cucumber.framework.common.AppSetting;
import com.spectralink.test_automation.cucumber.framework.common.TestPhone;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.LinkedHashMap;
import java.util.Map;

public class SimPhone extends VersityPhone implements TestPhone {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private Map<String, AppSetting> appSettings = new LinkedHashMap<>();
	private Application currentAppSettings;
	private String preferencesFile = "";
	private String model;
	private String serial;
	private String mac;

	public SimPhone(String model, String serialNumber, String macAddress) {
		super(null, serialNumber, "device", "0");
		this.model = model;
		this.serial = serialNumber;
		this.mac = macAddress;
		setPhoneType(PhoneType.VERSITY);
		currentAppSettings = Application.NONE;
	}

	@Override
	public void loadAppPreferences(Application application) {
		currentAppSettings = application;
	}

	@Override
	public void clearAppSettings() {
		setPreferencesFile("");
		currentAppSettings = Application.NONE;
	}

	@Override
	public void reloadAppPreferences() {
		loadAppPreferences(currentAppSettings);
	}

	@Override
	public Application getCurrentAppSettings() {
		return currentAppSettings;
	}

	private void setCurrentAppSettings(Application currentAppSettings) {
		this.currentAppSettings = currentAppSettings;
	}

	public Map<String, AppSetting> getAppSettings() {
		return appSettings;
	}

	private void setAppSettings(Map<String, AppSetting> appSettings) {
		this.appSettings = appSettings;
	}

	@Override
	public String getSerialNumber() {
		return serial;
	}

	@Override
	public String getMacAddress() {
		return mac;
	}

	@Override
	public String getModel() {
		return model;
	}

	@Override
	public AppSetting getSettingForAppKey(String key) {
		AppSetting setting = new AppSetting();
		return setting;
	}

	@Override
	public Object getValueTypeForAppKey(String key) {
		return getStringForAppKey(key);
	}

	@Override
	public Object getValueForAppKey(String key) {
		return getStringForAppKey(key);
	}

	@Override
	public String getStringForAppKey(String key) {
		return "";
	}

	@Override
	public String getForcedStringForAppKey(String key) {
		return "";
	}

	@Override
	public Integer getIntegerForAppKey(String key) {
		return 0;
	}

	@Override
	public Boolean getBooleanForAppKey(String key) {
		return false;
	}

	@Override
	public boolean hasCamera() {
		return false;
	}

	@Override
	public boolean hasBarcodeScanner() {
		return false;
	}

	public String getPreferencesFile() {
		return preferencesFile;
	}

	private void setPreferencesFile(String preferencesFile) {
		this.preferencesFile = preferencesFile;
	}

	@Override
	public int compareButton(String key, String samValue) {
		return 0;
	}

	@Override
	public int compare(String key, String samValue) {
		return 0;
	}

	@Override
	public int contrast(String key, String samValue) {
		return 0;
	}

	@Override
	public int compareApproximate(String key, String samValue, int bound) {
		return 0;
	}

	@Override
	public int compareSound(String key, String samValue) {
		return 0;
	}
}





