package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.*;
import com.spectralink.test_automation.cucumber.framework.device.pages.AmieAgentUi;
import com.spectralink.test_automation.cucumber.framework.device.pages.BizPhoneUi;
import io.appium.java_client.android.connection.ConnectionStateBuilder;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.SkipException;

import java.io.File;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.*;
import static com.spectralink.test_automation.cucumber.framework.common.AppiumPhone.Activity;
import static com.spectralink.test_automation.cucumber.framework.common.AppiumPhone.Application;
import static com.spectralink.test_automation.cucumber.framework.common.Util.*;
import static com.spectralink.test_automation.cucumber.framework.device.common.CallServerDetails.SipServerType.*;

public class DeviceNavigationSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    public static Boolean inCall = false;
    public static Boolean phoneOnHomeScreen = false;

    @Given("^there are \"([^\"]*)\" test phones available$")
    public void checkTestPhones(String arg1) {
        List<VersityPhone> phoneList = Environment.getUsbHost().getAllVersityPhones();
        int phoneCount = phoneList.size();
        if (phoneCount < Integer.parseInt(arg1.trim())) {
            throw new SkipException("Skipping test since " + arg1 + " phones are needed but only found " + phoneCount);
        }
        log.info("Found {} possible test phones", phoneList.size());
    }

    @When("^I unlock the screen of device \"([^\"]*)\" with pin \"([^\"]*)\"$")
    public void downloadInstallApp(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.unlockScreen(arg2.trim());
        if (phone.screenIsDark() || phone.isLocked()) {
            log.fatal("Device {} could not be unlocked", arg1);
            Assert.fail("DEVICE UNLOCK FAILURE");
        }
    }

    @When("^I unlock the screen of device \"([^\"]*)\" without any checks with pin \"([^\"]*)\"$")
    public void unlockDevice(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.swipeScreen();
        phone.swipeScreen();
        phone.typeText(arg2.trim());
        phone.tapEnter();
        log.debug("Device unlocked");
    }

    @When("^I lock the screen of device \"([^\"]*)\"$")
    public void lockScreen(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.lockScreen();
    }

    @When("^I bring the \"([^\"]*)\" app on screen \"([^\"]*)\" to the foreground on device \"([^\"]*)\"$")
    public void foregroundActivity(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        Application application = phone.findApplication(arg1.trim());
        if (application != null) {
            Activity activity = phone.findActivity(arg2.trim());
            if (activity != null) {
                phone.bringAppToForeground(application, activity);
                if (phone.getForegroundPackage().contentEquals(application.getPackage())) {
                    log.debug("Started application {}", arg1);
                } else {
                    log.fatal("Application {} could not be foregrounded", arg1);
                    Assert.fail(Util.glue("COULD NOT START APPLICATION", quote(arg1.toUpperCase())));
                }
            } else {
                log.error("Invalid screen name '{}' requested for application {}", arg2, arg1);
                Assert.fail(Util.glue("INVALID APPLICATION SCREEN", quote(arg2.toUpperCase()), "REQUESTED"));
            }
        } else {
            log.error("Invalid application name '{}' requested", arg1);
            Assert.fail(glue("INVALID APPLICATION", arg1.toUpperCase(), "INVALID APPLICATION REQUESTED"));
        }
    }

    @When("^I bring the \"([^\"]*)\" app to the foreground on device \"([^\"]*)\"$")
    public void foregroundApp(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        Application app = phone.findApplication(arg1.trim());
        if (!phone.getForegroundPackage().contentEquals(app.getPackage())) {
            phone.bringAppToForeground(app);
            if (phone.getForegroundPackage().contentEquals(app.getPackage())) {
                phone.setCurrentAppUi(phone.getBattLifeUi());
                log.debug("Started application '{}'", arg1);
                sleepSeconds(1);
            } else {
                log.fatal("'{}' application could not be started", arg1);
                Assert.fail(Util.glue("COULD NOT START '" + arg1 + "' APPLICATION"));
            }
        }
    }

    @When("^I bring the Barcode app to the foreground on device \"([^\"]*)\"$")
    public void foregroundAppBarcode(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone.hasBarcodeScanner()) {
            AndroidPhone.Application app;
            if(phone.getModel().toLowerCase().contains("saturn"))
                app = phone.findApplication(SATURN_BARCODE.getLabel());
            else
                app = phone.findApplication(BARCODE.getLabel());
            String packageName = app.getPackage();

            if (!phone.getForegroundPackage().contentEquals(packageName)) {
                phone.bringAppToForeground(app);
                if (phone.getForegroundPackage().contentEquals(app.getPackage())) {
                    phone.setCurrentAppUi(phone.getBattLifeUi());
                    log.debug("Started Barcode application");
                    sleepSeconds(1);
                } else {
                    log.fatal("Barcode application could not be started");
                    Assert.fail(Util.glue("COULD NOT START BARCODE APPLICATION"));
                }
            }
        }
        else {
            log.debug("Phone does not have a barcode scanner");
        }
    }

    @When("^I bring the Saturn Barcode app to the foreground on device \"([^\"]*)\"$")
    public void foregroundSaturnAppBarcode(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone.hasBarcodeScanner()) {
            Application app = phone.findApplication(SATURN_BARCODE.getLabel());
            if (!phone.getForegroundPackage().contentEquals(app.getPackage())) {
                phone.bringAppToForeground(app);
                if (phone.getForegroundPackage().contentEquals(app.getPackage())) {
                    phone.setCurrentAppUi(phone.getBattLifeUi());
                    log.debug("Started Barcode application");
                    sleepSeconds(1);
                } else {
                    log.fatal("Barcode application could not be started");
                    Assert.fail(Util.glue("COULD NOT START BARCODE APPLICATION"));
                }
            }
        }
        else {
            log.debug("Phone does not have a barcode scanner");
        }
    }

    @When("^I tap the back button on device \"([^\"]*)\"$")
    public void goBack(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @When("^I navigate to the home screen on device \"([^\"]*)\"$")
    public void goHome(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.sendKeyEvent(AndroidKey.HOME);
    }

    @When("^I scroll to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void scrollUpDown(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        log.debug("Scrolling " + arg1);
        switch (arg1.toLowerCase()) {
            case "bottom":
                try {
                    phone.appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingToEnd(10);");
                } catch (Exception e) {
                    // ignore
                }
                break;
            case "top":
                try {
                    phone.appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingToBeginning(10);");
                } catch (Exception e) {
                    // ignore
                }
                break;
        }
    }

    @When("^I fling \"([^\"]*)\" on \"([^\"]*)\"$")
    public void flingUpDown(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        log.debug("Scrolling " + arg1);
        switch (arg1.toLowerCase()) {
            case "forward":
                try {
                    phone.appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingForward();");
                } catch (Exception e) {
                    // ignore
                }
                break;
            case "backward":
                try {
                    phone.appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingBackward();");
                } catch (Exception e) {
                    // ignore
                }
                break;
        }
    }

    @When("^I clear the data for \"([^\"]*)\" on device \"([^\"]*)\"$")
    public void clearData(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        Application app = phone.findApplication(arg1.trim());
        if (app != null) {
            phone.clearAppData(app);
            log.debug("Cleared data for '{}' application", arg1);
        } else {
            log.error("No application named '{}' was found", arg1);
        }
    }

    @When("^I kill the \"([^\"]*)\" app on device \"([^\"]*)\"$")
    public void killApp(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        Application app = phone.findApplication(arg1.trim());
        if (app != null) {
            phone.closeApp(app);
            log.debug("Closed '{}' application", arg1);
        } else {
            log.error("No application named '{}' was found", arg1);
        }
    }

    @Then("^the \"([^\"]*)\" screen is displayed on device \"([^\"]*)\"")
    public void verifyActivity(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        Activity activity = phone.findActivity(arg1.trim());
        if (activity != null) {
            String[] chunks = activity.getIntent().split("\\.");
            if (phone.getForegroundActivity().contains(chunks[chunks.length - 1])) {
                log.debug("{} screen appeared in foreground", arg1);
            } else {
                log.fatal("{} screen was not visible", arg1);
                Environment.softAssert().fail("SCREEN NOT VISIBLE");
            }
        } else {
            log.error("No screen named '{}' was found", arg1);
            Environment.softAssert().fail("UNKNOWN SCREEN DISPLAYED");
        }
    }

    @Then("^the \"([^\"]*)\" screen is not displayed on device \"([^\"]*)\"")
    public void verifyNotActivity(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        Activity activity = phone.findActivity(arg1.trim());
        if (!phone.getForegroundActivity().contains(activity.getIntent())) {
            log.debug("{} screen was not in foreground", arg1);
        } else {
            log.fatal("{} screen was visible", arg1);
            Environment.softAssert().fail("SCREEN WAS VISIBLE");
        }
    }

    @Then("^I dump all UI info from the current screen of device \"([^\"]*)\" into file \"([^\"]*)\"$")
    public void findIds(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        AmieAgentUi agentUi = phone.getAmieAgentUi();
        XmlTool.printXml(agentUi.getPageSource(), arg2.trim());
    }

    @When("^I sleep for \"([^\"]*)\" seconds")
    public void sleep(String arg1) {
        log.debug("Sleeping: " + arg1 + " seconds" );
        try {
            long seconds = Long.parseLong(arg1);
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @When("^I start video recording on \"([^\"]*)\"$")
    public void startVideo(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        phone.startVideoRecording();
        log.debug("Started video recording on: " + arg1);
    }

    @When("^I stop video recording on \"([^\"]*)\" and name the video file \"([^\"]*)\"$")
    public void stopVideo(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        phone.stopVideoRecording(getVideoDirectory() + "/" + arg1 + "-" + arg2);
        log.debug("Stopped video recording on: " + arg1);
        phone.removeLeftoverVideosFromPhone();
    }

    @When("^I encrypt the token \"([^\"]*)\"$")
    public void encrypt(String arg1) {
        log.debug("Encrypted {} = '{}' ", arg1, Environment.salinate(arg1));
    }

    /*@When("^I press and hold the \"([^\"]*)\" button for \"([^\"]*)\" seconds on device \"([^\"]*)\"$")
    public void pressAndHoldButton(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String keyCode;
        switch (arg1.trim().toLowerCase()) {
            case "ptt":
                keyCode = "F14";
                break;
            default:
                keyCode = "F14";
        }
        HardButtonPress buttonPress = new HardButtonPress(phone, keyCode, Integer.valueOf(arg2.trim()));
        Environment.setThread(new Thread(buttonPress));
        Environment.getThread().start();
    }*/

    @When("^I reboot the device \"([^\"]*)\"$")
    public void rebootPhone(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        log.debug("Deleting Android Driver");
        phone.deleteAndroidDriver();
        log.debug("Rebooting the phone");
        phone.rebootPhone();
    }

    @Then("^I verify \"([^\"]*)\" usage of \"([^\"]*)\" is acceptable on \"([^\"]*)\"$")
    public void acceptableUsage(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        Application app = phone.findApplication(arg2.trim());
        double result;
        switch (arg1.trim().toLowerCase()) {
            case "memory":
                result = Double.parseDouble(phone.getAppMemoryUsage(app));
                if (result <= 75.0) {
                    log.debug("Memory usage: {} : is acceptable", result);
                } else {
                    log.error("Memory usage: {} : is not acceptable", result);
                    Environment.softAssert().fail("MEMORY USAGE UNACCEPTABLE");
                }
                break;
            case "cpu":
                result = Double.parseDouble(phone.getAppCpuUsage(app));
                if (result <= 75.0) {
                    log.debug("Cpu usage: {} : is acceptable", result);
                } else {
                    log.error("Cpu usage: {} : is not acceptable", result);
                    Environment.softAssert().fail("CPU USAGE UNACCEPTABLE");
                }
                break;
        }
    }

    @When("^I clear logcat on \"([^\"]*)\"$")
    public void clearLogcat(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.clearLogcat();
        log.debug("Logcat cleared on: " + arg1);
    }

    @When("^I check \"([^\"]*)\"'s current screen")
    public void callReceivingPhoneScreen(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        log.debug("Current screen on " + arg1 + " is: " + phone.getForegroundPackage());
        if (phone.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone.getForegroundActivity().equals("com.spectralink.phone.activities.InCallScreen"))
            inCall = true;
    }

    @Then("^I verify the string \"([^\"]*)\" is present in the logs on \"([^\"]*)\"$")
    public void logcatParse(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        log.debug("Looking for '{}' in the logs",arg1);
        if(phone.parseLogsForString(arg1))
            log.debug("String found");
        else {
            log.fatal("String not found");
            Environment.softAssert().fail("LOG PARSING FAILED");
        }
    }

    @When("^I open notification bar on \"([^\"]*)\"$")
    public void openNotification(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        phone.openNotificationBar();
    }

    @When("^I select \"([^\"]*)\" as the call server on \"([^\"]*)\"")
    public void callServer(String arg1, String arg2) {
        File configFile = Environment.getRegistrationFile();
        RunDefaults.setConfigFile(configFile);
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;

        switch (arg1.toLowerCase()) {

            case "switchvox":
                phone.callServerDetails().setSipServer(SWITCHVOX, arg2);
                break;
            case "avaya":
                phone.callServerDetails().setSipServer(AVAYA, arg2);
                break;
            case "mitel":
                phone.callServerDetails().setSipServer(MITEL, arg2);
                break;
            case "cisco spp":
                phone.callServerDetails().setSipServer(CISCO_SPP, arg2);
                break;
            case "saturn":
                phone.callServerDetails().setSipServer(SATURN, arg2);
                break;
        }
    }

    @When("^I tap 'enter' on \"([^\"]*)\"$")
    public void enter(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.sendKeyEvent(AndroidKey.ENTER);
    }

    @Then("^I scroll to \"([^\"]*)\" notification on \"([^\"]*)\"$")
    public void notificationItem(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.openNotificationBar();
        sleepSeconds(1);
        for (int count = 0; count < 4; count++) {
            List<WebElement> options = phone.appium().findElementsById("android:id/app_name_text");
            for (WebElement element : options) {
                if (element.getText().trim().equals(arg1.trim())) {
                    return;
                }
            }
            phone.scrollUpDimensions(0.80, 0.20);
        }
    }

    @When("^I toggle Wifi \"([^\"]*)\" on \"([^\"]*)\"$")
    public void toggleWifi(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        switch (arg1.trim().toLowerCase()) {

            case "off":
                log.debug("Turning Wi-Fi off");
                phone.toggleWifiSvc(false);
                break;
            case "on":
                log.debug("Turning Wi-Fi on");
                phone.toggleWifiSvc(true);
                break;
        }
    }

    @Then("^I clear notifications on \"([^\"]*)\"$")
    public void clearNotifications(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        for (int count = 0; count < 4; count++) {
            try {
                phone.appium().findElementByAccessibilityId("Clear all notifications.").click();
                break;
            }
            catch (Exception exception) {
                log.debug("CLEAR ALL not found on '{}'", arg1);
                try {
                    phone.appium().findElementByAccessibilityId("Manage notifications");
                    break;
                }
                catch (Exception exception1) {
                    log.debug("MANAGE not found on '{}'", arg1);
                }
            }
            phone.scrollUpDimensions(0.80, 0.20);
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @When("^I tap the Don't Send button on device \"([^\"]*)\"$")
    public void dontSendAppForScanning(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        bizPhoneUi.tapCancelButton();
    }
}
