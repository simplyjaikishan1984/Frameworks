package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.WaitOptions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static io.appium.java_client.touch.offset.PointOption.point;

public class DeviceTranslationUi extends AppiumUi {

    @AndroidFindBy(id = "com.android.settings:id/add_language")
    private WebElement addLanguageButton;

    @AndroidFindBy(accessibility = "Search")
    private WebElement searchControl;

    @AndroidFindBy(id = "android:id/search_src_text")
    private WebElement searchEditText;

    @AndroidFindBy(accessibility = "French")
    private WebElement frenchLanguage;

    @AndroidFindBy(accessibility = "Canada")
    private WebElement frenchCountryCanada;

    @AndroidFindBy(accessibility = "France")
    private WebElement frenchCountryFrance;

    @AndroidFindBy(id = "android:id/button1")
    private WebElement okButton;

    @AndroidFindBy(accessibility = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.view.ViewGroup/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/androidx.appcompat.widget.LinearLayoutCompat")
    private WebElement overflowMenu;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout")
    private WebElement overflowMenuItem1Android10;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]")
    private WebElement overflowMenuItem1Android8;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[2]/android.widget.LinearLayout")
    private WebElement overflowMenuItem2Android10;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[2]")
    private WebElement overflowMenuItem2Android8;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[3]/android.widget.LinearLayout")
    private WebElement overflowMenuItem3Android10;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[3]")
    private WebElement overflowMenuItem3Android8;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout[2]/android.widget.Button")
    private WebElement advancedDebuggingButton;

    @AndroidFindBy(id = "com.spectralink.slnklogger:id/password_edittext")
    private WebElement loggingAdminPassword;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ListView/android.widget.LinearLayout[1]")
    private WebElement advancedLoggingOption;

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    public DeviceTranslationUi(AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void clickOkButton() {
        okButton.click();
    }

    public void addLanguage() {
        addLanguageButton.click();
    }

    public void clickSearch() {
        searchControl.click();
    }

    public void enterIntoSearchEditText(String language) {
        searchEditText.clear();
        searchEditText.sendKeys(language);
    }

    public void selectFrench() {
        frenchLanguage.click();
    }

    public void selectFrenchCanada() {
        frenchCountryCanada.click();
    }

    public void pushLanguageToTop() {
        new TouchAction(driver).press(point(1000, 600)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(500))).moveTo(point(1000, 350)).release().perform();
    }

    public boolean selectTextMenuOption(String option) {
        List<WebElement> options = driver.findElements(By.className("android.widget.TextView"));
        for (WebElement element : options) {
            if (element.getText().toLowerCase().contentEquals(option.toLowerCase())) {
                clickOnPageEntity(element);
                sleepSeconds(1);
                return true;
            }
        }
        return false;
    }

    public void tapOnMoreOptions() {
        overflowMenu.click();
    }

    public void selectOverflowMenuItem1Android10() {
        overflowMenuItem1Android10.click();
    }

    public void selectOverflowMenuItem2Android10() {
        overflowMenuItem2Android10.click();
    }

    public void selectOverflowMenuItem3Android10() {
        try {
            if(overflowMenuItem3Android10.isDisplayed())
                overflowMenuItem3Android10.click();
        }
        catch (NoSuchElementException exception) {
            log.debug("Overflow menu item 3 not found");
        }
    }

    public void selectOverflowMenuItem1Android8() {
        overflowMenuItem1Android8.click();
    }

    public void selectOverflowMenuItem2Android8() {
        overflowMenuItem2Android8.click();
    }

    public void selectOverflowMenuItem3Android8() {
        try {
            if(overflowMenuItem3Android8.isDisplayed())
                overflowMenuItem3Android8.click();
        }
        catch (NoSuchElementException exception) {
            log.debug("Overflow menu item 3 not found");
        }
    }

    public void fetchScreenElements(VersityPhone phone, Boolean scroll, List<String> appiumElements) {

        if (scroll) {
            for (int count = 0; count < 2; count++) {
                List<WebElement> elementsScroll = (List<WebElement>)driver.findElements(By.className("android.widget.TextView"));
                for (WebElement elementScroll : elementsScroll)
                    appiumElements.add(elementScroll.getText().trim());
                phone.flingForward();
            }
        }
        else {
            List<WebElement> elementsNoScroll = (List<WebElement>)driver.findElements(By.className("android.widget.TextView"));
            for (WebElement elementNoScroll : elementsNoScroll)
                appiumElements.add(elementNoScroll.getText().trim());
        }
    }

    public void tapAdvancedDebuggingButton() {
        advancedDebuggingButton.click();
    }

    public void enterAdminPassword() {
        loggingAdminPassword.sendKeys("admin");
    }

    public void tapAdvancedLoggingOption() {
        advancedLoggingOption.click();
    }

}
