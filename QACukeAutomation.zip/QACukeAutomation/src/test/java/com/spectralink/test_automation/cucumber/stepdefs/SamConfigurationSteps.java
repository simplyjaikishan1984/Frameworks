package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamConfigurationPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.Environment.SamPage.*;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamConfigurationSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I click the AMiE Agent card$")
    public void clickAmieAgentCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoAmieAgent(), AMIE_AGENT);
        } else {
            log.error("Cannot navigate to {} page from {} page", AMIE_AGENT.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the Barcode card$")
	public void clickBarcodeCard() {
		if (Environment.onConfigurationPage()) {
		    SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoBarcode(), BARCODE);
        } else {
		    log.error("Cannot navigate to {} page from {} page", BARCODE.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
	}

    @When("^I click the BattLife card$")
    public void clickBattLifeCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoBattLife(), BATTLIFE);
        } else {
            log.error("Cannot navigate to {} page from {} page", BATTLIFE.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the Biz Phone card$")
    public void clickBizPhoneCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoBizPhone(), BIZ_PHONE);
        } else {
            log.error("Cannot navigate to {} page from {} page", BIZ_PHONE.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the Buttons card$")
    public void clickButtonsCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoButtons(), BUTTONS);
        } else {
            log.error("Cannot navigate to {} page from {} page", BUTTONS.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the Device Settings card$")
    public void clickDeviceSettingsCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoDeviceSettings(), DEVICE_SETTINGS);
        } else {
            log.error("Cannot navigate to {} page from {} page", DEVICE_SETTINGS.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the Lens Grid card$")
    public void clickLensGridCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoLensGrid(), LENS_GRID);
        } else {
            log.error("Cannot navigate to {} page from {} page", LENS_GRID.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the Logging card$")
    public void clickLoggingCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoLogging(), LOGGING);
        } else {
            log.error("Cannot navigate to {} page from {} page", LOGGING.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the PTT card$")
    public void clickPttCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoPtt(), PTT);
        } else {
            log.error("Cannot navigate to {} page from {} page", PTT.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the SAFE card$")
    public void clickSafeCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoSafe(), SAFE);
        } else {
            log.error("Cannot navigate to {} page from {} page", SAFE.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the SSO Status card$")
    public void clickSsoStatusCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoSsoStatus(), SSO_STATUS);
        } else {
            log.error("Cannot navigate to {} page from {} page", SSO_STATUS.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the SysUpdater card$")
    public void clickSysUpdaterCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoSysUpdater(), SYS_UPDATER);
        } else {
            log.error("Cannot navigate to {} page from {} page", SYS_UPDATER.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the VQO card$")
    public void clickVqoCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoVqo(), VQO);
        } else {
            log.error("Cannot navigate to {} page from {} page", VQO.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the WebAPI card$")
    public void clickWebapiCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoWebApi(), WEBAPI);
        } else {
            log.error("Cannot navigate to {} page from {} page", WEBAPI.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the Custom Apps card$")
    public void clickCustomAppsCard() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            Environment.setCurrentPage(configPage.gotoCustomApps(), CUSTOM_APPS);
        } else {
            log.error("Cannot navigate to {} page from {} page", CUSTOM_APPS.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the 'Send Configuration Now' button$")
    public void clickSendConfiguration() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            configPage.clickSaveAndTriggerConfiguration();
            sleepSeconds(1);
        } else {
            log.error("Cannot click 'Send Configuration Now' from {} page", Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the 'Save Configuration' button$")
    public void clickSaveConfiguration() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            configPage.clickSaveConfiguration();
            sleepSeconds(1);
        } else {
            log.error("Cannot click 'Save Configuration' from {} page", Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I click the 'Cancel' button$")
    public void clickCancelConfiguration() {
        if (Environment.onConfigurationPage()) {
            SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
            configPage.clickCancel();
        } else {
            log.error("Cannot click 'Cancel' from {} page", Environment.getCurrentPageName().name());
            Assert.fail("SAM Navigation Error");
        }
    }

    @When("^I unfold the Custom Attributes section$")
    public void clickCustomAttributes() {
        SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
        if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
            configPage.openCustomAttributes();
        }
    }

    @When("^I set a custom attribute with key \"([^\"]*)\" and type \"([^\"]*)\" to \"([^\"]*)\"$")
    public void setCustomAttribute(String arg1, String arg2, String arg3) {
        SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
        if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
            configPage.setCustomAttribute(arg1, arg2, arg3);
        } else {
            log.debug("Skipped setting attribute '{}' since custom attribute testing is turned off", arg1);
        }
    }

    @Then("I delete the custom attribute with key \"([^\"]*)\"$")
    public void deleteCustomAttributeSetting(String arg1) {
        SamConfigurationPage configPage = (SamConfigurationPage) Environment.getCurrentPage();
        if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
            configPage.deleteCustomAttribute(arg1);
        }
    }

    @Then("^there were no mismatches between SAM and app settings on \"([^\"]*)\"$")
    public void checkNoMismatches(String arg1) {
        int failures = Environment.getScenarioFailureCount();
        if (failures > 0) {
            for (String phoneName : arg1.trim().split("\\s*,\\s*")) {
                VersityPhone phone = Environment.getPhone(phoneName);
                Environment.getSam().jarvisLog().logLastFullResponse(phone.getSerialNumber());
            }
            Assert.fail(Util.glue("Found", failures, "mismatched settings between SAM and the app"));
        }
        log.debug("No mismatched settings were found between SAM and the application(s)");
    }
}