package com.spectralink.test_automation.cucumber.framework.sam;

import com.spectralink.test_automation.cucumber.framework.WebAutomation;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamAutomation extends WebAutomation {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	public SamAutomation() {
		super();
		explicitWait = RunDefaults.getNumericSetting("explicitWaitSeconds");
	}

	public void setExplicitWait(int implicitWait) {
		this.explicitWait = implicitWait;
	}

	public void setNoWait() {
		this.explicitWait = 0;
	}

	public void resetWait() {
		this.explicitWait = RunDefaults.getNumericSetting("explicitWaitSeconds");
	}

	public void saveLastHeartbeat(File heartbeatFile, String serial) {
		try {
			Files.write(heartbeatFile.toPath(), Environment.getSam().jarvisLog().getLastHeartbeat(serial).getBytes());
		} catch (Exception e) {
			log.error("Error saving heartbeat: {}", e.getMessage());
		}
	}

	public void saveLastResponse(File responseFile, String serial) {
		try {
			Files.write(responseFile.toPath(), Environment.getSam().jarvisLog().getLastResponse(serial).getBytes());
		} catch (Exception e) {
			log.error("Error saving response: {}", e.getMessage());
		}
	}

	public String getToastMessage() {
		waitForElementPresence(By.xpath("//*[@id=\"toast-container\"]/ng-include/div/div[2]"));
		return driver.findElement(By.xpath("//*[@id=\"toast-container\"]/ng-include/div/div[2]")).getText();
	}

	protected boolean isToastPresent() {
		return isPresent(By.xpath("//*[@id=\"toast-container\"]/ng-include/div/button/span[1]"));
	}

	protected void closeToastMessage() {
		if (isToastPresent()) {
			WebElement element = locateElement(By.xpath("//*[@id=\"toast-container\"]/ng-include/div/button/span[1]"));
			clickOnPageEntity(element);
			log.trace("Closed toast message");
		}
	}

	public int getRowCount(int canvasIndex) {
		List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
		List<WebElement> rows = canvas.get(canvasIndex).findElements(By.className("ui-grid-row"));
		return rows.size();
	}

	public WebElement getRowElement(int rowNumber, int canvasIndex) {
		if (rowNumber - 1 >= 0) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 1) {
				List<WebElement> rows = canvas.get(canvasIndex).findElements(By.className("ui-grid-draggable-row"));
				return rows.get(rowNumber - 1);
			}
		}
		return null;
	}

	public boolean gridRowExists(int rowNumber) {
		if (rowNumber - 1 >= 0) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 0) {
				List<WebElement> rows = canvas.get(1).findElements(By.className("ui-grid-row"));
				return rows.size() >= rowNumber;
			}
		}
		return false;
	}

	public boolean gridRowExists(int rowNumber, int canvasIndex) {
		if (rowNumber - 1 >= 0) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 0) {
				List<WebElement> rows = canvas.get(canvasIndex).findElements(By.className("ui-grid-row"));
				return rows.size() >= rowNumber;
			}
		}
		return false;
	}

	public boolean gridCellExists(int rowNumber, int colNumber) {
		if (rowNumber - 1 >= 0 && colNumber - 1 >= 0) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 0) {
				List<WebElement> rows = canvas.get(1).findElements(By.className("ui-grid-row"));
				if (rows.size() >= rowNumber) {
					List<WebElement> columns = rows.get(rowNumber - 1).findElements(By.className("ui-grid-cell-contents"));
					return columns.size() >= colNumber;
				}
			}
		}
		return false;
	}

	public boolean gridCellExists(int rowNumber, int colNumber, int canvasIndex) {
		if (rowNumber - 1 >= 0 && colNumber - 1 >= 0) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 0) {
				List<WebElement> rows = canvas.get(canvasIndex).findElements(By.className("ui-grid-row"));
				if (rows.size() >= rowNumber) {
					List<WebElement> columns = rows.get(rowNumber - 1).findElements(By.className("ui-grid-cell-contents"));
					return columns.size() >= colNumber;
				}
			}
		}
		return false;
	}

	public String getGridCellValue(int rowNumber, int colNumber) {
		if (rowNumber - 1 >= 0 && colNumber - 1 >= 0) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 0) {
				List<WebElement> rows = canvas.get(1).findElements(By.className("ui-grid-row"));
				if (rows.size() >= rowNumber) {
					List<WebElement> columns = rows.get(rowNumber - 1).findElements(By.className("ui-grid-cell-contents"));
					if (columns.size() >= colNumber) {
						return columns.get(colNumber - 1).getText();
					}
				}
			}
		}
		return null;
	}

	public String getGridCellValue(int rowNumber, int colNumber, int canvasIndex) {
		if (rowNumber - 1 >= 0 && colNumber - 1 >= 0) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 0) {
				List<WebElement> rows = canvas.get(canvasIndex).findElements(By.className("ui-grid-row"));
				if (rows.size() >= rowNumber) {
					List<WebElement> columns = rows.get(rowNumber - 1).findElements(By.className("ui-grid-cell-contents"));
					if (columns.size() >= colNumber) {
						return columns.get(colNumber - 1).getText();
					}
				}
			}
		}
		return null;
	}

	public int getRowIndexOfColumnFragment(String targetValue, int column, int canvasIndex) {
		List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
		if (canvas.size() > 0) {
			List<WebElement> rows = canvas.get(canvasIndex).findElements(By.className("ui-grid-row"));
			for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
				List<WebElement> columns = rows.get(rowIndex).findElements(By.className("ui-grid-cell-contents"));
				if (columns.get(column - 1).getText().contains(targetValue)) {
					return rowIndex;
				}
			}
		}
		log.warn("Could not find cell with partial value {}", targetValue);
		return -1;
	}

	public int getRowIndexOfColumnValue(String targetValue, int column) {
		List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
		if (canvas.size() > 0) {
			List<WebElement> rows = canvas.get(1).findElements(By.className("ui-grid-row"));
			for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
				List<WebElement> columns = rows.get(rowIndex).findElements(By.className("ui-grid-cell-contents"));
				if (columns.get(column - 1).getText().contentEquals(targetValue)) {
					return rowIndex;
				}
			}
		}
		log.warn("Could not find cell with value {}", targetValue);
		return -1;
	}

	public int getRowIndexOfColumnValue(String targetValue, int column, int canvasIndex) {
		List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
		if (canvas.size() > 0) {
			List<WebElement> rows = canvas.get(canvasIndex).findElements(By.className("ui-grid-row"));
			for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
				List<WebElement> columns = rows.get(rowIndex).findElements(By.className("ui-grid-cell-contents"));
				if (columns.get(column - 1).getText().contentEquals(targetValue)) {
					return rowIndex;
				}
			}
		}
		log.warn("Could not find cell with value {}", targetValue);
		return -1;
	}

	public int waitForColumnValue(String targetValue, int column) {
		Long startTime = System.currentTimeMillis();
		while (System.currentTimeMillis() - startTime < getExplicitWait() * 1000L) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 0) {
				List<WebElement> rows = canvas.get(1).findElements(By.className("ui-grid-row"));
				for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
					List<WebElement> columns = rows.get(rowIndex).findElements(By.className("ui-grid-cell-contents"));
					if (columns.get(column - 1).getText().contentEquals(targetValue)) {
						return rowIndex;
					}
				}
			}
			sleepSeconds(2);
		}
		log.error("Cell with value {} never appeared", targetValue);
		return -1;
	}

	public int waitForColumnValue(String targetValue, int column, int canvasIndex) {
		Long startTime = System.currentTimeMillis();
		while (System.currentTimeMillis() - startTime < getExplicitWait() * 1000L) {
			List<WebElement> canvas = driver.findElements(By.className("ui-grid-canvas"));
			if (canvas.size() > 0) {
				List<WebElement> rows = canvas.get(canvasIndex).findElements(By.className("ui-grid-row"));
				for (int rowIndex = 0; rowIndex < rows.size(); rowIndex++) {
					List<WebElement> columns = rows.get(rowIndex).findElements(By.className("ui-grid-cell-contents"));
					if (columns.get(column - 1).getText().contentEquals(targetValue)) {
						return rowIndex;
					}
				}
			}
			sleepSeconds(2);
		}
		log.error("Cell with value {} never appeared", targetValue);
		return -1;
	}

}
