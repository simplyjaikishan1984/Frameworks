package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.Jenkins;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.File;

public class DeviceFileSystemSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I download and install the latest \"([^\"]*)\" version of the \"([^\"]*)\" application on device\\(s\\) \"([^\"]*)\"$")
    public void downloadInstallApp(String arg1, String arg2, String arg3) {
        if (!arg2.trim().isEmpty()) {
            boolean success = false;
            Jenkins jenkins = Jenkins.getInstance();
            File targetApp = jenkins.downloadApp(arg2.trim(), arg1.trim());
            if (targetApp!= null && targetApp.exists() && targetApp.length() > 900000) {
                for (String eachPhone : arg3.trim().split("\\s*,\\s*")) {
                    VersityPhone phone = Environment.getPhone(eachPhone);
                    if (phone.installApp(targetApp)) {
                        log.debug("File {} was installed on {}", targetApp.getName(), eachPhone);
                        success = true;
                    } else {
                        log.error("File {} failed to install on {}", targetApp.getName(), eachPhone);
                        Assert.fail("App Installation Failure");
                    }
                }
            } else {
                log.error("Failed to download update for {}", arg2);
            }
            Environment.softAssert().assertTrue(success, "App Download Failure");
        } else {
            log.error("No app name was provided");
        }
    }

    @When("^I install the apk in the path \"([^\"]*)\" on device\\(s\\) \"([^\"]*)\"$")
    public void installLocalApp(String arg1, String arg2) {
        if (!arg2.trim().isEmpty()) {
            boolean success = false;
            File targetApp = new File(arg1.trim());
            if (targetApp.exists() /*&& targetApp.length() > 900000*/) {
                for (String eachPhone : arg2.trim().split("\\s*,\\s*")) {
                    VersityPhone phone = Environment.getPhone(eachPhone);
                    if (phone.installApp(targetApp)) {
                        log.debug("File {} was installed on {}", targetApp.getName(), eachPhone);
                        success = true;
                    } else {
                        log.error("File {} failed to install on {}", targetApp.getName(), eachPhone);
                        Assert.fail("App Installation Failure");
                    }
                }
            } else {
                log.error("Failed to download update for {}", arg2);
            }
            Assert.assertTrue(success, "App Download Failure");
        } else {
            log.error("No app name was provided");
        }
    }
}