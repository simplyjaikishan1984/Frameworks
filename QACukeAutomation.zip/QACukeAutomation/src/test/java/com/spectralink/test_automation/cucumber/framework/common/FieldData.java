package com.spectralink.test_automation.cucumber.framework.common;

public interface FieldData {
    public String attribute();
    public String title();
}
