package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class RunDefaults {

	private static Logger log = LogManager.getLogger(RunDefaults.class.getName());
	private static File jsonFile;
	private static JSONObject settings;

	public static void setConfigFile(File configFile) {
		jsonFile = configFile;
		if (configFile != null && configFile.exists()) {
			JSONParser parser = new JSONParser();
			try {
				Object parsedJson = parser.parse(new FileReader(jsonFile));
				settings = (JSONObject) parsedJson;
				log.info("Using test run configuration file at {}", configFile.toString());
			} catch (FileNotFoundException fnfe) {
				log.error(Util.glue("Could not locate config file", jsonFile.getName() + ":", fnfe.getMessage()));
			} catch (IOException ioe) {
				log.error(Util.glue("Could not read config file", jsonFile.getName() + ":", ioe.getMessage()));
			} catch (ParseException pe) {
				log.error(Util.glue("Could not parse config file", jsonFile.getName() + ":", pe.getMessage()));
			}
		} else {
			log.error("No config file could be loaded");
		}
	}

	public static JSONObject getJson() {
		return settings;
	}

	public static Object findSetting(String targetKey) {
		for (Object key : settings.keySet()) {
			JSONObject section = (JSONObject) settings.get(key);
			if (section.containsKey(targetKey)) {
				return section.get(targetKey);
			}
		}
		return null;
	}

	public static List<String> getSections() {
		List<String> sections = new ArrayList<>();
		for (Object key : settings.keySet()) {
			sections.add((String) key);
		}
		return sections;
	}

	public static Map<String, Object> getSection(String sectionKey) {
		Map<String, Object> normalizedSettings = new HashMap<>();
		JSONObject section = (JSONObject) settings.get(sectionKey);
		for (Object key : section.keySet()) {
			normalizedSettings.put((String) key, section.get(key));
		}
		return normalizedSettings;
	}

	public static List<String> getSectionSettingKeys(String sectionKey) {
		List<String> sectionKeys = new ArrayList<>();
		JSONObject section = (JSONObject) settings.get(sectionKey);
		for (Object key : section.keySet()) {
			sectionKeys.add((String) key);
		}
		return sectionKeys;
	}

	public static Integer getNumericSetting(String key) {
		Object integerValue = findSetting(key);
		if (integerValue != null) {
			Long returnValue = (Long) integerValue;
			return returnValue.intValue();
		} else {
			log.error("Numeric run setting {} could not be found", key);
			return null;
		}
	}

	public static String getStringSetting(String key) {
		Object stringValue = findSetting(key);
		if (stringValue != null) {
			return (String) stringValue;
		} else {
			log.error("String run setting '{}' could not be found", key);
			return null;
		}
	}

	public static String getDecryptedSetting(String key) {
		Object stringValue = findSetting(key);
		if (stringValue != null) {
			return Environment.desalinate((String) stringValue);
		} else {
			log.error("String run setting {} could not be found", key);
			return null;
		}
	}

	public static Boolean getBooleanSetting(String key) {
		Object stringValue = findSetting(key);
		if (stringValue != null) {
			return (Boolean) stringValue;
		} else {
			log.error("Boolean run setting {} could not be found", key);
			return null;
		}
	}

	public static List<String> getArraySetting(String key) {
		JSONArray arrayValues = (JSONArray) getSetting(key);
		List<String> values = new ArrayList<>();
		if (arrayValues != null) {
			Iterator iterator = arrayValues.iterator();
			while (iterator.hasNext()) {
				values.add((String) iterator.next());
			}
		} else {
			log.error("Array run setting {} could not be found", key);
		}
		return values;
	}

	public static Object getSetting(String targetKey) {
		Object rawValue = null;
		rawValue = findSetting(targetKey);
		return rawValue;
	}
}

