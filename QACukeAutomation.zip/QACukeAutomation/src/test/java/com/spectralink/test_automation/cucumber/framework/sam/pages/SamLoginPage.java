package com.spectralink.test_automation.cucumber.framework.sam.pages;

import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamLoginPage extends SamBasePage {

	@FindBy(id = "accountNumber")
	private WebElement accountNumberTextbox;

	@FindBy(id = "username")
	private WebElement usernameTextbox;

	@FindBy(id = "newPassword")
	private WebElement newPasswordTextbox;

	@FindBy(id = "reNewPassword")
	private WebElement confirmPasswordTextbox;

	@FindBy(id = "newUserForm-button")
	private WebElement createAccountButton;

	@FindBy(id = "newUserForm")
	private WebElement createAccountIndicator;

	@FindBy(id = "changePasswordForm-button")
	private WebElement changePasswordButton;

	@FindBy(id = "changePasswordForm")
	private WebElement changePasswordIndicator;

	@FindBy(id = "password")
	private WebElement passwordTextbox;

	@FindBy(id = "loginForm")
	private WebElement loginIndicator;

	@FindBy(id = "loginForm-submit")
	private WebElement loginButton;

	@FindBy(id = "toast-container")
	private WebElement toastText;

	public SamLoginPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public void clickLoginButton() {
		clickOnPageEntity(loginButton);
	}

	public void clickCreateAccountButton() {
		clickOnPageEntity(createAccountButton);
	}

	public void clickChangePasswordButton() {
		clickOnPageEntity(changePasswordButton);
	}

	public void createAccount(Integer accountNumber, String username, String password) {
		typeIntoPageEntity(accountNumberTextbox, accountNumber.toString());
		typeIntoPageEntity(usernameTextbox, username);
		typeIntoPageEntity(newPasswordTextbox, password);
		typeIntoPageEntity(confirmPasswordTextbox, password);
		clickCreateAccountButton();
		sleepSeconds(3);
	}

	public SamDeviceListPage changePassword(String oldPassword, String newPassword) {
		typeIntoPageEntity(newPasswordTextbox, oldPassword);
		typeIntoPageEntity(confirmPasswordTextbox, newPassword);
		clickChangePasswordButton();
		sleepSeconds(3);
		return new SamDeviceListPage();
	}

	public SamDeviceListPage loginToSam(String username, String password) {
		typeIntoPageEntity(usernameTextbox, username);
		typeIntoPageEntity(passwordTextbox, password);
		clickLoginButton();
		sleepSeconds(2);
		return new SamDeviceListPage();
	}

	public SamDeviceListPage accessSam(String username, String password) {
		if (isPresent(By.id("newUserForm"))) {
			createAccount(RunDefaults.getNumericSetting("accountNumber"), username, password);
			sleepSeconds(8);
		}
		if (isPresent(By.id("changePasswordForm"))) {
			return changePassword(password, password);
		} else {
			return loginToSam(username, password);
		}
	}
}