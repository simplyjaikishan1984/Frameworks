package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.CliResult;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RemoteShell;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamUpgradeSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I download the last successful SAM artifact build into file \"([^\"]*)\"")
    public void downloadArtifacts(String arg1) {
        String fullUrl = "http://" + RunDefaults.getStringSetting("buildHost") +  RunDefaults.getStringSetting("artifact");
        File downloadFile = new File("artifacts.zip");
        log.debug("Downloading the file {} from the URL {}", downloadFile.getName(), fullUrl);
        try {
            CloseableHttpClient client = HttpClients.createDefault();
            HttpGet getRequest = new HttpGet(fullUrl);
            try (CloseableHttpResponse response = client.execute(getRequest)) {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    try (FileOutputStream outstream = new FileOutputStream(downloadFile)) {
                        entity.writeTo(outstream);
                    }
                }
            }
        } catch (ClientProtocolException cpe) {
            log.error("Failed to connect to repository: {}", cpe.getMessage());
            Assert.fail("Repository Connection Failure");
        } catch (IOException ioe) {
            log.error("Failed to get download file: {}", ioe.getMessage());
            Assert.fail("File Download Error");
        }
        Assert.assertTrue(downloadFile.exists(), "Artifacts.zip file does not exist");
        log.debug("Downloaded {} successfully", downloadFile.getName());
    }

    @When("^I run the upgrade command on SAM")
    public void runUpgradeCommand() {
        if (Environment.isSamSet()) {
            List<String> command = new ArrayList<>();
            command.add("export PATH=\"$PATH:/home/sam/bin\"; ~/bin/upgrade.sh");
            String address = Environment.getSam().getAddress();
            String osAccount = Environment.getSam().getOsAccount();
            String osPassword = Environment.getSam().getOsPassword();
            RemoteShell shell = new RemoteShell(address, osAccount, osPassword);
            try {
                Environment.getSam().imDatabase().close();
                Environment.getSam().keyDatabase().close();
                CliResult result = shell.executeCommand(command);
                if (result.commandSucceeded()) {
                    log.debug("Command '{}' completed on SAM at {}", result.getCommand(), address);
                    sleepSeconds(30);
                    command.clear();
                    command.add("export PATH=\"$PATH:/home/sam/bin\"; ~/bin/debug-setup.sh");
                    result = shell.executeCommand(command);
                    if (result.commandSucceeded()) {
                        log.debug("Command '{}' completed on SAM at {}", result.getCommand(), address);
                        sleepSeconds(20);
                    } else {
                        log.error("Command '{}' failed on SAM at {}", result.getCommand(), address);
                        log.error("Command output: {}", result.getStdout());
                        Assert.fail("SAM Command Failed");
                    }
                } else {
                    log.error("Command '{}' failed on SAM at {}", result.getCommand(), address);
                    log.error("Command output: {}", result.getStdout());
                    Assert.fail("SAM Command Failed");
                }
            } catch (Exception e) {
                log.error("Could not connect to SAM instance at {}: {}", address, e.getMessage());
                Assert.fail("SAM Command Failed");
            }
        } else {
            log.error("SAM instance has not been identified yet");
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("^there are no unapplied settings in the database")
    public void findUnclearedSettings() {
        Assert.assertEquals(0, Environment.getSam().keyDatabase().getUnappliedUpdatesCount(), "There were unapplied settings in the database");
    }
}
