package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Jenkins {
    private final static Logger log = LogManager.getLogger(Jenkins.class.getName());
    public static Integer resultCode = -1;
    public static String targetFile;
    private static RestClient client;
    private static Jenkins INSTANCE;

    private Jenkins() {
        RunDefaults.setConfigFile(Environment.getConfigFile());
        client = new RestClient(RunDefaults.getStringSetting("buildHost"));
        client.setSecure(true);
    }

    public static Jenkins getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Jenkins();
        }
        return INSTANCE;
    }

    public RestClient getRestClient() {
        return client;
    }

    public List<String> getBuildList(String buildProject) {
        RestClient client = getRestClient();
        JSONParser parser = new JSONParser();
        List<String> buildList = new ArrayList<>();
        try {
            Jenkins.resultCode = client.getGetRequest("job/" + buildProject + "/api/json?tree=builds[number]");
            if (Jenkins.resultCode >= 200 && Jenkins.resultCode < 300) {
                Object parsedJson = parser.parse(client.getResultJson());
                JSONObject response = (JSONObject) parsedJson;
                JSONArray builds = (JSONArray) response.get("builds");
                for (Object rawBuild : builds) {
                    JSONObject build = (JSONObject) rawBuild;
                    Long number = (Long) build.get("number");
                    buildList.add(number.toString());
                }
            } else {
                log.error("Could not complete rest request: GET returned code {}", Jenkins.resultCode);
            }
        } catch (ParseException pe) {
            log.error("Could not parse build list JSON: {}", pe.getMessage());
        }
        return buildList;
    }

    public String getBuildAppName(String buildProject, String buildNumber) {
        RestClient client = getRestClient();
        JSONParser parser = new JSONParser();
        String appName = "";
        try {
            String uriOnly = "job/" + buildProject + "/" + buildNumber + "/api/json?tree=actions[parameters[value]]";
            Jenkins.resultCode = client.getGetRequest(uriOnly);
            if (Jenkins.resultCode >= 200 && Jenkins.resultCode < 300) {
                Object parsedJson = parser.parse(client.getResultJson());
                JSONObject response = (JSONObject) parsedJson;
                JSONArray actions = (JSONArray) response.get("actions");
                Iterator iterator = actions.iterator();
                while (iterator.hasNext()) {
                    JSONObject branch = (JSONObject) iterator.next();
                    String classValue = (String) branch.get("_class");
                    if (classValue != null && classValue.contains("hudson.model.ParametersAction")) {
                        JSONArray parameters = (JSONArray) branch.get("parameters");
                        JSONObject firstParameter = (JSONObject) parameters.get(0);
                        appName = (String) firstParameter.get("value");
                    }
                }
            } else {
                log.error("Could not complete rest request: GET returned code {}", Jenkins.resultCode);
            }
        } catch (ParseException pe) {
            log.error("Could not parse build {} info JSON: {}", buildNumber, pe.getMessage());
        }
        return appName;
    }

    public String getArtifactUrl(String buildProject, String targetApp, String buildType) {
        RestClient client = getRestClient();
        JSONParser parser = new JSONParser();
        String Url = "";
        for (String buildNumber : getBuildList(buildProject)) {
            String appBuild = getBuildAppName(buildProject, buildNumber);
            if (targetApp.equalsIgnoreCase(appBuild)) {
                String buildNameRequest = "";
                try {
                    buildNameRequest = "job/" + buildProject + "/" + buildNumber + "/api/json?tree=artifacts[fileName,relativePath]";
                    Jenkins.resultCode = client.getGetRequest(buildNameRequest);
                    if (Jenkins.resultCode >= 200 && Jenkins.resultCode < 300) {
                        Object parsedJson = parser.parse(client.getResultJson());
                        JSONObject response = (JSONObject) parsedJson;
                        JSONArray artifacts = (JSONArray) response.get("artifacts");
                        String relativePath = "";
                        Iterator iterator = artifacts.iterator();
                        while (iterator.hasNext()) {
                            JSONObject artifactInfo = (JSONObject) iterator.next();
                            String fileName = (String) artifactInfo.get("fileName");
                            String expectedName = buildType.isEmpty() ? buildNumber + ".apk" : buildNumber + "-" + buildType + ".apk";
                            if (fileName.contains(expectedName)) {
                                relativePath = (String) artifactInfo.get("relativePath");
                                targetFile = fileName;
                            }
                        }
                        Url = "job/" + buildProject + "/" + buildNumber + "/artifact/" + relativePath;
                    } else {
                        log.error("Could not complete rest request: GET returned code {}", Jenkins.resultCode);
                    }
                } catch (ParseException pe) {
                    log.error("Could not parse build {} info JSON: {}", buildNumber, pe.getMessage());
                }
                break;
            }
        }
        return Url;
    }

    public File downloadApp(String targetApp, String buildType) {
        RunDefaults.setConfigFile(Environment.getConfigFile());
        RestClient client = getRestClient();
        JSONParser parser = new JSONParser();
        String downloadUrl = getArtifactUrl(RunDefaults.getStringSetting("appBuildProject"), targetApp, buildType);
        log.info("Downloading latest '{}' version of {}", buildType, targetApp);
        try {
            Path apk = Paths.get(Environment.getProjectDirectory(), targetFile);
            File file = apk.toFile();
            if(!file.exists()) {
                Jenkins.resultCode = client.getGetFileRequest(downloadUrl, apk);
                if (Jenkins.resultCode >= 200 && Jenkins.resultCode < 300) {
                    log.debug("File saved as {}", apk);
                } else {
                    log.error("Could not complete rest request: GET returned code {}", Jenkins.resultCode);
                }
            }
            return file;
        }
        catch (NullPointerException nullPointerException) {
            log.debug("File does not exist");
            return null;
        }
    }

}
