package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BizPhoneStrings.POPUP;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.ButtonStrings.*;

public class ButtonsUi extends AppiumUi {

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    public ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            overflowButton,
            overflowButton,
            null
    );

    @AndroidFindBy(accessibility = "Left button title")
    private WebElement leftButtonLabel;

    @AndroidFindBy(accessibility = "Left button summary")
    private WebElement leftButtonValue;

    public ConfigUiField leftButtonField = new ConfigUiField(
            driver,
            LEFT_BUTTON,
            leftButtonLabel,
            leftButtonLabel,
            leftButtonValue
    );

    @AndroidFindBy(accessibility = "Right button title")
    private WebElement rightButtonLabel;

    @AndroidFindBy(accessibility = "Right button summary")
    private WebElement rightButtonValue;

    public ConfigUiField rightButtonField = new ConfigUiField(
            driver,
            RIGHT_BUTTON,
            rightButtonLabel,
            rightButtonLabel,
            rightButtonValue
    );

    @AndroidFindBy(accessibility = "Top title")
    private WebElement topLabel;

    @AndroidFindBy(accessibility = "Top summary")
    private WebElement topValue;

    public ConfigUiField topField = new ConfigUiField(
            driver,
            TOP,
            topLabel,
            topLabel,
            topValue
    );

    @AndroidFindBy(accessibility = "Fingerprint title")
    private WebElement fingerprintLabel;

    @AndroidFindBy(accessibility = "Fingerprint summary")
    private WebElement fingerprintValue;

    public ConfigUiField fingerprintField = new ConfigUiField(
            driver,
            FINGERPRINT,
            fingerprintLabel,
            fingerprintLabel,
            fingerprintValue
    );

    @AndroidFindBy(accessibility = "Volume up title")
    private WebElement volumeUpLabel;

    @AndroidFindBy(accessibility = "Volume up summary")
    private WebElement volumeUpValue;

    public ConfigUiField volumeUpField = new ConfigUiField(
            driver,
            VOLUME_UP,
            volumeUpLabel,
            volumeUpLabel,
            volumeUpValue
    );

    @AndroidFindBy(accessibility = "Volume down title")
    private WebElement volumeDownLabel;

    @AndroidFindBy(accessibility = "Volume down summary")
    private WebElement volumeDownValue;

    public ConfigUiField volumeDownField = new ConfigUiField(
            driver,
            VOLUME_DOWN,
            volumeDownLabel,
            volumeDownLabel,
            volumeDownValue
    );

    @AndroidFindBy(xpath = "//android.widget.Toast[1]")
    private WebElement popup;

    @AndroidFindBy(id = "com.spectralink.automationhelper:id/buttonDataTextView")
    private WebElement automationHelperButtonPressTextView;

    public ButtonsUi (AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(OVERFLOW_MENU.title().toLowerCase(), overflowButtonField);
                put(RIGHT_BUTTON.title().toLowerCase(), rightButtonField);
                put(LEFT_BUTTON.title().toLowerCase(), leftButtonField);
                put(TOP.title().toLowerCase(), topField);
                put(FINGERPRINT.title().toLowerCase(), fingerprintField);
                put(VOLUME_DOWN.title().toLowerCase(), volumeDownField);
                put(VOLUME_UP.title().toLowerCase(), volumeUpField);

            }
        };
    }

    public String getToastText() {
        return popup.getText();
    }

    public String getAutomationHelperAppButtonPressText() {
        return automationHelperButtonPressTextView.getText();
    }

}
