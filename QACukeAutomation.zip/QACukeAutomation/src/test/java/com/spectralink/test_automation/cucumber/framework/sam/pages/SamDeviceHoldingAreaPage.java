package com.spectralink.test_automation.cucumber.framework.sam.pages;

import com.spectralink.test_automation.cucumber.framework.common.Util;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamDeviceHoldingAreaPage extends SamBasePage {

	private static final int grid = 1;

	@FindBy(xpath = "//div[@ng-click=\"headerButtonClick($event)\"]")
	private WebElement selectAll;

	@FindBy(id = "topMenu-Pending")
	private WebElement pendingTab;

	@FindBy(id = "topMenu-Approved")
	private WebElement approvedTab;

	@FindBy(id = "topMenu-Rejected")
	private WebElement rejectedTab;

	@FindBy(id="global-search-column-select")
	private WebElement searchMenu;

	@FindBy(id="searchinput")
	private WebElement searchTextbox;

	@FindBy(id = "searchclear")
	private WebElement clearButton;

	@FindBy(id="holdingArea-drop-down")
	private WebElement actionMenu;

	@FindBy(id = "devicelist-actions-approveDevice")
	private WebElement approveDevicesOption;

	@FindBy(id = "devicelist-actions-rejectDevices")
	private WebElement rejectDevicesOption;

	@FindBy(id = "devicelist-actions-export")
	private WebElement exportDevicesOption;

	@FindBy(id = "devicelist-actions-deleteDevices")
	private WebElement deleteDevicesOption;

	@FindBy(xpath = "//div[@ng-click=\"selectButtonClick(row, $event)\"]")
	private List<WebElement> deviceListCheckboxes;

	@FindBy(xpath = "//div[@role=\"columnheader\"]")
	private List<WebElement> headings;

	@FindBy(xpath = "//div[@container-id=\"'body'\"]")
	private WebElement deviceGrid;


	public SamDeviceHoldingAreaPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public WebElement getGridElement() {
		return deviceGrid;
	}

	public void clickPendingTab() {
		clickOnPageEntity(pendingTab);
		Util.sleepSeconds(2);
	}

	public void clickApprovedTab() {
		clickOnPageEntity(approvedTab);
		Util.sleepSeconds(2);
	}

	public void clickRejectedTab() {
		clickOnPageEntity(rejectedTab);
		Util.sleepSeconds(2);
	}

	public void clickSelectAllDevices() {
		clickOnPageEntity(selectAll);
	}

	public WebElement getDeviceCheckBox(int index) {
		return deviceListCheckboxes.get(index);
	}

	public void selectSearchType(String option) {
		selectMenuByText(searchMenu, option);
	}

	public void enterSearchValue(String matchThis){
		typeIntoPageEntity(searchTextbox, matchThis);
	}

	public void clickSearchClearButton() {
		clickOnPageEntity(clearButton);
	}

	public int getDeviceRowCount() {
		return getRowCount(grid);
	}

	public void clickPhoneCheckbox(String serial) {
		int rowIndex = getRowIndexOfColumnValue(serial, 2, grid);
		if (rowIndex != -1) clickOnPageEntity(getDeviceCheckBox(rowIndex));
	}

	public void clickColumnHeading(String title) {
		for (WebElement heading : headings) {
			if (heading.getAttribute("innerText").contains(title)) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView(true)", heading);
				clickOnPageEntity(heading);
				sleepSeconds(1);
				break;
			}
		}
	}

	public String getSortDirection(String title) {
		for (WebElement heading : headings) {
			if (heading.getAttribute("innerText").contains(title)) {
				return heading.getAttribute("aria-sort");
			}
		}
		return "unknown";
	}

	public void selectRejectAction() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(rejectDevicesOption);
		Util.sleepSeconds(1);
	}

	public void selectApproveAction() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(approveDevicesOption);
		Util.sleepSeconds(1);
	}

	public void selectExportAllDevices() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(exportDevicesOption);
		Util.sleepSeconds(5);
	}

	public void selectDeleteAction() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(deleteDevicesOption);
		Util.sleepSeconds(1);
	}

	public Boolean phoneInList(String serial) {
		if (getRowCount(grid) > 0) {
			int row = getRowIndexOfColumnValue(serial, 2, grid);
			return row != -1;
		}
		return false;
	}

	public boolean deviceIsVisible(String serial) {
		int rowIndex = getRowIndexOfColumnValue(serial, 2, grid);
		return rowIndex != -1;
	}

	public SamDeviceListPage.DeviceListColumns getHoldingAreaColumn(String title) {
		for (SamDeviceListPage.DeviceListColumns columnTitle : SamDeviceListPage.DeviceListColumns.values()) {
			if (columnTitle.title().toLowerCase().contentEquals(title.trim().toLowerCase())) {
				return columnTitle;
			}
		}
		return null;
	}
}
