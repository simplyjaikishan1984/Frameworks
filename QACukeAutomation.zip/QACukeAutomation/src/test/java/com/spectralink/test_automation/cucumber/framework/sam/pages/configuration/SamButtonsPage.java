package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.ButtonsStrings.*;

public class SamButtonsPage extends SamConfigurationPage {

	@FindBy(id = "label_btn_enableUserControlLeftButton")
	private WebElement leftButtonUserAssignedLabel;

	@FindBy(id = "enable_btn_enableUserControlLeftButton")
	private WebElement leftButtonUserAssignedCheckbox;

	@FindBy(id = "delete_setting_enableUserControlLeftButton")
	private WebElement leftButtonUserAssignedDelete;

	@FindBy(id = "edit_setting_btn_enableUserControlLeftButton")
	private WebElement leftButtonUserAssignedEdit;

	public ConfigPageField leftButtonUserAssignedField = new ConfigPageField(
			LEFT_BUTTON_USER_CONTROL,
			leftButtonUserAssignedLabel,
			leftButtonUserAssignedCheckbox,
			leftButtonUserAssignedDelete,
			leftButtonUserAssignedEdit
	);

	@FindBy(id = "select_btn_buttonLeft")
	private WebElement leftButtonActionMenu;

	@FindBy(id = "delete_setting_select_buttonLeft")
	private WebElement leftButtonActionDelete;

	@FindBy(id = "edit_setting_select_buttonLeft")
	private WebElement leftButtonActionEdit;

	public ConfigPageField leftButtonActionField = new ConfigPageField(
			LEFT_BUTTON,
			leftButtonActionMenu,
			leftButtonActionDelete,
			leftButtonActionEdit
	);

	@FindBy(id = "input_run_app_buttonLeftRunApplication")
	private WebElement leftButtonApplicationTextbox;

	@FindBy(id = "delete_setting_run_app_buttonLeftRunApplication")
	private WebElement leftButtonApplicationDelete;

	@FindBy(id = "edit_setting_run_app_buttonLeftRunApplication")
	private WebElement leftButtonApplicationEdit;

	public ConfigPageField leftButtonApplicationField = new ConfigPageField(
			LEFT_BUTTON_APPLICTION,
			leftButtonApplicationTextbox,
			leftButtonApplicationDelete,
			leftButtonApplicationEdit
	);

	@FindBy(id = "label_btn_enableUserControlRightButton")
	private WebElement rightButtonUserAssignedLabel;

	@FindBy(id = "enable_btn_enableUserControlRightButton")
	private WebElement rightButtonUserAssignedCheckbox;

	@FindBy(id = "delete_setting_enableUserControlRightButton")
	private WebElement rightButtonUserAssignedDelete;

	@FindBy(id = "edit_setting_btn_enableUserControlRightButton")
	private WebElement rightButtonUserAssignedEdit;

	public ConfigPageField rightButtonUserAssignedField = new ConfigPageField(
			RIGHT_BUTTON_USER_CONTROL,
			rightButtonUserAssignedLabel,
			rightButtonUserAssignedCheckbox,
			rightButtonUserAssignedDelete,
			rightButtonUserAssignedEdit
	);

	@FindBy(id = "select_btn_buttonRight")
	private WebElement rightButtonActionMenu;

	@FindBy(id = "delete_setting_select_buttonRight")
	private WebElement rightButtonActionDelete;

	@FindBy(id = "edit_setting_select_buttonRight")
	private WebElement rightButtonActionEdit;

	public ConfigPageField rightButtonActionField = new ConfigPageField(
			RIGHT_BUTTON,
			rightButtonActionMenu,
			rightButtonActionDelete,
			rightButtonActionEdit
	);

	@FindBy(id = "input_run_app_buttonRightRunApplication")
	private WebElement rightButtonApplicationTextbox;

	@FindBy(id = "delete_setting_run_app_buttonRightRunApplication")
	private WebElement rightButtonApplicationDelete;

	@FindBy(id = "edit_setting_run_app_buttonRightRunApplication")
	private WebElement rightButtonApplicationEdit;

	public ConfigPageField rightButtonApplicationField = new ConfigPageField(
			RIGHT_BUTTON_APPLICATION,
			rightButtonApplicationTextbox,
			rightButtonApplicationDelete,
			rightButtonApplicationEdit
	);

	@FindBy(id = "label_btn_enableUserControlTopButton")
	private WebElement topButtonUserAssignedLabel;

	@FindBy(id = "enable_btn_enableUserControlTopButton")
	private WebElement topButtonUserAssignedCheckbox;

	@FindBy(id = "delete_setting_enableUserControlTopButton")
	private WebElement topButtonUserAssignedDelete;

	@FindBy(id = "edit_setting_btn_enableUserControlTopButton")
	private WebElement topButtonUserAssignedEdit;

	public ConfigPageField topButtonUserAssignedField = new ConfigPageField(
			TOP_BUTTON_USER_CONTROL,
			topButtonUserAssignedLabel,
			topButtonUserAssignedCheckbox,
			topButtonUserAssignedDelete,
			topButtonUserAssignedEdit
	);

	@FindBy(id = "select_btn_buttonTop")
	private WebElement topButtonActionMenu;

	@FindBy(id = "delete_setting_select_buttonTop")
	private WebElement topButtonActionDelete;

	@FindBy(id = "edit_setting_select_buttonTop")
	private WebElement topButtonActionEdit;

	public ConfigPageField topButtonActionField = new ConfigPageField(
			TOP_BUTTON,
			topButtonActionMenu,
			topButtonActionDelete,
			topButtonActionEdit
	);

	@FindBy(id = "input_run_app_buttonTopRunApplication")
	private WebElement topButtonApplicationTextbox;

	@FindBy(id = "delete_setting_run_app_buttonTopRunApplication")
	private WebElement topButtonApplicationDelete;

	@FindBy(id = "edit_setting_run_app_buttonTopRunApplication")
	private WebElement topButtonApplicationEdit;

	public ConfigPageField topButtonApplicationField = new ConfigPageField(
			TOP_BUTTON_APPLICATION,
			topButtonApplicationTextbox,
			topButtonApplicationDelete,
			topButtonApplicationEdit
	);

	@FindBy(id = "label_btn_enableUserControlFingerprintButton")
	private WebElement fingerButtonUserAssignedLabel;

	@FindBy(id = "enable_btn_enableUserControlFingerprintButton")
	private WebElement fingerButtonUserAssignedCheckbox;

	@FindBy(id = "delete_setting_enableUserControlFingerprintButton")
	private WebElement fingerButtonUserAssignedDelete;

	@FindBy(id = "edit_setting_btn_enableUserControlFingerprintButton")
	private WebElement fingerButtonUserAssignedEdit;

	public ConfigPageField fingerButtonUserAssignedField = new ConfigPageField(
			FINGERPRINT_USER_CONTROL,
			fingerButtonUserAssignedLabel,
			fingerButtonUserAssignedCheckbox,
			fingerButtonUserAssignedDelete,
			fingerButtonUserAssignedEdit
	);

	@FindBy(id = "select_btn_buttonFingerprint")
	private WebElement fingerButtonActionMenu;

	@FindBy(id = "delete_setting_select_buttonFingerprint")
	private WebElement fingerButtonActionDelete;

	@FindBy(id = "edit_setting_select_buttonFingerprint")
	private WebElement fingerButtonActionEdit;

	public ConfigPageField fingerButtonActionField = new ConfigPageField(
			FINGERPRINT,
			fingerButtonActionMenu,
			fingerButtonActionDelete,
			fingerButtonActionEdit
	);

	@FindBy(id = "input_run_app_buttonFingerprintRunApplication")
	private WebElement fingerButtonApplicationTextbox;

	@FindBy(id = "delete_setting_run_app_buttonFingerprintRunApplication")
	private WebElement fingerButtonApplicationDelete;

	@FindBy(id = "edit_setting_run_app_buttonFingerprintRunApplication")
	private WebElement fingerButtonApplicationEdit;

	public ConfigPageField fingerButtonApplicationField = new ConfigPageField(
			FINGERPRINT_APPLICATION,
			fingerButtonApplicationTextbox,
			fingerButtonApplicationDelete,
			fingerButtonApplicationEdit
	);

	@FindBy(id = "label_btn_enableUserControlVolUpButton")
	private WebElement volumeUpButtonUserAssignedLabel;

	@FindBy(id = "enable_btn_enableUserControlVolUpButton")
	private WebElement volumeUpButtonUserAssignedCheckbox;

	@FindBy(id = "delete_setting_enableUserControlVolUpButton")
	private WebElement volumeUpButtonUserAssignedDelete;

	@FindBy(id = "edit_setting_btn_enableUserControlVolUpButton")
	private WebElement volumeUpButtonUserAssignedEdit;

	public ConfigPageField volumeUpButtonUserAssignedField = new ConfigPageField(
			VOLUME_UP_BUTTON_USER_CONTROL,
			volumeUpButtonUserAssignedLabel,
			volumeUpButtonUserAssignedCheckbox,
			volumeUpButtonUserAssignedDelete,
			volumeUpButtonUserAssignedEdit
	);

	@FindBy(id = "select_btn_buttonVolUp")
	private WebElement volumeUpButtonActionMenu;

	@FindBy(id = "delete_setting_select_buttonVolUp")
	private WebElement volumeUpButtonActionDelete;

	@FindBy(id = "edit_setting_select_buttonVolUp")
	private WebElement volumeUpButtonActionEdit;

	public ConfigPageField volumeUpButtonActionField = new ConfigPageField(
			VOLUME_UP_BUTTON,
			volumeUpButtonActionMenu,
			volumeUpButtonActionDelete,
			volumeUpButtonActionEdit
	);

	@FindBy(id = "input_run_app_buttonVolUpRunApplication")
	private WebElement volumeUpButtonApplicationTextbox;

	@FindBy(id = "delete_setting_run_app_buttonVolUpRunApplication")
	private WebElement volumeUpButtonApplicationDelete;

	@FindBy(id = "edit_setting_run_app_buttonVolUpRunApplication")
	private WebElement volumeUpButtonApplicationEdit;

	public ConfigPageField volumeUpButtonApplicationField = new ConfigPageField(
			VOLUME_UP_BUTTON_APPLICATION,
			volumeUpButtonApplicationTextbox,
			volumeUpButtonApplicationDelete,
			volumeUpButtonApplicationEdit
	);

	@FindBy(id = "label_btn_enableUserControlVolDownButton")
	private WebElement volumeDownButtonUserAssignedLabel;

	@FindBy(id = "enable_btn_enableUserControlVolDownButton")
	private WebElement volumeDownButtonUserAssignedCheckbox;

	@FindBy(id = "delete_setting_enableUserControlVolDownButton")
	private WebElement volumeDownButtonUserAssignedDelete;

	@FindBy(id = "edit_setting_btn_enableUserControlVolDownButton")
	private WebElement volumeDownButtonUserAssignedEdit;

	public ConfigPageField volumeDownButtonUserAssignedField = new ConfigPageField(
			VOLUME_DOWN_BUTTON_USER_CONTROL,
			volumeDownButtonUserAssignedLabel,
			volumeDownButtonUserAssignedCheckbox,
			volumeDownButtonUserAssignedDelete,
			volumeDownButtonUserAssignedEdit
	);

	@FindBy(id = "select_btn_buttonVolDown")
	private WebElement volumeDownButtonActionMenu;

	@FindBy(id = "delete_setting_select_buttonVolDown")
	private WebElement volumeDownButtonActionDelete;

	@FindBy(id = "edit_setting_select_buttonVolDown")
	private WebElement volumeDownButtonActionEdit;

	public ConfigPageField volumeDownButtonActionField = new ConfigPageField(
			VOLUME_DOWN_BUTTON,
			volumeDownButtonActionMenu,
			volumeDownButtonActionDelete,
			volumeDownButtonActionEdit
	);

	@FindBy(id = "input_run_app_buttonVolDownRunApplication")
	private WebElement volumeDownButtonApplicationTextbox;

	@FindBy(id = "delete_setting_run_app_buttonVolDownRunApplication")
	private WebElement volumeDownButtonApplicationDelete;

	@FindBy(id = "edit_setting_run_app_buttonVolDownRunApplication")
	private WebElement volumeDownButtonApplicationEdit;

	public ConfigPageField volumeDownButtonApplicationField = new ConfigPageField(
			VOLUME_DOWN_BUTTON_APPLICATION,
			volumeDownButtonApplicationTextbox,
			volumeDownButtonApplicationDelete,
			volumeDownButtonApplicationEdit
	);

	public SamButtonsPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(leftButtonUserAssignedField.getTitle(), leftButtonUserAssignedField);
				put(leftButtonActionField.getTitle(), leftButtonActionField);
				put(leftButtonApplicationField.getTitle(), leftButtonApplicationField);
				put(rightButtonUserAssignedField.getTitle(), rightButtonUserAssignedField);
				put(rightButtonActionField.getTitle(), rightButtonActionField);
				put(rightButtonApplicationField.getTitle(), rightButtonApplicationField);
				put(topButtonUserAssignedField.getTitle(), topButtonUserAssignedField);
				put(topButtonActionField.getTitle(), topButtonActionField);
				put(topButtonApplicationField.getTitle(), topButtonApplicationField);
				put(fingerButtonUserAssignedField.getTitle(), fingerButtonUserAssignedField);
				put(fingerButtonActionField.getTitle(), fingerButtonActionField);
				put(fingerButtonApplicationField.getTitle(), fingerButtonApplicationField);
				put(volumeUpButtonUserAssignedField.getTitle(), volumeUpButtonUserAssignedField);
				put(volumeUpButtonActionField.getTitle(), volumeUpButtonActionField);
				put(volumeUpButtonApplicationField.getTitle(), volumeUpButtonApplicationField);
				put(volumeDownButtonUserAssignedField.getTitle(), volumeDownButtonUserAssignedField);
				put(volumeDownButtonActionField.getTitle(), volumeDownButtonActionField);
				put(volumeDownButtonApplicationField.getTitle(), volumeDownButtonApplicationField);
			}
		};
	}
}
