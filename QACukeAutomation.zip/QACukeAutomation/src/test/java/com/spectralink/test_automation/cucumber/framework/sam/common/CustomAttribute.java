package com.spectralink.test_automation.cucumber.framework.sam.common;

import com.spectralink.test_automation.cucumber.framework.WebAutomation;
import com.spectralink.test_automation.cucumber.framework.WebBrowser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class CustomAttribute extends WebAutomation {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private WebElement packageTextbox;
	private WebElement keyTextbox;
	private WebElement dataTypeMenu;
	private WebElement valueElement;
	private WebElement deleteButton;
	private WebElement editButton;
	private EntityType type;
	private Boolean isSet = false;
	private String lastToastMessage;

	public enum EntityType {
		CHECKBOX,
		TEXTBOX,
		PASSWORD,
		MENU,
		RADIO,
		BUTTON,
		SLIDER,
		UNKNOWN
	}

	public enum Level {
		DEFAULT,
		ENTERPRISE,
		GROUP,
		DEVICE,
		NONE
	}

	public CustomAttribute() {
		driver = WebBrowser.getDriver();
	}

	public CustomAttribute(WebElement packageTextbox, WebElement keyTextbox, WebElement dataTypeMenu, WebElement valueElement, WebElement editButton, WebElement deleteButton) {
		driver = WebBrowser.getDriver();
		this.packageTextbox = packageTextbox;
		this.keyTextbox = keyTextbox;
		this.dataTypeMenu = dataTypeMenu;
		this.valueElement = valueElement;
		this.editButton = editButton;
		this.deleteButton = deleteButton;
	}

	public WebElement getPackageElement() {
		return packageTextbox;
	}

	public void setPackageElement(WebElement packageTextbox) {
		this.packageTextbox = packageTextbox;
	}

	public void setPackageElementFromRow(WebElement row) {
		this.packageTextbox = getChildEntity(row, By.xpath(".//input[@ng-model=\"customAttributeURI.appName\"]"));
	}

	public WebElement getKeyElement() {
		return keyTextbox;
	}

	public void setKeyElement(WebElement keyTextbox) {
		this.keyTextbox = keyTextbox;
	}

	public void setKeyElementFromRow(WebElement row) {
		this.keyTextbox = getChildEntity(row, By.xpath(".//input[@ng-model=\"customAttribute.name\"]"));
	}

	public void setPackageKeyElementFromRow(WebElement row) {
		this.keyTextbox = getChildEntity(row, By.xpath(".//input[@ng-model=\"customAttributeURI.name\"]"));
	}

	public String getKeyName() {
		return keyTextbox.getAttribute("value");
	}

	public WebElement getDataTypeElement() {
		return dataTypeMenu;
	}

	public void setDataTypeElement(WebElement dataTypeMenu) {
		this.dataTypeMenu = dataTypeMenu;
	}

	public void setDataTypeElementFromRow(WebElement row) {
		this.dataTypeMenu = getChildEntity(row, By.xpath(".//select[@ng-model=\"customAttribute.dataType\"]"));
	}

	public void setPackageDataTypeElementFromRow(WebElement row) {
		this.dataTypeMenu = getChildEntity(row, By.xpath(".//select[@ng-model=\"customAttributeURI.dataType\"]"));
	}

	public String getDataType() {
		String attributeClass = getSelection();
		if (editButton != null || deleteButton != null) {
			return attributeClass;
		} else {
			return null;
		}
	}

	public WebElement getValueElement() {
		return valueElement;
	}

	public void setValueElement(WebElement valueElement) {
		this.valueElement = valueElement;
	}

	public void setValueElementFromRow(WebElement row) {
		this.valueElement = getChildEntity(row, By.xpath(".//input[@ng-model=\"customAttribute.value\"]"));
	}

	public void setPackageValueElementFromRow(WebElement row) {
		this.valueElement = getChildEntity(row, By.xpath(".//input[@ng-model=\"customAttributeURI.value\"]"));
	}

	public String getValue() {
		if (getDataTypeElement().getAttribute("value").contentEquals("boolean")) {
			return valueElement.isSelected() ? "true" : "false";
		} else {
			return valueElement.getAttribute("value");
		}
	}

	public WebElement getDeleteButton() {
		return deleteButton;
	}

	public void setDeleteButton(WebElement deleteButton) {
		this.deleteButton = deleteButton;
		this.isSet = true;
	}

	public void setDeleteButtonFromRow(WebElement row) {
		this.deleteButton = getChildEntity(row, By.xpath(".//*[@ng-click=\"removeCurrentCustomElement(itemSentViaCaller,$index)\"]"));
		if (this.deleteButton != null) {
			this.isSet = true;
		}
	}

	public void setPackageDeleteButtonFromRow(WebElement row) {
		this.deleteButton = getChildEntity(row, By.xpath(".//*[@ng-click=\"removeCurrentCustomElement(configOptions.customAppConfig,$index)\"]"));
		if (this.deleteButton != null) {
			this.isSet = true;
		}
	}

	public WebElement getEditButton() {
		return editButton;
	}

	public void setEditButton(WebElement editButton) {
		this.editButton = editButton;
		this.isSet = true;
	}

	public void setEditButtonFromRow(WebElement row) {
		this.editButton = getChildEntity(row, By.xpath(".//i[@ng-click=\"enableEditFlag($index)\"]"));
		if (this.editButton != null) {
			this.isSet = true;
		}
	}

	public void setPackageEditButtonFromRow(WebElement row) {
		this.editButton = getChildEntity(row, By.xpath(".//i[@ng-click=\"enableEditFlagForAppURI($index)\"]"));
		if (this.editButton != null) {
			this.isSet = true;
		}
	}

	public void enterPackage(String text) {
		if (packageTextbox != null) {
			typeIntoPageEntity(packageTextbox, text);
		} else {
			log.error("No Package element has been set");
		}
	}

	public void enterKey(String text) {
		if (keyTextbox != null) {
			edit();
			typeIntoPageEntity(keyTextbox, text);
		} else {
			log.error("No Value element has been set");
		}
	}

	public void selectType(String type) {
		if (dataTypeMenu != null) {
			selectMenuByText(dataTypeMenu, type);
		} else {
			log.error("No Data Type element has been set");
		}
	}

	public String getSelection() {
		return getMenuSelectedOption(dataTypeMenu);
	}

	public void updateValue(String type, String value) {
		if (valueElement != null) {
			if (type.contentEquals("String") || type.contentEquals("Integer")) {
				if (getType(valueElement).equals(EntityType.TEXTBOX)) {
					typeIntoPageEntity(valueElement, value);
				} else {
					log.error("Cannot update field of type {} with value of type {}", EntityType.CHECKBOX.name(), type);
				}
			} else if (type.contentEquals("Boolean")) {
				if (getType(valueElement).equals(EntityType.CHECKBOX)) {
					if ((value.contentEquals("true") && !isEntitySelected(valueElement)) || (value.contentEquals("false") && isEntitySelected(valueElement))) {
						String checkboxId = valueElement.getAttribute("id");
						WebElement label = locateElement(By.xpath("//label[@for='" + checkboxId + "']"));
						if (label != null) {
							clickOnPageEntity(label);
						} else {
							log.error("Cannot find label for checkbox {}", valueElement);
						}
					}
				} else {
					log.error("Cannot update field of type {} with value of type {}", EntityType.CHECKBOX.name(), type);
				}
			} else {
				log.error("Unknown field type '{}'", type);
			}
		} else {
			log.error("No Value element has been set");
		}
	}

	public boolean isEnabled() {
		if (valueElement != null && getType(valueElement).equals(EntityType.CHECKBOX)) {
			return isEntitySelected(valueElement);
		} else {
			log.error("Element is not of the type checkbox");
		}
		return false;
	}

	public void delete() {
		setTemporaryWait(1);
		if (deleteButton != null) {
			if (isEntityClickable(deleteButton)) {
				clickOnPageEntity(deleteButton);
			} else {
				log.warn("Cannot click delete button {}", deleteButton);
			}
		} else {
			log.warn("Cannot click delete button {}", deleteButton);
		}
		removeTemporaryWait();
	}

	public void edit() {
		setTemporaryWait(0);
		if (editButton != null && isEntityClickable(editButton)) {
			clickOnPageEntity(editButton);
		}
		removeTemporaryWait();
	}

	public boolean isConfigured() {
		setTemporaryWait(0);
		boolean deleteAvailable = false;
		if (isEntityClickable(deleteButton)) {
			deleteAvailable = true;
		}
		removeTemporaryWait();
		return deleteAvailable;
	}

	public EntityType getType(WebElement element) {
		EntityType type;
		String entity = getEntityTag(element);
		if (entity.contentEquals("input")) {
			String elementType = getEntityAttribute(element, "type");
			switch (elementType) {
				case "checkbox":
					type = CustomAttribute.EntityType.CHECKBOX;
					break;
				case "text":
					type = CustomAttribute.EntityType.TEXTBOX;
					break;
				case "url":
					type = CustomAttribute.EntityType.TEXTBOX;
					break;
				case "number":
					type = CustomAttribute.EntityType.TEXTBOX;
					break;
				case "password":
					type = CustomAttribute.EntityType.PASSWORD;
					break;
				case "radio":
					type = CustomAttribute.EntityType.RADIO;
					break;
				default:
					type = CustomAttribute.EntityType.UNKNOWN;
			}
		} else if (entity.contentEquals("select")) {
			type = CustomAttribute.EntityType.MENU;
		} else if (entity.contentEquals("button")) {
			type = CustomAttribute.EntityType.BUTTON;
		} else if (entity.contentEquals("rzslider")) {
			type = CustomAttribute.EntityType.SLIDER;
		} else {
			type = CustomAttribute.EntityType.UNKNOWN;
		}
		return type;
	}

	public int compareState(String expectedState) {
		return getValue().contentEquals(expectedState) ? 0 : 1;
	}
}
