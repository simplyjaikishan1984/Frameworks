package com.spectralink.test_automation.cucumber.framework.device.pages;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class AboutScreenUi extends AppiumUi{

    public AboutScreenUi(AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public boolean selectTextMenuOption(String option) {
        List<WebElement> options = driver.findElements(By.className("android.widget.TextView"));
        for (WebElement element : options) {
            if (element.getText().toLowerCase().contentEquals(option.toLowerCase())) {
                clickOnPageEntity(element);
                sleepSeconds(1);
                return true;
            }
        }
        return false;
    }

}
