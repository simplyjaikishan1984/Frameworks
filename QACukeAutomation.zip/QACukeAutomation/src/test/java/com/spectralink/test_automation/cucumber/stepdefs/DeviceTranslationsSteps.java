package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.common.XmlParser;
import com.spectralink.test_automation.cucumber.framework.device.pages.*;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.*;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.LOGGING;
import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.SYS_UPDATER;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class DeviceTranslationsSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    List<String> appiumElements = new ArrayList<>();
    List<String> extractXmlElements;

    @When("^I change device language (From Android Settings UI) to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void changeLanguage(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        phone.startApp("android.settings.LOCALE_SETTINGS");

        if ("French Canada".equals(arg1)) {
            deviceTranslationUi.addLanguage();
            deviceTranslationUi.clickSearch();
            deviceTranslationUi.enterIntoSearchEditText("French");
            deviceTranslationUi.selectFrench();
            deviceTranslationUi.selectFrenchCanada();
            deviceTranslationUi.pushLanguageToTop();
        }

        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.HOME);

    }

    @When("^I remove device language (From Android Settings UI) \"([^\"]*)\" on \"([^\"]*)\"$")
    public void removeLanguage(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        phone.startApp("android.settings.LOCALE_SETTINGS");

        if ("French Canada".equals(arg1)) {
            phone.appium().findElementByAccessibilityId("Plus d'options").click();
            deviceTranslationUi.selectTextMenuOption("Supprimer");
            phone.appium().findElementByAccessibilityId("Français (Canada)").click();
            phone.appium().findElementByAccessibilityId("Supprimer").click();
            deviceTranslationUi.clickOkButton();
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.HOME);
    }

    @When("^I grant required language change permission to the language app on \"([^\"]*)\"$")
    public void grantPermission(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        phone.grantLanguageChangePermission();
        log.debug("Language change permission granted");
    }

    @When("^I change language to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void changeLanguageFromApp(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        switch (arg1.trim()) {

            case "Danish":
                phone.changeLanguage("da-rDK");
                break;
            case "Dutch":
                phone.changeLanguage("nl-rNL");
                break;
            case "English (US)":
                phone.changeLanguage("en-rUS");
                break;
            case "Finnish":
                phone.changeLanguage("fi-rFI");
                break;
            case "French (France)":
                phone.changeLanguage("fr-rFR");
                break;
            case "French (Canada)":
                phone.changeLanguage("fr-rCA");
                break;
            case "German (Germany)":
                phone.changeLanguage("de-rDE");
                break;
            case "Hungarian":
                phone.changeLanguage("hu-rHU");
                break;
            case "Italian":
                phone.changeLanguage("it-rIT");
                break;
            case "Norwegian":
                phone.changeLanguage("nb-rNO");
                break;
            case "Portuguese (Port.)":
                phone.changeLanguage("pt-rPT");
                break;
            case "Portuguese (Brazil)":
                phone.changeLanguage("pt-rBR");
                break;
            case "Russian":
                phone.changeLanguage("ru-rRU");
                break;
            case "Slovenian":
                phone.changeLanguage("sl-rSI");
                break;
            case "Spanish (Spain)":
                phone.changeLanguage("es-rES");
                break;
            case "Spanish (Latam)":
                phone.changeLanguage("es-rMX");
                break;
            case "Swedish":
                phone.changeLanguage("sv-rSE");
                break;
        }
        log.debug("Language changed to: " + arg1);
        sleepSeconds(10);
    }

    @Then("^I verify Biz Phone's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChange(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        BizPhoneUi bizPhoneUi = phone.getBizPhoneUi();
        extractXmlElements = getXmlFileForApp("BizPhone", arg1);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem2Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem2Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem3Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem3Android10();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);

        bizPhoneUi.clickRegistration1();
        phone.sendKeyEvent(AndroidKey.BACK);

        bizPhoneUi.clickRegistration2();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        bizPhoneUi.clickCommonSettings();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        bizPhoneUi.clickLdapSettings();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        bizPhoneUi.clickEmergencySettings();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Batt Life's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeBattLife(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        BattLifeUi battLifeUi = phone.getBattLifeUi();
        extractXmlElements = getXmlFileForApp("BattLife", arg1);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);

        battLifeUi.enableBatteryMonitoring(true);
        phone.sendKeyEvent(AndroidKey.BACK);
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem2Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem2Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Safe's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeSafe(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        SafeUi safeUi = phone.getSafeUi();
        extractXmlElements = getXmlFileForApp("Safe", arg1);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();

        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);

        safeUi.enterMonitoringSettings();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        safeUi.enterPanicButtonSettings();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        safeUi.enterEmergencyConfigSettings();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        safeUi.enterSafeTonesSettings();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem2Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem2Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Web API's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeWebAPI(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();

        WebApiUi webApiUi = phone.getWebApiUi();
        extractXmlElements = getXmlFileForApp("Web API", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        webApiUi.clickPhoneStatePolling();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        webApiUi.clickPushSettings();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        webApiUi.clickWebApplicationShortcuts();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        webApiUi.clickDeviceEventNotifications();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        webApiUi.addNotification();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Device App's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeDeviceApp(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("Device", arg1);
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.sendKeyEvent(AndroidKey.BACK);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify VQO's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeVqo(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("Vqo", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Sys Updater's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeSysUpdater(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("SysUpdater", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.bringAppToForeground(SYS_UPDATER);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem2Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem2Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem3Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem3Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Buttons's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeButton(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("Buttons", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Sso's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeSso(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("Sso", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem2Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem2Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify LensGrid's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeLensGrid(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("LensGrid", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Sam Client's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeSamClient(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("SamClient", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem2Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem2Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify PTT's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangePtt(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("Ptt", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem2Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem2Android10();
        sleepSeconds(1);
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem3Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem3Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify AMIE Agent's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeAmie(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        AmieAgentUi amieAgentUi = phone.getAmieAgentUi();
        extractXmlElements = getXmlFileForApp("Amie", arg1);
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        amieAgentUi.enterConnectionDetails();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Logging's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeLogging(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
        extractXmlElements = getXmlFileForApp("Logging", arg1);
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        deviceTranslationUi.tapAdvancedDebuggingButton();
        deviceTranslationUi.enterAdminPassword();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        deviceTranslationUi.tapAdvancedLoggingOption();
        deviceTranslationUi.fetchScreenElements(phone, true, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.bringAppToForeground(LOGGING);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem2Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem2Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);

        tapOnMoreOptions(arg1,arg2);
        if(phone.getBuildRelease().equals("8.1.0"))
            deviceTranslationUi.selectOverflowMenuItem1Android8();
        else
            deviceTranslationUi.selectOverflowMenuItem1Android10();
        deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        phone.sendKeyEvent(AndroidKey.BACK);
        sleepSeconds(1);
        compareXmlAppium(arg1);
        sleepSeconds(1);
    }

    @Then("^I verify Barcode's language is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void languageChangeBarcode(String arg1, String arg2) throws ParserConfigurationException, SAXException, IOException {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        if(phone.hasBarcodeScanner()) {
            DeviceTranslationUi deviceTranslationUi = phone.getDeviceTranslationUi();
            extractXmlElements = getXmlFileForApp("Barcode", arg1);
            deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
            tapOnMoreOptions(arg1, arg2);
            if (phone.getBuildRelease().equals("8.1.0"))
                deviceTranslationUi.selectOverflowMenuItem1Android8();
            else
                deviceTranslationUi.selectOverflowMenuItem1Android10();
            deviceTranslationUi.fetchScreenElements(phone, false, appiumElements);
            phone.sendKeyEvent(AndroidKey.BACK);
            sleepSeconds(1);
            phone.sendKeyEvent(AndroidKey.BACK);
            sleepSeconds(1);
            compareXmlAppium(arg1);
            sleepSeconds(1);
        }
    }

    void compareXmlAppium(String arg1) {

        boolean found;
        removeItemsFromAppiumElementList();
        /*for (Object appiumElement : extractXmlElements)
            log.debug("Strings from xml: " +appiumElement);
        for (Object appiumElement : appiumElements)
            log.debug("Translated Strings using appium: " +appiumElement);*/

        found = extractXmlElements.containsAll(appiumElements);
        if(found)
            log.debug("The app contains translated strings for language: " + arg1);
        else {
            log.error("The app does not contain translated strings for language: " + arg1);
            Set<String> ad = new HashSet<>(appiumElements);
            Set<String> bd = new HashSet<>(extractXmlElements);
            ad.removeAll(bd);

            for (Object extract : ad)
                log.debug("Differences: " + extract);
            Environment.softAssert().fail("INCORRECT TRANSLATIONS");
            appiumElements.clear();
            extractXmlElements.clear();
        }
    }

    void removeItemsFromAppiumElementList() {
        removeListItems(appiumElements,"UDP");
        appiumElements.remove("mail");
        appiumElements.remove("mailAlternateAddress");
        removeListItemsContains(appiumElements,"Logging");
        removeListItemsContains(appiumElements,"America");
        removeListItemsContains(appiumElements,"*:w");
        removeListItemsContains(appiumElements,"www.spectralink.com");
        removeListItemsContains(appiumElements,"Spectralink");
        removeListItems(appiumElements,"Scanner");
        removeListItems(appiumElements,"Alarm");
        removeListItems(appiumElements,"PTT");
        removeListItems(appiumElements,"Volume down");
        removeListItems(appiumElements,"Volume up");
        removeListItems(appiumElements,"Fingerprint");
        removeListItems(appiumElements,"");
        removeListItems(appiumElements,"Li-ion");
        removeListItems(appiumElements,"HTTP");
        removeListItems(appiumElements,"HTTPS");
        removeListItems(appiumElements,"SAM URL");
        removeListItems(appiumElements,"Sys Updater");
        removeListItems(appiumElements,"Web API");
        removeListItems(appiumElements,"Batt Life");
        removeListItems(appiumElements,"SAFE");
        removeListItems(appiumElements,"Device");
        removeListItems(appiumElements,"PTT");
        removeListItems(appiumElements,"Buttons");
        removeListItems(appiumElements,"Lens Grid");
        removeListItems(appiumElements,"AMiE Agent");
        removeListItems(appiumElements,"SSO Status");
        removeListItems(appiumElements,"/sdcard/LoggerAppDebugData/Bugreport/");
        removeListItems(appiumElements,"/sdcard/LoggerAppDebugData/Slnkdump/");
        removeListItems(appiumElements,"/sdcard/LoggerAppDebugData/Logcat/");
        removeListItems(appiumElements,"/sdcard/LoggerAppDebugData/Qxdm/");
        removeListItemsContains(appiumElements,"Cesium");
        removeListItemsContains(appiumElements,"Flutey Phone");
        removeListItemsContains(appiumElements,"Pixie Dust");
        removeListItemsContains(appiumElements,"\"");
        removeListItemsMatches(appiumElements,".*\\d.*");
    }

    void removeListItems(List<String> list, String element) {
        for (int i = 0; i < list.size(); i++) {
            if (Objects.equals(element, list.get(i))) {
                list.remove(i);
            }
        }
    }

    void removeListItemsContains(List<String> list, String text) {
        list.removeIf(s -> s.contains(text));
    }

    void removeListItemsMatches(List<String> list, String text) {
        list.removeIf(s -> s.matches(text));
    }

    public void tapOnMoreOptions(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        switch (arg1.trim()) {

            case "Danish":
                phone.appium().findElementByAccessibilityId("Flere valgmuligheder").click();
                break;
            case "Dutch":
                phone.appium().findElementByAccessibilityId("Meer opties").click();
                break;
            case "Finnish":
                phone.appium().findElementByAccessibilityId("Lisää asetuksia").click();
                break;
            case "French (France)":
            case "French (Canada)":
                phone.appium().findElementByAccessibilityId("Plus d'options").click();
                break;
            case "German (Germany)":
                phone.appium().findElementByAccessibilityId("Weitere Optionen").click();
                break;
            case "Hungarian":
                phone.appium().findElementByAccessibilityId("További lehetőségek").click();
                break;
            case "Italian":
                phone.appium().findElementByAccessibilityId("Altre opzioni").click();
                break;
            case "Norwegian":
                phone.appium().findElementByAccessibilityId("Flere alternativer").click();
                break;
            case "Portuguese (Port.)":
            case "Portuguese (Brazil)":
                phone.appium().findElementByAccessibilityId("Mais opções").click();
                break;
            case "Russian":
                phone.appium().findElementByAccessibilityId("Ещё").click();
                break;
            case "Slovenian":
                phone.appium().findElementByAccessibilityId("Več možnosti").click();
                break;
            case "Spanish (Spain)":
            case "Spanish (Latam)":
                phone.appium().findElementByAccessibilityId("Más opciones").click();
                break;
            case "Swedish":
                phone.appium().findElementByAccessibilityId("Fler alternativ").click();
                break;
        }
    }

    public List<String> getXmlFileForApp(String arg1, String arg2) throws IOException, SAXException, ParserConfigurationException {
        List<String> elements = null;
        switch (arg2.trim()) {
            case "Danish":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-da-rDK/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-da-rDK/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-da-rDK/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-da-rDK/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-da-rDK/strings.xml");
                        break;
                    case "Vqo":
                        elements= XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-da-rDK/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-da-rDK/strings.xml");
                        break;
                    case "SysUpdater":
                        elements =XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-da-rDK/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-da-rDK/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-da-rDK/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-da-rDK/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-da-rDK/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-da-rDK/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-da-rDK/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-da-rDK/strings.xml");
                        break;
                }
                break;
            case "Dutch":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-nl-rNL/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-nl-rNL/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-nl-rNL/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-nl-rNL/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-nl-rNL/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-nl-rNL/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-nl-rNL/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-nl-rNL/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-nl-rNL/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-nl-rNL/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-nl-rNL/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-nl-rNL/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-nl-rNL/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-nl-rNL/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-nl-rNL/strings.xml");
                        break;
                }
                break;
            case "Finnish":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-fi-rFI/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-fi-rFI/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-fi-rFI/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-fi-rFI/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-fi-rFI/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-fi-rFI/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-fi-rFI/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-fi-rFI/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-fi-rFI/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-fi-rFI/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-fi-rFI/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-fi-rFI/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-fi-rFI/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-fi-rFI/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-fi-rFI/strings.xml");
                        break;
                }
                break;
            case "French (France)":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-fr-rFR/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-fr-rFR/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-fr-rFR/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-fr-rFR/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-fr-rFR/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-fr-rFR/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-fr-rFR/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-fr-rFR/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-fr-rFR/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-fr-rFR/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-fr-rFR/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-fr-rFR/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-fr-rFR/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-fr-rFR/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-fr-rFR/strings.xml");
                        break;
                }
                break;
            case "French (Canada)":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-fr-rCA/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-fr-rCA/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-fr-rCA/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-fr-rCA/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-fr-rCA/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-fr-rCA/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-fr-rCA/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-fr-rCA/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-fr-rCA/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-fr-rCA/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-fr-rCA/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-fr-rCA/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-fr-rCA/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-fr-rCA/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-fr-rCA/strings.xml");
                        break;
                }
                break;
            case "German (Germany)":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-de-rDE/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-de-rDE/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-de-rDE/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-de-rDE/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-de-rDE/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-de-rDE/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-de-rDE/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-de-rDE/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-de-rDE/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-de-rDE/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-de-rDE/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-de-rDE/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-de-rDE/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-de-rDE/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-de-rDE/strings.xml");
                        break;
                }
                break;
            case "Hungarian":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-hu-rHU/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-hu-rHU/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-hu-rHU/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-hu-rHU/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-hu-rHU/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-hu-rHU/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-hu-rHU/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-hu-rHU/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-hu-rHU/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-hu-rHU/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-hu-rHU/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-hu-rHU/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-hu-rHU/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-hu-rHU/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-hu-rHU/strings.xml");
                        break;
                }
                break;
            case "Italian":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-it-rIT/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-it-rIT/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-it-rIT/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-it-rIT/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-it-rIT/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-it-rIT/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-it-rIT/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-it-rIT/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-it-rIT/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-it-rIT/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-it-rIT/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-it-rIT/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-it-rIT/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-it-rIT/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-it-rIT/strings.xml");
                        break;
                }
                break;
            case "Norwegian":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-nb-rNO/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-nb-rNO/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-nb-rNO/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-nb-rNO/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-nb-rNO/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-nb-rNO/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-nb-rNO/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-nb-rNO/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-nb-rNO/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-nb-rNO/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-nb-rNO/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-nb-rNO/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-nb-rNO/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-nb-rNO/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-nb-rNO/strings.xml");
                        break;
                }
                break;
            case "Portuguese (Port.)":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-pt-rPT/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-pt-rPT/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-pt-rPT/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-pt-rPT/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-pt-rPT/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-pt-rPT/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-pt-rPT/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-pt-rPT/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-pt-rPT/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-pt-rPT/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-pt-rPT/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-pt-rPT/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-pt-rPT/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-pt-rPT/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-pt-rPT/strings.xml");
                        break;
                }
                break;
            case "Portuguese (Brazil)":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-pt-rBR/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-pt-rBR/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-pt-rBR/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-pt-rBR/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-pt-rBR/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-pt-rBR/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-pt-rBR/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-pt-rBR/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-pt-rBR/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-pt-rBR/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-pt-rBR/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-pt-rBR/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-pt-rBR/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-pt-rBR/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-pt-rBR/strings.xml");
                        break;
                }
                break;
            case "Russian":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-ru-rRU/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-ru-rRU/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-ru-rRU/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-ru-rRU/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-ru-rRU/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-ru-rRU/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-ru-rRU/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-ru-rRU/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-ru-rRU/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-ru-rRU/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-ru-rRU/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-ru-rRU/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-ru-rRU/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-ru-rRU/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-ru-rRU/strings.xml");
                        break;
                }
                break;
            case "Slovenian":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-sl-rSI/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-sl-rSI/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-sl-rSI/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-sl-rSI/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-sl-rSI/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-sl-rSI/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-sl-rSI/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-sl-rSI/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-sl-rSI/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-sl-rSI/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-sl-rSI/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-sl-rSI/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-sl-rSI/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-sl-rSI/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-sl-rSI/strings.xml");
                        break;
                }
                break;
            case "Spanish (Spain)":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-es-rES/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-es-rES/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-es-rES/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-es-rES/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-es-rES/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-es-rES/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-es-rES/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-es-rES/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-es-rES/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-es-rES/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-es-rES/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-es-rES/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-es-rES/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-es-rES/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-es-rES/strings.xml");
                        break;
                }
                break;
            case "Spanish (Latam)":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-es-rMX/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-es-rMX/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-es-rMX/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-es-rMX/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-es-rMX/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-es-rMX/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-es-rMX/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-es-rMX/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-es-rMX/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-es-rMX/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-es-rMX/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-es-rMX/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-es-rMX/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-es-rMX/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-es-rMX/strings.xml");
                        break;
                }
                break;
            case "Swedish":
                switch (arg1.trim()) {
                    case "BizPhone":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSip/values-sv-rSE/strings.xml");
                        break;
                    case "BattLife":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBattLife/values-sv-rSE/strings.xml");
                        break;
                    case "Safe":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSafe/values-sv-rSE/strings.xml");
                        break;
                    case "Web API":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkWebApi/values-sv-rSE/strings.xml");
                        break;
                    case "Device":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkDeviceSettings/values-sv-rSE/strings.xml");
                        break;
                    case "Vqo":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkVQO/values-sv-rSE/strings.xml");
                        break;
                    case "Ptt":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkPtt/values-sv-rSE/strings.xml");
                        break;
                    case "SysUpdater":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkOTA/values-sv-rSE/strings.xml");
                        break;
                    case "Buttons":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkButtons/values-sv-rSE/strings.xml");
                        break;
                    case "LensGrid":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLensGrid/values-sv-rSE/strings.xml");
                        break;
                    case "Logging":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkLogger/values-sv-rSE/strings.xml");
                        break;
                    case "SamClient":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSamClient/values-sv-rSE/strings.xml");
                        break;
                    case "Sso":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkSso/values-sv-rSE/strings.xml");
                        break;
                    case "Amie":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkAtlasAgent/values-sv-rSE/strings.xml");
                        break;
                    case "Barcode":
                        elements = XmlParser.parseXml("src/test/resources/test_data/languages/SlnkBarcode/values-sv-rSE/strings.xml");
                        break;
                }
                break;
        }
        return elements;
    }
}
