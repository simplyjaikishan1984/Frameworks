package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamLoggingPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.LOGGING;

public class SamLoggingSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I click the Syslog tab")
	public void clickSyslogTab() {
		SamLoggingPage loggingPage = (SamLoggingPage) Environment.getCurrentPage();
		loggingPage.clickSyslogTab();
	}

	@When("^I click the Advanced Logging tab")
	public void clickAdvancedTab() {
		SamLoggingPage loggingPage = (SamLoggingPage) Environment.getCurrentPage();
		loggingPage.clickAdvancedLoggingTab();
	}

	@When("^I check the \"([^\"]*)\" Logging field$")
	public void checkLoggingCheckbox(String arg1) {
		SamLoggingPage loggingPage = (SamLoggingPage) Environment.getCurrentPage();
		if (loggingPage.getField(arg1.trim()) != null) {
			loggingPage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with label '{}'", arg1);
		}
	}

	@When("^I uncheck the \"([^\"]*)\" Logging field$")
	public void uncheckLoggingCheckbox(String arg1) {
		SamLoggingPage loggingPage = (SamLoggingPage) Environment.getCurrentPage();
		if (loggingPage.getField(arg1.trim()) != null) {
			loggingPage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with label '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" Logging field$")
	public void selectLoggingMenuOption(String arg1, String arg2) {
		SamLoggingPage loggingPage = (SamLoggingPage) Environment.getCurrentPage();
		if (loggingPage.getField(arg2) != null) {
			loggingPage.getField(arg2.trim()).updateMenuByLabel(arg1.trim());
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" Logging field$")
	public void enterLoggingFieldValue(String arg1, String arg2) {
		SamLoggingPage loggingPage = (SamLoggingPage) Environment.getCurrentPage();
		if (loggingPage.getField(arg2.trim()) != null) {
			loggingPage.getField(arg2.trim()).updateTextbox(arg1);
		} else {
			log.error("No matching field with label '{}'", arg2);
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the \"([^\"]*)\" Logging setting$")
	public void verifyLoggingValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(LOGGING, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(LOGGING, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(LOGGING)) phone.loadAppPreferences(LOGGING);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("No matching field with label '{}'", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I delete the \"([^\"]*)\" Logging field$")
	public void deleteLoggingSetting(String arg1) {
		SamLoggingPage loggingPage = (SamLoggingPage) Environment.getCurrentPage();
		loggingPage.getField(arg1.trim()).delete();
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the Logging custom attribute \"([^\"]*)\" setting$")
	public void checkLoggingCustomAttributeSetting(String arg1, String arg2, String arg3) {
		if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
			VersityPhone phone = Environment.getPhone(arg1.trim());
			if (phone != null) {
				if (!phone.getCurrentAppSettings().equals(LOGGING)) phone.loadAppPreferences(LOGGING);
				Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
			} else {
				log.error("Phone with label '{}' does not exist", arg1);
				Assert.fail("Specified Phone Not Available");
			}
		} else {
			log.debug("Skipped checking attribute {} since custom attribute testing is turned off", arg1);
		}
	}

	@Then("^the Logging page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyLoggingPageValue(String arg1, String arg2) {
		SamLoggingPage loggingPage = (SamLoggingPage) Environment.getCurrentPage();
		if (loggingPage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(loggingPage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(loggingPage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Field with label '{}' does not exist", arg2);
		}
	}
}