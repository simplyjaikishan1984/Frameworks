package com.spectralink.test_automation.cucumber.framework.common;

import com.spectralink.test_automation.cucumber.framework.WebBrowser;
import com.spectralink.test_automation.cucumber.framework.sam.SamAutomation;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import java.util.logging.Logger;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class ConfigPageField extends SamAutomation {
	private final org.apache.logging.log4j.Logger log = LogManager.getLogger(this.getClass().getName());
	private WebElement label;
	private WebElement targetElement;
	private WebElement deleteButton;
	private WebElement editButton;
	private WebElement undoButton;
	private String title;
	private String key;
	private EntityType type;
	private String lastToastMessage;

	public enum EntityType {
		CHECKBOX,
		TEXTBOX,
		PASSWORD,
		MENU,
		RADIO,
		BUTTON,
		SLIDER,
		UNKNOWN
	}

	public enum Level {
		DEFAULT,
		ENTERPRISE,
		GROUP,
		DEVICE,
		NONE
	}

	public ConfigPageField(FieldData strings, WebElement label, WebElement targetElement, WebElement deleteButton, WebElement editButton, WebElement undoButton) {
		driver = WebBrowser.getDriver();
		this.title = strings.title();
		this.label = label;
		this.targetElement = targetElement;
		this.deleteButton = deleteButton;
		this.editButton = editButton;
		this.undoButton = undoButton;
	}

	public ConfigPageField(WebElement targetElement, WebElement deleteButton, WebElement editButton) {
		driver = WebBrowser.getDriver();
		this.targetElement = targetElement;
		this.deleteButton = deleteButton;
		this.editButton = editButton;
	}

	public ConfigPageField(FieldData strings, WebElement label, WebElement targetElement, WebElement deleteButton, WebElement editButton) {
		driver = WebBrowser.getDriver();
		this.title = strings.title();
		this.key = strings.attribute();
		this.label = label;
		this.targetElement = targetElement;
		this.deleteButton = deleteButton;
		this.editButton = editButton;
	}

	public ConfigPageField(FieldData strings, WebElement targetElement, WebElement deleteButton, WebElement editButton) {
		driver = WebBrowser.getDriver();
		this.title = strings.title();
		this.key = strings.attribute();
		this.targetElement = targetElement;
		this.deleteButton = deleteButton;
		this.editButton = editButton;
	}

	public String getLastToastMessage() {
		return lastToastMessage;
	}

	public void setLastToastMessage(String message) {
		lastToastMessage = message;
	}

	public WebElement getLabel() {
		return label;
	}

	public void setLabel(WebElement label) {
		this.label = label;
	}

	public WebElement getTargetElement() {
		return targetElement;
	}

	public void setTargetElement(WebElement targetElement) {
		this.targetElement = targetElement;
	}

	public WebElement getDeleteButton() {
		return deleteButton;
	}

	public void setDeleteButton(WebElement deleteButton) {
		this.deleteButton = deleteButton;
	}

	public WebElement getEditButton() {
		return editButton;
	}

	public void setEditButton(WebElement editButton) {
		this.editButton = editButton;
	}

	public WebElement getUndoButton() {
		return undoButton;
	}

	public void setUndoButton(WebElement undoButton) {
		this.undoButton = undoButton;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public EntityType getType() {
		if (type != null) {
			return type;
		} else {
			String entity = getEntityTag(targetElement);
			if (entity == null) {
				log.error("Cannot locate element {}", targetElement);
				type = EntityType.UNKNOWN;
			} else if (entity.contentEquals("input")) {
				String elementType = getEntityAttribute(targetElement, "type");
				switch (elementType) {
					case "checkbox":
						type = EntityType.CHECKBOX;
						break;
					case "text":
						type = EntityType.TEXTBOX;
						break;
					case "url":
						type = EntityType.TEXTBOX;
						break;
					case "number":
						type = EntityType.TEXTBOX;
						break;
					case "password":
						type = EntityType.PASSWORD;
						break;
					case "radio":
						type = EntityType.RADIO;
						break;
					case "range":
						type = EntityType.SLIDER;
						break;
					default:
						log.error("Element {} had unknown tag of {}", targetElement, elementType);
						type = EntityType.UNKNOWN;
				}
			} else if (entity.contentEquals("select")) {
				type = EntityType.MENU;
			} else if (entity.contentEquals("textarea")) {
				type = EntityType.TEXTBOX;
			} else if (entity.contentEquals("button")) {
				type = EntityType.BUTTON;
			} else if (entity.contentEquals("rzslider")) {
				type = EntityType.SLIDER;
			} else if (entity.contentEquals("span")) {
				type = EntityType.UNKNOWN;
			} else {
				log.error("Element {} had unknown entity type of {}", targetElement, entity);
				type = EntityType.UNKNOWN;
			}
			return type;
		}
	}

	public String getLabelText() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO)) {
			if (label != null) {
				return label.getText();
			}
		} else {
			log.warn("Cannot get label text for an element of type {}", entityType.name());
		}
		return null;
	}

	public void enter(String text) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.TEXTBOX) || entityType.equals(EntityType.PASSWORD)) {
			edit();
			typeIntoPageEntity(targetElement, text);
		} else {
			log.warn("Cannot enter text into an element of type {}", entityType.name());
		}
	}

	public void click() {
		EntityType entityType = getType();
		if ((entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO) && label != null)) {
			clickOnPageEntity(label);
		} else {
			clickOnPageEntity(targetElement);
		}
	}

	public boolean isEnabled() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO)) {
			return isEntitySelected(targetElement);
		}
		return false;
	}

	public void enable() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO)) {
			if (label != null && !isEntitySelected(targetElement)) {
				clickOnPageEntity(label);
			}
		} else {
			log.warn("Cannot enable an element of type {}", entityType.name());
		}
	}

	public void disable() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO)) {
			if (label != null && isEntitySelected(targetElement)) {
				clickOnPageEntity(label);
			}
		} else {
			log.warn("Cannot disable an element of type {}", entityType.name());
		}
	}

	public void checkUncheck(Boolean enable) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX)) {
			if (label != null) {
				if (enable != null) {
					if (enable && !isEntitySelected(targetElement)) {
						clickOnPageEntity(label);
					} else if (!enable && isEntitySelected(targetElement)) {
						clickOnPageEntity(label);
					}
				} else {
					log.error("No boolean value set for {}", getTargetElement().toString());
				}
			} else {
				log.error("No label defined for {}", getTargetElement().toString());
			}
		} else {
			log.warn("Cannot disable an element of type {}", entityType.name());
		}
	}

	public void selectText(String option) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			selectMenuByText(targetElement, option);
		} else {
			log.warn("Cannot select an element of type {}", entityType.name());
		}
	}

	public void selectIndex(int option) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			selectMenuByIndex(targetElement, option);
		} else {
			log.warn("Cannot select an element of type {}", entityType.name());
		}
	}

	public void selectValue(String option) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			selectMenuByValue(targetElement, option);
		} else {
			log.warn("Cannot select an element of type {}", entityType.name());
		}
	}

	public String getSelection() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			return getMenuSelectedOption(targetElement);
		} else {
			log.warn("Cannot get option for element of type {}", entityType.name());
			return null;
		}
	}

	public Integer slideToValue(int targetValue) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SLIDER)) {
			Actions builder = new Actions(driver);
			Action dragAndDrop;
			int distance = targetValue - getSliderValue();
			int elementWidth = targetElement.getSize().getWidth();
			float increments = elementWidth / (getSliderMax() - getSliderMin());
			int travelPixels = Math.round(increments * distance);
			dragAndDrop = builder.clickAndHold(label).moveByOffset(travelPixels, 0).release().build();
			dragAndDrop.perform();
			log.debug("Set new slider value to {}", getSliderValue());
			sleepSeconds(1);
			return getSliderValue();
		} else {
			log.warn("Cannot slide an element of type {}", entityType.name());
			return 0;
		}
	}

	private void tuneSliderValue(Integer startValue, Integer targetValue) {
		Actions builder = new Actions(driver);
		java.util.logging.Level seleniumLogLevel = Logger.getLogger("org.openqa.selenium").getLevel();
		Logger.getLogger("org.openqa.selenium").setLevel(java.util.logging.Level.SEVERE);
		int offset = startValue;
		int attempts = 1;
		while (getNewSliderValue() != targetValue) {
			offset = getNewSliderValue() > targetValue ? offset - 3 : offset + 3;
            builder.dragAndDropBy(targetElement, offset, 0).build().perform();
			if (attempts > 5) {
				break;
			} else {
				attempts += 1;
			}
		}
		Logger.getLogger("org.openqa.selenium").setLevel(seleniumLogLevel);
	}

	public Integer updateSliderValue(int targetValue) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SLIDER)) {
			edit();
			double elementWidth = targetElement.getSize().getWidth();
			double range = getNewSliderMax() - getNewSliderMin();
			double middle = getNewSliderMin() + (range / 2);
			double travel = targetValue - middle;
			double increments = elementWidth / range;
			Long travelPixels = Math.round(increments * travel);
			tuneSliderValue(travelPixels.intValue(), targetValue);
			log.debug("Set slider value to {}", getNewSliderValue());
			sleepSeconds(1);
			return getNewSliderValue();
		} else {
			log.warn("Cannot slide an element of type {}", entityType.name());
			return 0;
		}
	}

	public Integer getSliderValue() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SLIDER)) {
			return Integer.valueOf(label.getAttribute("aria-valuenow"));
		} else {
			log.warn("Cannot get slider value of an element of type {}", entityType.name());
			return 0;
		}
	}

	public Integer getNewSliderValue() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SLIDER)) {
			return Integer.valueOf(targetElement.getAttribute("aria-valuenow"));
		} else {
			log.warn("Cannot get slider value of an element of type {}", entityType.name());
			return 0;
		}
	}

	public Integer getSliderMax() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SLIDER)) {
			return Integer.valueOf(label.getAttribute("aria-valuemax"));
		} else {
			log.warn("Cannot get slider max value of an element of type {}", entityType.name());
			return 0;
		}
	}

	public Integer getNewSliderMax() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SLIDER)) {
			return Integer.valueOf(targetElement.getAttribute("aria-valuemax"));
		} else {
			log.warn("Cannot get slider max value of an element of type {}", entityType.name());
			return 0;
		}
	}

	public Integer getSliderMin() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SLIDER)) {
			return Integer.valueOf(label.getAttribute("aria-valuemin"));
		} else {
			log.warn("Cannot get slider min value of an element of type {}", entityType.name());
			return 0;
		}
	}

	public Integer getNewSliderMin() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SLIDER)) {
			return Integer.valueOf(targetElement.getAttribute("aria-valuemin"));
		} else {
			log.warn("Cannot get slider min value of an element of type {}", entityType.name());
			return 0;
		}
	}

	public void delete() {
		setTemporaryWait(2);
		if (deleteButton != null) {
			if (isEntityClickable(deleteButton)) {
				clickOnPageEntity(deleteButton);
				WebElement dialogDeleteButton = locateElement(By.xpath("//button[contains(text(), \"Delete\")]"));
				if (dialogDeleteButton != null) {
					try {
						clickOnPageEntity(dialogDeleteButton);
						WebElement toastMessage = locateElement(By.className("default-message-content"));
						if (toastMessage != null) {
							lastToastMessage = toastMessage.getAttribute("innerText");
							WebElement toastClose = locateElement(By.className("close-custom-error"));
							if (toastClose != null) {
								clickOnPageEntity(toastClose);
							}
						}
						sleepSeconds(1);
					} catch (StaleElementReferenceException sere) {
						log.trace("Stale element reference");
					}
				} else {
				    log.error("Could not click delete acknowledgement button");
                }
			} else {
				log.warn("Could not click trash icon {}", deleteButton);
			}
		}
		removeTemporaryWait();
	}

	public void edit() {
		setTemporaryWait(0);
		if (editButton != null && isEntityClickable(editButton)) {
			clickOnPageEntity(editButton);
		}
		removeTemporaryWait();
	}

	public void undo() {
		setTemporaryWait(2);
		if (undoButton != null && isEntityClickable(undoButton)) {
			clickOnPageEntity(undoButton);
		}
		removeTemporaryWait();
	}

	public void updateTextbox(Object newText) {
		setTemporaryWait(0);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.TEXTBOX) || entityType.equals(EntityType.PASSWORD)) {
			edit();
			enter(newText.toString());
		} else {
			log.error("Cannot enter text into an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public void updateCheckbox(Boolean newState) {
		setTemporaryWait(1);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX)) {
			edit();
			checkUncheck(newState);
		} else {
			log.error("Cannot check or uncheck an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public void updateRadioButton() {
		setTemporaryWait(1);
		EntityType targetType = getType();
		if (targetType.equals(EntityType.RADIO)) {
			edit();
			enable();
		} else {
			log.error("Can't click radio on an element of type {}", targetType.name());
		}
		removeTemporaryWait();
	}

	public void updateMenuByLabel(String newLabel) {
		setTemporaryWait(1);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			edit();
			selectText(newLabel);
		} else {
			log.error("Can't choose option on an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public void updateMenuByIndex(Integer newNumber) {
		setTemporaryWait(1);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			edit();
			selectIndex(newNumber);
		} else {
			log.error("Can't choose option index on an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public void updateMenuByValue(String newValue) {
		setTemporaryWait(1);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			edit();
			selectValue(newValue);
		} else {
			log.error("Can't choose option value on an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public boolean isConfigured() {
		setTemporaryWait(0);
		boolean deleteAvailable = false;
		if (isEntityClickable(deleteButton)) {
			deleteAvailable = true;
		}
		removeTemporaryWait();
		return deleteAvailable;
	}

	private WebElement findEntity(WebElement element, String xpath) {
		WebElement targetEntity = null;
		try {
			targetEntity = element.findElement(By.xpath(xpath));
		} catch (NoSuchElementException nsee) {
			log.debug(nsee.getMessage());
		}
		return targetEntity;
	}

	public Level getLevel() {
		setTemporaryWait(2);
		Level level = Level.NONE;
		if (isConfigured()) {
			if (isPresent(By.xpath("//*[contains(@id, \"top-menu-main-0\") and contains(@class, \"active\")]"))) {
				level = Level.ENTERPRISE;
			} else if (isPresent(By.xpath("//*[contains(@id, \"top-menu-main-1\") and contains(@class, \"active\")]"))) {
				level = Level.GROUP;
			} else {
				level = Level.DEVICE;
			}
		} else {
			WebElement parent = findEntity(targetElement, "..");
			WebElement levelContainer = findEntity(parent, "//*[contains(@class, \"level-setting-change-main\")]");
			if (levelContainer != null) {
				WebElement defaultLevel = findEntity(levelContainer, "//*[contains(text(), \"DEFAULT\")]");
				if (defaultLevel != null) {
					level = Level.DEFAULT;
				} else {
					WebElement image = findEntity(levelContainer, "//img");
					if (image != null) {
						String src = image.getAttribute("src");
						if (src.contains("enterprise_level_phone_icon_new.png")) {
							level = Level.ENTERPRISE;
						} else if (src.contains("icon_groups_new.png")) {
							level = Level.GROUP;
						} else if (src.contains("icon_devices_expanded_new.png")) {
							level = Level.DEVICE;
						} else {
							level = Level.NONE;
						}
					}
				}
			}
		}
		removeTemporaryWait();
		return level;
	}

	public int compareState(String samValue) {
		String pageValue = targetElement.getAttribute("value");
		if (pageValue == null) {
			log.fatal("Could not get value for page element {}", targetElement);
			return 1;
		} else if (!pageValue.contains(samValue)) {
			log.fatal(String.format("Mismatch on %-40s Data Setting: %-15s Page Setting: %-15s", targetElement.toString(), samValue, pageValue));
			return 1;
		} else {
			return 0;
		}
	}

	public int compareState(Integer samValue) {
		Integer pageValue = Integer.valueOf(targetElement.getAttribute("value"));
		if (pageValue == null) {
			log.fatal("Could not get value for page element {}", targetElement);
			return 1;
		} else if (!samValue.equals(pageValue)) {
			log.fatal(String.format("Mismatch on %-40s Data Setting: %-15s Page Setting: %-15s", targetElement.toString(), samValue, pageValue));
			return 1;
		} else {
			return 0;
		}
	}

	public int compareState(Boolean samValue) {
		Boolean pageValue = targetElement.isSelected();
		if (pageValue == null) {
			log.fatal("Could not get value for page element {}", targetElement);
			return 1;
		} else if (!samValue.equals(pageValue)) {
			log.fatal(String.format("Mismatch on %-40s Data Setting: %-15s Page Setting: %-15s", targetElement.toString(), samValue, pageValue));
			return 1;
		} else {
			return 0;
		}
	}

}
