package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamManageGroupsPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.commons.text.WordUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamManageGroupSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I enter \"([^\"]*)\" into the Group Name field$")
    public void enterGroupName(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.enterGroupName(arg1);
    }

    @When("^I click the 'Select Devices' button$")
    public void clickSelectDevices() {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.clickSelectDevicesButton();
        Environment.setTemporaryValue("Available", groupsPage.getDeviceTally("Available"));
        Environment.setTemporaryValue("Selected", groupsPage.getDeviceTally("Selected"));
    }

    @When("^I click the 'Save' button$")
    public void clickSaveButton() {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.clickSaveButton();
    }

    @When("^I click the 'Reset' button$")
    public void clickResetButton() {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.clickResetButton();
    }

    @When("^from the Select Device dialog box I select \"([^\"]*)\"$")
    public void selectDevice(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        if (groupsPage.deviceSelectDialogShowing()) {
            if (Environment.getPhone(arg1.trim()) != null) {
                groupsPage.selectDevice(Environment.getPhone(arg1.trim()).getSerialNumber());
            } else {
                log.error("Cannot find phone with label '{}'", arg1);
                Assert.fail("Specified Label Is Invalid");
            }
        } else {
            log.error("Cannot select '{}' when Select Device dialog is not showing", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^from the Select Device dialog box I unselect \"([^\"]*)\"$")
    public void unselectDevice(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        if (groupsPage.deviceSelectDialogShowing()) {
            if (Environment.getPhone(arg1.trim()) != null) {
                groupsPage.unselectDevice(Environment.getPhone(arg1.trim()).getSerialNumber());
            } else {
                log.error("Cannot find phone with label '{}'", arg1);
                Assert.fail("Specified Label Is Invalid");
            }
        } else {
            log.error("Cannot select '{}' when Select Device dialog is not showing", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^from the Select Device dialog box I select the search type \"([^\"]*)\"$")
    public void selectDeviceSearchType(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        if (groupsPage.deviceSelectDialogShowing()) {
            SamManageGroupsPage.DeviceSearchMenu option = groupsPage.getDeviceMenuOption(arg1.trim());
            if (option != null) {
                groupsPage.selectDeviceSearchType(option);
            } else {
                log.error("Cannot find menu option '{}'", arg1);
                Assert.fail("Specified Label Is Invalid");
            }
        } else {
            log.error("Cannot select '{}' when Select Device dialog is not showing", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^in the Select Device dialog box I enter the \"([^\"]*)\" of device \"([^\"]*)\" into the search field$")
    public void enterDeviceSearchValue(String arg1, String arg2) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if (phone != null) {
            SamManageGroupsPage.DeviceSearchMenu column = groupsPage.getDeviceMenuOption(arg1.trim());
            if (column != null) {
                switch (column) {
                    case MAC:
                        groupsPage.enterDeviceSearchValue(phone.getMacAddress());
                        break;
                    case SERIAL_NUMBER:
                        groupsPage.enterDeviceSearchValue(phone.getSerialNumber());
                        break;
                    case MODEL:
                        String modifiedModel = phone.getModel().toUpperCase().replace(" ", "_");
                        groupsPage.enterDeviceSearchValue(modifiedModel);
                        break;
                    case SIP_1_EXTENSION:
                        String extension = Environment.getSam().keyDatabase().getSipExtension(phone.getSerialNumber());
                        groupsPage.enterDeviceSearchValue(extension);
                        break;
                    case DEVICE_INFO_1:
                        String info1 = Environment.getSam().keyDatabase().getDeviceInfo1(phone.getSerialNumber());
                        groupsPage.enterDeviceSearchValue(info1);
                        break;
                    case DEVICE_INFO_2:
                        String info2 = Environment.getSam().keyDatabase().getDeviceInfo2(phone.getSerialNumber());
                        groupsPage.enterDeviceSearchValue(info2);
                        break;
                    case DEVICE_INFO_3:
                        String info3 = Environment.getSam().keyDatabase().getDeviceInfo3(phone.getSerialNumber());
                        groupsPage.enterDeviceSearchValue(info3);
                        break;
                    case DEVICE_INFO_4:
                        String info4 = Environment.getSam().keyDatabase().getDeviceInfo4(phone.getSerialNumber());
                        groupsPage.enterDeviceSearchValue(info4);
                        break;
                }
            } else {
                log.error("Column with title '{}' does not exist", arg1);
                Assert.fail("SAM UI Interaction Error");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg2);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @When("^in the Select Device dialog box I enter \"([^\"]*)\" into the search field$")
    public void enterFreeformDeviceSearchValue(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.enterDeviceSearchValue(arg1.trim());
    }

    @When("^from the Select Device dialog box I click the 'SELECT DEVICE' button$")
    public void clickSelectDeviceButton() {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.clickSelectDeviceSaveButton();
    }

    @When("^I select the \"([^\"]*)\" group$")
    public void selectGroup(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.selectGroupByName(arg1.trim());
    }

    @When("^I select all groups$")
    public void selectAllGroups() {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.selectAllGroups();
    }

    @When("^I select \"([^\"]*)\" from the Manage Groups action menu$")
    public void selectAction(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        if (arg1.trim().contentEquals("Change config")) {
            Environment.setCurrentPage(groupsPage.selectChangeConfig(), Environment.SamPage.BARCODE);
        } else if (arg1.trim().contentEquals("Delete group(s)")) {
            groupsPage.deleteSelectedGroup();
        } else if (arg1.trim().contentEquals("Edit group")) {
            groupsPage.selectEditGroup();
        } else {
            log.error("Cannot select '{}' from action menu", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^I select \"([^\"]*)\" from the Manage Groups search menu$")
    public void selectSearch(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        SamManageGroupsPage.GroupSearchMenu option = groupsPage.getGroupMenuOption(arg1.trim());
        if (option != null) {
            groupsPage.selectSearchType(option);
        } else {
            log.error("Cannot select '{}' from search menu", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^I enter \"([^\"]*)\" into the Manage Groups search field$")
    public void enterGroupSearchString(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.enterSearchValue(arg1.trim());
        sleepSeconds(1);
    }

    @When("^I enter the device serial of \"([^\"]*)\" into the Manage Groups search field$")
    public void searchDeviceSerial(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone != null) {
            groupsPage.enterSearchValue(phone.getSerialNumber());
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @When("^I move the \"([^\"]*)\" group to the top priority$")
    public void moveGroupToTop(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.dragGroupToTop(arg1.trim());
    }

    @When("^I click the Manage Groups search clear button$")
    public void clickClearSearch() {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.clickSearchClearButton();
    }

    @When("^I close the Select Device dialog box$")
    public void closeSelectDeviceDialog() {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        groupsPage.clickDeviceCloseButton();
        sleepSeconds(1);
    }

    @When("^I click the close button for device bubble \"([^\"]*)\"$")
    public void closeDeviceButton(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        groupsPage.closeDeviceBubble(phone.getSerialNumber());
        sleepSeconds(1);
    }

    @Then("^the \"([^\"]*)\" group is not visible$")
    public void groupDeleted(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        if (!groupsPage.groupIsVisible(arg1.trim())) {
            log.debug("Group '{}' was deleted", arg1);
        } else {
            log.fatal("Group '{}' still appeared after deletion", arg1);
            Assert.fail("Group Deletion Failure");
        }
    }

    @Then("^the \"([^\"]*)\" group is visible$")
    public void groupCreated(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        if (groupsPage.groupIsVisible(arg1.trim())) {
            log.debug("Group '{}' was visible", arg1);
        } else {
            log.fatal("Group '{}' failed to be created", arg1);
            Assert.fail("Group Creation Failure");
        }
    }

    @Then("^the \"([^\"]*)\" group has \"([^\"]*)\" devices$")
    public void groupDeviceCount(String arg1, String arg2) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        int deviceCount = groupsPage.getDeviceCount(arg1.trim());
        if (deviceCount == Integer.parseInt(arg2.trim())) {
            log.debug("Group '{}' has expected {} devices", arg1, arg2);
        } else {
            log.fatal("Group '{}' had {} devices but expected {}", arg1, deviceCount, arg2);
            Assert.fail("Group Device Count Failure");
        }
    }

    @Then("^there are exactly \"([^\"]*)\" group\\(s\\) displayed$")
    public void groupRowsDisplayed(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        int expectedRows = Integer.parseInt(arg1.trim());
        int foundRows = groupsPage.getGroupRowCount();
        if (expectedRows == foundRows) {
            log.debug("Searching found {} group(s)", foundRows);
        } else {
            log.fatal("Number of groups found {} was not expected {}", foundRows, arg1);
            Assert.fail("Group Search Failure");
        }
    }

    @Then("^there are exactly \"([^\"]*)\" devices\\(s\\) displayed in the Select Device dialog box$")
    public void deviceRowsDisplayed(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        int expectedRows = Integer.parseInt(arg1.trim());
        int foundRows = groupsPage.getDeviceRowCount();
        if (expectedRows == foundRows) {
            log.debug("Searching found {} devices(s)", foundRows);
        } else {
            log.fatal("Number of devices found {} was not expected {}", foundRows, arg1);
            Assert.fail("Device Search Failure");
        }
    }

    @Then("^there is at least \"([^\"]*)\" devices\\(s\\) displayed in the Select Device dialog box$")
    public void minimumDeviceRowsDisplayed(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        int expectedRows = Integer.parseInt(arg1.trim());
        int foundRows = groupsPage.getDeviceRowCount();
        if (foundRows >= expectedRows) {
            log.debug("Searching found at least {} devices(s)", foundRows);
        } else {
            log.fatal("Number of devices found {} was not expected {}", foundRows, arg1);
            Assert.fail("Device Search Failure");
        }
    }

    @Then("^the device \"([^\"]*)\" is visible in the Select Device dialog box$")
    public void deviceVisible(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone != null) {
            if (groupsPage.deviceIsVisible(phone.getMacAddress())) {
                log.debug("Device {} was visible", arg1);
            } else {
                log.error("Device with mac address {} was not found", arg1);
                Assert.fail("Device Search Failed");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @Then("^the \"([^\"]*)\" device count in the Select Device dialog box has decreased by \"([^\"]*)\"")
    public void verifyTallyIncrease(String arg1, String arg2) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        String badgeType = WordUtils.capitalize(arg1.trim());
        if (badgeType.contentEquals("Available") || badgeType.contentEquals("Selected")) {
            int currentTallyCount = groupsPage.getDeviceTally(arg1.trim());
            int difference = Integer.parseInt(arg2.trim());
            if (currentTallyCount == Environment.getIntegerTemporaryValue(badgeType) - difference) {
                log.debug("{} count decreased by {}", arg1, arg2);
                Environment.setTemporaryValue(badgeType, groupsPage.getDeviceTally(badgeType));
            } else {
                log.error("{} device count did not decrease", arg1);
                Assert.fail("Device Availability/Selected Count Was Incorrect");
            }
        } else {
            log.error("'{}' is an invalid type of device count", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("^the \"([^\"]*)\" device count in the Select Device dialog box has increased by \"([^\"]*)\"")
    public void verifyTallyDecrease(String arg1, String arg2) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        String badgeType = WordUtils.capitalize(arg1.trim());
        if (badgeType.contentEquals("Available") || badgeType.contentEquals("Selected")) {
            int currentTallyCount = groupsPage.getDeviceTally(arg1.trim());
            int difference = Integer.parseInt(arg2.trim());
            if (currentTallyCount == Environment.getIntegerTemporaryValue(badgeType) + difference) {
                log.debug("{} count increased by {}", arg1, arg2);
                Environment.setTemporaryValue(badgeType, groupsPage.getDeviceTally(badgeType));
            } else {
                log.error("{} device count did not increase", arg1);
                Assert.fail("Device Availability/Selected Count Was Incorrect");
            }
        } else {
            log.error("'{}' is an invalid type of device count", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("^the \"([^\"]*)\" device count in the Select Device dialog box is \"([^\"]*)\"")
    public void verifyTally(String arg1, String arg2) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        String badgeType = WordUtils.capitalize(arg1.trim());
        if (badgeType.contentEquals("Available") || badgeType.contentEquals("Selected")) {
            int currentTallyCount = groupsPage.getDeviceTally(arg1.trim());
            if (currentTallyCount == Environment.getIntegerTemporaryValue(badgeType)) {
                log.debug("{} count was {}", arg1, arg2);
                Environment.setTemporaryValue(badgeType, groupsPage.getDeviceTally(badgeType));
            } else {
                log.error("{} device count was not expected {}", arg1, arg2);
                Assert.fail("Device Availability/Selected Count Was Incorrect");
            }
        } else {
            log.error("'{}' is an invalid type of device count", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("^the device bubble for \"([^\"]*)\" is visible")
    public void verifyBubble(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone != null) {
            if (groupsPage.isBubblePresent(phone.getSerialNumber())) {
                log.debug("Device bubble for {} was visible", arg1);
            } else {
                log.error("Device bubble for {} was not visible", arg1);
                Assert.fail("SAM Page Failure");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @Then("^the device bubble for \"([^\"]*)\" is not visible")
    public void verifyNoBubble(String arg1) {
        SamManageGroupsPage groupsPage = (SamManageGroupsPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone != null) {
            if (!groupsPage.isBubblePresent(phone.getSerialNumber())) {
                log.debug("Device bubble for {} was not visible", arg1);
            } else {
                log.error("Device bubble for {} was still visible", arg1);
                Assert.fail("SAM Page Failure");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }
}