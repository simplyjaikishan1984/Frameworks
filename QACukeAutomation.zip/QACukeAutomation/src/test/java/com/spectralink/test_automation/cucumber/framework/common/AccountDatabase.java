package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

public class AccountDatabase extends Database {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	public AccountDatabase(String dbIP, Integer dbPort, String dbName, String dbUsername, String dbPassword) {
		super(dbIP, dbPort, dbName, dbUsername, dbPassword);
	}

	public void deleteLicencesExcept(String serialNumber) {
		PreparedStatement pstmt = null;
		String query = "";
		try {
			query = String.format("SELECT id FROM licenses WHERE serial_number = '%s'", serialNumber);
			Long protectedId = queryLong(query, "id");

			query = String.format("DELETE FROM license_configuration WHERE license_id <> %d", protectedId);
			pstmt = dbConnection.prepareStatement(query);
			pstmt.executeUpdate();
			log.trace("Deleted license configurations");

			query = String.format("DELETE FROM licenses WHERE id <> %d", protectedId);
			pstmt = dbConnection.prepareStatement(query);
			pstmt.executeUpdate();
			log.debug("Deleted all licenses except " + serialNumber);
		} catch (SQLException e) {
			log.error("SQL query error; ", e.getMessage());
			log.error("QUERY: {}", query);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
			} catch (SQLException e) {
				log.error("statement close error {}", e.getMessage());
			}
		}
	}

	public Boolean isPhoneInGroup(String deviceSerialNumber, String groupName) {
		String query = String.format("SELECT groups.name " +
				"FROM public.devices_groups " +
				"JOIN public.groups ON devices_groups.group_id=groups.id " +
				"WHERE active=true " +
				"AND device_serial='%s' " +
				"AND groups.name='%s'", deviceSerialNumber, groupName);
		if (query(query).hasNext()) {
			return true;
		} else {
			return false;
		}
	}

	public String getGroupForPhone(String deviceSerialNumber) {
		String query = String.format("SELECT groups.name " +
				"FROM public.devices_groups " +
				"JOIN public.groups ON devices_groups.group_id=groups.id " +
				"WHERE active=true AND device_serial='%s'", deviceSerialNumber);
		Iterator<HashMap<String, Object>> list = query(query);
		if (list.hasNext()) {
			HashMap<String, Object> firstRecord = list.next();
			return (String) firstRecord.get("name");
		} else {
			return null;
		}
	}

	public Boolean groupExists(String groupName) {
		String query = String.format("SELECT groups.name " +
				"FROM public.groups " +
				"WHERE active=true AND name='%s'", groupName);
		if (query(query).hasNext()) {
			return true;
		} else {
			return false;
		}
	}

	public List<String> getGroupMemberSerials(String groupName) {
		String query = String.format("SELECT devices_groups.device_serial " +
				"FROM public.devices_groups " +
				"JOIN public.groups ON devices_groups.group_id=groups.id " +
				"WHERE groups.active=true AND groups.name='%s'", groupName);
		Iterator<HashMap<String, Object>> list = query(query);
		List<String> serialList = new ArrayList<>();
		while (list.hasNext()) {
			HashMap<String, Object> record = list.next();
			serialList.add((String) record.get("device_serial"));
		}
		return serialList;
	}

	public Iterator<HashMap<String, Object>> getAllDevices() {
		String deviceQuery = "SELECT device_serial FROM devices";
		return query(deviceQuery);
	}

	public void addDevicesToGroup(String groupName, String ... serials) {
		String findIdQuery = "SELECT id FROM groups WHERE active=true AND name='" + groupName + "'";
		Long groupId = queryLong(findIdQuery, "id");
		for (String serialNumber : serials) {
			String addPhoneQuery = String.format("INSERT INTO devices_groups (group_id, device_serial) " +
					"VALUES (%d, '%s')", groupId, serialNumber);
			execute(addPhoneQuery);
			log.debug("Added phone {} to group {}", serialNumber, groupName);
		}
	}

	public void removeDevicesFromGroup(String groupName, String ... serials) {
		String findIdQuery = String.format("SELECT id FROM groups WHERE active=true AND name='%s'", groupName);
		Long groupId = queryLong(findIdQuery, "id");
		for (String serialNumber : serials) {
			String removePhoneQuery = String.format("DELETE FROM devices_groups " +
					"WHERE device_serial='%s' " +
					"AND group_id=%d", serialNumber, groupId);
			execute(removePhoneQuery);
			log.debug("Removed phone {} from group {}", serialNumber, groupName);
		}
	}

	public String setupTestCertificate(String certPath, String certFile, String certFileName) {
		String expectedCertValue = null;
		try {
			byte[] array = Files
					.readAllBytes(new File(String.valueOf(Util.getResourceFile(certPath))).toPath());
			expectedCertValue = Base64.getEncoder().encodeToString(array);
			String query = String.format("INSERT INTO certificate " +
					"(name, certificate_type, user_name, certificate_file, certificate_file_name) " +
					" VALUES ('%s', 2, 'user', '%s', '%s')", certFile, expectedCertValue, certFileName);
			execute(query);
			log.debug("Added certificate {} to the database", certFile);
		} catch (FileNotFoundException fnfe) {
			log.error("Failed to find {}: {}", certPath, fnfe.getMessage());
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			log.error("Could not read {}: {}", certPath, ioe.getMessage());
			ioe.printStackTrace();
		}
		return expectedCertValue;
	}

	public void removeTestCertificate(String certName) {
		execute(String.format("DELETE FROM certificate WHERE name='%s'", certName));
		log.debug("Removed certificate {} from database", certName);
	}

	public void databaseReset() {
		clearTableCascade("groups");
		clearTableCascade("devices_groups");
		clearTableCascade("certificate");
		clearTableCascade("config");
		clearTableCascade("enterprise_config");
		clearTableCascade("extra");
		clearTableCascade("file_descriptor");
		clearTableCascade("filedescriptor_device");
		clearTableCascade("filedescriptor_enterprise");
		clearTableCascade("filedescriptor_group");
		clearTableCascade("group_config");
		clearTableCascade("sip_config");
		clearTableCascade("wireless_profiles");
	}

	public void clearGroupTables() {
		clearTableCascade("groups");
		clearTableCascade("devices_groups");
	}

	public void resetGroups() {
		clearTable("groups");
		log.debug("Deleted all groups");
	}

	public void resetDevices() {
		clearTable("config");
		log.debug("Deleted all devices");
	}

	public Map<String, Object> getPhoneInfo(String serialNumber) {
		String phoneQuery = String.format("SELECT * FROM devices WHERE device_serial = '%s'", serialNumber);
		Map<String, Object> phoneRecord = new HashMap<>();
		Iterator<HashMap<String, Object>> fields = query(phoneQuery);
		while (fields.hasNext()) {
			HashMap<String, Object> phoneField = fields.next();
			for (String key : phoneField.keySet()) {
				phoneRecord.put(key, phoneField.get(key));
			}
		}
		return phoneRecord;
	}

	public String getLastGroupName(String orderBy) {
		String query = String.format("SELECT name FROM groups WHERE active = 'TRUE' ORDER BY name %s LIMIT 1", orderBy);
		return queryString(query, "name");
	}

	public String getLastGroupDeviceSerials(String orderBy) {
		String query = String.format("SELECT array_agg(device_serial) AS device_serial " +
				"FROM devices_groups INNER JOIN groups ON devices_groups.group_id = groups.id " +
				"GROUP BY name ORDER BY device_serial %s LIMIT 1", orderBy);
		return queryStringNew(query, "device_serial").replace("{", "[").replace("}", "]");
	}

	public String getLastGroupUserName(String orderBy) {
		String query = String.format("SELECT user_name FROM groups WHERE active = 'TRUE' " +
				"ORDER BY user_name %s limit 1", orderBy);
		return queryString(query, "user_name");
	}

	public void approveAllDevices() {
		execute("UPDATE devices SET status = 1");
	}

	public void setPendingOnRejectedDevice(String serialNumber) {
		String query = "UPDATE devices SET status = 1 WHERE device_type = '2'";
		execute(query);
	}

	public Integer getDevicePendingCount() {
		String query = "SELECT count(*) as status FROM devices WHERE device_type = '2' AND status = '0'";
		return queryInteger(query,"status");
	}

	public Iterator<HashMap<String, Object>> getLicenseKey(String key) {
		return query(String.format("SELECT license_key FROM licenses WHERE license_key = '%s'", key));
	}

	public boolean doesLicenseExist(String key) {
		Iterator<HashMap<String, Object>> iter = query("SELECT license_key FROM licenses WHERE license_key = '" + key + "'");
		return iter.hasNext();
	}

	public boolean samLicenseExists(String serialNumber) {
		String sqlCommand = String.format("SELECT id FROM licenses WHERE serial_number = '%s'", serialNumber);
		Iterator<HashMap<String, Object>> iter = query(sqlCommand);
		return iter.hasNext();
	}

	public int deleteSamLicense(String serialNumber) {
		String sqlCommand = String.format("DELETE FROM licenses WHERE serial_number = '%s'", serialNumber);
		return update(sqlCommand);
	}

	public int deleteSamTestLicenses(String exceptionLicense) {
		String sqlCommand = String.format("DELETE FROM licenses WHERE serial_number <> '%s'", exceptionLicense);
		return update(sqlCommand);
	}

	public int insertSamLicense(String serialNumber, String licenseKey) {
		String sqlCommand = String.format("INSERT INTO licenses (license_key, serial_number) VALUES ('%s', '%s')", licenseKey, serialNumber);
		return update(sqlCommand);
	}

	public boolean isLicenseDuplicated(String key) {
		Iterator<HashMap<String, Object>> iter = query("SELECT license_key FROM licenses WHERE license_key = '" + key + "'");
		int count = 0;
		while (iter.hasNext()) {
			iter.next();
			count += 1;
		}
		return count > 1;
	}

	public String getCertificateFileName(String crtName) {
		String query = String.format("SELECT certificate_file_name FROM certificate WHERE name = '%s'", crtName);
		return queryString(query, "certificate_file_name");
	}

	public String getDeviceDisplayId(String deviceSerial) {
		String query = String.format("SELECT device_display_id FROM devices WHERE device_serial = '%s'", deviceSerial);
		return queryString(query,"device_display_id");
	}

	public Timestamp getLastHeartbeat(String serialNumber) {
		String query = String.format("SELECT last_heartbeat FROM devices WHERE device_serial = '%s'", serialNumber);
		return queryTime(query, "last_heartbeat");
	}

	public String getDeviceInfo1(String deviceSerial) {
		String query = String.format("SELECT device_info_1 FROM devices WHERE device_serial = '%s'", deviceSerial);
		return queryString(query, "device_info_1");
	}

	public String getDeviceInfo2(String deviceSerial) {
		String query = String.format("SELECT device_info_2 FROM devices WHERE device_serial = '%s'", deviceSerial);
		return queryString(query, "device_info_2");
	}

	public String getDeviceInfo3(String deviceSerial) {
		String query = String.format("SELECT device_info_3 FROM devices WHERE device_serial = '%s'", deviceSerial);
		return queryString(query, "device_info_3");
	}

	public String getDeviceInfo4(String deviceSerial) {
		String query = String.format("SELECT device_info_4 FROM devices WHERE device_serial = '%s'", deviceSerial);
		return queryString(query, "device_info_4");
	}

	public String getSipExtension(String deviceSerial) {
		String query = String.format("SELECT sip_extension FROM devices WHERE device_serial = '%s'", deviceSerial);
		return queryString(query, "sip_extension");
	}

	public String getSecondarySipExtension(String deviceSerial) {
		String query = String.format("SELECT secondary_sip_extension FROM devices WHERE device_serial = '%s'", deviceSerial);
		return queryString(query, "secondary_sip_extension");
	}

	public Long getLastCertificateId() {
		String query = "SELECT id FROM certificate ORDER BY id DESC LIMIT 1";
		return queryLong(query, "id");
	}

	public Map<String, Object> getLastCertificate() {
		String certificateQuery = "SELECT * FROM certificate ORDER BY id DESC LIMIT 1";
		Map<String, Object> lastRecord = new HashMap<>();
		Iterator<HashMap<String, Object>> fields = query(certificateQuery);
		while (fields.hasNext()) {
			HashMap<String, Object> certInfo = fields.next();
			for (String key : certInfo.keySet()) {
				lastRecord.put(key, certInfo.get(key));
			}
		}
		return lastRecord;
	}

	public Map<String, Object> getCertificate(Long id) {
		String query = String.format("SELECT * FROM certificate WHERE id = %d", id);
		Map<String, Object> lastRecord = new HashMap<>();
		Iterator<HashMap<String, Object>> fields = query(query);
		while (fields.hasNext()) {
			HashMap<String, Object> certInfo = fields.next();
			for (String key : certInfo.keySet()) {
				lastRecord.put(key, certInfo.get(key));
			}
		}
		return lastRecord;
	}

	public Iterator<HashMap<String, Object>> getExpectedWebApiEventUri(String serialNumber) {
		String getConfigQuery = String.format("SELECT * FROM " +
			"(SELECT cfg.config_value, row_number() " +
			"OVER (PARTITION BY cfg.config_uri ORDER BY cfg.default_config_id DESC, cfg.enterprise_config_id DESC, cfg.group_config_id DESC, cfg.id DESC) " +
			"FROM config as cfg " +
			"WHERE cfg.is_config_cleared = 'F' " +
			"AND cfg.device_serial = '%s' " +
			"AND cfg.config_uri= 'content:..settings.spectralink.web_api_event_urls') as configs " +
			"WHERE configs.row_number = 1", serialNumber);
		return query(getConfigQuery);
	}

	public Integer getDeviceStatus(String serialNumber) {
		return queryInteger("SELECT status FROM devices WHERE device_serial = '" + serialNumber + "'", "status");
	}

	public Long getDeviceRssi(String serialNumber) {
		String query = String.format("SELECT network_rssi FROM devices WHERE device_serial = '%s'", serialNumber);
		return queryLong(query, "network_rssi");
	}

	public String getCreateDate(String serialNumber) {
		String query = String.format("SELECT created FROM devices WHERE device_serial = '%s'", serialNumber);
		return queryTime(query, "created").toLocalDateTime().toLocalDate().toString();
	}

	public List<String> getGroupOrder() {
		List<String> groupOrder = new ArrayList<>();
		String groupsQuery = "SELECT name FROM groups WHERE active = TRUE ORDER BY priority";
		Iterator<HashMap<String, Object>> rows = query(groupsQuery);
		while (rows.hasNext()) {
			HashMap<String, Object> groupInfo = rows.next();
			groupOrder.add((String) groupInfo.get("name"));
		}
		return groupOrder;
	}

	public int getUnappliedUpdatesCount() {
		String query = "SELECT COUNT(*) AS unapplied FROM config WHERE is_applied = FALSE AND is_config_cleared = FALSE";
		return queryInteger(query, "unapplied");
	}

	public String getLastTriggerSetting(String phoneSerial) {
		String query = String.format("SELECT config_value FROM config WHERE device_serial = '%s' AND config_uri = 'content://com.spectralink.slnkota/string/preferences/ota_trigger_setting' ORDER BY id DESC LIMIT 1", phoneSerial);
		return queryString(query, "config_value");
	}

	public String getLastCopyConfigCategory() {
		String query = String.format("SELECT category FROM rma_log ORDER BY id DESC LIMIT 1");
		return queryString(query, "category");
	}

	public String getLastCopyConfigReason() {
		String query = String.format("SELECT reason FROM rma_log ORDER BY id DESC LIMIT 1");
		return queryString(query, "reason");
	}
}
