package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.AmieAgentStrings.*;

public class SamAmieAgentPage extends SamConfigurationPage {

	@FindBy(id = "amie_agent_enabled_label")
	private WebElement amieAgentEnabledLabel;

	@FindBy(id = "amie_agent_enabled")
	private WebElement amieAgentEnabledCheckbox;

	@FindBy(id = "delete_setting_amieAgentEnabled")
	private WebElement amieAgentEnabledDelete;

	@FindBy(id = "edit_setting_amieAgentEnabled")
	private WebElement amieAgentEnabledEdit;

	public ConfigPageField amieAgentEnabledField = new ConfigPageField(
			ENABLE_AMIE_AGENT,
			amieAgentEnabledLabel,
			amieAgentEnabledCheckbox,
			amieAgentEnabledDelete,
			amieAgentEnabledEdit
	);

	@FindBy(id = "amieAgent-cloud-endpointURL")
	private WebElement endpointTextbox;

	@FindBy(id = "delete_setting_amieEndPointURL")
	private WebElement endpointDelete;

	@FindBy(id = "edit_setting_amieEndPointURL")
	private WebElement endpointEdit;

	public ConfigPageField endpointField = new ConfigPageField(
			ENDPOINT_URL,
			endpointTextbox,
			endpointDelete,
			endpointEdit
	);

	@FindBy(xpath = "//label[@for=\"upload-over-lte\"]")
	private WebElement uploadOverLteLabel;

	@FindBy(id = "upload-over-lte")
	private WebElement uploadOverLteRadio;

	@FindBy(id = "delete_setting_amieUploadOverLte")
	private WebElement uploadOverLteDelete;

	@FindBy(id = "edit_setting_amieUploadOverLte")
	private WebElement uploadOverLteEdit;

	public ConfigPageField uploadOverLteField = new ConfigPageField(
			UPLOAD_OVER_METERED,
			uploadOverLteLabel,
			uploadOverLteRadio,
			uploadOverLteDelete,
			uploadOverLteEdit
	);

	@FindBy(xpath = "//label[@for=\"disable-upload-over-lte\"]")
	private WebElement disableUploadOverLteLabel;

	@FindBy(id = "disable-upload-over-lte")
	private WebElement disableUploadOverLteRadio;

	public ConfigPageField disableUploadOverLteField = new ConfigPageField(
			UPLOAD_OVER_METERED,
			disableUploadOverLteLabel,
			disableUploadOverLteRadio,
			uploadOverLteDelete,
			uploadOverLteEdit
	);

	@FindBy(id = "network-metrics-frequency")
	private WebElement networkFrequencyMenu;

	@FindBy(id = "delete_setting_amieNetworkMetricsFrequency")
	private WebElement networkFrequencyDelete;

	@FindBy(id = "edit_setting_amieNetworkMetricsFrequency")
	private WebElement networkFrequencyEdit;

	public ConfigPageField networkFrequencyField = new ConfigPageField(
			NETWORK_FREQUENCY,
			networkFrequencyMenu,
			networkFrequencyDelete,
			networkFrequencyEdit
	);

	@FindBy(id = "device-metrics-frequency")
	private WebElement deviceFrequencyMenu;

	@FindBy(id = "delete_setting_amieDeviceMetricsFrequency")
	private WebElement deviceFrequencyDelete;

	@FindBy(id = "edit_setting_amieDeviceMetricsFrequency")
	private WebElement deviceFrequencyEdit;

	public ConfigPageField deviceFrequencyField = new ConfigPageField(
			DEVICE_FREQUENCY,
			deviceFrequencyMenu,
			deviceFrequencyDelete,
			deviceFrequencyEdit
	);

	@FindBy(id = "battery-metrics-frequency")
	private WebElement batteryFrequencyMenu;

	@FindBy(id = "delete_setting_amieBatteryMetricsFrequency")
	private WebElement batteryFrequencyDelete;

	@FindBy(id = "edit_setting_amieBatteryMetricsFrequency")
	private WebElement batteryFrequencyEdit;

	public ConfigPageField batteryFrequencyField = new ConfigPageField(
			BATTERY_FREQUENCY,
			batteryFrequencyMenu,
			batteryFrequencyDelete,
			batteryFrequencyEdit
	);

	@FindBy(id = "custom-cert")
	private WebElement certificateTextbox;

	@FindBy(id = "delete_setting_amieCustomCert")
	private WebElement certificateDelete;

	@FindBy(id = "edit_setting_amieCustomCert")
	private WebElement certificateEdit;

	public ConfigPageField certificateField = new ConfigPageField(
			MQTTS_CERTIFICATE,
			certificateTextbox,
			certificateDelete,
			certificateEdit
	);

	@FindBy(id = "max_rows")
	private WebElement bufferSizeTextbox;

	@FindBy(id = "delete_setting_amieBufferSize")
	private WebElement bufferSizeDelete;

	@FindBy(id = "edit_setting_amieBufferSize")
	private WebElement bufferSizeEdit;

	public ConfigPageField bufferSizeField = new ConfigPageField(
			BUFFER_SIZE,
			bufferSizeTextbox,
			bufferSizeDelete,
			bufferSizeEdit
	);

	public SamAmieAgentPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(amieAgentEnabledField.getTitle(), amieAgentEnabledField);
				put(endpointField.getTitle(), endpointField);
				put(uploadOverLteField.getTitle(), uploadOverLteField);
				put("allow" + uploadOverLteField.getTitle(), uploadOverLteField);
				put("disallow" + disableUploadOverLteField.getTitle(), disableUploadOverLteField);
				put(networkFrequencyField.getTitle(), networkFrequencyField);
				put(deviceFrequencyField.getTitle(), deviceFrequencyField);
				put(batteryFrequencyField.getTitle(), batteryFrequencyField);
				put(certificateField.getTitle(), certificateField);
				put(bufferSizeField.getTitle(), bufferSizeField);
			}
		};
	}
}
