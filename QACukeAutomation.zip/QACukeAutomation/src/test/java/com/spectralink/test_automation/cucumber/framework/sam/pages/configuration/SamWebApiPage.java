package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.WebApiStrings.*;

public class SamWebApiPage extends SamConfigurationPage {

	@FindBy(className = "md-tab")
	private List<WebElement> tabs;

	@FindBy(id = "add_more_web_api")
	private WebElement addApiEventButton;

	@FindBy(id = "remove_dynamic_web_api")
	private WebElement removeApiEventButton;

	@FindBy(id = "add_more_apollo-web-app")
	private WebElement addWebAppButton;

	@FindBy(id = "remove_dynamic_apollo-web-app")
	private WebElement removeWebAppButton;

	@FindBy(id = "loadnewconfigsettings")
	private WebElement reloadPageLink;

	@FindBy(xpath = "//button[@ng-click=\"ok()\"]")
	private WebElement reloadOkButton;


	@FindBy(id = "web_api_enable_disable_label")
	private WebElement enableWebApiLabel;

	@FindBy(id = "web_api_enable_disable")
	private WebElement enableWebApiCheckbox;

	@FindBy(id = "edit_setting_webApiEnableDisable")
	private WebElement enableWebApiEdit;

	@FindBy(id = "delete_setting_webApiEnableDisable")
	private WebElement enableWebApiDelete;

	public ConfigPageField enableWebApiField = new ConfigPageField(
			ENABLE_WEBAPI,
			enableWebApiLabel,
			enableWebApiCheckbox,
			enableWebApiDelete,
			enableWebApiEdit
	);

	@FindBy(id = "webApi_format_type")
	private WebElement webApiFormatMenu;

	@FindBy(id = "delete_setting_webApiFormatType")
	private WebElement webApiFormatDelete;

	@FindBy(id = "edit_setting_webApiFormatType")
	private WebElement webApiFormatEdit;

	public ConfigPageField webApiFormatField = new ConfigPageField(
			DATA_FORMAT,
			webApiFormatMenu,
			webApiFormatDelete,
			webApiFormatEdit
	);

	@FindBy(id = "webApi_polling_username")
	private WebElement pollingUserNameTextbox;

	@FindBy(id = "delete_setting_webApiPollingUsername")
	private WebElement pollingUserNameDelete;

	@FindBy(id = "edit_setting_webApiPollingUsername")
	private WebElement pollingUserNameEdit;

	public ConfigPageField pollingUserNameField = new ConfigPageField(
			POLL_USERNAME,
			pollingUserNameTextbox,
			pollingUserNameDelete,
			pollingUserNameEdit
	);

	@FindBy(id = "webApiPollingPassword")
	private WebElement pollingPasswordTextbox;

	@FindBy(id = "delete_setting_webApiPollingPassword")
	private WebElement pollingPasswordDelete;

	@FindBy(id = "edit_setting_webApiPollingPassword")
	private WebElement pollingPasswordEdit;

	public ConfigPageField pollingPasswordField = new ConfigPageField(
			POLL_PASSWORD,
			pollingPasswordTextbox,
			pollingPasswordDelete,
			pollingPasswordEdit
	);

	@FindBy(xpath = "//label[@for='show-pooling-password-checkbox']")
	private WebElement pollingShowPasswordLabel;

	@FindBy(id = "show-pooling-password-checkbox")
	private WebElement pollingShowPasswordCheckbox;

	public ConfigPageField pollingShowPasswordField = new ConfigPageField(
			POLL_SHOW_PASSWORD,
			pollingShowPasswordLabel,
			pollingShowPasswordCheckbox,
			null,
			null
	);

	@FindBy(id = "pollingRespondMethod")
	private WebElement pollingRespondMethodMenu;

	@FindBy(id = "delete_setting_pollingRespondMethod")
	private WebElement pollingRespondMethodDelete;

	@FindBy(id = "edit_setting_pollingRespondMethod")
	private WebElement pollingRespondMethodEdit;

	public ConfigPageField pollingRespondMethodField = new ConfigPageField(
			POLL_RESPONSE,
			pollingRespondMethodMenu,
			pollingRespondMethodDelete,
			pollingRespondMethodEdit
	);

	@FindBy(id = "pollingUrlToRespond")
	private WebElement pollingUrlToRespondTextbox;

	@FindBy(id = "delete_setting_pollingUrlToRespond")
	private WebElement pollingUrlToRespondDelete;

	@FindBy(id = "edit_setting_pollingUrlToRespond")
	private WebElement pollingUrlToRespondEdit;

	public ConfigPageField pollingUrlReceiveResponseField = new ConfigPageField(
			POLL_RESPONSE_URL,
			pollingUrlToRespondTextbox,
			pollingUrlToRespondDelete,
			pollingUrlToRespondEdit
	);

	@FindBy(id = "webApiPushUsername")
	private WebElement pushUserNameTextbox;

	@FindBy(id = "delete_setting_webApiPushUsername")
	private WebElement pushUserNameDelete;

	@FindBy(id = "edit_setting_webApiPushUsername")
	private WebElement pushUserNameEdit;

	public ConfigPageField pushUserNameField = new ConfigPageField(
			PUSH_USERNAME,
			pushUserNameTextbox,
			pushUserNameDelete,
			pushUserNameEdit
	);

	@FindBy(id = "webApiPushPassword")
	private WebElement pushPasswordTextbox;

	@FindBy(id = "delete_setting_webApiPushPassword")
	private WebElement pushPasswordDelete;

	@FindBy(id = "edit_setting_webApiPushPassword")
	private WebElement pushPasswordEdit;

	public ConfigPageField pushPasswordField = new ConfigPageField(
			PUSH_PASSWORD,
			pushPasswordTextbox,
			pushPasswordDelete,
			pushPasswordEdit
	);

	@FindBy(xpath = "//label[@for='show-password-checkbox1']")
	private WebElement pushShowPasswordLabel;

	@FindBy(id = "show-password-checkbox1")
	private WebElement pushShowPasswordCheckbox;

	public ConfigPageField pushShowPasswordField = new ConfigPageField(
			PUSH_SHOW_PASSWORD,
			pushShowPasswordLabel,
			pushShowPasswordCheckbox,
			null,
			null
	);

	@FindBy(id = "pushMessagePriority")
	private WebElement allowMessagePriorityMenu;

	@FindBy(id = "delete_setting_pushMessagePriority")
	private WebElement allowMessagePriorityDelete;

	@FindBy(id = "edit_setting_pushMessagePriority")
	private WebElement allowMessagePriorityEdit;

	public ConfigPageField allowMessagePriorityField = new ConfigPageField(
			PUSH_ALERT_PRIORITY,
			allowMessagePriorityMenu,
			allowMessagePriorityDelete,
			allowMessagePriorityEdit
	);

	@FindBy(xpath = "//label[@for='enable_pushNotificationRingtoneEnable']")
	private WebElement pushRingToneEnableLabel;

	@FindBy(id = "enable_pushNotificationRingtoneEnable")
	private WebElement pushRingToneEnableRadio;

	@FindBy(id = "delete_setting_pushNotificationRingtoneEnable")
	private WebElement pushRingToneDelete;

	@FindBy(id = "edit_setting_pushNotificationRingtoneEnable")
	private WebElement pushRingToneEdit;

	public ConfigPageField pushRingToneEnableField = new ConfigPageField(
			PUSH_NOTIFICATION_RINGTONE,
			pushRingToneEnableLabel,
			pushRingToneEnableRadio,
			pushRingToneDelete,
			pushRingToneEdit
	);

	@FindBy(xpath = "//label[@for='disable_pushNotificationRingtoneEnable']")
	private WebElement pushRingToneDisableLabel;

	@FindBy(id = "disable_pushNotificationRingtoneEnable")
	private WebElement pushRingToneDisableRadio;

	public ConfigPageField pushRingToneDisableField = new ConfigPageField(
			PUSH_NOTIFICATION_RINGTONE,
			pushRingToneDisableLabel,
			pushRingToneDisableRadio,
			pushRingToneDelete,
			pushRingToneEdit
	);

	@FindBy(id = "webApiPushRingtoneVolumeOutput")
	private WebElement ringtoneVolumeValue;

	@FindBy(id = "webApiPushRingtoneVolume")
	private WebElement ringtoneVolumeSlider;

	@FindBy(id = "delete_setting_webApiPushRingtoneVolume")
	private WebElement ringtoneVolumeDelete;

	@FindBy(id = "edit_setting_webApiPushRingtoneVolume")
	private WebElement ringtoneVolumeEdit;

	public ConfigPageField ringtoneVolumeField = new ConfigPageField(
			PUSH_RINGTONE_VOLUME,
			ringtoneVolumeSlider,
			ringtoneVolumeDelete,
			ringtoneVolumeEdit
	);

	@FindBy(id = "pushServerRootUrl")
	private WebElement pushServerRootUrlTextbox;

	@FindBy(id = "delete_setting_pushServerRootUrl")
	private WebElement pushServerRootUrlDelete;

	@FindBy(id = "edit_setting_pushServerRootUrl")
	private WebElement pushServerRootUrlEdit;

	public ConfigPageField pushServerRootUrlField = new ConfigPageField(
			PUSH_SERVER_ROOT,
			pushServerRootUrlTextbox,
			pushServerRootUrlDelete,
			pushServerRootUrlEdit
	);


	// event URI 1

	@FindBy(id = "webApiEventUrls_EventLabel_0")
	private WebElement event1LabelTextbox;

	@FindBy(id = "delete_setting_webApiEventUrls")
	private WebElement eventUrlsDelete;

	@FindBy(id = "edit_setting_webApiEventUrls")
	private WebElement eventUrlsEdit;

	public ConfigPageField event1LabelField = new ConfigPageField(
			EVENT_1_LABEL,
			event1LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_0")
	private WebElement event1UrlTextbox;

	public ConfigPageField event1UrlField = new ConfigPageField(
			EVENT_1_URL,
			event1UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_none']")
	private WebElement event1NoneLabel;

	@FindBy(id = "event_settings_0_none")
	private WebElement event1NoneCheckbox;

	public ConfigPageField event1NoneField = new ConfigPageField(
			EVENT_1_NONE,
			event1NoneLabel,
			event1NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_all']")
	private WebElement event1AllLabel;

	@FindBy(id = "event_settings_0_all")
	private WebElement event1AllCheckbox;

	public ConfigPageField event1AllField = new ConfigPageField(
			EVENT_1_ALL,
			event1AllLabel,
			event1AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_statechange']")
	private WebElement event1StateChangeLabel;

	@FindBy(id = "event_settings_0_statechange")
	private WebElement event1StateChangeCheckbox;

	public ConfigPageField event1StateChangeField = new ConfigPageField(
			EVENT_1_STATE,
			event1StateChangeLabel,
			event1StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_incoming']")
	private WebElement event1IncomingLabel;

	@FindBy(id = "event_settings_0_incoming")
	private WebElement event1IncomingCheckbox;

	public ConfigPageField event1IncomingField = new ConfigPageField(
			EVENT_1_INCOMING,
			event1IncomingLabel,
			event1IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_registration']")
	private WebElement event1RegistrationLabel;

	@FindBy(id = "event_settings_0_registration")
	private WebElement event1RegistrationCheckbox;

	public ConfigPageField event1RegistrationField = new ConfigPageField(
			EVENT_1_REGISTRATION,
			event1RegistrationLabel,
			event1RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_unregistration']")
	private WebElement event1UnregistrationLabel;

	@FindBy(id = "event_settings_0_unregistration")
	private WebElement event1UnregistrationCheckbox;

	public ConfigPageField event1UnregistrationField = new ConfigPageField(
			EVENT_1_UNREGISTRATION,
			event1UnregistrationLabel,
			event1UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_offhook']")
	private WebElement event1OffHookLabel;

	@FindBy(id = "event_settings_0_offhook")
	private WebElement event1OffHookCheckbox;

	public ConfigPageField event1OffHookField = new ConfigPageField(
			EVENT_1_OFF_HOOK,
			event1OffHookLabel,
			event1OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_onhook']")
	private WebElement event1OnHookLabel;

	@FindBy(id = "event_settings_0_onhook")
	private WebElement event1OnHookCheckbox;

	public ConfigPageField event1OnHookField = new ConfigPageField(
			EVENT_1_ON_HOOK,
			event1OnHookLabel,
			event1OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_outgoing']")
	private WebElement event1OutgoingLabel;

	@FindBy(id = "event_settings_0_outgoing")
	private WebElement event1OutgoingCheckbox;

	public ConfigPageField event1OutgoingField = new ConfigPageField(
			EVENT_1_OUTGOING,
			event1OutgoingLabel,
			event1OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_userlogin']")
	private WebElement event1UserLoginLabel;

	@FindBy(id = "event_settings_0_userlogin")
	private WebElement event1UserLoginCheckbox;

	public ConfigPageField event1UserLoginField = new ConfigPageField(
			EVENT_1_LOGIN,
			event1UserLoginLabel,
			event1UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_0_safealarm']")
	private WebElement event1SafeAlarmLabel;

	@FindBy(id = "event_settings_0_safealarm")
	private WebElement event1SafeAlarmCheckbox;

	public ConfigPageField event1SafeAlarmField = new ConfigPageField(
			EVENT_1_SAFE_ALARM,
			event1SafeAlarmLabel,
			event1SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 2

	@FindBy(id = "webApiEventUrls_EventLabel_1")
	private WebElement event2LabelTextbox;

	public ConfigPageField event2LabelField = new ConfigPageField(
			EVENT_2_LABEL,
			event2LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_1")
	private WebElement event2UrlTextbox;

	public ConfigPageField event2UrlField = new ConfigPageField(
			EVENT_2_URL,
			event2UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_none']")
	private WebElement event2NoneLabel;

	@FindBy(id = "event_settings_1_none")
	private WebElement event2NoneCheckbox;

	public ConfigPageField event2NoneField = new ConfigPageField(
			EVENT_2_NONE,
			event2NoneLabel,
			event2NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_all']")
	private WebElement event2AllLabel;

	@FindBy(id = "event_settings_1_all")
	private WebElement event2AllCheckbox;

	public ConfigPageField event2AllField = new ConfigPageField(
			EVENT_2_ALL,
			event2AllLabel,
			event2AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_statechange']")
	private WebElement event2StateChangeLabel;

	@FindBy(id = "event_settings_1_statechange")
	private WebElement event2StateChangeCheckbox;

	public ConfigPageField event2StateChangeField = new ConfigPageField(
			EVENT_2_STATE,
			event2StateChangeLabel,
			event2StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_incoming']")
	private WebElement event2IncomingLabel;

	@FindBy(id = "event_settings_1_incoming")
	private WebElement event2IncomingCheckbox;

	public ConfigPageField event2IncomingField = new ConfigPageField(
			EVENT_2_INCOMING,
			event2IncomingLabel,
			event2IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_registration']")
	private WebElement event2RegistrationLabel;

	@FindBy(id = "event_settings_1_registration")
	private WebElement event2RegistrationCheckbox;

	public ConfigPageField event2RegistrationField = new ConfigPageField(
			EVENT_2_REGISTRATION,
			event2RegistrationLabel,
			event2RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_unregistration']")
	private WebElement event2UnregistrationLabel;

	@FindBy(id = "event_settings_1_unregistration")
	private WebElement event2UnregistrationCheckbox;

	public ConfigPageField event2UnregistrationField = new ConfigPageField(
			EVENT_2_UNREGISTRATION,
			event2UnregistrationLabel,
			event2UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_offhook']")
	private WebElement event2OffHookLabel;

	@FindBy(id = "event_settings_1_offhook")
	private WebElement event2OffHookCheckbox;

	public ConfigPageField event2OffHookField = new ConfigPageField(
			EVENT_2_OFF_HOOK,
			event2OffHookLabel,
			event2OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_onhook']")
	private WebElement event2OnHookLabel;

	@FindBy(id = "event_settings_1_onhook")
	private WebElement event2OnHookCheckbox;

	public ConfigPageField event2OnHookField = new ConfigPageField(
			EVENT_2_ON_HOOK,
			event2OnHookLabel,
			event2OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_outgoing']")
	private WebElement event2OutgoingLabel;

	@FindBy(id = "event_settings_1_outgoing")
	private WebElement event2OutgoingCheckbox;

	public ConfigPageField event2OutgoingField = new ConfigPageField(
			EVENT_2_OUTGOING,
			event2OutgoingLabel,
			event2OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_userlogin']")
	private WebElement event2UserLoginLabel;

	@FindBy(id = "event_settings_1_userlogin")
	private WebElement event2UserLoginCheckbox;

	public ConfigPageField event2UserLoginField = new ConfigPageField(
			EVENT_2_LOGIN,
			event2UserLoginLabel,
			event2UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_1_safealarm']")
	private WebElement event2SafeAlarmLabel;

	@FindBy(id = "event_settings_1_safealarm")
	private WebElement event2SafeAlarmCheckbox;

	public ConfigPageField event2SafeAlarmField = new ConfigPageField(
			EVENT_2_SAFE_ALARM,
			event2SafeAlarmLabel,
			event2SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 3

	@FindBy(id = "webApiEventUrls_EventLabel_2")
	private WebElement event3LabelTextbox;

	public ConfigPageField event3LabelField = new ConfigPageField(
			EVENT_3_LABEL,
			event3LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_2")
	private WebElement event3UrlTextbox;

	public ConfigPageField event3UrlField = new ConfigPageField(
			EVENT_3_URL,
			event3UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_none']")
	private WebElement event3NoneLabel;

	@FindBy(id = "event_settings_2_none")
	private WebElement event3NoneCheckbox;

	public ConfigPageField event3NoneField = new ConfigPageField(
			EVENT_3_NONE,
			event3NoneLabel,
			event3NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_all']")
	private WebElement event3AllLabel;

	@FindBy(id = "event_settings_2_all")
	private WebElement event3AllCheckbox;

	public ConfigPageField event3AllField = new ConfigPageField(
			EVENT_3_ALL,
			event3AllLabel,
			event3AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_statechange']")
	private WebElement event3StateChangeLabel;

	@FindBy(id = "event_settings_2_statechange")
	private WebElement event3StateChangeCheckbox;

	public ConfigPageField event3StateChangeField = new ConfigPageField(
			EVENT_3_STATE,
			event3StateChangeLabel,
			event3StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_incoming']")
	private WebElement event3IncomingLabel;

	@FindBy(id = "event_settings_2_incoming")
	private WebElement event3IncomingCheckbox;

	public ConfigPageField event3IncomingField = new ConfigPageField(
			EVENT_3_INCOMING,
			event3IncomingLabel,
			event3IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_registration']")
	private WebElement event3RegistrationLabel;

	@FindBy(id = "event_settings_2_registration")
	private WebElement event3RegistrationCheckbox;

	public ConfigPageField event3RegistrationField = new ConfigPageField(
			EVENT_3_REGISTRATION,
			event3RegistrationLabel,
			event3RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_unregistration']")
	private WebElement event3UnregistrationLabel;

	@FindBy(id = "event_settings_2_unregistration")
	private WebElement event3UnregistrationCheckbox;

	public ConfigPageField event3UnregistrationField = new ConfigPageField(
			EVENT_3_UNREGISTRATION,
			event3UnregistrationLabel,
			event3UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_offhook']")
	private WebElement event3OffHookLabel;

	@FindBy(id = "event_settings_2_offhook")
	private WebElement event3OffHookCheckbox;

	public ConfigPageField event3OffHookField = new ConfigPageField(
			EVENT_3_OFF_HOOK,
			event3OffHookLabel,
			event3OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_onhook']")
	private WebElement event3OnHookLabel;

	@FindBy(id = "event_settings_2_onhook")
	private WebElement event3OnHookCheckbox;

	public ConfigPageField event3OnHookField = new ConfigPageField(
			EVENT_3_ON_HOOK,
			event3OnHookLabel,
			event3OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_outgoing']")
	private WebElement event3OutgoingLabel;

	@FindBy(id = "event_settings_2_outgoing")
	private WebElement event3OutgoingCheckbox;

	public ConfigPageField event3OutgoingField = new ConfigPageField(
			EVENT_3_OUTGOING,
			event3OutgoingLabel,
			event3OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_userlogin']")
	private WebElement event3UserLoginLabel;

	@FindBy(id = "event_settings_2_userlogin")
	private WebElement event3UserLoginCheckbox;

	public ConfigPageField event3UserLoginField = new ConfigPageField(
			EVENT_3_LOGIN,
			event3UserLoginLabel,
			event3UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_2_safealarm']")
	private WebElement event3SafeAlarmLabel;

	@FindBy(id = "event_settings_2_safealarm")
	private WebElement event3SafeAlarmCheckbox;

	public ConfigPageField event3SafeAlarmField = new ConfigPageField(
			EVENT_3_SAFE_ALARM,
			event3SafeAlarmLabel,
			event3SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 4

	@FindBy(id = "webApiEventUrls_EventLabel_3")
	private WebElement event4LabelTextbox;

	public ConfigPageField event4LabelField = new ConfigPageField(
			EVENT_4_LABEL,
			event4LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_3")
	private WebElement event4UrlTextbox;

	public ConfigPageField event4UrlField = new ConfigPageField(
			EVENT_4_URL,
			event4UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_none']")
	private WebElement event4NoneLabel;

	@FindBy(id = "event_settings_3_none")
	private WebElement event4NoneCheckbox;

	public ConfigPageField event4NoneField = new ConfigPageField(
			EVENT_4_NONE,
			event4NoneLabel,
			event4NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_all']")
	private WebElement event4AllLabel;

	@FindBy(id = "event_settings_3_all")
	private WebElement event4AllCheckbox;

	public ConfigPageField event4AllField = new ConfigPageField(
			EVENT_4_ALL,
			event4AllLabel,
			event4AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_statechange']")
	private WebElement event4StateChangeLabel;

	@FindBy(id = "event_settings_3_statechange")
	private WebElement event4StateChangeCheckbox;

	public ConfigPageField event4StateChangeField = new ConfigPageField(
			EVENT_4_STATE,
			event4StateChangeLabel,
			event4StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_incoming']")
	private WebElement event4IncomingLabel;

	@FindBy(id = "event_settings_3_incoming")
	private WebElement event4IncomingCheckbox;

	public ConfigPageField event4IncomingField = new ConfigPageField(
			EVENT_4_INCOMING,
			event4IncomingLabel,
			event4IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_registration']")
	private WebElement event4RegistrationLabel;

	@FindBy(id = "event_settings_3_registration")
	private WebElement event4RegistrationCheckbox;

	public ConfigPageField event4RegistrationField = new ConfigPageField(
			EVENT_4_REGISTRATION,
			event4RegistrationLabel,
			event4RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_unregistration']")
	private WebElement event4UnregistrationLabel;

	@FindBy(id = "event_settings_3_unregistration")
	private WebElement event4UnregistrationCheckbox;

	public ConfigPageField event4UnregistrationField = new ConfigPageField(
			EVENT_4_UNREGISTRATION,
			event4UnregistrationLabel,
			event4UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_offhook']")
	private WebElement event4OffHookLabel;

	@FindBy(id = "event_settings_3_offhook")
	private WebElement event4OffHookCheckbox;

	public ConfigPageField event4OffHookField = new ConfigPageField(
			EVENT_4_OFF_HOOK,
			event4OffHookLabel,
			event4OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_onhook']")
	private WebElement event4OnHookLabel;

	@FindBy(id = "event_settings_3_onhook")
	private WebElement event4OnHookCheckbox;

	public ConfigPageField event4OnHookField = new ConfigPageField(
			EVENT_4_ON_HOOK,
			event4OnHookLabel,
			event4OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_outgoing']")
	private WebElement event4OutgoingLabel;

	@FindBy(id = "event_settings_3_outgoing")
	private WebElement event4OutgoingCheckbox;

	public ConfigPageField event4OutgoingField = new ConfigPageField(
			EVENT_4_OUTGOING,
			event4OutgoingLabel,
			event4OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_userlogin']")
	private WebElement event4UserLoginLabel;

	@FindBy(id = "event_settings_3_userlogin")
	private WebElement event4UserLoginCheckbox;

	public ConfigPageField event4UserLoginField = new ConfigPageField(
			EVENT_4_LOGIN,
			event4UserLoginLabel,
			event4UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_3_safealarm']")
	private WebElement event4SafeAlarmLabel;

	@FindBy(id = "event_settings_3_safealarm")
	private WebElement event4SafeAlarmCheckbox;

	public ConfigPageField event4SafeAlarmField = new ConfigPageField(
			EVENT_4_SAFE_ALARM,
			event4SafeAlarmLabel,
			event4SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 5

	@FindBy(id = "webApiEventUrls_EventLabel_4")
	private WebElement event5LabelTextbox;

	public ConfigPageField event5LabelField = new ConfigPageField(
			EVENT_5_LABEL,
			event5LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_4")
	private WebElement event5UrlTextbox;

	public ConfigPageField event5UrlField = new ConfigPageField(
			EVENT_5_URL,
			event5UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_none']")
	private WebElement event5NoneLabel;

	@FindBy(id = "event_settings_4_none")
	private WebElement event5NoneCheckbox;

	public ConfigPageField event5NoneField = new ConfigPageField(
			EVENT_5_NONE,
			event5NoneLabel,
			event5NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_all']")
	private WebElement event5AllLabel;

	@FindBy(id = "event_settings_4_all")
	private WebElement event5AllCheckbox;

	public ConfigPageField event5AllField = new ConfigPageField(
			EVENT_5_ALL,
			event5AllLabel,
			event5AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_statechange']")
	private WebElement event5StateChangeLabel;

	@FindBy(id = "event_settings_4_statechange")
	private WebElement event5StateChangeCheckbox;

	public ConfigPageField event5StateChangeField = new ConfigPageField(
			EVENT_5_STATE,
			event5StateChangeLabel,
			event5StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_incoming']")
	private WebElement event5IncomingLabel;

	@FindBy(id = "event_settings_4_incoming")
	private WebElement event5IncomingCheckbox;

	public ConfigPageField event5IncomingField = new ConfigPageField(
			EVENT_5_INCOMING,
			event5IncomingLabel,
			event5IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_registration']")
	private WebElement event5RegistrationLabel;

	@FindBy(id = "event_settings_4_registration")
	private WebElement event5RegistrationCheckbox;

	public ConfigPageField event5RegistrationField = new ConfigPageField(
			EVENT_5_REGISTRATION,
			event5RegistrationLabel,
			event5RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_unregistration']")
	private WebElement event5UnregistrationLabel;

	@FindBy(id = "event_settings_4_unregistration")
	private WebElement event5UnregistrationCheckbox;

	public ConfigPageField event5UnregistrationField = new ConfigPageField(
			EVENT_5_UNREGISTRATION,
			event5UnregistrationLabel,
			event5UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_offhook']")
	private WebElement event5OffHookLabel;

	@FindBy(id = "event_settings_4_offhook")
	private WebElement event5OffHookCheckbox;

	public ConfigPageField event5OffHookField = new ConfigPageField(
			EVENT_5_OFF_HOOK,
			event5OffHookLabel,
			event5OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_onhook']")
	private WebElement event5OnHookLabel;

	@FindBy(id = "event_settings_4_onhook")
	private WebElement event5OnHookCheckbox;

	public ConfigPageField event5OnHookField = new ConfigPageField(
			EVENT_5_ON_HOOK,
			event5OnHookLabel,
			event5OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_outgoing']")
	private WebElement event5OutgoingLabel;

	@FindBy(id = "event_settings_4_outgoing")
	private WebElement event5OutgoingCheckbox;

	public ConfigPageField event5OutgoingField = new ConfigPageField(
			EVENT_5_OUTGOING,
			event5OutgoingLabel,
			event5OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_userlogin']")
	private WebElement event5UserLoginLabel;

	@FindBy(id = "event_settings_4_userlogin")
	private WebElement event5UserLoginCheckbox;

	public ConfigPageField event5UserLoginField = new ConfigPageField(
			EVENT_5_LOGIN,
			event5UserLoginLabel,
			event5UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_4_safealarm']")
	private WebElement event5SafeAlarmLabel;

	@FindBy(id = "event_settings_4_safealarm")
	private WebElement event5SafeAlarmCheckbox;

	public ConfigPageField event5SafeAlarmField = new ConfigPageField(
			EVENT_5_SAFE_ALARM,
			event5SafeAlarmLabel,
			event5SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 6

	@FindBy(id = "webApiEventUrls_EventLabel_5")
	private WebElement event6LabelTextbox;

	public ConfigPageField event6LabelField = new ConfigPageField(
			EVENT_6_LABEL,
			event6LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_5")
	private WebElement event6UrlTextbox;

	public ConfigPageField event6UrlField = new ConfigPageField(
			EVENT_6_URL,
			event6UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_none']")
	private WebElement event6NoneLabel;

	@FindBy(id = "event_settings_5_none")
	private WebElement event6NoneCheckbox;

	public ConfigPageField event6NoneField = new ConfigPageField(
			EVENT_6_NONE,
			event6NoneLabel,
			event6NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_all']")
	private WebElement event6AllLabel;

	@FindBy(id = "event_settings_5_all")
	private WebElement event6AllCheckbox;

	public ConfigPageField event6AllField = new ConfigPageField(
			EVENT_6_ALL,
			event6AllLabel,
			event6AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_statechange']")
	private WebElement event6StateChangeLabel;

	@FindBy(id = "event_settings_5_statechange")
	private WebElement event6StateChangeCheckbox;

	public ConfigPageField event6StateChangeField = new ConfigPageField(
			EVENT_6_STATE,
			event6StateChangeLabel,
			event6StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_incoming']")
	private WebElement event6IncomingLabel;

	@FindBy(id = "event_settings_5_incoming")
	private WebElement event6IncomingCheckbox;

	public ConfigPageField event6IncomingField = new ConfigPageField(
			EVENT_6_INCOMING,
			event6IncomingLabel,
			event6IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_registration']")
	private WebElement event6RegistrationLabel;

	@FindBy(id = "event_settings_5_registration")
	private WebElement event6RegistrationCheckbox;

	public ConfigPageField event6RegistrationField = new ConfigPageField(
			EVENT_6_REGISTRATION,
			event6RegistrationLabel,
			event6RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_unregistration']")
	private WebElement event6UnregistrationLabel;

	@FindBy(id = "event_settings_5_unregistration")
	private WebElement event6UnregistrationCheckbox;

	public ConfigPageField event6UnregistrationField = new ConfigPageField(
			EVENT_6_UNREGISTRATION,
			event6UnregistrationLabel,
			event6UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_offhook']")
	private WebElement event6OffHookLabel;

	@FindBy(id = "event_settings_5_offhook")
	private WebElement event6OffHookCheckbox;

	public ConfigPageField event6OffHookField = new ConfigPageField(
			EVENT_6_OFF_HOOK,
			event6OffHookLabel,
			event6OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_onhook']")
	private WebElement event6OnHookLabel;

	@FindBy(id = "event_settings_5_onhook")
	private WebElement event6OnHookCheckbox;

	public ConfigPageField event6OnHookField = new ConfigPageField(
			EVENT_6_ON_HOOK,
			event6OnHookLabel,
			event6OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_outgoing']")
	private WebElement event6OutgoingLabel;

	@FindBy(id = "event_settings_5_outgoing")
	private WebElement event6OutgoingCheckbox;

	public ConfigPageField event6OutgoingField = new ConfigPageField(
			EVENT_6_OUTGOING,
			event6OutgoingLabel,
			event6OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_userlogin']")
	private WebElement event6UserLoginLabel;

	@FindBy(id = "event_settings_5_userlogin")
	private WebElement event6UserLoginCheckbox;

	public ConfigPageField event6UserLoginField = new ConfigPageField(
			EVENT_6_LOGIN,
			event6UserLoginLabel,
			event6UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_5_safealarm']")
	private WebElement event6SafeAlarmLabel;

	@FindBy(id = "event_settings_5_safealarm")
	private WebElement event6SafeAlarmCheckbox;

	public ConfigPageField event6SafeAlarmField = new ConfigPageField(
			EVENT_6_SAFE_ALARM,
			event6SafeAlarmLabel,
			event6SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 7

	@FindBy(id = "webApiEventUrls_EventLabel_6")
	private WebElement event7LabelTextbox;

	public ConfigPageField event7LabelField = new ConfigPageField(
			EVENT_7_LABEL,
			event7LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_6")
	private WebElement event7UrlTextbox;

	public ConfigPageField event7UrlField = new ConfigPageField(
			EVENT_7_URL,
			event7UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_none']")
	private WebElement event7NoneLabel;

	@FindBy(id = "event_settings_6_none")
	private WebElement event7NoneCheckbox;

	public ConfigPageField event7NoneField = new ConfigPageField(
			EVENT_7_NONE,
			event7NoneLabel,
			event7NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_all']")
	private WebElement event7AllLabel;

	@FindBy(id = "event_settings_6_all")
	private WebElement event7AllCheckbox;

	public ConfigPageField event7AllField = new ConfigPageField(
			EVENT_7_ALL,
			event7AllLabel,
			event7AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_statechange']")
	private WebElement event7StateChangeLabel;

	@FindBy(id = "event_settings_6_statechange")
	private WebElement event7StateChangeCheckbox;

	public ConfigPageField event7StateChangeField = new ConfigPageField(
			EVENT_7_STATE,
			event7StateChangeLabel,
			event7StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_incoming']")
	private WebElement event7IncomingLabel;

	@FindBy(id = "event_settings_6_incoming")
	private WebElement event7IncomingCheckbox;

	public ConfigPageField event7IncomingField = new ConfigPageField(
			EVENT_7_INCOMING,
			event7IncomingLabel,
			event7IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_registration']")
	private WebElement event7RegistrationLabel;

	@FindBy(id = "event_settings_6_registration")
	private WebElement event7RegistrationCheckbox;

	public ConfigPageField event7RegistrationField = new ConfigPageField(
			EVENT_7_REGISTRATION,
			event7RegistrationLabel,
			event7RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_unregistration']")
	private WebElement event7UnregistrationLabel;

	@FindBy(id = "event_settings_6_unregistration")
	private WebElement event7UnregistrationCheckbox;

	public ConfigPageField event7UnregistrationField = new ConfigPageField(
			EVENT_7_UNREGISTRATION,
			event7UnregistrationLabel,
			event7UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_offhook']")
	private WebElement event7OffHookLabel;

	@FindBy(id = "event_settings_6_offhook")
	private WebElement event7OffHookCheckbox;

	public ConfigPageField event7OffHookField = new ConfigPageField(
			EVENT_7_OFF_HOOK,
			event7OffHookLabel,
			event7OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_onhook']")
	private WebElement event7OnHookLabel;

	@FindBy(id = "event_settings_6_onhook")
	private WebElement event7OnHookCheckbox;

	public ConfigPageField event7OnHookField = new ConfigPageField(
			EVENT_7_ON_HOOK,
			event7OnHookLabel,
			event7OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_outgoing']")
	private WebElement event7OutgoingLabel;

	@FindBy(id = "event_settings_6_outgoing")
	private WebElement event7OutgoingCheckbox;

	public ConfigPageField event7OutgoingField = new ConfigPageField(
			EVENT_7_OUTGOING,
			event7OutgoingLabel,
			event7OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_userlogin']")
	private WebElement event7UserLoginLabel;

	@FindBy(id = "event_settings_6_userlogin")
	private WebElement event7UserLoginCheckbox;

	public ConfigPageField event7UserLoginField = new ConfigPageField(
			EVENT_7_LOGIN,
			event7UserLoginLabel,
			event7UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_6_safealarm']")
	private WebElement event7SafeAlarmLabel;

	@FindBy(id = "event_settings_6_safealarm")
	private WebElement event7SafeAlarmCheckbox;

	public ConfigPageField event7SafeAlarmField = new ConfigPageField(
			EVENT_7_SAFE_ALARM,
			event7SafeAlarmLabel,
			event7SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 8

	@FindBy(id = "webApiEventUrls_EventLabel_7")
	private WebElement event8LabelTextbox;

	public ConfigPageField event8LabelField = new ConfigPageField(
			EVENT_8_LABEL,
			event8LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_7")
	private WebElement event8UrlTextbox;

	public ConfigPageField event8UrlField = new ConfigPageField(
			EVENT_8_URL,
			event8UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_none']")
	private WebElement event8NoneLabel;

	@FindBy(id = "event_settings_7_none")
	private WebElement event8NoneCheckbox;

	public ConfigPageField event8NoneField = new ConfigPageField(
			EVENT_8_NONE,
			event8NoneLabel,
			event8NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_all']")
	private WebElement event8AllLabel;

	@FindBy(id = "event_settings_7_all")
	private WebElement event8AllCheckbox;

	public ConfigPageField event8AllField = new ConfigPageField(
			EVENT_8_ALL,
			event8AllLabel,
			event8AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_statechange']")
	private WebElement event8StateChangeLabel;

	@FindBy(id = "event_settings_7_statechange")
	private WebElement event8StateChangeCheckbox;

	public ConfigPageField event8StateChangeField = new ConfigPageField(
			EVENT_8_STATE,
			event8StateChangeLabel,
			event8StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_incoming']")
	private WebElement event8IncomingLabel;

	@FindBy(id = "event_settings_7_incoming")
	private WebElement event8IncomingCheckbox;

	public ConfigPageField event8IncomingField = new ConfigPageField(
			EVENT_8_INCOMING,
			event8IncomingLabel,
			event8IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_registration']")
	private WebElement event8RegistrationLabel;

	@FindBy(id = "event_settings_7_registration")
	private WebElement event8RegistrationCheckbox;

	public ConfigPageField event8RegistrationField = new ConfigPageField(
			EVENT_8_REGISTRATION,
			event8RegistrationLabel,
			event8RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_unregistration']")
	private WebElement event8UnregistrationLabel;

	@FindBy(id = "event_settings_7_unregistration")
	private WebElement event8UnregistrationCheckbox;

	public ConfigPageField event8UnregistrationField = new ConfigPageField(
			EVENT_8_UNREGISTRATION,
			event8UnregistrationLabel,
			event8UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_offhook']")
	private WebElement event8OffHookLabel;

	@FindBy(id = "event_settings_7_offhook")
	private WebElement event8OffHookCheckbox;

	public ConfigPageField event8OffHookField = new ConfigPageField(
			EVENT_8_OFF_HOOK,
			event8OffHookLabel,
			event8OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_onhook']")
	private WebElement event8OnHookLabel;

	@FindBy(id = "event_settings_7_onhook")
	private WebElement event8OnHookCheckbox;

	public ConfigPageField event8OnHookField = new ConfigPageField(
			EVENT_8_ON_HOOK,
			event8OnHookLabel,
			event8OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_outgoing']")
	private WebElement event8OutgoingLabel;

	@FindBy(id = "event_settings_7_outgoing")
	private WebElement event8OutgoingCheckbox;

	public ConfigPageField event8OutgoingField = new ConfigPageField(
			EVENT_8_OUTGOING,
			event8OutgoingLabel,
			event8OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_userlogin']")
	private WebElement event8UserLoginLabel;

	@FindBy(id = "event_settings_7_userlogin")
	private WebElement event8UserLoginCheckbox;

	public ConfigPageField event8UserLoginField = new ConfigPageField(
			EVENT_8_LOGIN,
			event8UserLoginLabel,
			event8UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_7_safealarm']")
	private WebElement event8SafeAlarmLabel;

	@FindBy(id = "event_settings_7_safealarm")
	private WebElement event8SafeAlarmCheckbox;

	public ConfigPageField event8SafeAlarmField = new ConfigPageField(
			EVENT_8_SAFE_ALARM,
			event8SafeAlarmLabel,
			event8SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 9

	@FindBy(id = "webApiEventUrls_EventLabel_8")
	private WebElement event9LabelTextbox;

	public ConfigPageField event9LabelField = new ConfigPageField(
			EVENT_9_LABEL,
			event9LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_8")
	private WebElement event9UrlTextbox;

	public ConfigPageField event9UrlField = new ConfigPageField(
			EVENT_9_URL,
			event9UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_none']")
	private WebElement event9NoneLabel;

	@FindBy(id = "event_settings_8_none")
	private WebElement event9NoneCheckbox;

	public ConfigPageField event9NoneField = new ConfigPageField(
			EVENT_9_NONE,
			event9NoneLabel,
			event9NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_all']")
	private WebElement event9AllLabel;

	@FindBy(id = "event_settings_8_all")
	private WebElement event9AllCheckbox;

	public ConfigPageField event9AllField = new ConfigPageField(
			EVENT_9_ALL,
			event9AllLabel,
			event9AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_statechange']")
	private WebElement event9StateChangeLabel;

	@FindBy(id = "event_settings_8_statechange")
	private WebElement event9StateChangeCheckbox;

	public ConfigPageField event9StateChangeField = new ConfigPageField(
			EVENT_9_STATE,
			event9StateChangeLabel,
			event9StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_incoming']")
	private WebElement event9IncomingLabel;

	@FindBy(id = "event_settings_8_incoming")
	private WebElement event9IncomingCheckbox;

	public ConfigPageField event9IncomingField = new ConfigPageField(
			EVENT_9_INCOMING,
			event9IncomingLabel,
			event9IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_registration']")
	private WebElement event9RegistrationLabel;

	@FindBy(id = "event_settings_8_registration")
	private WebElement event9RegistrationCheckbox;

	public ConfigPageField event9RegistrationField = new ConfigPageField(
			EVENT_9_REGISTRATION,
			event9RegistrationLabel,
			event9RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_unregistration']")
	private WebElement event9UnregistrationLabel;

	@FindBy(id = "event_settings_8_unregistration")
	private WebElement event9UnregistrationCheckbox;

	public ConfigPageField event9UnregistrationField = new ConfigPageField(
			EVENT_9_UNREGISTRATION,
			event9UnregistrationLabel,
			event9UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_offhook']")
	private WebElement event9OffHookLabel;

	@FindBy(id = "event_settings_8_offhook")
	private WebElement event9OffHookCheckbox;

	public ConfigPageField event9OffHookField = new ConfigPageField(
			EVENT_9_OFF_HOOK,
			event9OffHookLabel,
			event9OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_onhook']")
	private WebElement event9OnHookLabel;

	@FindBy(id = "event_settings_8_onhook")
	private WebElement event9OnHookCheckbox;

	public ConfigPageField event9OnHookField = new ConfigPageField(
			EVENT_9_ON_HOOK,
			event9OnHookLabel,
			event9OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_outgoing']")
	private WebElement event9OutgoingLabel;

	@FindBy(id = "event_settings_8_outgoing")
	private WebElement event9OutgoingCheckbox;

	public ConfigPageField event9OutgoingField = new ConfigPageField(
			EVENT_9_OUTGOING,
			event9OutgoingLabel,
			event9OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_userlogin']")
	private WebElement event9UserLoginLabel;

	@FindBy(id = "event_settings_8_userlogin")
	private WebElement event9UserLoginCheckbox;

	public ConfigPageField event9UserLoginField = new ConfigPageField(
			EVENT_9_LOGIN,
			event9UserLoginLabel,
			event9UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_8_safealarm']")
	private WebElement event9SafeAlarmLabel;

	@FindBy(id = "event_settings_8_safealarm")
	private WebElement event9SafeAlarmCheckbox;

	public ConfigPageField event9SafeAlarmField = new ConfigPageField(
			EVENT_9_SAFE_ALARM,
			event9SafeAlarmLabel,
			event9SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 10

	@FindBy(id = "webApiEventUrls_EventLabel_9")
	private WebElement event10LabelTextbox;

	public ConfigPageField event10LabelField = new ConfigPageField(
			EVENT_10_LABEL,
			event10LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_9")
	private WebElement event10UrlTextbox;

	public ConfigPageField event10UrlField = new ConfigPageField(
			EVENT_10_URL,
			event10UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_none']")
	private WebElement event10NoneLabel;

	@FindBy(id = "event_settings_9_none")
	private WebElement event10NoneCheckbox;

	public ConfigPageField event10NoneField = new ConfigPageField(
			EVENT_10_NONE,
			event10NoneLabel,
			event10NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_all']")
	private WebElement event10AllLabel;

	@FindBy(id = "event_settings_9_all")
	private WebElement event10AllCheckbox;

	public ConfigPageField event10AllField = new ConfigPageField(
			EVENT_10_ALL,
			event10AllLabel,
			event10AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_statechange']")
	private WebElement event10StateChangeLabel;

	@FindBy(id = "event_settings_9_statechange")
	private WebElement event10StateChangeCheckbox;

	public ConfigPageField event10StateChangeField = new ConfigPageField(
			EVENT_10_STATE,
			event10StateChangeLabel,
			event10StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_incoming']")
	private WebElement event10IncomingLabel;

	@FindBy(id = "event_settings_9_incoming")
	private WebElement event10IncomingCheckbox;

	public ConfigPageField event10IncomingField = new ConfigPageField(
			EVENT_10_INCOMING,
			event10IncomingLabel,
			event10IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_registration']")
	private WebElement event10RegistrationLabel;

	@FindBy(id = "event_settings_9_registration")
	private WebElement event10RegistrationCheckbox;

	public ConfigPageField event10RegistrationField = new ConfigPageField(
			EVENT_10_REGISTRATION,
			event10RegistrationLabel,
			event10RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_unregistration']")
	private WebElement event10UnregistrationLabel;

	@FindBy(id = "event_settings_9_unregistration")
	private WebElement event10UnregistrationCheckbox;

	public ConfigPageField event10UnregistrationField = new ConfigPageField(
			EVENT_10_UNREGISTRATION,
			event10UnregistrationLabel,
			event10UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_offhook']")
	private WebElement event10OffHookLabel;

	@FindBy(id = "event_settings_9_offhook")
	private WebElement event10OffHookCheckbox;

	public ConfigPageField event10OffHookField = new ConfigPageField(
			EVENT_10_OFF_HOOK,
			event10OffHookLabel,
			event10OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_onhook']")
	private WebElement event10OnHookLabel;

	@FindBy(id = "event_settings_9_onhook")
	private WebElement event10OnHookCheckbox;

	public ConfigPageField event10OnHookField = new ConfigPageField(
			EVENT_10_ON_HOOK,
			event10OnHookLabel,
			event10OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_outgoing']")
	private WebElement event10OutgoingLabel;

	@FindBy(id = "event_settings_9_outgoing")
	private WebElement event10OutgoingCheckbox;

	public ConfigPageField event10OutgoingField = new ConfigPageField(
			EVENT_10_OUTGOING,
			event10OutgoingLabel,
			event10OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_userlogin']")
	private WebElement event10UserLoginLabel;

	@FindBy(id = "event_settings_9_userlogin")
	private WebElement event10UserLoginCheckbox;

	public ConfigPageField event10UserLoginField = new ConfigPageField(
			EVENT_10_LOGIN,
			event10UserLoginLabel,
			event10UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_9_safealarm']")
	private WebElement event10SafeAlarmLabel;

	@FindBy(id = "event_settings_9_safealarm")
	private WebElement event10SafeAlarmCheckbox;

	public ConfigPageField event10SafeAlarmField = new ConfigPageField(
			EVENT_10_SAFE_ALARM,
			event10SafeAlarmLabel,
			event10SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 11

	@FindBy(id = "webApiEventUrls_EventLabel_10")
	private WebElement event11LabelTextbox;

	public ConfigPageField event11LabelField = new ConfigPageField(
			EVENT_11_LABEL,
			event11LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_10")
	private WebElement event11UrlTextbox;

	public ConfigPageField event11UrlField = new ConfigPageField(
			EVENT_11_URL,
			event11UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_none']")
	private WebElement event11NoneLabel;

	@FindBy(id = "event_settings_10_none")
	private WebElement event11NoneCheckbox;

	public ConfigPageField event11NoneField = new ConfigPageField(
			EVENT_11_NONE,
			event11NoneLabel,
			event11NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_all']")
	private WebElement event11AllLabel;

	@FindBy(id = "event_settings_10_all")
	private WebElement event11AllCheckbox;

	public ConfigPageField event11AllField = new ConfigPageField(
			EVENT_11_ALL,
			event11AllLabel,
			event11AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_statechange']")
	private WebElement event11StateChangeLabel;

	@FindBy(id = "event_settings_10_statechange")
	private WebElement event11StateChangeCheckbox;

	public ConfigPageField event11StateChangeField = new ConfigPageField(
			EVENT_11_STATE,
			event11StateChangeLabel,
			event11StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_incoming']")
	private WebElement event11IncomingLabel;

	@FindBy(id = "event_settings_10_incoming")
	private WebElement event11IncomingCheckbox;

	public ConfigPageField event11IncomingField = new ConfigPageField(
			EVENT_11_INCOMING,
			event11IncomingLabel,
			event11IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_registration']")
	private WebElement event11RegistrationLabel;

	@FindBy(id = "event_settings_10_registration")
	private WebElement event11RegistrationCheckbox;

	public ConfigPageField event11RegistrationField = new ConfigPageField(
			EVENT_11_REGISTRATION,
			event11RegistrationLabel,
			event11RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_unregistration']")
	private WebElement event11UnregistrationLabel;

	@FindBy(id = "event_settings_10_unregistration")
	private WebElement event11UnregistrationCheckbox;

	public ConfigPageField event11UnregistrationField = new ConfigPageField(
			EVENT_11_UNREGISTRATION,
			event11UnregistrationLabel,
			event11UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_offhook']")
	private WebElement event11OffHookLabel;

	@FindBy(id = "event_settings_10_offhook")
	private WebElement event11OffHookCheckbox;

	public ConfigPageField event11OffHookField = new ConfigPageField(
			EVENT_11_OFF_HOOK,
			event11OffHookLabel,
			event11OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_onhook']")
	private WebElement event11OnHookLabel;

	@FindBy(id = "event_settings_10_onhook")
	private WebElement event11OnHookCheckbox;

	public ConfigPageField event11OnHookField = new ConfigPageField(
			EVENT_11_ON_HOOK,
			event11OnHookLabel,
			event11OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_outgoing']")
	private WebElement event11OutgoingLabel;

	@FindBy(id = "event_settings_10_outgoing")
	private WebElement event11OutgoingCheckbox;

	public ConfigPageField event11OutgoingField = new ConfigPageField(
			EVENT_11_OUTGOING,
			event11OutgoingLabel,
			event11OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_userlogin']")
	private WebElement event11UserLoginLabel;

	@FindBy(id = "event_settings_10_userlogin")
	private WebElement event11UserLoginCheckbox;

	public ConfigPageField event11UserLoginField = new ConfigPageField(
			EVENT_11_LOGIN,
			event11UserLoginLabel,
			event11UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_10_safealarm']")
	private WebElement event11SafeAlarmLabel;

	@FindBy(id = "event_settings_10_safealarm")
	private WebElement event11SafeAlarmCheckbox;

	public ConfigPageField event11SafeAlarmField = new ConfigPageField(
			EVENT_11_SAFE_ALARM,
			event11SafeAlarmLabel,
			event11SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	// event URI 12

	@FindBy(id = "webApiEventUrls_EventLabel_11")
	private WebElement event12LabelTextbox;

	public ConfigPageField event12LabelField = new ConfigPageField(
			EVENT_12_LABEL,
			event12LabelTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(id = "webApiEventUrls_EventURL_11")
	private WebElement event12UrlTextbox;

	public ConfigPageField event12UrlField = new ConfigPageField(
			EVENT_12_URL,
			event12UrlTextbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_none']")
	private WebElement event12NoneLabel;

	@FindBy(id = "event_settings_11_none")
	private WebElement event12NoneCheckbox;

	public ConfigPageField event12NoneField = new ConfigPageField(
			EVENT_12_NONE,
			event12NoneLabel,
			event12NoneCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_all']")
	private WebElement event12AllLabel;

	@FindBy(id = "event_settings_11_all")
	private WebElement event12AllCheckbox;

	public ConfigPageField event12AllField = new ConfigPageField(
			EVENT_12_ALL,
			event12AllLabel,
			event12AllCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_statechange']")
	private WebElement event12StateChangeLabel;

	@FindBy(id = "event_settings_11_statechange")
	private WebElement event12StateChangeCheckbox;

	public ConfigPageField event12StateChangeField = new ConfigPageField(
			EVENT_12_STATE,
			event12StateChangeLabel,
			event12StateChangeCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_incoming']")
	private WebElement event12IncomingLabel;

	@FindBy(id = "event_settings_11_incoming")
	private WebElement event12IncomingCheckbox;

	public ConfigPageField event12IncomingField = new ConfigPageField(
			EVENT_12_INCOMING,
			event12IncomingLabel,
			event12IncomingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_registration']")
	private WebElement event12RegistrationLabel;

	@FindBy(id = "event_settings_11_registration")
	private WebElement event12RegistrationCheckbox;

	public ConfigPageField event12RegistrationField = new ConfigPageField(
			EVENT_12_REGISTRATION,
			event12RegistrationLabel,
			event12RegistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_unregistration']")
	private WebElement event12UnregistrationLabel;

	@FindBy(id = "event_settings_11_unregistration")
	private WebElement event12UnregistrationCheckbox;

	public ConfigPageField event12UnregistrationField = new ConfigPageField(
			EVENT_12_UNREGISTRATION,
			event12UnregistrationLabel,
			event12UnregistrationCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_offhook']")
	private WebElement event12OffHookLabel;

	@FindBy(id = "event_settings_11_offhook")
	private WebElement event12OffHookCheckbox;

	public ConfigPageField event12OffHookField = new ConfigPageField(
			EVENT_12_OFF_HOOK,
			event12OffHookLabel,
			event12OffHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_onhook']")
	private WebElement event12OnHookLabel;

	@FindBy(id = "event_settings_11_onhook")
	private WebElement event12OnHookCheckbox;

	public ConfigPageField event12OnHookField = new ConfigPageField(
			EVENT_12_ON_HOOK,
			event12OnHookLabel,
			event12OnHookCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_outgoing']")
	private WebElement event12OutgoingLabel;

	@FindBy(id = "event_settings_11_outgoing")
	private WebElement event12OutgoingCheckbox;

	public ConfigPageField event12OutgoingField = new ConfigPageField(
			EVENT_12_OUTGOING,
			event12OutgoingLabel,
			event12OutgoingCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_userlogin']")
	private WebElement event12UserLoginLabel;

	@FindBy(id = "event_settings_11_userlogin")
	private WebElement event12UserLoginCheckbox;

	public ConfigPageField event12UserLoginField = new ConfigPageField(
			EVENT_12_LOGIN,
			event12UserLoginLabel,
			event12UserLoginCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);

	@FindBy(xpath = "//label[@for='event_settings_11_safealarm']")
	private WebElement event12SafeAlarmLabel;

	@FindBy(id = "event_settings_11_safealarm")
	private WebElement event12SafeAlarmCheckbox;

	public ConfigPageField event12SafeAlarmField = new ConfigPageField(
			EVENT_12_SAFE_ALARM,
			event12SafeAlarmLabel,
			event12SafeAlarmCheckbox,
			eventUrlsDelete,
			eventUrlsEdit
	);


	@FindBy(id = "webAppShortcut1")
	private WebElement webApp1LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut1")
	private WebElement webApp1LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut1")
	private WebElement webApp1LabelEdit;

	public ConfigPageField webApp1LabelField = new ConfigPageField(
			APP_SHORTCUT_1,
			webApp1LabelTextbox,
			webApp1LabelDelete,
			webApp1LabelEdit
	);

	@FindBy(id = "webAppUri1")
	private WebElement webApp1UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri1")
	private WebElement webApp1UrlDelete;

	@FindBy(id = "edit_setting_webAppUri1")
	private WebElement webApp1UrlEdit;

	public ConfigPageField webApp1UrlField = new ConfigPageField(
			APP_URI_1,
			webApp1UrlTextbox,
			webApp1UrlDelete,
			webApp1UrlEdit
	);


	@FindBy(id = "webAppShortcut2")
	private WebElement webApp2LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut2")
	private WebElement webApp2LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut2")
	private WebElement webApp2LabelEdit;

	public ConfigPageField webApp2LabelField = new ConfigPageField(
			APP_SHORTCUT_2,
			webApp2LabelTextbox,
			webApp2LabelDelete,
			webApp2LabelEdit
	);

	@FindBy(id = "webAppUri2")
	private WebElement webApp2UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri2")
	private WebElement webApp2UrlDelete;

	@FindBy(id = "edit_setting_webAppUri2")
	private WebElement webApp2UrlEdit;

	public ConfigPageField webApp2UrlField = new ConfigPageField(
			APP_URI_2,
			webApp2UrlTextbox,
			webApp2UrlDelete,
			webApp2UrlEdit
	);


	@FindBy(id = "webAppShortcut3")
	private WebElement webApp3LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut3")
	private WebElement webApp3LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut3")
	private WebElement webApp3LabelEdit;

	public ConfigPageField webApp3LabelField = new ConfigPageField(
			APP_SHORTCUT_3,
			webApp3LabelTextbox,
			webApp3LabelDelete,
			webApp3LabelEdit
	);

	@FindBy(id = "webAppUri3")
	private WebElement webApp3UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri3")
	private WebElement webApp3UrlDelete;

	@FindBy(id = "edit_setting_webAppUri3")
	private WebElement webApp3UrlEdit;

	public ConfigPageField webApp3UrlField = new ConfigPageField(
			APP_URI_3,
			webApp3UrlTextbox,
			webApp3UrlDelete,
			webApp3UrlEdit
	);


	@FindBy(id = "webAppShortcut4")
	private WebElement webApp4LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut4")
	private WebElement webApp4LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut4")
	private WebElement webApp4LabelEdit;

	public ConfigPageField webApp4LabelField = new ConfigPageField(
			APP_SHORTCUT_4,
			webApp4LabelTextbox,
			webApp4LabelDelete,
			webApp4LabelEdit
	);

	@FindBy(id = "webAppUri4")
	private WebElement webApp4UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri4")
	private WebElement webApp4UrlDelete;

	@FindBy(id = "edit_setting_webAppUri4")
	private WebElement webApp4UrlEdit;

	public ConfigPageField webApp4UrlField = new ConfigPageField(
			APP_URI_4,
			webApp4UrlTextbox,
			webApp4UrlDelete,
			webApp4UrlEdit
	);


	@FindBy(id = "webAppShortcut5")
	private WebElement webApp5LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut5")
	private WebElement webApp5LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut5")
	private WebElement webApp5LabelEdit;

	public ConfigPageField webApp5LabelField = new ConfigPageField(
			APP_SHORTCUT_5,
			webApp5LabelTextbox,
			webApp5LabelDelete,
			webApp5LabelEdit
	);

	@FindBy(id = "webAppUri5")
	private WebElement webApp5UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri5")
	private WebElement webApp5UrlDelete;

	@FindBy(id = "edit_setting_webAppUri5")
	private WebElement webApp5UrlEdit;

	public ConfigPageField webApp5UrlField = new ConfigPageField(
			APP_URI_5,
			webApp5UrlTextbox,
			webApp5UrlDelete,
			webApp5UrlEdit
	);


	@FindBy(id = "webAppShortcut6")
	private WebElement webApp6LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut6")
	private WebElement webApp6LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut6")
	private WebElement webApp6LabelEdit;

	public ConfigPageField webApp6LabelField = new ConfigPageField(
			APP_SHORTCUT_6,
			webApp6LabelTextbox,
			webApp6LabelDelete,
			webApp6LabelEdit
	);

	@FindBy(id = "webAppUri6")
	private WebElement webApp6UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri6")
	private WebElement webApp6UrlDelete;

	@FindBy(id = "edit_setting_webAppUri6")
	private WebElement webApp6UrlEdit;

	public ConfigPageField webApp6UrlField = new ConfigPageField(
			APP_URI_6,
			webApp6UrlTextbox,
			webApp6UrlDelete,
			webApp6UrlEdit
	);


	@FindBy(id = "webAppShortcut7")
	private WebElement webApp7LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut7")
	private WebElement webApp7LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut7")
	private WebElement webApp7LabelEdit;

	public ConfigPageField webApp7LabelField = new ConfigPageField(
			APP_SHORTCUT_7,
			webApp7LabelTextbox,
			webApp7LabelDelete,
			webApp7LabelEdit
	);

	@FindBy(id = "webAppUri7")
	private WebElement webApp7UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri7")
	private WebElement webApp7UrlDelete;

	@FindBy(id = "edit_setting_webAppUri7")
	private WebElement webApp7UrlEdit;

	public ConfigPageField webApp7UrlField = new ConfigPageField(
			APP_URI_7,
			webApp7UrlTextbox,
			webApp7UrlDelete,
			webApp7UrlEdit
	);


	@FindBy(id = "webAppShortcut8")
	private WebElement webApp8LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut8")
	private WebElement webApp8LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut8")
	private WebElement webApp8LabelEdit;

	public ConfigPageField webApp8LabelField = new ConfigPageField(
			APP_SHORTCUT_8,
			webApp8LabelTextbox,
			webApp8LabelDelete,
			webApp8LabelEdit
	);

	@FindBy(id = "webAppUri8")
	private WebElement webApp8UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri8")
	private WebElement webApp8UrlDelete;

	@FindBy(id = "edit_setting_webAppUri8")
	private WebElement webApp8UrlEdit;

	public ConfigPageField webApp8UrlField = new ConfigPageField(
			APP_URI_8,
			webApp8UrlTextbox,
			webApp8UrlDelete,
			webApp8UrlEdit
	);


	@FindBy(id = "webAppShortcut9")
	private WebElement webApp9LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut9")
	private WebElement webApp9LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut9")
	private WebElement webApp9LabelEdit;

	public ConfigPageField webApp9LabelField = new ConfigPageField(
			APP_SHORTCUT_9,
			webApp9LabelTextbox,
			webApp9LabelDelete,
			webApp9LabelEdit
	);

	@FindBy(id = "webAppUri9")
	private WebElement webApp9UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri9")
	private WebElement webApp9UrlDelete;

	@FindBy(id = "edit_setting_webAppUri9")
	private WebElement webApp9UrlEdit;

	public ConfigPageField webApp9UrlField = new ConfigPageField(
			APP_URI_9,
			webApp9UrlTextbox,
			webApp9UrlDelete,
			webApp9UrlEdit
	);


	@FindBy(id = "webAppShortcut10")
	private WebElement webApp10LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut10")
	private WebElement webApp10LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut10")
	private WebElement webApp10LabelEdit;

	public ConfigPageField webApp10LabelField = new ConfigPageField(
			APP_SHORTCUT_10,
			webApp10LabelTextbox,
			webApp10LabelDelete,
			webApp10LabelEdit
	);

	@FindBy(id = "webAppUri10")
	private WebElement webApp10UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri10")
	private WebElement webApp10UrlDelete;

	@FindBy(id = "edit_setting_webAppUri10")
	private WebElement webApp10UrlEdit;

	public ConfigPageField webApp10UrlField = new ConfigPageField(
			APP_URI_10,
			webApp10UrlTextbox,
			webApp10UrlDelete,
			webApp10UrlEdit
	);


	@FindBy(id = "webAppShortcut11")
	private WebElement webApp11LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut11")
	private WebElement webApp11LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut11")
	private WebElement webApp11LabelEdit;

	public ConfigPageField webApp11LabelField = new ConfigPageField(
			APP_SHORTCUT_11,
			webApp11LabelTextbox,
			webApp11LabelDelete,
			webApp11LabelEdit
	);

	@FindBy(id = "webAppUri11")
	private WebElement webApp11UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri11")
	private WebElement webApp11UrlDelete;

	@FindBy(id = "edit_setting_webAppUri11")
	private WebElement webApp11UrlEdit;

	public ConfigPageField webApp11UrlField = new ConfigPageField(
			APP_URI_11,
			webApp11UrlTextbox,
			webApp11UrlDelete,
			webApp11UrlEdit
	);


	@FindBy(id = "webAppShortcut12")
	private WebElement webApp12LabelTextbox;

	@FindBy(id = "delete_setting_webAppShortcut12")
	private WebElement webApp12LabelDelete;

	@FindBy(id = "edit_setting_webAppShortcut12")
	private WebElement webApp12LabelEdit;

	public ConfigPageField webApp12LabelField = new ConfigPageField(
			APP_SHORTCUT_12,
			webApp12LabelTextbox,
			webApp12LabelDelete,
			webApp12LabelEdit
	);

	@FindBy(id = "webAppUri12")
	private WebElement webApp12UrlTextbox;

	@FindBy(id = "delete_setting_webAppUri12")
	private WebElement webApp12UrlDelete;

	@FindBy(id = "edit_setting_webAppUri12")
	private WebElement webApp12UrlEdit;

	public ConfigPageField webApp12UrlField = new ConfigPageField(
			APP_URI_12,
			webApp12UrlTextbox,
			webApp12UrlDelete,
			webApp12UrlEdit
	);


	public SamWebApiPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(enableWebApiField.getTitle(), enableWebApiField);
				put(webApiFormatField.getTitle(), webApiFormatField);
				put(pollingUserNameField.getTitle(), pollingUserNameField);
				put(pollingPasswordField.getTitle(), pollingPasswordField);
				put(pollingShowPasswordField.getTitle(), pollingShowPasswordField);
				put(pollingRespondMethodField.getTitle(), pollingRespondMethodField);
				put(pollingUrlReceiveResponseField.getTitle(), pollingUrlReceiveResponseField);
				put(pushUserNameField.getTitle(), pushUserNameField);
				put(pushPasswordField.getTitle(), pushPasswordField);
				put(pushShowPasswordField.getTitle(), pushShowPasswordField);
				put(allowMessagePriorityField.getTitle(), allowMessagePriorityField);
				put(pushRingToneEnableField.getTitle(), pushRingToneEnableField);
				put("enable" + pushRingToneEnableField.getTitle(), pushRingToneEnableField);
				put("disable" + pushRingToneDisableField.getTitle(), pushRingToneDisableField);
				put(ringtoneVolumeField.getTitle(), ringtoneVolumeField);
				put(pushServerRootUrlField.getTitle(), pushServerRootUrlField);
				put(event1LabelField.getTitle(), event1LabelField);
				put(event1UrlField.getTitle(), event1UrlField);
				put(event1NoneField.getTitle(), event1NoneField);
				put(event1AllField.getTitle(), event1AllField);
				put(event1StateChangeField.getTitle(), event1StateChangeField);
				put(event1IncomingField.getTitle(), event1IncomingField);
				put(event1RegistrationField.getTitle(), event1RegistrationField);
				put(event1UnregistrationField.getTitle(), event1UnregistrationField);
				put(event1OffHookField.getTitle(), event1OffHookField);
				put(event1OnHookField.getTitle(), event1OnHookField);
				put(event1OutgoingField.getTitle(), event1OutgoingField);
				put(event1UserLoginField.getTitle(), event1UserLoginField);
				put(event1SafeAlarmField.getTitle(), event1SafeAlarmField);

				put(event2LabelField.getTitle(), event2LabelField);
				put(event2UrlField.getTitle(), event2UrlField);
				put(event2NoneField.getTitle(), event2NoneField);
				put(event2AllField.getTitle(), event2AllField);
				put(event2StateChangeField.getTitle(), event2StateChangeField);
				put(event2IncomingField.getTitle(), event2IncomingField);
				put(event2RegistrationField.getTitle(), event2RegistrationField);
				put(event2UnregistrationField.getTitle(), event2UnregistrationField);
				put(event2OffHookField.getTitle(), event2OffHookField);
				put(event2OnHookField.getTitle(), event2OnHookField);
				put(event2OutgoingField.getTitle(), event2OutgoingField);
				put(event2UserLoginField.getTitle(), event2UserLoginField);
				put(event2SafeAlarmField.getTitle(), event2SafeAlarmField);

				put(event3LabelField.getTitle(), event3LabelField);
				put(event3UrlField.getTitle(), event3UrlField);
				put(event3NoneField.getTitle(), event3NoneField);
				put(event3AllField.getTitle(), event3AllField);
				put(event3StateChangeField.getTitle(), event3StateChangeField);
				put(event3IncomingField.getTitle(), event3IncomingField);
				put(event3RegistrationField.getTitle(), event3RegistrationField);
				put(event3UnregistrationField.getTitle(), event3UnregistrationField);
				put(event3OffHookField.getTitle(), event3OffHookField);
				put(event3OnHookField.getTitle(), event3OnHookField);
				put(event3OutgoingField.getTitle(), event3OutgoingField);
				put(event3UserLoginField.getTitle(), event3UserLoginField);
				put(event3SafeAlarmField.getTitle(), event3SafeAlarmField);

				put(event4LabelField.getTitle(), event4LabelField);
				put(event4UrlField.getTitle(), event4UrlField);
				put(event4NoneField.getTitle(), event4NoneField);
				put(event4AllField.getTitle(), event4AllField);
				put(event4StateChangeField.getTitle(), event4StateChangeField);
				put(event4IncomingField.getTitle(), event4IncomingField);
				put(event4RegistrationField.getTitle(), event4RegistrationField);
				put(event4UnregistrationField.getTitle(), event4UnregistrationField);
				put(event4OffHookField.getTitle(), event4OffHookField);
				put(event4OnHookField.getTitle(), event4OnHookField);
				put(event4OutgoingField.getTitle(), event4OutgoingField);
				put(event4UserLoginField.getTitle(), event4UserLoginField);
				put(event4SafeAlarmField.getTitle(), event4SafeAlarmField);

				put(event5LabelField.getTitle(), event5LabelField);
				put(event5UrlField.getTitle(), event5UrlField);
				put(event5NoneField.getTitle(), event5NoneField);
				put(event5AllField.getTitle(), event5AllField);
				put(event5StateChangeField.getTitle(), event5StateChangeField);
				put(event5IncomingField.getTitle(), event5IncomingField);
				put(event5RegistrationField.getTitle(), event5RegistrationField);
				put(event5UnregistrationField.getTitle(), event5UnregistrationField);
				put(event5OffHookField.getTitle(), event5OffHookField);
				put(event5OnHookField.getTitle(), event5OnHookField);
				put(event5OutgoingField.getTitle(), event5OutgoingField);
				put(event5UserLoginField.getTitle(), event5UserLoginField);
				put(event5SafeAlarmField.getTitle(), event5SafeAlarmField);

				put(event6LabelField.getTitle(), event6LabelField);
				put(event6UrlField.getTitle(), event6UrlField);
				put(event6NoneField.getTitle(), event6NoneField);
				put(event6AllField.getTitle(), event6AllField);
				put(event6StateChangeField.getTitle(), event6StateChangeField);
				put(event6IncomingField.getTitle(), event6IncomingField);
				put(event6RegistrationField.getTitle(), event6RegistrationField);
				put(event6UnregistrationField.getTitle(), event6UnregistrationField);
				put(event6OffHookField.getTitle(), event6OffHookField);
				put(event6OnHookField.getTitle(), event6OnHookField);
				put(event6OutgoingField.getTitle(), event6OutgoingField);
				put(event6UserLoginField.getTitle(), event6UserLoginField);
				put(event6SafeAlarmField.getTitle(), event6SafeAlarmField);

				put(event7LabelField.getTitle(), event7LabelField);
				put(event7UrlField.getTitle(), event7UrlField);
				put(event7NoneField.getTitle(), event7NoneField);
				put(event7AllField.getTitle(), event7AllField);
				put(event7StateChangeField.getTitle(), event7StateChangeField);
				put(event7IncomingField.getTitle(), event7IncomingField);
				put(event7RegistrationField.getTitle(), event7RegistrationField);
				put(event7UnregistrationField.getTitle(), event7UnregistrationField);
				put(event7OffHookField.getTitle(), event7OffHookField);
				put(event7OnHookField.getTitle(), event7OnHookField);
				put(event7OutgoingField.getTitle(), event7OutgoingField);
				put(event7UserLoginField.getTitle(), event7UserLoginField);
				put(event7SafeAlarmField.getTitle(), event7SafeAlarmField);

				put(event8LabelField.getTitle(), event8LabelField);
				put(event8UrlField.getTitle(), event8UrlField);
				put(event8NoneField.getTitle(), event8NoneField);
				put(event8AllField.getTitle(), event8AllField);
				put(event8StateChangeField.getTitle(), event8StateChangeField);
				put(event8IncomingField.getTitle(), event8IncomingField);
				put(event8RegistrationField.getTitle(), event8RegistrationField);
				put(event8UnregistrationField.getTitle(), event8UnregistrationField);
				put(event8OffHookField.getTitle(), event8OffHookField);
				put(event8OnHookField.getTitle(), event8OnHookField);
				put(event8OutgoingField.getTitle(), event8OutgoingField);
				put(event8UserLoginField.getTitle(), event8UserLoginField);
				put(event8SafeAlarmField.getTitle(), event8SafeAlarmField);

				put(event9LabelField.getTitle(), event9LabelField);
				put(event9UrlField.getTitle(), event9UrlField);
				put(event9NoneField.getTitle(), event9NoneField);
				put(event9AllField.getTitle(), event9AllField);
				put(event9StateChangeField.getTitle(), event9StateChangeField);
				put(event9IncomingField.getTitle(), event9IncomingField);
				put(event9RegistrationField.getTitle(), event9RegistrationField);
				put(event9UnregistrationField.getTitle(), event9UnregistrationField);
				put(event9OffHookField.getTitle(), event9OffHookField);
				put(event9OnHookField.getTitle(), event9OnHookField);
				put(event9OutgoingField.getTitle(), event9OutgoingField);
				put(event9UserLoginField.getTitle(), event9UserLoginField);
				put(event9SafeAlarmField.getTitle(), event9SafeAlarmField);

				put(event10LabelField.getTitle(), event10LabelField);
				put(event10UrlField.getTitle(), event10UrlField);
				put(event10NoneField.getTitle(), event10NoneField);
				put(event10AllField.getTitle(), event10AllField);
				put(event10StateChangeField.getTitle(), event10StateChangeField);
				put(event10IncomingField.getTitle(), event10IncomingField);
				put(event10RegistrationField.getTitle(), event10RegistrationField);
				put(event10UnregistrationField.getTitle(), event10UnregistrationField);
				put(event10OffHookField.getTitle(), event10OffHookField);
				put(event10OnHookField.getTitle(), event10OnHookField);
				put(event10OutgoingField.getTitle(), event10OutgoingField);
				put(event10UserLoginField.getTitle(), event10UserLoginField);
				put(event10SafeAlarmField.getTitle(), event10SafeAlarmField);

				put(event11LabelField.getTitle(), event11LabelField);
				put(event11UrlField.getTitle(), event11UrlField);
				put(event11NoneField.getTitle(), event11NoneField);
				put(event11AllField.getTitle(), event11AllField);
				put(event11StateChangeField.getTitle(), event11StateChangeField);
				put(event11IncomingField.getTitle(), event11IncomingField);
				put(event11RegistrationField.getTitle(), event11RegistrationField);
				put(event11UnregistrationField.getTitle(), event11UnregistrationField);
				put(event11OffHookField.getTitle(), event11OffHookField);
				put(event11OnHookField.getTitle(), event11OnHookField);
				put(event11OutgoingField.getTitle(), event11OutgoingField);
				put(event11UserLoginField.getTitle(), event11UserLoginField);
				put(event11SafeAlarmField.getTitle(), event11SafeAlarmField);

				put(event12LabelField.getTitle(), event12LabelField);
				put(event12UrlField.getTitle(), event12UrlField);
				put(event12NoneField.getTitle(), event12NoneField);
				put(event12AllField.getTitle(), event12AllField);
				put(event12StateChangeField.getTitle(), event12StateChangeField);
				put(event12IncomingField.getTitle(), event12IncomingField);
				put(event12RegistrationField.getTitle(), event12RegistrationField);
				put(event12UnregistrationField.getTitle(), event12UnregistrationField);
				put(event12OffHookField.getTitle(), event12OffHookField);
				put(event12OnHookField.getTitle(), event12OnHookField);
				put(event12OutgoingField.getTitle(), event12OutgoingField);
				put(event12UserLoginField.getTitle(), event12UserLoginField);
				put(event12SafeAlarmField.getTitle(), event12SafeAlarmField);

				put(webApp1LabelField.getTitle(), webApp1LabelField);
				put(webApp1UrlField.getTitle(), webApp1UrlField);
				put(webApp2LabelField.getTitle(), webApp2LabelField);
				put(webApp2UrlField.getTitle(), webApp2UrlField);
				put(webApp3LabelField.getTitle(), webApp3LabelField);
				put(webApp3UrlField.getTitle(), webApp3UrlField);
				put(webApp4LabelField.getTitle(), webApp4LabelField);
				put(webApp4UrlField.getTitle(), webApp4UrlField);
				put(webApp5LabelField.getTitle(), webApp5LabelField);
				put(webApp5UrlField.getTitle(), webApp5UrlField);
				put(webApp6LabelField.getTitle(), webApp6LabelField);
				put(webApp6UrlField.getTitle(), webApp6UrlField);
				put(webApp7LabelField.getTitle(), webApp7LabelField);
				put(webApp7UrlField.getTitle(), webApp7UrlField);
				put(webApp8LabelField.getTitle(), webApp8LabelField);
				put(webApp8UrlField.getTitle(), webApp8UrlField);
				put(webApp9LabelField.getTitle(), webApp9LabelField);
				put(webApp9UrlField.getTitle(), webApp9UrlField);
				put(webApp10LabelField.getTitle(), webApp10LabelField);
				put(webApp10UrlField.getTitle(), webApp10UrlField);
				put(webApp11LabelField.getTitle(), webApp11LabelField);
				put(webApp11UrlField.getTitle(), webApp11UrlField);
				put(webApp12LabelField.getTitle(), webApp12LabelField);
				put(webApp12UrlField.getTitle(), webApp12UrlField);
			}
		};
	}

	public void clickWebApiTab() {
		clickOnPageEntity(tabs.get(0));
		sleepSeconds(2);
	}

	public void clickAppUrlsTab() {
		clickOnPageEntity(tabs.get(1));
		sleepSeconds(2);
	}

	public void clickAddApiEvent() {
		setTemporaryWait(0);
		if (isEntityClickable(addApiEventButton)) {
			clickOnPageEntity(addApiEventButton);
			sleepSeconds(1);
		}
		removeTemporaryWait();
	}

	public void clickRemoveApiEvent() {
		setTemporaryWait(0);
		if (isEntityClickable(removeApiEventButton)) {
			clickOnPageEntity(removeApiEventButton);
			sleepSeconds(1);
		}
		removeTemporaryWait();
	}

	public void clickAddWebApp() {
		setTemporaryWait(0);
		if (isEntityClickable(addWebAppButton)) {
			clickOnPageEntity(addWebAppButton);
			sleepSeconds(1);
		}
		removeTemporaryWait();
	}

	public void clickRemoveWebApp() {
		setTemporaryWait(0);
		if (isEntityClickable(removeWebAppButton)) {
			clickOnPageEntity(removeWebAppButton);
			sleepSeconds(1);
		}
		removeTemporaryWait();
	}

	public void clickReloadPageLink() {
        setTemporaryWait(60);
        if (isEntityClickable(reloadPageLink)) {
            clickOnPageEntity(reloadPageLink);
        }
        removeTemporaryWait();
	}

	public void clickReloadOkButton() {
        setTemporaryWait(2);
        if (isEntityClickable(reloadOkButton)) {
            clickOnPageEntity(reloadOkButton);
            sleepSeconds(3);
        }
        removeTemporaryWait();
	}
}
