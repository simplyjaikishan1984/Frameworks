package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class XmlTool {

	private static List<String> unwantedAttributes = new ArrayList<>();
	private static final Logger log = LogManager.getLogger(XmlTool.class.getName());

	public XmlTool() {
		unwantedAttributes.add("xmlns:xsi");
		unwantedAttributes.add("xsi:noNamespaceSchemaLocation");
	}

	public static Map<String, AppSetting> loadApolloSettingsFromXml(String settingsString) {
		Map<String, AppSetting> settings = new LinkedHashMap<>();
		try {
			DOMParser parser = new DOMParser();
			parser.parse(new InputSource(new ByteArrayInputStream(settingsString.getBytes())));
			Document customSettings = parser.getDocument();
			Element documentNode = customSettings.getDocumentElement();
			findApolloElements(settings, documentNode);
		} catch (IOException ioe) {
			log.error("Could not get XML string: {}", ioe.getMessage());
		} catch (SAXException se) {
			log.error("Could not parse XML string: {}", se.getMessage());
		}
		return settings;
	}

	private static void findApolloElements(Map<String, AppSetting> settings, Element node) {
		if (node.hasChildNodes()) {
			NodeList children = node.getChildNodes();
			for (int childIndex = 0; childIndex < children.getLength(); childIndex++) {
				if (children.item(childIndex).getNodeType() == Node.ELEMENT_NODE) {
					Element childNode = (Element) children.item(childIndex);
					findApolloElements(settings, childNode);
				}
			}
		}
		findApolloSettings(settings, node);
	}

	private static void findApolloSettings(Map<String, AppSetting> settings, Element node) {
		if (!node.getNodeName().contentEquals("map")) {
			AppSetting newSetting;
			if (node.getNodeName().contentEquals("string")) {
				newSetting = new AppSetting(node.getNodeName(), node.getAttribute("name"), node.getTextContent());
				settings.put(node.getAttribute("name"), newSetting);
			} else {
				newSetting = new AppSetting(node.getNodeName(), node.getAttribute("name"), node.getAttribute("value"));
				settings.put(node.getAttribute("name"), newSetting);
			}
			settings.put(node.getAttribute("name"), newSetting);
		}
	}

	public static List<Setting> loadSettingsFromXml(Path settingsFile) {
		List<Setting> settings = new ArrayList<>();
		try {
			DOMParser parser = new DOMParser();
			parser.parse(settingsFile.toString());
			Document customSettings = parser.getDocument();
			Element documentNode = customSettings.getDocumentElement();
			findElements(settings, documentNode);
		} catch (IOException ioe) {
			log.error("Could not open XML file: {}", ioe.getMessage());
		} catch (SAXException se) {
			log.error("Could not parse XML file: {}", se.getMessage());
		}
		return settings;
	}

	private static void findElements(List<Setting> settings, Element node) {
		if (node.hasChildNodes()) {
			NodeList children = node.getChildNodes();
			for (int childIndex = 0; childIndex < children.getLength(); childIndex++) {
				if (children.item(childIndex).getNodeType() == Node.ELEMENT_NODE) {
					Element childNode = (Element) children.item(childIndex);
					findElements(settings, childNode);
				}
			}
		}
		findAttributes(settings, node);
	}

	private static void findAttributes(List<Setting> settings, Element node) {
		NamedNodeMap attributeMap = node.getAttributes();
		for (int attributeIndex = 0; attributeIndex < attributeMap.getLength(); attributeIndex++) {
			Node current = attributeMap.item(attributeIndex);
			if (!current.getNodeName().contentEquals("xmlns:xsi") && !current.getNodeName().contentEquals("xsi:noNamespaceSchemaLocation")) {
				settings.add(new Setting(current.getNodeName(), current.getNodeValue()));
			}
		}
	}

	public static void printXml(String xml, String fileName) {
		List<Setting> settings = new ArrayList<>();
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document uiMap = builder.parse(new InputSource(new StringReader(xml)));
			uiMap.getDocumentElement().normalize();
			Element root = uiMap.getDocumentElement();
			NodeList topElement = uiMap.getChildNodes();
			StringBuilder objectInfo = new StringBuilder();
			traverseTree(topElement, 0, objectInfo);
			Path path = Paths.get(fileName);
			byte[] strToBytes = objectInfo.toString().getBytes();
			Files.write(path, strToBytes);
			log.debug("Dumped UI info into file {}", fileName);
		} catch (ParserConfigurationException pce) {
			log.error("Could not parse UI XML: {}", pce.getMessage());
		} catch (IOException ioe) {
			log.error("Could not open XML file: {}", ioe.getMessage());
		} catch (SAXException se) {
			log.error("Could not parse XML file: {}", se.getMessage());
		}
	}

	public static void traverseTree(NodeList childElements, int depth, StringBuilder objectInfo) {
		for (int index = 0; index < childElements.getLength(); index++) {
			Node node = childElements.item(index);
			if (node.hasAttributes()) {
				NamedNodeMap nodeMap = node.getAttributes();
				String clazz = node.getNodeName().contains("Layout") ? node.getNodeName() + " (Disregard)" : node.getNodeName();
				String resourceId = nodeMap.getNamedItem("resource-id") != null ? nodeMap.getNamedItem("resource-id").getNodeValue() : "empty";
				String contentDesc = nodeMap.getNamedItem("content-desc") != null ? nodeMap.getNamedItem("content-desc").getNodeValue() : "empty";
				String text = nodeMap.getNamedItem("text") != null ? nodeMap.getNamedItem("text").getNodeValue() : "empty";
				String spacer = StringUtils.repeat("  ", depth);
				objectInfo.append(spacer + clazz + "\r\n");
				objectInfo.append(spacer + "resource-id:  " + resourceId + "\r\n");
				objectInfo.append(spacer + "content-desc: " + contentDesc + "\r\n");
				objectInfo.append(spacer + "text:         " + text + "\r\n\r\n");
				if (node.hasChildNodes()) {
					traverseTree(node.getChildNodes(), depth + 1, objectInfo);
				}
			}
		}
	}
}
