package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.spectralink.test_automation.cucumber.framework.common.Util.qquote;

public class LogcatInspector {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private final AndroidPhone phone;
	private String timestamp;
    private List<String> chattyDisabledPackages = new ArrayList<>();

	public LogcatInspector(AndroidPhone phone) {
		this.phone = phone;
	}

	public AndroidPhone getPhone() {
		return phone;
	}

	private Map<String, String> getProcessedAttributes(String[] entries) {
		Map<String, String> attributes = new HashMap<>();
		int lineIndex = 0;
		Pattern pattern = Pattern.compile("(\\d{2}\\-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}).*URI to update ::content://(\\S+)");
		for (String line : entries) {
			Matcher match = pattern.matcher(line);
			if (match.find()) {
				timestamp = match.group(1);
				String uri = match.group(2);
				String[] chunks = uri.split("/");
				String packageName = chunks[0].substring(chunks[0].lastIndexOf(".") + 1);
				attributes.put(chunks[3], packageName);
			} else {
				break;
			}
		}
		return attributes;
	}

	private Map<String, String> getLastEntry(String entries) {
		String[] lines = entries.split("\\n");
		int lastElement = lines.length - 1;
		for (int lineIndex = lastElement; lineIndex >= 0; lineIndex--) {
			if (lines[lineIndex].contains("HB response entity contains config data")) {
				String[] slice = Arrays.copyOfRange(lines, lineIndex + 1, lastElement);
				return getProcessedAttributes(slice);
			}
			if (lines[lineIndex].contains("no config key in response entity")) {
				log.error("Empty heartbeat response was found");
				return new HashMap<>();
			}
		}
		return new HashMap<>();
	}

	public String[] getAppLogEntries(String packageName, String appName, String level) {
        disableChatty(packageName);
        String appLevel = appName + ":" + level.toUpperCase() + " *:S";
		List<String> command = new ArrayList<>(Arrays.asList("logcat", "-d", appLevel, "*:S"));
		CliResult result = phone.sendAdbCommand(command);
		if (result.commandFailed()) {
			log.error("ADB command '{}' failed: {}", result.getCommand(), result.getStdout());
			return new String[0];
		} else {
			return result.getStdout().split("\\n");
		}
	}

	public void disableChatty(String packageName) {
	    if (!chattyDisabledPackages.contains(packageName)) {
			List<String> command = new ArrayList<>(Arrays.asList("shell", "pidof", packageName));
			CliResult result = phone.sendAdbCommand(command);
            if (result.commandFailed()) {
                log.error("ADB command '{}' failed: {}", result.getCommand(), result.getStdout());
            } else {
                try {
                    Integer pid = Integer.valueOf(result.getStdout().trim());
					command = new ArrayList<>(Arrays.asList("logcat", "-P", qquote(pid)));
					CliResult secondResult = phone.sendAdbCommand(command);
                    if (secondResult.commandFailed()) {
                        log.error("Could not suppress chatty with command {}: {}", secondResult.getCommand(), secondResult.getStdout());
                    } else {
                        chattyDisabledPackages.add(packageName);
                    }
                } catch (NumberFormatException nfe) {
                    log.error("ADB command '{}' returned non-numeric PID: {}", result.getCommand(), result.getStdout());
                }
            }
        }
    }

	public Map<String, String> getLastSamClientResponse() {
        disableChatty("com.spectralink.slnksamclient");
		Map<String, String> acceptedValues = new HashMap<>();
		List<String> command = new ArrayList<>(Arrays.asList("logcat", "-d", "SamClient:I", "*:S"));
		CliResult result = phone.sendAdbCommand(command);
		if (result.commandFailed()) {
			log.error("ADB command '{}' failed: {}", result.getCommand(), result.getStdout());
		} else {
			acceptedValues = getLastEntry(result.getStdout());
		}
		return acceptedValues;
	}

	public void logLastResponse() {
		Map<String, List<String>> groupedAttributes = new HashMap<>();
		log.debug("SamClient processed attributes starting at {} for {}:", timestamp, getPhone().getSerialNumber());
		Map<String, String> samClientResponse = getLastSamClientResponse();
		for (String attributeName : samClientResponse.keySet()) {
			String packageName = samClientResponse.get(attributeName);
			if (!groupedAttributes.containsKey(packageName)) {
				groupedAttributes.put(packageName, new ArrayList<>());
			}
			groupedAttributes.get(packageName).add(attributeName);
		}

		for (String packageName : groupedAttributes.keySet()) {
			Object[] packageAttributes = groupedAttributes.get(packageName).toArray();
			Arrays.sort(packageAttributes);
			log.debug("Package {}:", packageName);
			for (Object attribute : packageAttributes) {
				log.debug("  {}", attribute.toString());
			}
		}
	}

	public int getLastResponseCount() {
		return getLastSamClientResponse().size();
	}

	public void compareSentToProcessed(Map<String, String> jarvisResponse) {
		Map<String, String> samClientResponse = getLastSamClientResponse();
		if (samClientResponse.size() == 0) {
		    Assert.fail("No recent response was found");
        } else {
            int differences = 0;
            log.debug("Logcat entries pulled at {}", timestamp);
            for (String jarvisAttribute : jarvisResponse.keySet()) {
                if (!samClientResponse.containsKey(jarvisAttribute)) {
                    log.error("SAM sent {} but it was not processed by SamClient", jarvisAttribute);
                    differences += 1;
                }
            }
            Assert.assertEquals(differences, 0, "Differences were found between what SAM sent and SamClient processed");
            log.debug("No differences were found between what SAM sent and SamClient processed");
        }
	}
}
