package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.AndroidPhone;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.DeviceAppUi;
import io.appium.java_client.android.connection.ConnectionStateBuilder;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Activity.SETTINGS_MAIN;
import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Activity.SETTINGS_WIFI;
import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.DEVICE;
import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.SETTINGS;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.DeviceAppStrings.*;

public class DeviceDeviceAppSteps {

    public static Boolean toggleEnabled = true;
    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I tap the Device app \"([^\"]*)\" on \"([^\"]*)\"$")
    public void tapDeviceAppObject(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, arg1.trim());
        if (field != null) {
            if (field.hasLabelElement()) {
                assert heading != null;
                field.scrollIntoView(heading);
                if (field.isLabelPresent()) {
                    field.tap();
                } else {
                    log.error("Field '{}' has no label", arg1);
                }
            } else if (field.hasControlElement())
                field.tap();
            else {
                log.error("Field '{}' has no control", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I set the Device app \"([^\"]*)\" switch to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setDeviceAppSwitch(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, arg1.trim());

        if (field != null) {
            if (field.hasLabelElement()) {
                assert heading != null;
                field.scrollIntoExactView(heading);
            }
            switch (arg2.toLowerCase()) {
                case "on":
                    toggleEnabled = true;
                    if (field.getControlElement().getAttribute("checked").equals("false"))
                        field.tap();
                    else
                        log.debug("Field '{}' was already set to '{}'", arg1, arg2);
                    break;
                case "off":
                    toggleEnabled = false;
                    if (field.getControlElement().getAttribute("checked").equals("true"))
                        field.tap();
                    else
                        log.debug("Field '{}' was already set to '{}'", arg1, arg2);
                    break;
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I set the Device app Allow emergency call button on lockscreen switch to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setDeviceAppEmergencyCallSwitch(String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        if(phone.isWifiOnly()) {
            DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
            ConfigUiField field = deviceAppUi.getField(ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title().trim().toLowerCase());
            FieldData heading = DeviceFields.getStrings(DEVICE, ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title().trim());

            if (field != null) {
                if (field.hasLabelElement()) {
                    assert heading != null;
                    field.scrollIntoExactView(heading);
                }
                switch (arg2.toLowerCase()) {
                    case "on":
                        toggleEnabled = true;
                        if (field.getControlElement().getAttribute("checked").equals("false"))
                            field.tap();
                        else
                            log.debug("Field '{}' was already set to '{}'", ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title(), arg2);
                        break;
                    case "off":
                        toggleEnabled = false;
                        if (field.getControlElement().getAttribute("checked").equals("true"))
                            field.tap();
                        else
                            log.debug("Field '{}' was already set to '{}'", ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title(), arg2);
                        break;
                }
            } else {
                log.error("No matching field with title '{}'", ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title());
            }
        }
    }

    @When("^I set the Device app Enable Wi-Fi calling/VoLTE switch to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setDeviceAppWifiCallingSwitch(String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        if(phone.isLte()) {
            DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
            ConfigUiField field = deviceAppUi.getField(ENABLE_WIFI_CALLING.title().trim().toLowerCase());
            FieldData heading = DeviceFields.getStrings(DEVICE, ENABLE_WIFI_CALLING.title().trim());

            if (field != null) {
                if (field.hasLabelElement()) {
                    assert heading != null;
                    field.scrollIntoExactView(heading);
                }
                switch (arg2.toLowerCase()) {
                    case "on":
                        toggleEnabled = true;
                        if (field.getControlElement().getAttribute("checked").equals("false"))
                            field.tap();
                        else
                            log.debug("Field '{}' was already set to '{}'", ENABLE_WIFI_CALLING.title(), arg2);
                        break;
                    case "off":
                        toggleEnabled = false;
                        if (field.getControlElement().getAttribute("checked").equals("true"))
                            field.tap();
                        else
                            log.debug("Field '{}' was already set to '{}'", ENABLE_WIFI_CALLING.title(), arg2);
                        break;
                }
            } else {
                log.error("No matching field with title '{}'", ENABLE_WIFI_CALLING.title());
            }
        }
    }

    @When("^I \"([^\"]*)\" the quick settings tiles \"([^\"]*)\" checkbox on \"([^\"]*)\"$")
    public void enableCheckbox(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(arg2.trim().toLowerCase());
        if (field != null) {
            field.scrollIntoViewAttribute(arg2.toLowerCase());
            switch (arg1.toLowerCase()) {
                case "enable":
                    if (field.getControlElement().getAttribute("checked").equals("false"))
                        field.tap();
                    else
                        log.debug("Field '{}' was already set to '{}'", arg2, arg1);
                    break;
                case "disable":
                    if (field.getControlElement().getAttribute("checked").equals("true"))
                        field.tap();
                    else
                        log.debug("Field '{}' was already set to '{}'", arg2, arg1);
                    break;
            }
        } else {
            log.error("No matching field with title '{}'", arg2);
        }
    }

    @When("^I select \"([^\"]*)\" from the Device app overflow menu on \"([^\"]*)\"$")
    public void selectOverflowOption(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isControlPresent()) {
            deviceAppUi.clickOverflowMenu();
            found = field.selectTextMenuOption(arg1.trim().toLowerCase());
            if (found) {
                log.debug("Selected menu option '{}'", arg1);
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @When("^I select \"([^\"]*)\" from the Device app Time zone menu on \"([^\"]*)\"$")
    public void selectScrollMenuOption(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(TIME_ZONE);
        FieldData heading = DeviceFields.getStrings(DEVICE, arg1.trim());
        if (field != null) {
            field.scrollIntoExactViewAttribute(TIME_ZONE.title());
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                assert heading != null;
                field.scrollIntoViewMaxSwipes(heading, 200);
                found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
                if (found) {
                    log.debug("Selected menu option '{}'", arg1);
                    sleepSeconds(1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                }
            } else {
                log.debug("Field was already set to '{}'", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I select \"([^\"]*)\" from the Device app menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(arg2.trim());
        if (field != null)
            field.scrollIntoExactViewAttribute(arg2);
        boolean found;
        if (field.isValueAccessible()) {
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
                if (found) {
                    log.debug("Selected menu option '{}'", arg1);
                    sleepSeconds(1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg2, arg1);
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Device app switch/checkbox \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyDeviceAppValue(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, arg1.trim());

        if (field.hasControlElement()) {
            assert heading != null;
            field.scrollIntoExactView(heading);
        }
        if (field.isControlPresent()) {
            String fieldControl = field.getControlElement().getAttribute("checked");
            switch (arg2.toLowerCase()) {
                case "on":
                    if (fieldControl.contentEquals("true")) {
                        log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
                    } else {
                        log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldControl, arg2, arg3);
                        Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
                    }
                    break;
                case "off":
                    if (fieldControl.contentEquals("false")) {
                        log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
                    } else {
                        log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldControl, arg2, arg3);
                        Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
                    }
                    break;
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Device app Enable Wi-Fi calling/VoLTE switch value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyDeviceAppEnableWifiCallingValue(String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        if(phone.isLte()) {
            DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
            ConfigUiField field = deviceAppUi.getField(ENABLE_WIFI_CALLING.title().trim().toLowerCase());
            FieldData heading = DeviceFields.getStrings(DEVICE, ENABLE_WIFI_CALLING.title().trim());

            if (field.hasControlElement()) {
                assert heading != null;
                field.scrollIntoExactView(heading);
            }
            if (field.isControlPresent()) {
                String fieldControl = field.getControlElement().getAttribute("checked");
                switch (arg2.toLowerCase()) {
                    case "on":
                        if (fieldControl.contentEquals("true")) {
                            log.debug("Verified field '{}' was set to '{}'", ENABLE_WIFI_CALLING.title(), arg2);
                        } else {
                            log.error("Field '{}' was set to '{}' rather than '{}' on {}", ENABLE_WIFI_CALLING.title(), fieldControl, arg2, arg3);
                            Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
                        }
                        break;
                    case "off":
                        if (fieldControl.contentEquals("false")) {
                            log.debug("Verified field '{}' was set to '{}'", ENABLE_WIFI_CALLING.title(), arg2);
                        } else {
                            log.error("Field '{}' was set to '{}' rather than '{}' on {}", ENABLE_WIFI_CALLING.title(), fieldControl, arg2, arg3);
                            Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
                        }
                        break;
                }
            } else {
                log.error("Field '{}' was not visible", ENABLE_WIFI_CALLING.title());
                Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
            }
        }
    }

    @Then("^the Device app Allow emergency call button on lockscreen switch value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyDeviceAppEmergencyCallValue(String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        if(phone.isWifiOnly()) {
            DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
            ConfigUiField field = deviceAppUi.getField(ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title().trim().toLowerCase());
            FieldData heading = DeviceFields.getStrings(DEVICE, ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title().trim());

            if (field.hasControlElement()) {
                assert heading != null;
                field.scrollIntoExactView(heading);
            }
            if (field.isControlPresent()) {
                String fieldControl = field.getControlElement().getAttribute("checked");
                switch (arg2.toLowerCase()) {
                    case "on":
                        if (fieldControl.contentEquals("true")) {
                            log.debug("Verified field '{}' was set to '{}'", ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title(), arg2);
                        } else {
                            log.error("Field '{}' was set to '{}' rather than '{}' on {}", ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title(), fieldControl, arg2, arg3);
                            Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
                        }
                        break;
                    case "off":
                        if (fieldControl.contentEquals("false")) {
                            log.debug("Verified field '{}' was set to '{}'", ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title(), arg2);
                        } else {
                            log.error("Field '{}' was set to '{}' rather than '{}' on {}", ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title(), fieldControl, arg2, arg3);
                            Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
                        }
                        break;
                }
            } else {
                log.error("Field '{}' was not visible", ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title());
                Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
            }
        }
    }

    @Then("^the Device app \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyDeviceValue(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, arg1.trim());

        if (field.hasValueElement()) {
            assert heading != null;
            field.scrollIntoExactView(heading);
        }
        if (field.isValuePresent()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
            }
        }
        else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I enter \"([^\"]*)\" into the Device app edit box on \"([^\"]*)\"$")
    public void enterInEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = deviceAppUi.getField(EDIT_TEXT);
            field.getControlElement().clear();
            field.enter(arg1.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg2);
        }
    }

    @When("^I clear the Device app edit box on \"([^\"]*)\"$")
    public void enterEndpointText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            deviceAppUi.clearEditText();
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @Then("^the Device app \"([^\"]*)\" value is not set anymore on \"([^\"]*)\"$")
    public void textViewValue(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, arg1.trim());
        assert heading != null;
        field.scrollIntoView(heading);
        try {
            if (field.isValuePresent()) {
                log.error("Field should not have been present");
                Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
            }
        }
        catch (Exception exception) {
            log.debug("Field '{}' was not visible", arg1);
        }
    }

    @Then("^I verify Device name is set to device serial number on \"([^\"]*)\"$")
    public void verifyDeviceName(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        String phoneModel;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(DEVICE_NAME);
        FieldData heading = DeviceFields.getStrings(DEVICE, DEVICE_NAME.title());
        if (field.hasLabelElement()) {
            assert heading != null;
            field.scrollIntoView(heading);
        }
        if (field.isValuePresent()) {
            String fieldValue = field.getValueElement().getText();
            if (phone.getModel().toLowerCase().contains("saturn"))
                phoneModel = "Cisco " + phone.getSerialNumber();
            else
                phoneModel = "Spectralink " + phone.getSerialNumber();
            if (fieldValue.contentEquals(phoneModel)) {
                log.debug("Verified device name was set to serial number on :" + arg1);
            } else {
                log.error("Device name was set to '{}' rather than the serial number on {}", fieldValue, arg1);
                Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
            }
        } else {
            log.error("Device name field was not visible");
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I enter device serial number into the Device app edit box on \"([^\"]*)\"$")
    public void enterInEditTextSerialNumber(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        String phoneModel;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = deviceAppUi.getField(EDIT_TEXT);
            if (phone.getModel().toLowerCase().contains("saturn"))
                phoneModel = "Cisco " + phone.getSerialNumber();
            else
                phoneModel = "Spectralink " + phone.getSerialNumber();
            field.enter(phoneModel);
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @Then("^I verify I \"([^\"]*)\" toggle Wi-Fi from notification bar on \"([^\"]*)\"$")
    public void verifyCanToggleWifi(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        String wifiAndroidSettingsApp;
        String wifiAdbState;
        switch (arg1.trim().toLowerCase()) {
            case "can":
                phone.openNotificationBarAndDragDown();
                deviceAppUi.toggleWifiNotificationBar("off");
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                sleepSeconds(1);
                wifiAndroidSettingsApp = deviceAppUi.getWifiToggleStateAndroidSettings();
                wifiAdbState = phone.wifiState();
                log.debug("WiFi Mode adb State: " + wifiAdbState);
                if (wifiAndroidSettingsApp.equals("false") && wifiAdbState.equals("disabled"))
                    log.debug("Wifi is disabled");
                else {
                    log.error("Unable to disable Wifi");
                    Environment.softAssert().fail("INCORRECT WIFI STATE");
                }
                phone.openNotificationBarAndDragDown();
                deviceAppUi.toggleWifiNotificationBar("on");
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                wifiAndroidSettingsApp = deviceAppUi.getWifiToggleStateAndroidSettings();
                wifiAdbState = phone.wifiState();
                log.debug("WiFi Mode adb State: " + wifiAdbState);
                if(wifiAndroidSettingsApp.equals("true") && wifiAdbState.equals("enabled"))
                    log.debug("Wifi is enabled");
                else {
                    log.error("Unable to enable Wifi");
                    Environment.softAssert().fail("INCORRECT WIFI STATE");
                }
                break;
            case "cannot":
                phone.openNotificationBarAndDragDown();
                String wifiState = deviceAppUi.getWifiStateNotificationBar();
                switch (wifiState) {
                    case "On":
                        deviceAppUi.toggleWifiNotificationBar("off");
                        phone.sendKeyEvent(AndroidKey.BACK);
                        sleepSeconds(1);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                        wifiAndroidSettingsApp = deviceAppUi.getWifiToggleStateAndroidSettings();
                        wifiAdbState = phone.wifiState();
                        log.debug("WiFi Mode adb State: " + wifiAdbState);
                        if (wifiAndroidSettingsApp.equals("false") && wifiAdbState.equals("disabled")) {
                            log.error("Wifi was disabled");
                            Environment.softAssert().fail("INCORRECT WIFI STATE");
                        }
                        else
                            log.debug("Wifi is still enabled");
                        break;
                    case "Off":
                        deviceAppUi.toggleWifiNotificationBar("on");
                        phone.sendKeyEvent(AndroidKey.BACK);
                        sleepSeconds(1);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                        wifiAndroidSettingsApp = deviceAppUi.getWifiToggleStateAndroidSettings();
                        wifiAdbState = phone.wifiState();
                        log.debug("WiFi Mode adb State: " + wifiAdbState);
                        if (wifiAndroidSettingsApp.equals("true") && wifiAdbState.equals("enabled")) {
                            log.error("Wifi was enabled");
                            Environment.softAssert().fail("INCORRECT WIFI STATE");
                        }
                        else
                            log.debug("Wifi is still disabled");
                        break;
                }
        }
        toggleEnabled = true;
    }

    @Then("^I verify I \"([^\"]*)\" toggle Wi-Fi from Android Settings on \"([^\"]*)\"$")
    public void verifyCannotToggleWifi(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        String wifiNotificationBarState;
        String wifiAdbState;

        switch (arg1.trim().toLowerCase()) {
            case "can":
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                deviceAppUi.toggleWifiAndroidSettings("off");
                phone.openNotificationBarAndDragDown();
                wifiNotificationBarState = deviceAppUi.getWifiStateNotificationBar();
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                wifiAdbState = phone.wifiState();
                log.debug("WiFi Mode adb State: " + wifiAdbState);
                if (wifiNotificationBarState.equals("Off") && wifiAdbState.equals("disabled"))
                    log.debug("Wifi is disabled");
                else {
                    log.error("Unable to disable Wifi");
                    Environment.softAssert().fail("INCORRECT WIFI STATE");
                }
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                deviceAppUi.toggleWifiAndroidSettings("on");
                phone.openNotificationBarAndDragDown();
                wifiNotificationBarState = deviceAppUi.getWifiStateNotificationBar();
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                wifiAdbState = phone.wifiState();
                log.debug("WiFi Mode adb State: " + wifiAdbState);
                if(wifiNotificationBarState.equals("On") && wifiAdbState.equals("enabled")) {
                    log.debug("Wifi is enabled");
                }
                else {
                    log.error("Unable to enable Wifi");
                    Environment.softAssert().fail("INCORRECT WIFI STATE");
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "cannot":
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                String wifiState = deviceAppUi.getWifiToggleStateAndroidSettings();
                switch (wifiState) {
                    case "true":
                        deviceAppUi.toggleWifiAndroidSettings("off");
                        phone.openNotificationBarAndDragDown();
                        wifiNotificationBarState = deviceAppUi.getWifiStateNotificationBar();
                        phone.sendKeyEvent(AndroidKey.BACK);
                        sleepSeconds(1);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        wifiAdbState = phone.wifiState();
                        log.debug("WiFi Mode adb State: " + wifiAdbState);
                        if (wifiNotificationBarState.equals("Off") && wifiAdbState.equals("disabled")) {
                            log.error("Wifi was disabled");
                            Environment.softAssert().fail("INCORRECT WIFI STATE");
                        }
                        else
                            log.debug("Wifi is still enabled");
                        break;
                    case "false":
                        deviceAppUi.toggleWifiNotificationBar("on");
                        phone.openNotificationBarAndDragDown();
                        wifiNotificationBarState = deviceAppUi.getWifiStateNotificationBar();
                        phone.sendKeyEvent(AndroidKey.BACK);
                        sleepSeconds(1);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        wifiAdbState = phone.wifiState();
                        log.debug("WiFi Mode adb State: " + wifiAdbState);
                        if (wifiNotificationBarState.equals("On") && wifiAdbState.equals("enabled")) {
                            log.error("Wifi was enabled");
                            Environment.softAssert().fail("INCORRECT WIFI STATE");
                        }
                        else
                            log.debug("Wifi is still disabled");
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
        }
        toggleEnabled = true;
    }

    @Then("^I verify I \"([^\"]*)\" toggle Airplane mode from notification bar on \"([^\"]*)\"$")
    public void verifyCanToggleAirplaneMode(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        String airplaneModeAndroidSettingsApp;
        String airplaneModeAdbState;
        WebElement airplaneModeElement = null;
        boolean airplaneModeElementFound;
        switch (arg1.trim().toLowerCase()) {
            case "can":
                phone.openNotificationBarAndDragDown();
                try {
                    if (toggleEnabled)
                        airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
                    else
                        airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));
                    airplaneModeElementFound = true;
                }
                catch (Exception exception){
                    airplaneModeElementFound = false;
                    log.debug("Couldn't find Airplane mode");
                }

                if(!airplaneModeElementFound) {
                    phone.swipeNotificationLeft();
                    try {
                        if (toggleEnabled)
                            airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
                        else
                            airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));
                    }
                    catch (Exception exception){
                        log.debug("Couldn't find Airplane mode");
                    }
                }

                deviceAppUi.toggleAirplaneModeNotificationBar("on", airplaneModeElement);
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                sleepSeconds(1);
                airplaneModeAndroidSettingsApp = deviceAppUi.getAirplaneModeToggleStateAndroidSettings();
                phone.sendKeyEvent(AndroidKey.BACK);
                airplaneModeAdbState = phone.airplaneModeState();
                log.debug("Airplane Mode adb State: " + airplaneModeAdbState);
                if (airplaneModeAndroidSettingsApp.equals("true") && airplaneModeAdbState.equals("1"))
                    log.debug("Airplane mode is enabled");
                else {
                    log.error("Unable to enable Airplane mode");
                    Environment.softAssert().fail("INCORRECT AIRPLANE MODE STATE");
                }
                phone.openNotificationBarAndDragDown();
                try {
                    if (toggleEnabled)
                        airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
                    else
                        airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));
                    airplaneModeElementFound = true;
                }
                catch (Exception exception){
                    airplaneModeElementFound = false;
                    log.debug("Couldn't find Airplane mode");
                }

                if(!airplaneModeElementFound) {
                    phone.swipeNotificationLeft();
                    try {
                        if (toggleEnabled)
                            airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
                        else
                            airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));
                    }
                    catch (Exception exception){
                        log.debug("Couldn't find Airplane mode");
                    }
                }
                deviceAppUi.toggleAirplaneModeNotificationBar("off", airplaneModeElement);
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                airplaneModeAndroidSettingsApp = deviceAppUi.getAirplaneModeToggleStateAndroidSettings();
                phone.sendKeyEvent(AndroidKey.BACK);
                airplaneModeAdbState = phone.airplaneModeState();
                log.debug("Airplane Mode adb State: " + airplaneModeAdbState);
                if(airplaneModeAndroidSettingsApp.equals("false") && airplaneModeAdbState.equals("0"))
                    log.debug("Airplane mode is disabled");
                else {
                    log.error("Unable to disable Airplane Mode");
                    Environment.softAssert().fail("INCORRECT AIRPLANE MODE STATE");
                }
                break;
            case "cannot":
                phone.openNotificationBarAndDragDown();
                String airplaneModeState = deviceAppUi.getAirplaneModeStateNotificationBar();
                switch (airplaneModeState) {
                    case "On":
                        try {
                            if (toggleEnabled)
                                airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
                            else
                                airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));
                            airplaneModeElementFound = true;
                        }
                        catch (Exception exception){
                            airplaneModeElementFound = false;
                            log.debug("Couldn't find Airplane mode");
                        }

                        if(!airplaneModeElementFound) {
                            phone.swipeNotificationLeft();
                            try {
                                if (toggleEnabled)
                                    airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
                                else
                                    airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));
                            }
                            catch (Exception exception){
                                log.debug("Couldn't find Airplane mode");
                            }
                        }
                        deviceAppUi.toggleAirplaneModeNotificationBar("off", airplaneModeElement);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        sleepSeconds(1);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                        airplaneModeAndroidSettingsApp = deviceAppUi.getAirplaneModeToggleStateAndroidSettings();
                        phone.sendKeyEvent(AndroidKey.BACK);
                        airplaneModeAdbState = phone.airplaneModeState();
                        log.debug("Airplane Mode adb State: " + airplaneModeAdbState);
                        if (airplaneModeAndroidSettingsApp.equals("false") && airplaneModeAdbState.equals("0")) {
                            log.error("Airplane mode was disabled");
                            Environment.softAssert().fail("INCORRECT AIRPLANE MODE STATE");
                        }
                        else
                            log.debug("Airplane mode is still enabled");
                        break;
                    case "Off":
                        try {
                            if (toggleEnabled)
                                airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
                            else
                                airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));
                            airplaneModeElementFound = true;
                        }
                        catch (Exception exception){
                            airplaneModeElementFound = false;
                            log.debug("Couldn't find Airplane mode");
                        }

                        if(!airplaneModeElementFound) {
                            phone.swipeNotificationLeft();
                            try {
                                if (toggleEnabled)
                                    airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
                                else
                                    airplaneModeElement = phone.appium().findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));
                            }
                            catch (Exception exception){
                                log.debug("Couldn't find Airplane mode");
                            }
                        }
                        deviceAppUi.toggleAirplaneModeNotificationBar("on", airplaneModeElement);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        sleepSeconds(1);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                        airplaneModeAndroidSettingsApp = deviceAppUi.getAirplaneModeToggleStateAndroidSettings();
                        phone.sendKeyEvent(AndroidKey.BACK);
                        airplaneModeAdbState = phone.airplaneModeState();
                        log.debug("Airplane Mode adb State: " + airplaneModeAdbState);
                        if (airplaneModeAndroidSettingsApp.equals("true") && airplaneModeAdbState.equals("1")) {
                            log.error("Airplane mode was enabled");
                            Environment.softAssert().fail("INCORRECT AIRPLANE MODE STATE");
                        }
                        else
                            log.debug("Airplane mode is still disabled");
                        break;
                }
        }
        toggleEnabled = true;
        airplaneModeElementFound = false;
    }

    @Then("^I verify I \"([^\"]*)\" toggle Airplane mode from Android Settings on \"([^\"]*)\"$")
    public void verifyCannotToggleAirplaneMode(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        String airplaneModeNotificationBarState;
        String airplaneModeAdbState;
        String airplaneModeState;

        switch (arg1.trim().toLowerCase()) {
            case "can":
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                if(phone.isLte())
                    deviceAppUi.toggleAirplaneModeAndroidSettingsLte("on");
                else
                    deviceAppUi.toggleAirplaneModeAndroidSettingsWifi("on");
                phone.sendKeyEvent(AndroidKey.BACK);
                phone.openNotificationBarAndDragDown();
                airplaneModeNotificationBarState = deviceAppUi.getAirplaneModeStateNotificationBar();
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                airplaneModeAdbState = phone.airplaneModeState();
                log.debug("Airplane Mode adb State: " + airplaneModeAdbState);
                if (airplaneModeNotificationBarState.equals("On") && airplaneModeAdbState.equals("1"))
                    log.debug("Airplane mode is enabled");
                else {
                    log.error("Unable to enable Airplane mode");
                    Environment.softAssert().fail("INCORRECT AIRPLANE MODE STATE");
                }
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                if(phone.isLte())
                    deviceAppUi.toggleAirplaneModeAndroidSettingsLte("off");
                else
                    deviceAppUi.toggleAirplaneModeAndroidSettingsWifi("off");
                phone.sendKeyEvent(AndroidKey.BACK);
                phone.openNotificationBarAndDragDown();
                airplaneModeNotificationBarState = deviceAppUi.getAirplaneModeStateNotificationBar();
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                airplaneModeAdbState = phone.airplaneModeState();
                log.debug("Airplane Mode adb State: " + airplaneModeAdbState);
                if(airplaneModeNotificationBarState.equals("Off") && airplaneModeAdbState.equals("0"))
                    log.debug("Airplane mode is disabled");
                else {
                    log.error("Unable to disable Airplane Mode");
                    Environment.softAssert().fail("INCORRECT AIRPLANE MODE STATE");
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "cannot":
                phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
                airplaneModeState = deviceAppUi.getAirplaneModeToggleStateAndroidSettings();
                switch (airplaneModeState) {
                    case "true":
                        if(phone.isLte())
                            deviceAppUi.toggleAirplaneModeAndroidSettingsLte("off");
                        else
                            deviceAppUi.toggleAirplaneModeAndroidSettingsWifi("off");
                        phone.sendKeyEvent(AndroidKey.BACK);
                        phone.openNotificationBarAndDragDown();
                        airplaneModeNotificationBarState = deviceAppUi.getAirplaneModeStateNotificationBar();
                        phone.sendKeyEvent(AndroidKey.BACK);
                        sleepSeconds(1);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        airplaneModeAdbState = phone.airplaneModeState();
                        log.debug("Airplane Mode adb State: " + airplaneModeAdbState);
                        if (airplaneModeNotificationBarState.equals("Off") && airplaneModeAdbState.equals("0")) {
                            log.error("Airplane mode was disabled");
                            Environment.softAssert().fail("INCORRECT AIRPLANE MODE STATE");
                        }
                        else
                            log.debug("Airplane mode is still enabled");
                        break;
                    case "false":
                        if(phone.isLte())
                            deviceAppUi.toggleAirplaneModeAndroidSettingsLte("on");
                        else
                            deviceAppUi.toggleAirplaneModeAndroidSettingsWifi("on");
                        phone.sendKeyEvent(AndroidKey.BACK);
                        phone.openNotificationBarAndDragDown();
                        airplaneModeNotificationBarState = deviceAppUi.getAirplaneModeStateNotificationBar();
                        phone.sendKeyEvent(AndroidKey.BACK);
                        sleepSeconds(1);
                        phone.sendKeyEvent(AndroidKey.BACK);
                        airplaneModeAdbState = phone.airplaneModeState();
                        log.debug("Airplane Mode adb State: " + airplaneModeAdbState);
                        if (airplaneModeNotificationBarState.equals("On") && airplaneModeAdbState.equals("1")) {
                            log.error("Airplane mode was enabled");
                            Environment.softAssert().fail("INCORRECT AIRPLANE MODE STATE");
                        }
                        else
                            log.debug("Airplane mode is still disabled");
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
        }
        toggleEnabled = true;
    }

    @Then("^I verify Quick settings tiles are \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyCanToggleQuickSettings(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();

        switch (arg1.trim().toLowerCase()) {
            case "visible":
                if(phone.isWifiOnly()) {
                    phone.openNotificationBarAndDragDown();
                    try {
                        if(deviceAppUi.isWifiIconNotificationBarVisible() &&
                                deviceAppUi.isBluetoothIconNotificationBarVisible() &&
                                deviceAppUi.isDoNotDisturbIconNotificationBarVisible() &&
                                deviceAppUi.isFlashlightIconNotificationBarVisible() &&
                                deviceAppUi.isAutoRotateIconNotificationBarVisible() &&
                                deviceAppUi.isBatterySaverIconNotificationBarVisible() &&
                                deviceAppUi.isAirplaneModeIconNotificationBarVisible() &&
                                deviceAppUi.isCastIconNotificationBarVisible() &&
                                deviceAppUi.isHighTouchIconNotificationBarVisible())
                            log.debug("Quick Settings tiles icons visible");
                    } catch(Exception e){
                        log.error("Quick Settings tiles icons not visible");
                        Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                    sleepSeconds(1);
                    phone.sendKeyEvent(AndroidKey.BACK);
                }
                else {
                    phone.openNotificationBarAndDragDown();
                    try {
                        if(deviceAppUi.isWifiIconNotificationBarVisible() &&
                                deviceAppUi.isBluetoothIconNotificationBarVisible() &&
                                deviceAppUi.isDoNotDisturbIconNotificationBarVisible() &&
                                deviceAppUi.isFlashlightIconNotificationBarVisible() &&
                                deviceAppUi.isAutoRotateIconNotificationBarVisible() &&
                                deviceAppUi.isBatterySaverIconNotificationBarVisible() &&
                                deviceAppUi.isAirplaneModeIconNotificationBarVisible() &&
                                deviceAppUi.isCastIconNotificationBarVisible() &&
                                deviceAppUi.isMobileDataIconNotificationBarVisible())
                            log.debug("Quick Settings tiles icons visible");
                    } catch(Exception e){
                        log.error("Quick Settings tiles icons not visible");
                        Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                    }
                    phone.swipeNotificationLeft();

                    try {
                        if(deviceAppUi.isHighTouchIconNotificationBarVisible())
                            log.debug("Quick Settings tiles icons visible");
                    } catch(Exception e){
                        log.error("Quick Settings tiles icons not visible");
                        Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                    sleepSeconds(1);
                    phone.sendKeyEvent(AndroidKey.BACK);
                }

                break;
            case "not visible":
            case "invisible":
                if(phone.isWifiOnly()) {
                    phone.openNotificationBarAndDragDown();
                    try {
                        if(deviceAppUi.isWifiIconNotificationBarVisible() &&
                                deviceAppUi.isBluetoothIconNotificationBarVisible() &&
                                deviceAppUi.isDoNotDisturbIconNotificationBarVisible() &&
                                deviceAppUi.isFlashlightIconNotificationBarVisible() &&
                                deviceAppUi.isAutoRotateIconNotificationBarVisible() &&
                                deviceAppUi.isBatterySaverIconNotificationBarVisible() &&
                                deviceAppUi.isAirplaneModeIconNotificationBarVisible() &&
                                deviceAppUi.isCastIconNotificationBarVisible() &&
                                deviceAppUi.isHighTouchIconNotificationBarVisible()){
                            log.error("Quick Settings tiles icons visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                    } catch(Exception e){
                        log.debug("Quick Settings tiles icons not visible");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                    sleepSeconds(1);
                    phone.sendKeyEvent(AndroidKey.BACK);
                }
                else {
                    phone.openNotificationBarAndDragDown();
                    try {
                        if(deviceAppUi.isWifiIconNotificationBarVisible() &&
                                deviceAppUi.isBluetoothIconNotificationBarVisible() &&
                                deviceAppUi.isDoNotDisturbIconNotificationBarVisible() &&
                                deviceAppUi.isFlashlightIconNotificationBarVisible() &&
                                deviceAppUi.isAutoRotateIconNotificationBarVisible() &&
                                deviceAppUi.isBatterySaverIconNotificationBarVisible() &&
                                deviceAppUi.isAirplaneModeIconNotificationBarVisible() &&
                                deviceAppUi.isCastIconNotificationBarVisible() &&
                                deviceAppUi.isMobileDataIconNotificationBarVisible()
                        )
                        {
                            log.error("Quick Settings tiles icons visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                    } catch(Exception e){
                        log.debug("Quick Settings tiles icons not visible");
                    }
                    phone.swipeNotificationLeft();
                    try {
                        if(deviceAppUi.isHighTouchIconNotificationBarVisible()) {
                            log.error("Quick Settings tiles icons visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                    } catch(Exception e){
                        log.debug("Quick Settings tiles icons not visible");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                    sleepSeconds(1);
                    phone.sendKeyEvent(AndroidKey.BACK);
                }
                break;
        }
    }

    @Then("^I verify Quick settings tiles \"([^\"]*)\" icon is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyQuickSettingsTilesIcons(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        switch (arg1.trim()) {
            case "Wi-Fi":
                phone.openNotificationBarAndDragDown();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isWifiIconNotificationBarVisible())
                                log.debug("Wi-Fi icon visible");
                        } catch(Exception e){
                            log.error("Wi-Fi icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isWifiIconNotificationBarVisible() ) {
                                log.error("Wi-Fi icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Wi-Fi icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Bluetooth":
                phone.openNotificationBarAndDragDown();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isBluetoothIconNotificationBarVisible())
                                log.debug("Bluetooth icon visible");
                        } catch(Exception e){
                            log.error("Bluetooth icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isBluetoothIconNotificationBarVisible() ) {
                                log.error("Bluetooth icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Bluetooth icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Do not disturb":
                phone.openNotificationBarAndDragDown();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isDoNotDisturbIconNotificationBarVisible())
                                log.debug("Do not disturb icon visible");
                        } catch(Exception e){
                            log.error("Do not disturb icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isDoNotDisturbIconNotificationBarVisible() ) {
                                log.error("Do not disturb icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Do not disturb icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Flashlight":
                phone.openNotificationBarAndDragDown();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isFlashlightIconNotificationBarVisible())
                                log.debug("Flashlight icon visible");
                        } catch(Exception e){
                            log.error("Flashlight icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isFlashlightIconNotificationBarVisible() ) {
                                log.error("Flashlight icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Flashlight icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Rotation lock":
                phone.openNotificationBarAndDragDown();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isAutoRotateIconNotificationBarVisible())
                                log.debug("Rotation lock icon visible");
                        } catch(Exception e){
                            log.error("Rotation lock icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isAutoRotateIconNotificationBarVisible() ) {
                                log.error("Rotation lock icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Rotation lock icon not visible");
                        }
                        break;

                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Battery saver":
                phone.openNotificationBarAndDragDown();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isBatterySaverIconNotificationBarVisible())
                                log.debug("Battery saver icon visible");
                        } catch(Exception e){
                            log.error("Battery saver icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isBatterySaverIconNotificationBarVisible() ) {
                                log.error("Battery saver icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Battery saver icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Mobile data":
                if(phone.isLte()) {
                    phone.openNotificationBarAndDragDown();
                    switch (arg2.trim().toLowerCase()) {
                        case "visible":
                            try {
                                if (deviceAppUi.isMobileDataIconNotificationBarVisible())
                                    log.debug("Mobile data icon visible");
                            } catch (Exception e) {
                                log.error("Mobile data icon not visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                            break;
                        case "not visible":
                        case "invisible":
                            try {
                                if (deviceAppUi.isMobileDataIconNotificationBarVisible()) {
                                    log.error("Mobile data icon visible");
                                    Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                                }
                            } catch (Exception e) {
                                log.debug("Mobile data icon not visible");
                            }
                            break;
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                    sleepSeconds(1);
                    phone.sendKeyEvent(AndroidKey.BACK);
                }
                break;

            case "Airplane mode":
                phone.openNotificationBarAndDragDown();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isAirplaneModeIconNotificationBarVisible())
                                log.debug("Airplane mode icon visible");
                        } catch(Exception e){
                            log.error("Airplane mode icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isAirplaneModeIconNotificationBarVisible() ) {
                                log.error("Airplane mode icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Airplane mode icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Cast":
                phone.openNotificationBarAndDragDown();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isCastIconNotificationBarVisible())
                                log.debug("Cast icon visible");
                        } catch(Exception e){
                            log.error("Cast icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isCastIconNotificationBarVisible() ) {
                                log.error("Cast icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Cast icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "High touch":
                if(phone.isWifiOnly())
                    phone.openNotificationBarAndDragDown();
                else {
                    phone.openNotificationBarAndDragDown();
                    phone.swipeNotificationLeft();
                }
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isHighTouchIconNotificationBarVisible())
                                log.debug("High touch icon visible");
                        } catch(Exception e){
                            log.error("High touch icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isHighTouchIconNotificationBarVisible() ) {
                                log.error("High touch icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("High touch icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Night light":
                phone.openNotificationBarAndDragDown();
                deviceAppUi.editButtonNotifications();
                phone.flingForward();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isNightLightIconNotificationBarVisible())
                                log.debug("Night light icon visible");
                        } catch(Exception e){
                            log.error("Night light icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isNightLightIconNotificationBarVisible() ) {
                                log.error("Night light icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Night light icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Location":
                phone.openNotificationBarAndDragDown();
                deviceAppUi.editButtonNotifications();
                phone.flingForward();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isLocationIconNotificationBarVisible())
                                log.debug("Location icon visible");
                        } catch(Exception e){
                            log.error("Location icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isLocationIconNotificationBarVisible() ) {
                                log.error("Location icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Location icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Invert colors":
                phone.openNotificationBarAndDragDown();
                deviceAppUi.editButtonNotifications();
                phone.flingForward();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isInvertColorsIconNotificationBarVisible())
                                log.debug("Invert colors icon visible");
                        } catch(Exception e){
                            log.error("Invert colors icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isInvertColorsIconNotificationBarVisible() ) {
                                log.error("Invert colors icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Invert colors icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Data saver":
                phone.openNotificationBarAndDragDown();
                deviceAppUi.editButtonNotifications();
                phone.flingForward();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isDataSaverNotificationBarVisible())
                                log.debug("Data saver icon visible");
                        } catch(Exception e){
                            log.error("Data saver icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isDataSaverNotificationBarVisible() ) {
                                log.error("Data saver icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Data saver icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;

            case "Hotspot":
                phone.openNotificationBarAndDragDown();
                deviceAppUi.editButtonNotifications();
                phone.flingForward();
                switch (arg2.trim().toLowerCase()) {
                    case "visible":
                        try {
                            if(deviceAppUi.isHotspotIconNotificationBarVisible())
                                log.debug("Hotspot icon visible");
                        } catch(Exception e){
                            log.error("Hotspot icon not visible");
                            Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                        }
                        break;
                    case "not visible":
                    case "invisible":
                        try {
                            if(deviceAppUi.isHotspotIconNotificationBarVisible() ) {
                                log.error("Hotspot icon visible");
                                Environment.softAssert().fail("INCORRECT QUICK SETTINGS TILES ICONS");
                            }
                        } catch(Exception e){
                            log.debug("Hotspot icon not visible");
                        }
                        break;
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
        }
    }

    @Then("^I verify Notification shade settings gear is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyVisibilityNotificationShadeSettingsGear(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();

        switch (arg1.trim().toLowerCase()) {
            case "visible":
                phone.openNotificationBarAndDragDown();
                try {
                    if(deviceAppUi.isSettingsButtonNotificationsVisible())
                        log.debug("Notification shade settings gear is visible");
                } catch(Exception e){
                    log.error("Notification shade settings gear is not visible");
                    Environment.softAssert().fail("UNEXPECTED DEVICE SETTINGS APP'S ICON VISIBILITY");
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "not visible":
            case "invisible":
                phone.openNotificationBarAndDragDown();
                try {
                    if(deviceAppUi.isSettingsButtonNotificationsVisible()) {
                        log.error("Notification shade settings gear is visible");
                        Environment.softAssert().fail("UNEXPECTED DEVICE SETTINGS APP'S ICON VISIBILITY");
                    }
                } catch(Exception e){
                    log.debug("Notification shade settings gear is not visible");
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                sleepSeconds(1);
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
        }
    }

    @Then("^I verify time zone is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyTimeZoneConfigurability(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        setDeviceAppSwitch("Automatic time zone", "off", arg2);
        switch (arg1.trim().toLowerCase()) {
            case "configurable":
                if(deviceAppUi.timeZoneLabelEnabled().equals("true") && deviceAppUi.timeZoneValueEnabled().equals("true"))
                    log.debug("Time zone is configurable");
                else {
                    log.error("Time zone is not configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                break;
            case "not configurable":
                if(deviceAppUi.timeZoneLabelEnabled().equals("false") && deviceAppUi.timeZoneValueEnabled().equals("false"))
                    log.debug("Time zone is not configurable");
                else {
                    log.error("Time zone is configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                break;
        }
        setDeviceAppSwitch("Automatic time zone", "on", arg2);
    }

    @Then("^I verify time format is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyTimeFormatConfigurability(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField("Time format".trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, "Time format".trim());
        String timeFormatStateAndroidSettings;
        if (field != null) {
            if (field.hasValueElement()) {
                assert heading != null;
                field.scrollIntoExactView(heading);
            }
        }
        switch (arg1.trim().toLowerCase()) {
            case "configurable":
                if (deviceAppUi.timeFormatLabelEnabled().equals("true") && deviceAppUi.timeFormatValueEnabled().equals("true"))
                    log.debug("Time format is configurable");
                else {
                    log.error("Time format is not configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                phone.forceStopApp("com.android.settings");
                phone.startApp("android.settings.DATE_SETTINGS");
                timeFormatStateAndroidSettings = deviceAppUi.getTimeFormatStateAndroidSettings();
                if (timeFormatStateAndroidSettings.equals("true"))
                    log.debug("Time format is configurable in Android Settings");
                else {
                    log.error("Time format is not configurable in Android Settings");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "not configurable":
                if (deviceAppUi.timeFormatLabelEnabled().equals("false") && deviceAppUi.timeFormatValueEnabled().equals("false"))
                    log.debug("Time format is not configurable");
                else {
                    log.error("Time format is configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                phone.forceStopApp("com.android.settings");
                phone.startApp("android.settings.DATE_SETTINGS");
                timeFormatStateAndroidSettings = deviceAppUi.getTimeFormatStateAndroidSettings();
                if (timeFormatStateAndroidSettings.equals("false"))
                    log.debug("Time format is not configurable in Android Settings");
                else {
                    log.error("Time format is configurable in Android Settings");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
        }
    }

    @Then("^I verify automatic time zone toggle is \"([^\"]*)\" from android settings on \"([^\"]*)\"$")
    public void verifyAutomaticTimeZoneToggle(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(AUTOMATIC_TIME_ZONE.title().trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, AUTOMATIC_TIME_ZONE.title().trim());

        if (field != null) {
            if (field.hasControlElement()) {
                assert heading != null;
                field.scrollIntoExactView(heading);
            }
        }
        switch (arg1.trim().toLowerCase()) {
            case "configurable":
                if (deviceAppUi.getAutomaticTimeZoneControl().equals("true"))
                    log.debug("Automatic Time zone is configurable");
                else {
                    log.error("Automatic Time zone is not configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                if(phone.isLte()) {
                    phone.startApp("android.settings.DATE_SETTINGS");
                    if (deviceAppUi.getAutomaticTimeZoneStateAndroidSettings().equals("true"))
                        log.debug("Automatic Time zone is configurable in Android Settings");
                    else {
                        log.error("Automatic Time zone is not configurable in Android Settings");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                }
                break;
            case "not configurable":
                if (deviceAppUi.getAutomaticTimeZoneControl().equals("false"))
                    log.debug("Automatic Time zone is not configurable");
                else {
                    log.error("Automatic Time zone is configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                if(phone.isLte()) {
                    phone.startApp("android.settings.DATE_SETTINGS");
                    if (deviceAppUi.getAutomaticTimeZoneStateAndroidSettings().equals("false"))
                        log.debug("Automatic Time zone is not configurable in Android Settings");
                    else {
                        log.error("Automatic Time zone is configurable in Android Settings");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                }
                break;
        }
    }

    @Then("^I verify emergency call button is \"([^\"]*)\" on lock screen on \"([^\"]*)\"$")
    public void verifyEmergencyCallButtonVisibility(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        if(phone.isWifiOnly()) {
            DeviceAppUi deviceAppUi = phone.getDeviceAppUi();

            switch (arg1.trim().toLowerCase()) {
                case "visible":
                    phone.appium().lockDevice();
                    phone.wakeUpScreen();
                    try {
                        if (deviceAppUi.isEmergencyCallButtonVisibleOnLockScreen())
                            log.debug("Emergency call button is visible");
                    } catch (Exception e) {
                        log.error("Emergency call button is not visible");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    }
                    phone.unlockScreen("1111");
                    phone.longPressKey("26");
                    try {
                        phone.appium().findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/message') and contains(@text, 'Emergency')]");
                        log.debug("Emergency button in the power menu is visible");
                    } catch (Exception e) {
                        log.error("Emergency button in the power menu is not visible");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                    break;
                case "not visible":
                case "invisible":
                    phone.appium().lockDevice();
                    phone.wakeUpScreen();
                    try {
                        if (deviceAppUi.isEmergencyCallButtonVisibleOnLockScreen()) {
                            log.error("Emergency call button is visible");
                            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                        }
                    } catch (Exception e) {
                        log.debug("Emergency call button is not visible");
                    }
                    phone.unlockScreen("1111");
                    phone.longPressKey("26");
                    try {
                        phone.appium().findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/message') and contains(@text, 'Emergency')]");
                        log.error("Emergency button in the power menu is visible");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    } catch (Exception e) {
                        log.debug("Emergency button in the power menu is not visible");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                    break;
            }
        }
    }

    @When("^I unlock the Device app Developer Options option on \"([^\"]*)\"$")
    public void selectOverflowOption(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isControlPresent()) {
            deviceAppUi.clickOverflowMenu();
            found = field.selectTextMenuOption("About");
            if (found) {
                Point position = deviceAppUi.getDeviceAppIconPosition();
                phone.tapOnScreenFor10Seconds(position.getX(), position.getY());
                deviceAppUi.clickExposeButton(phone);
                log.debug("Enabled Device app developer options");
                deviceAppUi.goBack();
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @Then("^I verify time zone is \"([^\"]*)\" from android settings on \"([^\"]*)\"$")
    public void verifyAutomaticTimeZone(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(AUTOMATIC_TIME_ZONE.title().trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, AUTOMATIC_TIME_ZONE.title().trim());

        if (field != null) {
            if (field.hasControlElement()) {
                assert heading != null;
                field.scrollIntoExactView(heading);
            }
        }
        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.timeZoneLabelEnabled().equals("false") && deviceAppUi.timeZoneValueEnabled().equals("false"))
                    log.debug("Time zone is configurable");
                else {
                    log.error("Time zone is not configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                if(phone.isLte()) {
                    phone.startApp("android.settings.DATE_SETTINGS");
                    if (deviceAppUi.getAutomaticTimeZoneSwitchAndroidSettings().equals("true"))
                        log.debug("Time zone is enabled in Android Settings");
                    else {
                        log.error("Time zone is not enabled in Android Settings");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.timeZoneLabelEnabled().equals("true") && deviceAppUi.timeZoneValueEnabled().equals("true"))
                    log.debug("Time zone is not configurable");
                else {
                    log.error("Time zone is configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                if(phone.isLte()) {
                    phone.startApp("android.settings.DATE_SETTINGS");
                    if (deviceAppUi.getAutomaticTimeZoneSwitchAndroidSettings().equals("false"))
                        log.debug("Time zone is not enabled in Android Settings");
                    else {
                        log.error("Time zone is enabled in Android Settings");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    }
                    phone.sendKeyEvent(AndroidKey.BACK);
                }
                break;
        }
    }

    @Then("^I verify time zone is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyTimeZone(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.startApp("android.settings.DATE_SETTINGS");

        switch (arg1.trim()) {
            case "US/Alaska":
                if (deviceAppUi.getTimeZoneValueAndroidSettings().equals("GMT-08:00"))
                    log.debug("Time zone changed to Alaska");
                else {
                    log.error("Time zone couldn't change to Alaska");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                break;
            case "US/Central":
                if (deviceAppUi.getTimeZoneValueAndroidSettings().equals("GMT-05:00"))
                    log.debug("Time zone changed to Central");
                else {
                    log.error("Time zone couldn't change to Central");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                break;

            case "US/Mountain":
                if (deviceAppUi.getTimeZoneValueAndroidSettings().equals("GMT-06:00"))
                    log.debug("Time zone changed to Mountain");
                else {
                    log.error("Time zone couldn't change to Mountain");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                break;

            case "US/Eastern":
                if (deviceAppUi.getTimeZoneValueAndroidSettings().equals("GMT-04:00"))
                    log.debug("Time zone changed to Eastern");
                else {
                    log.error("Time zone couldn't change to Eastern");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                break;

            case "US/Pacific":
                if (deviceAppUi.getTimeZoneValueAndroidSettings().equals("GMT-07:00"))
                    log.debug("Time zone changed to Pacific");
                else {
                    log.error("Time zone couldn't change to Pacific");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                break;

            case "US/Hawaii":
                if (deviceAppUi.getTimeZoneValueAndroidSettings().equals("GMT-09:00"))
                    log.debug("Time zone changed to Hawaii");
                else {
                    log.error("Time zone couldn't change to Hawaii");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.HOME);
    }

    @Then("^I verify time format is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyTimeFormat(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.DATE_SETTINGS");
        switch (arg1.trim().toLowerCase()) {
            case "12 hours":
                if (deviceAppUi.getTimeFormatSwitchAndroidSettings().equals("false"))
                    log.debug("Time format changed to 12 hours");
                else {
                    log.error("Time format couldn't change to 12 hours");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "24 hours":
                if (deviceAppUi.getTimeFormatSwitchAndroidSettings().equals("true"))
                    log.debug("Time format changed to 24 hours");
                else {
                    log.error("Time format couldn't change to 24 hours");
                    Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                }
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
        }
    }

    @Then("^I verify device info is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyDeviceInfo(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();

        phone.openNotificationBar();
        if(deviceAppUi.getDeviceInfoNotificationBar().equals(arg1))
            log.debug("Device info showed up in the notification bar");
        else {
            log.error("Device info did not show up in the notification bar");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.lockScreen();
        phone.wakeUpScreen();
        if(deviceAppUi.getDeviceInfoLockScreen().equals(arg1))
            log.debug("Device info showed up on the lock screen");
        else {
            log.error("Device info did not show up on the lock screen");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        phone.unlockScreen("1111");
    }

    @Then("^I verify device info is not set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyDeviceInfoNotSet(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();

        phone.openNotificationBar();
        if(deviceAppUi.getDeviceInfoNotificationBar().equals(arg1)) {
            log.error("Device info showed up in the notification bar");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        else
            log.debug("Device info did not show up in the notification bar");
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.lockScreen();
        phone.wakeUpScreen();
        if(deviceAppUi.getDeviceInfoLockScreen().equals(arg1)) {
            log.error("Device info showed up on the lock screen");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        else
            log.debug("Device info did not show up on the lock screen");
        phone.unlockScreen("1111");
    }

    @Then("^I verify device info is not visible on \"([^\"]*)\"$")
    public void verifyDeviceInfoNotVisible(String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.openNotificationBar();
        try {
            if(deviceAppUi.isDeviceInfoVisibleInNotificationBar()) {
                log.error("Device Info Still Visible in notification bar");
                Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
            }
        } catch(Exception e){
            log.debug("Device Info Not Visible in notification bar");
        }
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.lockScreen();
        phone.wakeUpScreen();
        try {
            if(deviceAppUi.isDeviceInfoVisibleOnLockScreen()) {
                log.error("Device Info Still Visible on lock screen bar");
                Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
            }
        } catch(Exception e){
            log.debug("Device Info Not Visible on lock screen");
        }
        phone.unlockScreen("1111");
    }

    @Then("^I verify phone's time changes to \"([^\"]*)\" value on \"([^\"]*)\"$")
    public void verifyTimeChange(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        if (phone.isWifiOnly()) {
            String phoneTime = phone.currentDateTimeFormatForNtpValidation();
            Date today = Calendar.getInstance().getTime();
            SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
            String javaTime = formatter.format(today);

            switch (arg1) {
                case "incorrect":
                case "wrong":
                    log.debug("Phone time: " + phoneTime);
                    log.debug("Java time: " + javaTime);
                    if (phoneTime.equals(javaTime)) {
                        log.error("NTP server change did not change phone's time");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    } else
                        log.debug("NTP server changed phone's time");
                    break;

                case "correct":
                    log.debug("Phone time: " + phoneTime);
                    log.debug("Java time: " + javaTime);
                    if (phoneTime.equals(javaTime))
                        log.debug("NTP server changed back phone's time");
                    else {
                        log.error("NTP server change did not change back phone's time");
                        Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
                    }
                    break;
            }
        }
    }

    @Then("^I verify device name is changed to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyDeviceNameChange(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        boolean found;
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(ABOUT_PHONE.title().trim().toLowerCase());
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS, SETTINGS_MAIN);
        sleepSeconds(2);
        if (field != null)
            field.scrollIntoExactViewAttribute(ABOUT_PHONE.title());
        phone.flingForward();

        String aboutPhone = phone.appium().findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'About phone')]/parent::*/android.widget.TextView[2]").getText();
        found = aboutPhone.equals(arg1);
        if(found)
            log.debug("Device Name changed in Android Settings Page");
        else {
            log.error("Device Name did not change in Android Settings Page");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.DEVICE_INFO_SETTINGS");
        if (deviceAppUi.getDeviceNameBluetoothAboutPhonePage().equals(arg1)) {
            log.debug("Device Name changed in About Phone Page");
        }
        else {
            log.error("Device Name did not change in About Phone Page");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }

        phone.sendKeyEvent(AndroidKey.BACK);

        phone.forceStopApp("com.android.settings");
        phone.toggleBluetooth(true);
        sleepSeconds(5);
        phone.startApp("android.settings.BLUETOOTH_SETTINGS");

        if (deviceAppUi.getDeviceNameBluetoothScreen().contains(arg1)) {
            log.debug("Device Name changed in Connected Devices Page");
        }
        else {
            log.error("Device Name did not change in Connected Devices Page");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }

        deviceAppUi.tapOnConnectionPreferences();
        deviceAppUi.tapOnBluetooth();
        if (deviceAppUi.getDeviceNameBluetoothAboutPhonePage().contains(arg1)) {
            log.debug("Device Name changed on Bluetooth Screen");
        }
        else {
            log.error("Device Name did not change on Bluetooth Screen");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
        phone.toggleWifiSvc(false);
        sleepSeconds(5);
        deviceAppUi.tapOnWifiText();
        deviceAppUi.tapOnWiFiPreferences();
        phone.toggleWifiSvc(true);
        sleepSeconds(5);
        deviceAppUi.tapOnAdvanced();
        sleepSeconds(2);
        deviceAppUi.tapOnWiFiDirect();
        phone.flingToBeginning();
        boolean deviceNameFound = false;
        List<WebElement> options = phone.appium().findElementsById("android:id/title");
        for (WebElement element : options) {
            if(element.getText().equals(arg1))
                deviceNameFound = true;
        }
        if (deviceNameFound) {
            log.debug("Device Name changed in WiFi Direct Page");
        } else {
            log.error("Device Name did not change in WiFi Direct Page");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify device name is changed to default on \"([^\"]*)\"$")
    public void verifyDeviceNameChangeDefault(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        boolean found;
        String phoneModel;
        if (phone.getModel().toLowerCase().contains("saturn"))
            phoneModel = "Cisco " + phone.getSerialNumber();
        else
            phoneModel = "Spectralink " + phone.getSerialNumber();
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(ABOUT_PHONE.title().trim().toLowerCase());
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS, SETTINGS_MAIN);
        sleepSeconds(2);
        if (field != null)
            field.scrollIntoExactViewAttribute(ABOUT_PHONE.title());
        phone.flingForward();
        String aboutPhone = phone.appium().findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'About phone')]/parent::*/android.widget.TextView[2]").getText();
        found = aboutPhone.equals(phoneModel);
        if(found)
            log.debug("Device Name changed in Android Settings Page");
        else {
            log.error("Device Name did not change in Android Settings Page");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.HOME);

        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.DEVICE_INFO_SETTINGS");
        if (deviceAppUi.getDeviceNameBluetoothAboutPhonePage().equals(phoneModel)) {
            log.debug("Device Name changed in About Phone Page");
        } else {
            log.error("Device Name did not change in About Phone Page");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }

        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.HOME);

        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.BLUETOOTH_SETTINGS");

        if (deviceAppUi.getDeviceNameBluetoothScreen().contains(phoneModel)) {
            log.debug("Device Name changed in Connected Devices Page");
        } else {
            log.error("Device Name did not change in Connected Devices Page");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }

        deviceAppUi.tapOnConnectionPreferences();
        deviceAppUi.tapOnBluetooth();
        if (deviceAppUi.getDeviceNameBluetoothAboutPhonePage().contains(phoneModel)) {
            log.debug("Device Name changed on Bluetooth Screen");
        } else {
            log.error("Device Name did not change on Bluetooth Screen");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.HOME);

        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS, SETTINGS_WIFI);
        phone.toggleWifiSvc(false);
        sleepSeconds(5);
        deviceAppUi.tapOnWifiText();
        deviceAppUi.tapOnWiFiPreferences();
        phone.toggleWifiSvc(true);
        sleepSeconds(5);
        deviceAppUi.tapOnAdvanced();
        sleepSeconds(2);
        deviceAppUi.tapOnWiFiDirect();
        phone.flingToBeginning();

        boolean deviceNameFound = false;
        List<WebElement> options = phone.appium().findElementsById("android:id/title");
        for (WebElement element : options) {
            if(element.getText().equals(phoneModel))
                deviceNameFound = true;
        }

        if (deviceNameFound) {
            log.debug("Device Name changed in WiFi Direct Page");
        } else {
            log.error("Device Name did not change in WiFi Direct Page");
            Environment.softAssert().fail("INCORRECT DEVICE SETTINGS APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.HOME);
    }

    @When("^I enter the \"([^\"]*)\" app's package name in the Device app edit text box on \"([^\"]*)\"$")
    public void whitelistApp(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        AndroidPhone.Application app = phone.findApplication(arg1.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        String packageName = app.getPackage();
        ConfigUiField field = deviceAppUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = deviceAppUi.getField(EDIT_TEXT);
            field.getControlElement().clear();
            field.enter(packageName.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg2);
        }
    }

    @Then("^the Device app Battery optimization value is set to \"([^\"]*)\"'s package name on \"([^\"]*)\"$")
    public void verifyWhitelistApp(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        AndroidPhone.Application app = phone.findApplication(arg1.trim());
        String packageName = app.getPackage();
        ConfigUiField field = deviceAppUi.getField(BATTERY_OPTIMIZATION_WHITELIST.title().trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, BATTERY_OPTIMIZATION_WHITELIST.title().trim());

        if (field.hasValueElement()) {
            assert heading != null;
            field.scrollIntoExactView(heading);
        }
        if (field.isValuePresent()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(packageName.trim().toLowerCase())) {
                log.debug("Verified field Battery optimization was set to '{}''s package name", arg1);
            } else {
                log.error("Field Battery optimization was not set to '{}''s package name on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
            }
        }
        else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^I verify the \"([^\"]*)\" app is not optimized on \"([^\"]*)\"$")
    public void whitelistAppVerification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS");
        deviceAppUi.selectBatteryOptimizationSpinner();
        deviceAppUi.selectNotOptimized();
        sleepSeconds(7);
        if(phone.selectScrollableMenuOptionBatteryOptimization(arg1.trim())) {
            log.debug("App '{}' showed up in the Not Optimized list on '{}'", arg1, arg2);
        } else {
            log.error("App '{}' did not show up in the Not Optimized list on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify the \"([^\"]*)\" app is whitelisted on \"([^\"]*)\"$")
    public void whitelistAppVerificationAdb(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        AndroidPhone.Application app = phone.findApplication(arg1.trim());
        String packageName = app.getPackage();
        boolean isWhitelisted = phone.isWhitelisted(packageName);

        if(isWhitelisted)
            log.debug(arg1 + " app is whitelisted");
        else {
            log.error(arg1 + " app is not whitelisted");
            Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
        }
    }

    @Then("^I verify the \"([^\"]*)\" app is not whitelisted on \"([^\"]*)\"$")
    public void whitelistAppVerificationAdbNot(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        AndroidPhone.Application app = phone.findApplication(arg1.trim());
        String packageName = app.getPackage();
        boolean isWhitelisted = phone.isWhitelisted(packageName);

        if(isWhitelisted) {
            log.error(arg1 + " app is whitelisted");
            Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
        }
        else
            log.debug(arg1 + " app is not whitelisted");
    }

    @Then("^I verify the \"([^\"]*)\" app does not appear in the Not Optimized list on \"([^\"]*)\"$")
    public void whitelistAppVerificationNot(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS");
        deviceAppUi.selectBatteryOptimizationSpinner();
        deviceAppUi.selectNotOptimized();
        sleepSeconds(7);
        if(phone.selectScrollableMenuOptionBatteryOptimization(arg1.trim())) {
            log.error("App '{}' showed up in the Not Optimized list on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT DEVICE APP FIELD VALUE");
        }
        else {
            log.debug("App '{}' did not show up in the Not Optimized list on '{}'", arg1, arg2);
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Battery saver mode is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void batterySaverMode(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();

        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.BATTERY_SAVER_SETTINGS");

        switch (arg1.trim().toLowerCase()) {
            case "configurable":
                if(deviceAppUi.getBatterySaverButtonAndroidSettingsState().equals("true"))
                    log.debug("Battery saver mode is configurable");
                else {
                    log.error("Battery saver mode is not configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not configurable":
                if(deviceAppUi.getBatterySaverButtonAndroidSettingsState().equals("false"))
                    log.debug("Battery saver mode is not configurable");
                else {
                    log.error("Battery saver mode is configurable");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Skeyboard is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void sKeyboard(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS);

        ConfigUiField field = deviceAppUi.getField(SYSTEM.title().trim().toLowerCase());
        if (field != null) {
            field.scrollIntoExactViewAttribute(SYSTEM.title());
            field.tap();
        }
        deviceAppUi.tapOnLanguagesInput();
        deviceAppUi.tapOnVirtualKeyboard();
        deviceAppUi.tapOnManageKeyboards();

        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getSKeyboardStateAndroidSettings().equals("true"))
                    log.debug("SKeyboard is enabled");
                else {
                    log.error("SKeyboard is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getSKeyboardStateAndroidSettings().equals("false"))
                    log.debug("SKeyboard is not enabled");
                else {
                    log.error("SKeyboard is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Google voice typing is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void googleVoiceTyping(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS);

        ConfigUiField field = deviceAppUi.getField(SYSTEM.title().trim().toLowerCase());
        if (field != null) {
            field.scrollIntoExactViewAttribute(SYSTEM.title());
            field.tap();
        }
        deviceAppUi.tapOnLanguagesInput();
        deviceAppUi.tapOnVirtualKeyboard();
        deviceAppUi.tapOnManageKeyboards();

        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getGoogleVoiceTypingStateAndroidSettings().equals("true"))
                    log.debug("Google voice typing is enabled");
                else {
                    log.error("Google voice typing is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getGoogleVoiceTypingStateAndroidSettings().equals("false"))
                    log.debug("Google voice typing is not enabled");
                else {
                    log.error("Google voice typing is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Time to sleep after inactivity is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void timeToSleepAfterInactivity(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.DISPLAY_SETTINGS");
        deviceAppUi.tapOnAdvanced();
        phone.flingForward();
        if (deviceAppUi.getAndroidSettingsTimeToSleepValue().contains(arg1.trim()))
            log.debug("Time to sleep after inactivity was changed to '{}' on '{}'", arg1, arg2);
        else {
            log.debug("Time to sleep after inactivity did not change to '{}' on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Dialpad tones is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void dialpadTones(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.SOUND_SETTINGS");
        phone.flingForward();
        deviceAppUi.tapOnAdvanced();
        phone.flingForward();
        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getDialpadTonesStateAndroidSettings().equals("true"))
                    log.debug("Dialpad tones is enabled");
                else {
                    log.error("Dialpad tones is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getDialpadTonesStateAndroidSettings().equals("false"))
                    log.debug("Dialpad tones is not enabled");
                else {
                    log.error("Dialpad tones is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Touch sounds is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void touchSounds(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.SOUND_SETTINGS");
        phone.flingForward();
        deviceAppUi.tapOnAdvanced();
        phone.flingForward();
        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getTouchSoundsStateAndroidSettings().equals("true"))
                    log.debug("Touch sounds is enabled");
                else {
                    log.error("Touch sounds is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getTouchSoundsStateAndroidSettings().equals("false"))
                    log.debug("Touch sounds is not enabled");
                else {
                    log.error("Touch sounds is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Vibrate on tap is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void vibrateOnTap(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.startApp("android.settings.SOUND_SETTINGS");
        phone.flingForward();
        deviceAppUi.tapOnAdvanced();
        phone.flingForward();
        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getVibrateOnTapStateAndroidSettings().equals("true"))
                    log.debug("Vibrate on tap is enabled");
                else {
                    log.error("Vibrate on tap is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getVibrateOnTapStateAndroidSettings().equals("false"))
                    log.debug("Vibrate on tap is not enabled");
                else {
                    log.error("Vibrate on tap is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify AMBER alerts is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void amberAlerts(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS);

        ConfigUiField field = deviceAppUi.getField(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title().trim().toLowerCase());
        if (field != null) {
            field.scrollIntoExactViewAttribute(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title());
            field.tap();
        }
        deviceAppUi.tapOnAdvanced();
        phone.flingForward();
        deviceAppUi.tapOnEmergencyAlerts();

        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getAmberAlertsStateAndroidSettings().equals("true"))
                    log.debug("AMBER alerts is enabled");
                else {
                    log.error("AMBER alerts is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getAmberAlertsStateAndroidSettings().equals("false"))
                    log.debug("AMBER alerts is not enabled");
                else {
                    log.error("AMBER alerts is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Severe threats is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void severeThreats(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS);

        ConfigUiField field = deviceAppUi.getField(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title().trim().toLowerCase());
        if (field != null) {
            field.scrollIntoExactViewAttribute(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title());
            field.tap();
        }
        deviceAppUi.tapOnAdvanced();
        phone.flingForward();
        deviceAppUi.tapOnEmergencyAlerts();

        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getSevereThreatsValueAndroidSettings().equals("true"))
                    log.debug("Severe Threats is enabled");
                else {
                    log.error("Severe Threats is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getSevereThreatsValueAndroidSettings().equals("false"))
                    log.debug("Severe Threats is not enabled");
                else {
                    log.error("Severe Threats is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Severe threats is \"([^\"]*)\" out in Android Settings app on \"([^\"]*)\"$")
    public void severeThreatsAndroidSettingsGrayedOut(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS);

        ConfigUiField field = deviceAppUi.getField(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title().trim().toLowerCase());
        if (field != null) {
            field.scrollIntoExactViewAttribute(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title());
            field.tap();
        }
        deviceAppUi.tapOnAdvanced();
        phone.flingForward();
        deviceAppUi.tapOnEmergencyAlerts();

        switch (arg1.trim().toLowerCase()) {
            case "grayed":
                if(deviceAppUi.getSevereThreatsStateAndroidSettings().equals("false")) {
                    log.debug("Severe Threats is grayed out on {}", arg2);
                }
                else {
                    log.error("Severe Threats is not grayed out on {}", arg2);
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;

            case "not grayed":
                if(deviceAppUi.getSevereThreatsStateAndroidSettings().equals("true")) {
                    log.debug("Severe Threats is not grayed out on {}", arg2);
                }
                else {
                    log.error("Severe Threats is grayed out on {}", arg2);
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Severe threats is set to \"([^\"]*)\" in the device settings app on \"([^\"]*)\"$")
    public void severeThreatsValue(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();

        ConfigUiField field = deviceAppUi.getField(SEVERE_THREATS.title().trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, SEVERE_THREATS.title().trim());

        if (field != null) {
            if (field.hasValueElement()) {
                assert heading != null;
                field.scrollIntoExactView(heading);
            }
        }
        if(field.isValueAccessible()) {
            if (deviceAppUi.getSevereThreatsValueText().equals(arg1)) {
                log.debug("Severe Threats is set to '{}' on {}", arg1, arg2);
            } else {
                log.error("Severe Threats is set to '{}' instead on {}", deviceAppUi.getSevereThreatsValueText(), arg2);
                Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
            }
        }
        else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^I verify Severe threats is \"([^\"]*)\" out in the device settings app on \"([^\"]*)\"$")
    public void severeThreatsGrayedOut(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();

        switch (arg1.trim().toLowerCase()) {
            case "grayed":
                if(deviceAppUi.isSevereThreatsLabelEnabled().equals("false") && deviceAppUi.isSevereThreatsValueEnabled().equals("false")) {
                    log.debug("Severe Threats is grayed out on {}", arg2);
                }
                else {
                    log.error("Severe Threats is not grayed out on {}", arg2);
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;

            case "not grayed":
                if(deviceAppUi.isSevereThreatsLabelEnabled().equals("true") && deviceAppUi.isSevereThreatsValueEnabled().equals("true")) {
                    log.debug("Severe Threats is not grayed out on {}", arg2);
                }
                else {
                    log.error("Severe Threats is grayed out on {}", arg2);
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
    }

    @Then("^I verify Extreme threats is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void extremeThreats(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS);

        ConfigUiField field = deviceAppUi.getField(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title().trim().toLowerCase());
        if (field != null) {
            field.scrollIntoExactViewAttribute(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title());
            field.tap();
        }
        deviceAppUi.tapOnAdvanced();
        phone.flingForward();
        deviceAppUi.tapOnEmergencyAlerts();

        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getExtremeThreatsStateAndroidSettings().equals("true"))
                    log.debug("Extreme threats is enabled");
                else {
                    log.error("Extreme threats is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getExtremeThreatsStateAndroidSettings().equals("false"))
                    log.debug("Extreme threats is not enabled");
                else {
                    log.error("Extreme threats is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Jump to camera is \"([^\"]*)\" on \"([^\"]*)\"$")
    public void jumpToCamera(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        phone.forceStopApp("com.android.settings");
        phone.bringAppToForeground(SETTINGS);

        ConfigUiField field = deviceAppUi.getField(SYSTEM.title().trim().toLowerCase());
        if (field != null) {
            field.scrollIntoExactViewAttribute(SYSTEM.title());
            field.tap();
        }
        deviceAppUi.tapOnGestures();
        deviceAppUi.tapOnJumpToCamera();

        switch (arg1.trim().toLowerCase()) {
            case "enabled":
                if(deviceAppUi.getJumpToCameraStateAndroidSettings().equals("true"))
                    log.debug("Jump to camera is enabled");
                else {
                    log.error("Jump to camera is not enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
            case "not enabled":
            case "disabled":
                if(deviceAppUi.getJumpToCameraStateAndroidSettings().equals("false"))
                    log.debug("Jump to camera is not enabled");
                else {
                    log.error("Jump to camera is enabled");
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                }
                break;
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I restore Device and Android Settings on \"([^\"]*)\"$")
    public void clearAppData(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.flingToEnd();
        tapDeviceAppObject(DEVELOPER_OPTIONS.title(), arg1);
        tapDeviceAppObject(RESTORE_DEFAULT_SETTINGS.title(), arg1);
        tapDeviceAppObject(BACK_ARROW.title(), arg1);
        phone.flingToBeginning();
    }

    @Then("^I verify SKeyboard is not present in Device App on \"([^\"]*)\"$")
    public void elementNotPresent(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        DeviceAppUi deviceAppUi = phone.getDeviceAppUi();
        ConfigUiField field = deviceAppUi.getField(SKEYBOARD.title().toLowerCase());
        FieldData heading = DeviceFields.getStrings(DEVICE, SKEYBOARD.title().trim());

        if (field != null) {
            if (field.hasLabelElement()) {
                try {
                    field.scrollIntoExactView(heading);
                    log.error("SKeyboard is present on '{}' when it shouldn't have been", arg1);
                    Environment.softAssert().fail("INCORRECT DEVICE APP VALUE");
                } catch (Exception exception) {
                    log.debug("Verified SKeyboard is not present on '{}'", arg1);
                }
            }
        }
    }
}