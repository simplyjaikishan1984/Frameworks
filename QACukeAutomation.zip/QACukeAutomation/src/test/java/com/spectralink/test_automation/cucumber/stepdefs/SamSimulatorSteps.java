package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.common.SimPhone;
import com.spectralink.test_automation.cucumber.framework.sam.common.Simulator;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.util.Iterator;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.sam.common.Simulator.DeviceFileColumns.*;

public class SamSimulatorSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I start the Versity device simulator with \"([^\"]*)\" devices$")
	public void startSimulator(String arg1) {
		String samAddress = Environment.getSam().getAddress();
		String samAccountKey = Environment.getSam().imDatabase().getAccountKey();
		Simulator sim = new Simulator(samAddress, samAccountKey);
		sim.createVersityDeviceFile(Integer.parseInt(arg1.trim()));
		sim.setDeviceHearbeatInterval(5);
		sim.setAckConfig(true);
		Environment.setSimulator(sim);
		if (Environment.getSimulator().start()) {
			char token = 'A';
			for (int phoneIndex = 0; phoneIndex < Environment.getSimulator().getCsvData().getRowCount(); phoneIndex++) {
				String phoneLabel = "SIM PHONE " + token;
				String model = Environment.getSimulator().getCsvData().getCellValueInRow(phoneIndex, MODEL);
				String serial = Environment.getSimulator().getCsvData().getCellValueInRow(phoneIndex, SERIAL);
				String mac = Environment.getSimulator().getCsvData().getCellValueInRow(phoneIndex, MAC);
				SimPhone simPhone = new SimPhone(model, serial, mac);
				Environment.setPhone(phoneLabel, simPhone);
				log.info("'{}' is set to Versity with serial {}", phoneLabel, simPhone.getSerialNumber());
				token++;
			}
			sleepSeconds(15);
		}
	}

	@When("^I start the Versity device simulator with \"([^\"]*)\" devices and a hearbeat of \"([^\"]*)\" seconds$")
	public void startSimulatorWithHeartbeat(String arg1, String arg2) {
		String samAddress = Environment.getSam().getAddress();
		String samAccountKey = Environment.getSam().imDatabase().getAccountKey();
		Simulator sim = new Simulator(samAddress, samAccountKey);
		sim.createVersityDeviceFile(Integer.parseInt(arg1.trim()));
		sim.setDeviceHearbeatInterval(Integer.parseInt(arg2.trim()));
		sim.setAckConfig(true);
		Environment.setSimulator(sim);
		if (Environment.getSimulator().start()) {
			char token = 'A';
			for (int phoneIndex = 0; phoneIndex < Environment.getSimulator().getCsvData().getRowCount(); phoneIndex++) {
				String phoneLabel = "SIM PHONE " + token;
				String model = Environment.getSimulator().getCsvData().getCellValueInRow(phoneIndex, MODEL);
				String serial = Environment.getSimulator().getCsvData().getCellValueInRow(phoneIndex, SERIAL);
				String mac = Environment.getSimulator().getCsvData().getCellValueInRow(phoneIndex, MAC);
				SimPhone simPhone = new SimPhone(model, serial, mac);
				Environment.setPhone(phoneLabel, simPhone);
				log.info("'{}' is set to Versity with serial {}", phoneLabel, simPhone.getSerialNumber());
				token++;
			}
			sleepSeconds(15);
		}
	}

	@When("^I shut down the simulator$")
	public void shutDownSimulator() {
		if (Environment.getSimulator() != null) {
			Assert.assertTrue(Environment.getSimulator().stop(), "Simulator failed to stop");
		} else {
			log.error("Device simulator was never started");
		}
	}

	@When("^I remove all simulated phones$")
	public void removeSimulatedPhones() {
		if (Environment.getSimulator() != null) {
			Iterator<Map.Entry<String, VersityPhone>> phoneIterator = Environment.getPhones().entrySet().iterator();
			while(phoneIterator.hasNext()) {
				Map.Entry<String, VersityPhone> entry = phoneIterator.next();
				if (entry.getKey().contains("SIM PHONE")) {
					log.debug("Removing phone '{}'", entry.getKey());
					phoneIterator.remove();
				}
			}
		} else {
			log.error("Device simulator was never started");
		}
	}

	@Then("^the simulator is running$")
	public void verifySimulatorRunning() {
		if (Environment.getSimulator() != null) {

			Assert.assertTrue(Environment.getSimulator().isRunning(), "Simulator failed to start");
		} else {
			log.error("Device simulator was never started");
		}
	}

	@Then("^the simulator is not running$")
	public void verifySimulatorNotRunning() {
		if (Environment.getSimulator() != null) {
			Assert.assertFalse(Environment.getSimulator().isRunning(), "Simulator failed to stop");
		} else {
			log.error("Device simulator was never started");
		}
	}
}