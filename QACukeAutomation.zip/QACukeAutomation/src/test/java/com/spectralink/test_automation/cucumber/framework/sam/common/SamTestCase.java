package com.spectralink.test_automation.cucumber.framework.sam.common;

public class SamTestCase {

	private static final String projectDirectory = System.getProperty("user.dir");
	private static boolean recordScreenshotOnFail = true;
	private static boolean recordHtmlOnFail = false;
	private static boolean recordHeartbeat = false;
	/*private static boolean recordResponse = false;
	private final Log log;
	private final String testCaseSeparator = "=";
	private final String sectionSeparator = "-";
	private final int separatorLength = 60;
	protected SamAutomation samNavigation;
	protected String logFileDirectory;
	public VersityPhone phone;

	public SamTestCase() {
		log = new Log();
	}

	public static String getProjectDirectory() {
		return projectDirectory;
	}

	public String getLogFileDirectory() {
		return logFileDirectory;
	}

	public static void setRecordScreenshotOnFail(boolean record) {
		recordScreenshotOnFail = record;
	}

	public static void setRecordHtmlOnFail(boolean record) {
		recordHtmlOnFail = record;
	}

	public void setSamNavigation(SamPageObject samNavigation) {
		this.samNavigation = samNavigation;
	}

	public String getShortClassName(String className) {
		String[] packages = className.split("\\.");
		return packages[packages.length - 1];
	}

	@BeforeMethod
	public void printTestHeader(Method method) {
		log.info(StringUtils.repeat(testCaseSeparator, separatorLength));
		log.info(" > Started test " + method.getName());
		log.info(StringUtils.repeat(sectionSeparator, separatorLength));
	}

	public void printClass(String className) {
		String separator = StringUtils.repeat(testCaseSeparator, separatorLength);
		log.info(StringUtils.repeat(testCaseSeparator, separatorLength));
		String paddedClassName = " " + className + " ";
		if (paddedClassName.length() < separatorLength - 2) {
			int filler = separatorLength - paddedClassName.length();
			int leftSide = filler / 2;
			int rightSide = filler - leftSide;
			log.info(StringUtils.repeat('=', leftSide) + paddedClassName + StringUtils.repeat('=', rightSide));
		} else {
			log.info(className);
		}
	}

	public void printLogDirectory(String outputDirectory, String className) {
		logFileDirectory = outputDirectory + File.separator + className + File.separator;
		// not going to wait for testng to create.  @BeforeClass runs before the testng output directory is created
		log.info(glue("Logging directory located in", logFileDirectory));
		Util.executeCommand("mkdir -p \"" + logFileDirectory + "\"");
		Util.executeCommand("rm -rf \"" + logFileDirectory + "\"*");
	}

	private static Sam samSingleton = getSamInstance();
	public synchronized static Sam getSamInstance() {
		if (samSingleton == null) {
			samSingleton = new Sam();
		}
		return samSingleton;
	}

	private static UsbSystem hostSingleton = null;
	public synchronized static UsbSystem getHostInstance() {
		if (hostSingleton == null) {
			hostSingleton = new UsbSystem(samSingleton.getDeviceSerials());
		}
		return hostSingleton;
	}

	private static TestPhone selectedPhone = null;
	public synchronized static TestPhone getSelectedDevice() {
		if (selectedPhone == null) {
			selectedPhone = getHostInstance().getRandomPhone();
		}
		return selectedPhone;
	}

	protected Object initializeConfigs(String settingsPath, Class targetClass) {
		FileReader reader = null;
		try {
			File file = Util.getResourceFile(settingsPath);
			reader = new FileReader(file);
		} catch (FileNotFoundException e) {
			log.error(settingsPath + " configurations file not found in resources!");
			log.error(e.getMessage());
		}
		JsonReader jsonReader = new JsonReader(reader);
		Gson gson = new Gson();
		return gson.fromJson(jsonReader, targetClass);
	}

	public void logMultilineText(String rawText, Level level) {
		String[] allLines = rawText.split("\n");
		for (String line : allLines) {
			log.log(line, level);
		}
	}

	public void logKeyMismatch(PhoenixSettings phoneSettings, Setting setting) {
		String settingKey = setting.getParameter();
		String cmsValue = setting.getValue();
		String phoneValue = phoneSettings.getAttribute(setting.getParameter());
		String formattedLine = String.format("Key: %-56s Phone: %-24s CMS: %-24s", settingKey, phoneValue, cmsValue);
		log.error(formattedLine);
	}

	public static String shortFileName(String path) {
		String[] chunks = path.split("/");
		return chunks[chunks.length - 1];
	}

	public static String shortFileName(Path path) {
		String[] chunks = path.toString().split("/");
		return chunks[chunks.length - 1];
	}

	public void printSectionLine() {
		log.debug(StringUtils.repeat(sectionSeparator, separatorLength));
	}

	public void skip(String code, String reason) {
		log.warn(glue("Intentionally skipping", quote(code)));
		log.warn(glue("Remove when", reason));
	}

	private void printTestFooter(ITestResult result) {
		log.info(StringUtils.repeat(sectionSeparator, separatorLength));
		String testResult = result.getStatus() == ITestResult.SUCCESS ? "PASSED" : "FAILED";
		Double duration = (result.getEndMillis() - result.getStartMillis()) / 1000D;
		String prettyDuration = String.format("%.1f", duration);
		log.info(" > Finished test in " + prettyDuration + " seconds with result: " + testResult);
		log.info(StringUtils.repeat(testCaseSeparator, separatorLength));
	}

	@AfterMethod
	public void nameAfter(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String[] classNameChunks = result.getTestClass().getName().split("\\.");
			String className = classNameChunks[classNameChunks.length - 1];
			String methodName = result.getMethod().getMethodName();
			SimpleDateFormat ft = new SimpleDateFormat("MM:dd:HH:mm");
			String date = ft.format(result.getEndMillis());
			File record;
			log.error("==> Test failed with error: " + result.getThrowable().getMessage());

			if (recordScreenshotOnFail) {
				record = new File(getLogFileDirectory(), className + "-" + methodName + "-" + date + ".png");
				log.info("==> Saving screenshot to [" + record.getName() + "]");
				SamPageObject.saveScreenshot(record);
			}

			if (recordHtmlOnFail) {
				record = new File(getLogFileDirectory(), className + "-" + methodName + "-" + date + ".html");
				log.info(("==> Saving HTML to [" + record.getName() + "]"));
				SamPageObject.savePageSource(record);
			}

			if (recordHeartbeat && phone != null) {
				record = new File(getLogFileDirectory(), className + "-" + methodName + "-" + date + ".log");
				log.info(("==> Saving heartbeat to [" + record.getName() + "]"));
				SamPageObject.saveLastHeartbeat(getSamInstance(), record, phone.getSerialNumber());
			}

			if (recordResponse && phone != null) {
				record = new File(getLogFileDirectory(), className + "-" + methodName + "-" + date + ".log");
				log.info(("==> Saving response to [" + record.getName() + "]"));
				SamPageObject.saveLastResponse(getSamInstance(), record, phone.getSerialNumber());
			}
		}
		printTestFooter(result);
	}

	@AfterSuite(alwaysRun = true)
	public void Teardown() {
		WebDriver driver = SamPageObject.getWebDriver();
		if (driver != null) {
			log.info("Shutting down web driver");
			driver.manage().deleteAllCookies();
			driver.close();
			driver.quit();
		}

		//log4j has logs going into <project>/log.  move it to testng test-output directory
		Util.executeCommand("mv -f log/* \"" + logFileDirectory + "\"");

		getSamInstance().getKeyDatabase().close();
		getSamInstance().getImDatabase().close();
	}

	protected int compare(String samValue, DataKey key) {
		String phoneValue = phone.getStringForAppKey(key.text());
		if (phoneValue == null) {
			log.fatal(glue("Could not get value for key", key.text(), "from preferences.xml file"));
			return 1;
		} else if (!samValue.contentEquals(phoneValue.trim())) {
			log.fatal(String.format("Mismatch on %-40s SAM: %-15s <> Phone: %-15s", key.text(), samValue, phoneValue));
			return 1;
		} else {
			return 0;
		}
	}

	protected int compare(Integer samValue, DataKey key) {
		Integer phoneValue = phone.getIntegerForAppKey(key.text());
		if (phoneValue == null) {
			log.fatal(glue("Could not get value for key", key.text(), "from preferences.xml file"));
			return 1;
		} else if (!samValue.equals(phoneValue)) {
			log.fatal(String.format("Mismatch on %-40s SAM: %-15s <> Phone: %-15s", key.text(), samValue, phoneValue));
			return 1;
		} else {
			return 0;
		}
	}

	protected int compare(Boolean samValue, DataKey key) {
		Boolean phoneValue = phone.getBooleanForAppKey(key.text());
		if (phoneValue == null) {
			log.fatal(glue("Could not get value for key", key.text(), "from preferences.xml file"));
			return 1;
		} else if (!samValue.equals(phoneValue)) {
			log.fatal(String.format("Mismatch on %-40s SAM: %-15s <> Phone: %-15s", key.text(), samValue, phoneValue));
			return 1;
		} else {
			return 0;
		}
	}

	protected int compareSound(String samValue, DataKey key) {
		String phoneValue = phone.getStringForAppKey(key.text());
		Map<String, Properties> sounds = phone.getSoundFiles();
		if (sounds.size() == 0) {
			log.error(glue("Could not get sound list from phone"));
			return 1;
		} else {
			int startIdNumber = phoneValue.lastIndexOf("/");
			if (startIdNumber == -1) {
				if (!(phoneValue.contentEquals("None") || phoneValue.isEmpty())) {
					log.fatal(String.format("Mismatch on %-40s SAM: %-15s Phone: %-15s", key.text(), samValue, phoneValue));
					return 1;
				}
				return 0;
			} else {
				String phoneFileId = phoneValue.substring(startIdNumber + 1);
				if (!sounds.get(samValue).getProperty("_id").contains(phoneFileId)) {
					log.fatal(String.format("Mismatch on %-40s SAM: %-15s (%s) Phone: %-15s", key.text(), sounds.get(samValue).getProperty("_id"), samValue, phoneFileId));
					return 1;
				}
				return 0;
			}
		}
	}*/
}
