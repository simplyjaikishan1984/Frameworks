package com.spectralink.test_automation.cucumber.framework.device.common;

import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;

import java.util.regex.Pattern;

public class CiscoPhoneContentProvider {

    private final VersityPhone phone;

    private final String ciscoPhoneContentProviderCallDetails = "com.cisco.phone.provider/calls/";
    public static Boolean missedDroppedCiscoPhone =false;
    private final String ciscoPhoneContentProviderAcctDetails = "com.cisco.phone.provider/accts/0";
    private final String ciscoPhoneContentProviderConferenceDetails = "com.cisco.phone.provider/conference_participants";

    public CiscoPhoneContentProvider(VersityPhone phone) {
        this.phone = phone;
    }

    public String getTxPackets(String callId) {
        return phone.getQueryResult(getAudioStats(callId), Pattern.compile("Tx ([^,]+)"));
    }

    public String getRxPackets(String callId) {
        return phone.getQueryResult(getAudioStats(callId), Pattern.compile("Rx ([^,]+)"));
    }

    public String getMissedPackets(String callId) {
        missedDroppedCiscoPhone = true;
        return phone.getQueryResult(getAudioStats(callId), Pattern.compile("Missed ([^,]+\\(([^()]*)\\)*%)"));
    }

    public String getDroppedPackets(String callId) {
        missedDroppedCiscoPhone = true;
        return phone.getQueryResult(getAudioStats(callId), Pattern.compile("Dropped ([^,]+\\(([^()]*)\\)*%)"));
    }

    public String getCallState(String callId) {
        return phone.getQueryResult(ciscoPhoneContentProviderCallDetails + callId + " --projection callState", Pattern.compile("callState=([^,]+)"));
    }

    public String getMediaState(String callId) {
        return phone.getQueryResult(ciscoPhoneContentProviderCallDetails + callId + " --projection mediaState", Pattern.compile("mediaState=([^,]+)"));
    }

    public String getCallerName(String callId) {
        return phone.getQueryResult(ciscoPhoneContentProviderCallDetails + callId + " --projection farDispName", Pattern.compile("farDispName=(.*)"));
    }

    public String getCallMutedState(String callId) {
        return phone.getQueryResult(ciscoPhoneContentProviderCallDetails + callId + " --projection ismuted", Pattern.compile("ismuted=(.*)"));
    }

    public String getCallDuration(String callId) {
        return phone.getQueryResult(ciscoPhoneContentProviderCallDetails + callId + " --projection msStartConnect", Pattern.compile("msStartConnect=([^,]+)"));
    }

    public String getRegistrationCode() {
        return phone.getQueryResult(ciscoPhoneContentProviderAcctDetails + " --projection regCode", Pattern.compile("regCode=([^,]+)"));
    }

    public String getRegistrationUpdate() {
        return phone.getQueryResult(ciscoPhoneContentProviderAcctDetails + " --projection msRegUpdate", Pattern.compile("msRegUpdate=([^,]+)"));
    }

    public String getRegistrationExpiration() {
        return phone.getQueryResult(ciscoPhoneContentProviderAcctDetails + " --projection regExpire", Pattern.compile("regExpire=([^,]+)"));
    }

    public String getAudioStats(String callId) {
        return ciscoPhoneContentProviderCallDetails + callId + " --projection audioStats";
    }

    public String getCallIdFarEndUsername(String extensionNumber) {
        String fetchCallIdWithFarEndUserName;
        if (Util.isWindows())
            fetchCallIdWithFarEndUserName = ciscoPhoneContentProviderCallDetails + " --projection _id --where 'callState=\\\"CALL_STATE_CONFIRMED\\\" AND farUserName=\\\"" + extensionNumber + "\\\"'";
        else
            fetchCallIdWithFarEndUserName = ciscoPhoneContentProviderCallDetails + " --projection _id --where \"callState=\'CALL_STATE_CONFIRMED\' AND farUserName=\'" + extensionNumber + "\'\"";
        return phone.getQueryResult(fetchCallIdWithFarEndUserName, Pattern.compile("_id=([^,]+)"));
    }
    public String getCallId() {
        String fetchCallIdActiveCall;
        if (Util.isWindows())
            fetchCallIdActiveCall = ciscoPhoneContentProviderCallDetails + " --projection _id --where 'callState!=\\\"CALL_STATE_DISCONNECTED\\\"\\ AND\\ callState!=\\\"CALL_STATE_NULL\\\"\\ AND\\ mediaState!=\\\"MEDIA_STATE_LOCAL_HOLD\\\"'";
        else
            fetchCallIdActiveCall = ciscoPhoneContentProviderCallDetails + " --projection _id --where \"callState!=\'CALL_STATE_DISCONNECTED\' AND callState!=\'CALL_STATE_NULL\' AND mediaState!=\'MEDIA_STATE_LOCAL_HOLD\'\"";

        return phone.getQueryResult(fetchCallIdActiveCall, Pattern.compile("_id=([^,]+)"));
    }

    public String getCallIdOfHoldCall() {
        String fetchCallIdHoldCall;
        if (Util.isWindows())
            fetchCallIdHoldCall = ciscoPhoneContentProviderCallDetails + " --projection _id --where 'callState!=\\\"CALL_STATE_DISCONNECTED\\\"\\ AND\\ callState!=\\\"CALL_STATE_NULL\\\"\\ AND\\ mediaState=\\\"MEDIA_STATE_LOCAL_HOLD\\\"'";
        else
            fetchCallIdHoldCall = ciscoPhoneContentProviderCallDetails + " --projection _id --where \"callState!=\'CALL_STATE_DISCONNECTED\' AND callState!=\'CALL_STATE_NULL\' AND mediaState=\'MEDIA_STATE_LOCAL_HOLD\'\"";

        return phone.getQueryResult(fetchCallIdHoldCall, Pattern.compile("_id=([^,]+)"));
    }

    public String getCallIdIncomingOutgoingCall() {
        String fetchCallIdIncomingOutgoingCall;
        if (Util.isWindows())
            fetchCallIdIncomingOutgoingCall = ciscoPhoneContentProviderCallDetails + " --projection _id --where \"callState=\\'CALL_STATE_EARLY\\'\"";
        else
            fetchCallIdIncomingOutgoingCall = ciscoPhoneContentProviderCallDetails + " --projection _id --where \"callState=\'CALL_STATE_EARLY\'\"";
        return phone.getQueryResult(fetchCallIdIncomingOutgoingCall, Pattern.compile("_id=([^,]+)"));
    }

    public String isCapableToRemoveParticipants() {
        String isCapableToRemoveParticipants;
        isCapableToRemoveParticipants = ciscoPhoneContentProviderConferenceDetails + " --projection is_capable_to_remove_participant --where \"extension=\'" + phone.callServerDetails().extensionReg1 +"\'\"";
        return phone.getQueryResult(isCapableToRemoveParticipants, Pattern.compile("is_capable_to_remove_participant=([^,]+)"));
    }

    public String isHost() {
        String isCapableToRemoveParticipants;
        isCapableToRemoveParticipants = ciscoPhoneContentProviderConferenceDetails + " --projection is_host --where \"extension=\'" + phone.callServerDetails().extensionReg1 +"\'\"";
        return phone.getQueryResult(isCapableToRemoveParticipants, Pattern.compile("is_host=([^,]+)"));
    }

    public String isSelf() {
        String isCapableToRemoveParticipants;
        isCapableToRemoveParticipants = ciscoPhoneContentProviderConferenceDetails + " --projection is_self --where \"extension=\'" + phone.callServerDetails().extensionReg1 +"\'\"";
        return phone.getQueryResult(isCapableToRemoveParticipants, Pattern.compile("is_self=([^,]+)"));
    }
}
