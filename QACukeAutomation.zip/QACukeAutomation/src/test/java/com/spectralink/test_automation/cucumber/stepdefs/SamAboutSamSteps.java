package com.spectralink.test_automation.cucumber.stepdefs;

import com.jcraft.jsch.JSchException;
import com.spectralink.test_automation.cucumber.framework.common.CliResult;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamAboutSamPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class SamAboutSamSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    private Integer getBackupCount() {
        Integer fileCount = -1;
        ArrayList<String> command = new ArrayList<>();
        command.add("ls -l /var/ironman/uploads/backup | grep backup\\.20 | wc -l");
        try {
            CliResult result = Environment.getSam().executeCommand(command);
            if (result.commandSucceeded()) {
                fileCount = Integer.valueOf(result.getStdout().trim());
            } else {
                log.error("Could not execute command {}", command.toString());
            }
        } catch (IOException ioe) {
            log.error("Could not execute command {}", command.toString());
            Assert.fail("SAM Command Line Failure");
        } catch (JSchException jse) {
            log.error("Could not SSH to SAM host: {}", jse.getMessage());
            Assert.fail("SSH Failure");
        }
        return fileCount;
    }

    @When("^I record the current SAM version")
    public void recordVersion() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        Environment.setTemporaryValue("oldVersionNumber", aboutPage.getAppVersion());
    }

    @When("^I click the 'Browse file' button")
    public void clickBrowseFile() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        aboutPage.clickBrowseFile();
    }

    @When("^I click the 'Backup Now' button")
    public void clickBackupNow() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        Environment.setTemporaryValue("oldBackupCount", getBackupCount());
        aboutPage.clickBackupNow();
    }

    @When("^I click the 'Copy Account key to Clipboard' button")
    public void clickCopyAccountKey() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        aboutPage.clickCopyAccountKeyToClipboard();
    }

    @When("^I click the 'Copy Certificate to Clipboard' button")
    public void clickCopyCertificate() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        aboutPage.clickCopyCertToClipboard();
    }

    @When("^I click the 'Copy CSR to Clipboard' button")
    public void clickCopyCsr() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        aboutPage.clickCopyCsrToClipboard();
    }

    @When("^I choose the upgrade file \"([^\"]*)\"")
    public void chooseUpgradeFile(String arg1) {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        log.debug("Current SAM version is {}", aboutPage.getAppVersion());
        Path artifactsFile = Paths.get(Environment.getProjectDirectory() + "/" + arg1.trim());
        aboutPage.chooseFile(artifactsFile);
    }

    @Then("^the app version has changed")
    public void verifyAppVersionChange() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        String oldVersion = Environment.getTemporaryValue("oldVersionNumber");
        log.debug("Current SAM version is {}", aboutPage.getAppVersion());
        if (!oldVersion.contentEquals(aboutPage.getAppVersion())) {
            log.debug("Prior version {} was upgraded to {}", oldVersion, aboutPage.getAppVersion());
        } else {
            log.fatal("Version {} was unchanged", oldVersion);
            Assert.fail("Upgrade Failed");
        }
    }

    @Then("^the Software License Agreement is present")
    public void verifySoftwareLicense() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        aboutPage.clickAgreementExpander();
        String agreement = aboutPage.getAgreement();
        if (agreement.contains("TERMS AND CONDITIONS INDICATED ABOVE")) {
            log.debug("Full agreement was found on page");
        } else {
            log.debug("Full Software License Agreement was not found");
            Assert.fail("SAM Agreement Failure");
        }
    }

    @Then("^the page version matches the database version")
    public void verifyAppVersion() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        String databaseVersion = Environment.getSam().imDatabase().getAppVersion();
        String pageVersion = aboutPage.getAppVersion();
        if (pageVersion.contentEquals(databaseVersion)) {
            log.debug("Page version {} matched database version", pageVersion);
        } else {
            log.debug("Page version {} did not match database version {}", pageVersion, databaseVersion);
            Assert.fail("SAM Version Mismatch");
        }
    }

    @Then("^the page Account Key matches the database Account Key")
    public void verifyAccountKey() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        String databaseVersion = Environment.getSam().imDatabase().getAccountKey();
        String pageAccountKey = aboutPage.getAccountKey();
        if (pageAccountKey.contentEquals(databaseVersion)) {
            log.debug("Page account key {} matched database version", pageAccountKey);
        } else {
            log.debug("Page account key {} did not match database account key {}", pageAccountKey, databaseVersion);
            Assert.fail("SAM Account Key Mismatch");
        }
    }

    @Then("^the page Account Number matches the database Account Number")
    public void verifyAccountNumber() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        String databaseVersion = Environment.getSam().imDatabase().getSamAccountNumber();
        String pageAccountNumber = aboutPage.getAccountNumber();
        if (pageAccountNumber.contentEquals(databaseVersion)) {
            log.debug("Page account number {} matched database account number", pageAccountNumber);
        } else {
            log.debug("Page account number {} did not match database account number {}", pageAccountNumber, databaseVersion);
            Assert.fail("SAM Account Number Mismatch");
        }
    }

    @Then("^the clipboard holds the Account Key")
    public void verifyClipboardHasAccountKey() {
        String databaseVersion = Environment.getSam().imDatabase().getAccountKey();
        try {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            String certText = (String) clipboard.getData(DataFlavor.stringFlavor);
            if (certText != null && certText.contains(databaseVersion)) {
                log.debug("Clipboard contained {}", databaseVersion);
            } else {
                log.fatal("Clipboard contained {} instead of Account Key {}", certText, databaseVersion);
                Assert.fail("SAM Copy To Clipboard Failure");
            }
        } catch (UnsupportedFlavorException ufe) {
            ufe.printStackTrace();
            Assert.fail("Cannot get clipboard as string");
        } catch (IOException ioe) {
            ioe.printStackTrace();
            Assert.fail("Cannot open clipboard file");
        }
    }

    @Then("^the clipboard holds a valid certificate")
    public void verifyClipboardHasCertificate() {
        try {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            String certText = (String) clipboard.getData(DataFlavor.stringFlavor);
            if (certText != null &&
                    certText.contains("-----BEGIN CERTIFICATE-----") &&
                    certText.contains("-----END CERTIFICATE-----")) {
                log.debug("Certificate in clipboard appears to be valid");
            } else {
                log.fatal("Clipboard contained '{}' instead of a valid certificate", certText);
                Assert.fail("SAM Copy To Clipboard Failure");
            }
        } catch (UnsupportedFlavorException ufe) {
            ufe.printStackTrace();
            Assert.fail("Cannot get clipboard as string");
        } catch (IOException ioe) {
            ioe.printStackTrace();
            Assert.fail("Cannot open clipboard file");
        }
    }

    @Then("^the clipboard holds a valid CSR")
    public void verifyClipboardHasCsr() {
        try {
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            String certText = (String) clipboard.getData(DataFlavor.stringFlavor);
            if (certText != null &&
                    certText.contains("-----BEGIN CERTIFICATE REQUEST-----") &&
                    certText.contains("-----END CERTIFICATE REQUEST-----")) {
                log.info("CSR in clipboard appears to be valid");
            } else {
                log.fatal("Clipboard contained '{}' instead of a valid CSR", certText);
                Assert.fail("SAM Copy To Clipboard Failure");
            }
        } catch (UnsupportedFlavorException ufe) {
            ufe.printStackTrace();
            Assert.fail("Cannot get clipboard as string");
        } catch (IOException ioe) {
            ioe.printStackTrace();
            Assert.fail("Cannot open clipboard file");
        }
    }

    @Then("^a new backup file will appear on the SAM host within 1 minute")
    public void verifyBackupOccurred() {
        if (getBackupCount().equals(Environment.getIntegerTemporaryValue("oldBackupCount") + 1)) {
            log.debug("Backup files increased by 1");
        } else {
            log.fatal("No new backup files appeared");
            Assert.fail("Backup Failure");
        }
    }

    @Then("^the upgrade file is uploaded to the SAM host")
    public void verifyUploadOccurred() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        String pageText = aboutPage.getUploadMessage();
        if (pageText.contains("Software file uploaded")) {
            log.debug("About SAM page contains expected upload success message");
            ArrayList<String> command = new ArrayList<>();
            command.add("file /home/sam/uploads/artifacts.zip");
            try {
                CliResult result = Environment.getSam().executeCommand(command);
                if (result.getExitCode() != 0 || !result.getStdout().contains("Zip archive data")) {
                    Assert.fail("Uploaded file was missing or damaged on SAM: " + result.getStdout());
                } else {
                    log.info("Uploaded file was found on SAM");
                }
            } catch (IOException ioe) {
                log.fatal("Uploaded file was not found on SAM: {}", ioe.getMessage());
                Assert.fail("Artifact Upload Failure");
            } catch (JSchException jse) {
                log.error("Could not SSH to SAM host: {}", jse.getMessage());
                Assert.fail("SSH Failure");
            }
        } else {
            log.fatal("About SAM page does not contain successful upload message");
            Assert.fail("Upload Failure");
        }
    }

    @Then("^the faulty upgrade file causes an error message")
    public void verifyUploadFailed() {
        SamAboutSamPage aboutPage = (SamAboutSamPage) Environment.getCurrentPage();
        String errorMessage = aboutPage.getErrorMessage();
        if (errorMessage.contains("The file extension must be .zip, .key or .crt")) {
            log.debug("Correct error message appeared");
        } else {
            log.fatal("Page did not contain error message");
            Assert.fail("Upload Failure");
        }
    }
}
