package com.spectralink.test_automation.cucumber.framework.sam.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamCopyConfigPage extends SamBasePage {

	public enum CategoryMenu {
		BAD_BUTTONS("Buttons Not Working"),
		BAD_CAMERA("Camera"),
		BAD_NETWORK_CAMERA("Camera Connected to Network"),
		BAD_COSMETICS("Cosmetic"),
		BAD_EAR_SPEAKER("Ear Speaker Not Working"),
		BAD_LOUD_SPEAKER("Loud Speaker Not Working"),
		BAD_MICROPHONE("Microphone Not Working"),
		DAMAGED_LCD("Physical Damage - LCD"),
		DAMAGED_PLASTIC("Physical Damage - Plastic or Tabs"),
		DAMAGED_OTHER("Physical Damage - Other"),
		BAD_SCREEN("Screen/LCD Not Working"),
		BAD_SOFTWARE("Software Malfunction"),
		BAD_VIBRATOR("Vibrator Not Working"),
		NO_CHARGE("Will Not Charge"),
		NO_POWER("Will Not Power On"),
		NOT_DEFINED("Not Defined");

		private final String menuText;

		public String title() {
			return menuText;
		}

		CategoryMenu(String level) {
			this.menuText = level;
		}
	}

	@FindBy(xpath = "//button[@ng-click=\"selectDevice('replaceDevice')\"]")
	private WebElement sourceDeviceButton;

	@FindBy(xpath = "//button[@ng-click=\"selectDevice('withDevice')\"]")
	private WebElement targetDeviceButton;

	@FindBy(id = "rmaDeviceMacId")
	private WebElement macAddressTextbox;

	@FindBy(xpath = "//button[@ng-click=\"replaceDeviceSave()\"]")
	private WebElement copyConfigButton;

	@FindBy(xpath = "//button[@ng-click=\"resetForm()\"]")
	private WebElement cancelButton;

	@FindBy(id = "submit-replaceDevice")
	private WebElement selectSourceDeviceButton;

	@FindBy(id = "submit-withDevice")
	private WebElement selectTargetDeviceButton;

	@FindBy(id = "rma-form-category-select")
	private WebElement categorySelectMenu;

	@FindBy(id = "reasonTa")
	private WebElement reasonTextbox;

	@FindBy(xpath = "//div[@ng-click=\"selectButtonClick(row, $event)\"]")
	private List<WebElement> sourceCheckboxes;


	public SamCopyConfigPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public String getBodyText() {
		return locateElement(By.tagName("body")).getText();
	}

	public void clickSourceDeviceButton() {
		clickOnPageEntity(sourceDeviceButton);
	}

	public void clickTargetDeviceButton() {
		clickOnPageEntity(targetDeviceButton);
	}

	public void enterTargetMacAddress(String address) {
		typeIntoPageEntity(macAddressTextbox, address);
	}

	public void clickCopyConfigButton() {
		clickOnPageEntity(copyConfigButton);
		sleepSeconds(1);
	}

	public void clickCancelButton() {
		clickOnPageEntity(cancelButton);
	}

	public WebElement getDeviceCheckBox(int index) {
		return sourceCheckboxes.get(index);
	}

	public void clickSelectDeviceDialogButton() {
		if (isPresent(By.id("submit-replaceDevice"))) {
			clickOnPageEntity(selectSourceDeviceButton);
		} else {
			clickOnPageEntity(selectTargetDeviceButton);
		}
		sleepSeconds(1);
	}

	public void selectSourceDevice(String serial) {
		int rowIndex = getRowIndexOfColumnValue(serial, 2, 1);
		clickOnPageEntity(getDeviceCheckBox(rowIndex));
	}

	public void selectTargetDevice(String serial) {
		int rowIndex = getRowIndexOfColumnValue(serial, 2, 1);
		clickOnPageEntity(getDeviceCheckBox(rowIndex));
	}

	public CategoryMenu getCategoryOption(String title) {
		for (CategoryMenu option : CategoryMenu.values()) {
			if (option.title().toLowerCase().contentEquals(title.trim().toLowerCase())) {
				return option;
			}
		}
		return null;
	}

	public void selectCategory(CategoryMenu option) {
		selectMenuByText(categorySelectMenu, option.title());
	}

	public void enterReason(String reason) {
		typeIntoPageEntity(reasonTextbox, reason);
	}
}
