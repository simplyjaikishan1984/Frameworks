package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamBarcodePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.BARCODE;

public class SamBarcodeSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I check the \"([^\"]*)\" Barcode field$")
	public void checkBarcodeCheckbox(String arg1) throws Throwable {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		if (barcodePage.getField(arg1.trim()) != null) {
			barcodePage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I uncheck the \"([^\"]*)\" Barcode field$")
	public void uncheckBarcodeCheckbox(String arg1) throws Throwable {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		if (barcodePage.getField(arg1.trim()) != null) {
			barcodePage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I click the \"([^\"]*)\" radio button of the \"([^\"]*)\" Barcode field$")
	public void activateBarcodeRadio(String arg1, String arg2) throws Throwable {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		if (barcodePage.getField(arg2.trim()) != null) {
			String appendedKey = arg1.trim().toLowerCase() + arg2.trim();
			if (barcodePage.getField(appendedKey) != null) {
				barcodePage.getField(appendedKey).updateRadioButton();
			} else {
				log.error("No matching radio button value with title '{}'", arg1);
				Assert.fail("SAM Radio Button Not Found");
			}
		} else {
			log.error("No matching field with title '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" Barcode field$")
	public void selectBarcodeMenuOption(String arg1, String arg2) throws Throwable {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		if (barcodePage.getField(arg2.trim()) != null) {
			barcodePage.getField(arg2.trim()).updateMenuByLabel(arg1.trim());
		} else {
			log.error("Field with label '{}' does not exist", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" Barcode field$")
	public void enterFieldValue(String arg1, String arg2) {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		if (barcodePage.getField(arg2.trim()) != null) {
			barcodePage.getField(arg2.trim()).updateTextbox(arg1);
		} else {
			log.error("Field with label '{}' does not exist", arg1);
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the Barcode \"([^\"]*)\" setting$")
	public void verifyBarcodeValue(String arg1, String arg2, String arg3) throws Throwable {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(BARCODE, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(BARCODE, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(BARCODE)) phone.loadAppPreferences(BARCODE);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2.trim()));
			} else {
				log.error("Field with label '{}' does not exist", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("^\"([^\"]*)\" should have the value for the sound \"([^\"]*)\" in the Barcode \"([^\"]*)\" setting$")
	public void verifyBarcodeAlarmToneValue(String arg1, String arg2, String arg3) throws Throwable {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			String fieldKey = SamFields.getStrings(BARCODE, arg3.trim()).attribute();
			if (!phone.getCurrentAppSettings().equals(BARCODE)) phone.loadAppPreferences(BARCODE);
			Environment.addScenarioFailure(phone.compareSound(fieldKey, arg2));
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I delete the \"([^\"]*)\" Barcode field$")
	public void deleteBarcodeSetting(String arg1) throws Throwable {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		barcodePage.getField(arg1.trim()).delete();
	}

	@When("^I click open the additional settings for the \"([^\"]*)\" Barcode symbology$")
	public void expandBarcodeSetting(String arg1) throws Throwable {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		switch(arg1.trim()) {
			case "Aztec":
				barcodePage.clickExpandAztec();
				break;
			case "Codabar":
				barcodePage.clickExpandCodaBar();
				break;
			case "Code 11":
				barcodePage.clickExpandCode11();
				break;
			case "Code 39":
				barcodePage.clickExpandCode39();
				break;
			case "Data Matrix":
				barcodePage.clickExpandDataMatrix();
				break;
			case "EAN 8":
				barcodePage.clickExpandEan8();
				break;
			case "GS1 DataBar 14":
				barcodePage.clickExpandGs1Databar14();
				break;
			case "Interleaved 2 of 5":
				barcodePage.clickExpandInterleaved2Of5();
				break;
			case "Matrix 2 of 5":
				barcodePage.clickExpandMatrix2Of5();
				break;
			case "MSI Plessey":
				barcodePage.clickExpandMsiPlessey();
				break;
			case "QR":
				barcodePage.clickExpandQR();
				break;
			case "UPC-A":
				barcodePage.clickExpandUpca();
				break;
			case "UPC-E":
				barcodePage.clickExpandUpce();
				break;
			case "ISBT-128":
				barcodePage.clickExpandIsbt128();
				break;
			default:
				log.error("Field with label '{}' does not exist", arg1);
				Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I click close on the additional settings for the \"([^\"]*)\" Barcode symbology$")
	public void closeBarcodeSetting(String arg1) throws Throwable {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		switch(arg1.trim()) {
			case "Aztec":
				barcodePage.clickCloseAztec();
				break;
			case "Codabar":
				barcodePage.clickCloseCodabar();
				break;
			case "Code 11":
				barcodePage.clickCloseCode11();
				break;
			case "Code 39":
				barcodePage.clickCloseCode39();
				break;
			case "Data Matrix":
				barcodePage.clickCloseDataMatrix();
				break;
			case "EAN 8":
				barcodePage.clickCloseEan8();
				break;
			case "GS1 DataBar 14":
				barcodePage.clickCloseGs1Databar14();
				break;
			case "Interleaved 2 of 5":
				barcodePage.clickCloseInterleaved2Of5();
				break;
			case "Matrix 2 of 5":
				barcodePage.clickCloseMatrix2Of5();
				break;
			case "MSI Plessey":
				barcodePage.clickCloseMsiPlessey();
				break;
			case "QR":
				barcodePage.clickCloseQR();
				break;
			case "UPC-A":
				barcodePage.clickCloseUpca();
				break;
			case "UPC-E":
				barcodePage.clickCloseUpce();
				break;
			case "ISBT-128":
				barcodePage.clickCloseIsbt128();
				break;
			default:
				log.error("Field with label '{}' does not exist", arg1);
				Assert.fail("SAM Field Not Found");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the Barcode custom attribute \"([^\"]*)\" setting$")
	public void checkBarcodeCustomAttributeSetting(String arg1, String arg2, String arg3) {
		if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
			VersityPhone phone = Environment.getPhone(arg1.trim());
			if (phone != null) {
				if (!phone.getCurrentAppSettings().equals(BARCODE)) phone.loadAppPreferences(BARCODE);
				Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
			} else {
				log.error("Phone with label '{}' does not exist", arg1);
				Assert.fail("Specified Phone Not Available");
			}
		} else {
			log.debug("Skipped checking attribute {} since custom attribute testing is turned off", arg1);
		}

	}

	@Then("^the Barcode page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyBarcodePageValue(String arg1, String arg2) {
		SamBarcodePage barcodePage = (SamBarcodePage) Environment.getCurrentPage();
		if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
			Environment.addScenarioFailure(barcodePage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
		} else {
			Environment.addScenarioFailure(barcodePage.getField(arg1.trim()).compareState(arg2.trim()));
		}
	}
}