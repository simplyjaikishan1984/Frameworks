package com.spectralink.test_automation.cucumber.framework.common;

import java.io.IOException;
import java.net.InetAddress;
import java.sql.Timestamp;

public class DatabaseDevice {
	private String serialNumber;
	private Database accountKeyDatabase;

	public DatabaseDevice(String serialNumber, Database accountKeyDatabase) {
		this.serialNumber = serialNumber;
		this.accountKeyDatabase = accountKeyDatabase;
	}

	public Database getAccountKeyDatabase() {
		return accountKeyDatabase;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getMacAddress() {
		String query = "SELECT device_mac FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryString(query, "device_mac");
	}

	public Timestamp getLastUpdate() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryTime(query, "created");
	}

	public String getDisplayId() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryString(query, "device_display_id");
	}

	public String getModel() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryString(query, "device_model");
	}

	public String getNetworkSsid() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryString(query, "network_ssid");
	}

	public String getNetworkBssid() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryString(query, "network_bssid");
	}

	public String getIpAddress() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryString(query, "network_ip");
	}

	public Integer getBatteryLevel() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryInteger(query, "battery_level");
	}

	public Boolean getBatteryCharging() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryBoolean(query, "battery_charging");
	}

	public Double getBatteryTemperature() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryDouble(query, "battery_temperature");
	}

	public String getBatteryTempCelcius() {
		return String.format("%2.1fc", getBatteryTemperature());
	}

	public String getBatteryTempFahrenheit() {
		Double fahrenheit = (getBatteryTemperature() * 9 / 5.0) + 32;
		return String.format("%2.1ff", fahrenheit);
	}

	public Integer getBatteryCycles() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryInteger(query, "battery_cycles");
	}

	public String getBatteryHealth() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryString(query, "battery_health");
	}

	public String getSoftwareVersion() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryString(query, "device_display_id");
	}

	public java.sql.Date getBatteryMfgDate() {
		String query = "SELECT * FROM devices WHERE device_serial = '" + getSerialNumber() + "' ORDER BY created DESC LIMIT 1";
		return getAccountKeyDatabase().queryDate(query, "battery_mfg_date");
	}

	public Boolean deviceIsReachable() {
		try {
			InetAddress inet = InetAddress.getByAddress(Util.textToNumericIp(getIpAddress()));
			return inet.isReachable(5000);
		} catch (IOException ioe) {

		}
		return false;
	}

	public String getIdentity() {
		String identity = Util.glue("Using device", getSerialNumber(),
				"-- a model", getModel(),
				"running", getDisplayId(), "at IP", getIpAddress()
		);
		return identity;
	}
}





