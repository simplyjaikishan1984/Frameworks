package com.spectralink.test_automation.cucumber.framework.common;

import com.spectralink.test_automation.cucumber.framework.device.common.BizPhoneContentProvider;
import com.spectralink.test_automation.cucumber.framework.device.common.CallServerDetails;
import com.spectralink.test_automation.cucumber.framework.device.common.CiscoPhoneContentProvider;
import com.spectralink.test_automation.cucumber.framework.device.common.PttContentProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class VersityPhone extends AppiumPhone implements TestPhone {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private final Pattern spectralinkPattern = Pattern.compile("Row: 0 value=(.*)");
	private Map<String, AppSetting> appSettings = new LinkedHashMap<>();
	private Application currentAppSettings;
	private String preferencesFile;
	private PttContentProvider pttProvider;
	private BizPhoneContentProvider bizPhoneContentProvider;
	private CiscoPhoneContentProvider ciscoPhoneContentProvider;
	private CallServerDetails callServerDetails;
	private static final String pttContentProviderUri = "com.spectralink.slnkptt.provider/session";

	public VersityPhone(UsbHost host, String serialNumber, String status, String path) {
		super(host, serialNumber, status, path);
		setPhoneType(PhoneType.VERSITY);
		currentAppSettings = Application.NONE;
	}

	public void loadAppPreferences(Application application) {
		setPreferencesFile("");
		appSettings.clear();
		if (!isRooted()) rootPhone();
		Path preferences = Paths.get("/data/user_de/0", application.getPackage(), "/shared_prefs/preferences.xml");
		List<String> command = new ArrayList<>(Arrays.asList("shell", "cat", preferences.toString()));
		CliResult result = sendAdbCommand(command);
		if (result.commandFailed()) {
			log.error("ADB command '{}' failed: {}", result.getCommand(), result.getStdout());
			setCurrentAppSettings(Application.NONE);
		} else {
			setPreferencesFile(result.getStdout());
			setAppSettings(XmlTool.loadApolloSettingsFromXml(result.getStdout()));
			setCurrentAppSettings(application);
			log.trace("Reloaded {} settings on device {}", application.name(), getSerialNumber());
		}
	}

	public void loadAppPreferences(String application) {
		setPreferencesFile("");
		appSettings.clear();
		if (!isRooted()) rootPhone();
		Path preferences = Paths.get("/data/user_de/0", application, "/shared_prefs/preferences.xml");
		List<String> command = new ArrayList<>(Arrays.asList("shell", "cat", preferences.toString()));
		CliResult result = sendAdbCommand(command);
		if (result.commandFailed()) {
			log.error("ADB command '{}' failed: {}", result.getCommand(), result.getStdout());
			setCurrentAppSettings(Application.NONE);
		} else {
			setPreferencesFile(result.getStdout());
			setAppSettings(XmlTool.loadApolloSettingsFromXml(result.getStdout()));
			setCurrentAppSettings(Application.UNKNOWN);
			log.trace("Reloaded {} settings on device {}", application, getSerialNumber());
		}
	}

	public void clearAppSettings() {
		setPreferencesFile("");
		appSettings.clear();
		currentAppSettings = Application.NONE;
	}

	public void reloadAppPreferences() {
		loadAppPreferences(currentAppSettings);
	}

	public Application getCurrentAppSettings() {
		return currentAppSettings;
	}

	private void setCurrentAppSettings(Application currentAppSettings) {
		this.currentAppSettings = currentAppSettings;
	}

	public Map<String, AppSetting> getAppSettings() {
		return appSettings;
	}

	private void setAppSettings(Map<String, AppSetting> appSettings) {
		this.appSettings = appSettings;
	}

	public AppSetting getSettingForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key);
		}
		return null;
	}

	public Object getValueTypeForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getType();
		}
		return null;
	}

	public Object getValueForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getValue();
		}
		return null;
	}

	public String getStringForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getStringValue();
		}
		return null;
	}

	public String getForcedStringForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getForcedStringValue();
		}
		return null;
	}

	public Integer getIntegerForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getIntegerValue();
		}
		return null;
	}

	public Boolean getBooleanForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getBooleanValue();
		}
		return null;
	}

	public boolean hasCamera() {
		String scanner = getProperty("ro.slnk.hw.barcode_present");
        return scanner != null && scanner.contentEquals("true");
	}

	public boolean hasBarcodeScanner() {
		return hasCamera();
	}

	public String getPreferencesFile() {
		return preferencesFile;
	}

	private void setPreferencesFile(String preferencesFile) {
		this.preferencesFile = preferencesFile;
	}

	public int compareButton(String key, String samValue) {
		String phoneValue = getForcedStringForAppKey(key);
		if (phoneValue == null) {
			log.fatal("Could not get value for key {} from phone settings", key);
			return 1;
		} else if (samValue.contentEquals("Scanner")) {
			if (!(phoneValue.contentEquals("Scanner") || phoneValue.contentEquals("No action"))) {
				log.fatal(String.format("Mismatch on %-15s for %-40s SAM: %-15s <> Phone: %-15s", getSerialNumber(), key, samValue, phoneValue));
				return 1;
			} else {
				log.trace(String.format("Matched on %-15s for %-40s", getSerialNumber(), key));
				return 0;
			}
		} else if (!samValue.contentEquals(phoneValue.trim())) {
			log.fatal(String.format("Mismatch on %-15s for %-40s SAM: %-15s <> Phone: %-15s", getSerialNumber(), key, samValue, phoneValue));
			return 1;
		} else {
			log.trace(String.format("Matched on %-15s for %-40s", getSerialNumber(), key));
			return 0;
		}
	}

	public int compare(String key, String samValue) {
		String phoneValue = getForcedStringForAppKey(key);
		if (phoneValue == null) {
			log.fatal("Could not get value for key {} from phone settings", key);
			return 1;
		} else if (!samValue.contentEquals(phoneValue.trim())) {
			log.fatal(String.format("Mismatch on %-15s for %-40s SAM: %-15s <> Phone: %-15s", getSerialNumber(), key, samValue, phoneValue));
			return 1;
		} else {
			log.trace(String.format("Matched on %-15s for %-40s", getSerialNumber(), key));
			return 0;
		}
	}

	public int contrast(String key, String samValue) {
		String phoneValue = getForcedStringForAppKey(key);
		if (phoneValue == null) {
			log.fatal("Could not get value for key {} from phone settings", key);
			return 1;
		} else if (samValue.contentEquals(phoneValue.trim())) {
			log.fatal(String.format("Unexpected match on %-15s for %-40s SAM: %-15s <> Phone: %-15s", getSerialNumber(), key, samValue, phoneValue));
			return 1;
		} else {
			log.trace(String.format("Matched on %-15s for %-40s", getSerialNumber(), key));
			return 0;
		}
	}

	public int compareApproximate(String key, String samValue, int bound) {
		Integer phoneValue = getIntegerForAppKey(key);
		Integer targetValue = Integer.valueOf(samValue);
		if (phoneValue == null) {
			log.fatal("Could not get value for key {} from phone settings", key);
			return 1;
		} else if (phoneValue > targetValue + bound || phoneValue < targetValue - bound) {
			log.fatal(String.format("Out of range (+/-%d) on %-15s for %-40s SAM: %-15s <> Phone: %-15s", bound, getSerialNumber(), key, samValue, phoneValue));
			return 1;
		} else {
			log.trace(String.format("Matched on %-15s for %-40s", getSerialNumber(), key));
			return 0;
		}
	}

	public int compareSound(String key, String samValue) {
		String phoneValue = getStringForAppKey(key);
		Map<String, Properties> sounds = getSoundFiles();
		if (sounds.size() == 0) {
			log.error("Could not get sound list from phone {}", getSerialNumber());
			return 1;
		} else {
			int startIdNumber = phoneValue.lastIndexOf("/");
			if (samValue.contentEquals("None") || startIdNumber == -1) {
				if (phoneValue.isEmpty() || phoneValue.contentEquals("None")) {
					return 0;
				} else {
					log.fatal(String.format("Mismatch on %-15s for %-40s SAM: %-15s Phone: %-15s", getSerialNumber(), key, samValue, phoneValue));
					return 1;
				}
			} else {
				String phoneFileId = phoneValue.substring(startIdNumber + 1);
				if (sounds.get(samValue).getProperty("_id").contains(phoneFileId) || sounds.get(samValue).getProperty("_id").contains("alarm_alert")) {
					return 0;
				} else {
					log.fatal(String.format("Mismatch on %-15s for %-40s SAM: %-15s (%s) Phone: %-15s", getSerialNumber(), key, sounds.get(samValue).getProperty("_id"), samValue, phoneFileId));
					return 1;
				}
			}
		}
	}

	@Override
	public String getMacAddress() {
		String macAddress;
		List<String> command = new ArrayList<>(Arrays.asList("shell", "getprop", "ro.slnk.wifimac"));
		CliResult results = sendAdbCommand(command);
		String firstLine = results.getStdout().split("\n")[0].trim();
		if (firstLine.matches("[0-9A-Fa-f:]+")) {
			macAddress = firstLine;
			log.trace("MAC address for phone {} is {}", getSerialNumber(), macAddress);
		} else {
			log.error("MAC address for phone {} could not be determined", getSerialNumber());
			macAddress = "unknown";
		}
		return macAddress;
	}

	public Boolean hasLatestVersion(String appName, String packageName) {
		String version = "";
		Pattern propPattern = Pattern.compile("(?<=versionName=).*");
		List<String> command = new ArrayList<>(Arrays.asList("shell", "dumpsys", "package", packageName, "|", "grep", "versionName"));
		CliResult results = sendAdbCommand(command);
		if (results.getExitCode() == 0) {
			for (String line : results.getStdoutLines()) {
				Matcher propMatch = propPattern.matcher(line);
				if (line.length() > 0 && propMatch.find()) {
					version = propMatch.group();
				}
			}
		}

		String latestAppVersion = Util.getNightlyApps(appName, false);
		propPattern = Pattern.compile("(?<=" + appName +"-)(.+?).apk");
		Matcher propMatch = propPattern.matcher(latestAppVersion);
		if(propMatch.find())
			latestAppVersion = propMatch.group(1);

		log.debug("Phone version of {}: {}", appName, version);
		log.debug("Latest available version of {}: {}", appName, latestAppVersion);

		return latestAppVersion.equals(version);
	}

	public PttContentProvider pttContentProvider() {
		if (pttProvider == null) {
			pttProvider = new PttContentProvider(this);
		}
		return pttProvider;
	}

	public BizPhoneContentProvider bizPhoneContentProvider() {
		if (bizPhoneContentProvider == null) {
			bizPhoneContentProvider = new BizPhoneContentProvider(this);
		}
		return bizPhoneContentProvider;
	}

	public CiscoPhoneContentProvider ciscoPhoneContentProvider() {
		if (ciscoPhoneContentProvider == null) {
			ciscoPhoneContentProvider = new CiscoPhoneContentProvider(this);
		}
		return ciscoPhoneContentProvider;
	}

	public CallServerDetails callServerDetails() {
		if (callServerDetails == null) {
			callServerDetails = new CallServerDetails(this);
		}
		return callServerDetails;
	}
}





