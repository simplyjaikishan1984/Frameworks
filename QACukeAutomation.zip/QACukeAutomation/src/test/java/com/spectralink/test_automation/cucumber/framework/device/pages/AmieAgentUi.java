package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.AmieAgentStrings.*;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BattLifeStrings.BACK_ARROW;

public class AmieAgentUi extends AppiumUi {

    @AndroidFindBy(id = "com.spectralink.amieagent:id/imgLogo")
    private WebElement aboutIconButton;

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    public ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            overflowButton,
            overflowButton,
            null
    );

    @FindBy(xpath = "//android.widget.Button[(@resource-id ='com.spectralink.amieagent:id/snackbar_action')]/parent::*/android.widget.TextView[1]")
    private WebElement exposeButtonLabel;

    @AndroidFindBy(id = "com.spectralink.amieagent:id/snackbar_action")
    private WebElement exposeButton;

    public ConfigUiField exposeButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            exposeButtonLabel,
            exposeButton,
            null
    );

    @AndroidFindBy(accessibility = "AMiE Agent enabled title")
    private WebElement enableAmieLabel;

    @AndroidFindBy(accessibility = "AMiE Agent enabled switch")
    private WebElement enableAmieControl;

    @AndroidFindBy(accessibility = "AMiE Agent enabled summary")
    private WebElement enableAmieValue;

    public ConfigUiField enableAmieField = new ConfigUiField(
            driver,
            ENABLE_AMIE,
            enableAmieLabel,
            enableAmieControl,
            enableAmieValue
    );

    @AndroidFindBy(accessibility = "Endpoint URL title")
    private WebElement endpointUrlLabel;

    @AndroidFindBy(accessibility = "Endpoint URL summary")
    private WebElement endpointUrlValue;

    public ConfigUiField endpointUrlField = new ConfigUiField(
            driver,
            ENDPOINT_URL,
            endpointUrlLabel,
            null,
            endpointUrlValue
    );

    @AndroidFindBy(accessibility = "Endpoint URL dialog title")
    private WebElement editEndpointUrlLabel;

    @AndroidFindBy(accessibility = "Endpoint URL field")
    private WebElement editEndpointUrlBox;

    public ConfigUiField editEndpointUrlField = new ConfigUiField(
            driver,
            EDIT_ENDPOINT_URL,
            editEndpointUrlLabel,
            editEndpointUrlBox,
            null
    );

    @AndroidFindBy(accessibility = "Connection details title")
    private WebElement connectionDetailsLabel;

    public ConfigUiField connectionDetailsField = new ConfigUiField(
            driver,
            CONNECTION,
            connectionDetailsLabel,
            null,
            connectionDetailsLabel
    );

    @AndroidFindBy(accessibility = "Network metrics frequency title")
    private WebElement networkFrequencyLabel;

    @AndroidFindBy(accessibility = "Network metrics frequency summary")
    private WebElement networkFrequencyValue;

    public ConfigUiField networkFrequencyField = new ConfigUiField(
            driver,
            NETWORK_FREQUENCY,
            networkFrequencyLabel,
            null,
            networkFrequencyValue
    );

    @AndroidFindBy(accessibility = "Device metrics frequency title")
    private WebElement deviceFrequencyLabel;

    @AndroidFindBy(accessibility = "Device metrics frequency summary")
    private WebElement deviceFrequencyValue;

    public ConfigUiField deviceFrequencyField = new ConfigUiField(
            driver,
            DEVICE_FREQUENCY,
            deviceFrequencyLabel,
            null,
            deviceFrequencyValue
    );

    @AndroidFindBy(accessibility = "Battery metrics frequency title")
    private WebElement batteryFrequencyLabel;

    @AndroidFindBy(accessibility = "Battery metrics frequency summary")
    private WebElement batteryFrequencyValue;

    public ConfigUiField batteryFrequencyField = new ConfigUiField(
            driver,
            BATTERY_FREQUENCY,
            batteryFrequencyLabel,
            null,
            batteryFrequencyValue
    );

    @AndroidFindBy(accessibility = "Last connected time title")
    private WebElement lastConnectLabel;

    @AndroidFindBy(accessibility = "Last connected time summary")
    private WebElement lastConnectValue;

    public ConfigUiField lastConnectField = new ConfigUiField(
            driver,
            LAST_CONNECT,
            lastConnectLabel,
            null,
            lastConnectValue
    );

    @AndroidFindBy(accessibility = "Last disconnected time title")
    private WebElement lastDisconnectLabel;

    @AndroidFindBy(accessibility = "Last disconnected time summary")
    private WebElement lastDisconnectValue;

    public ConfigUiField lastDisconnectField = new ConfigUiField(
            driver,
            LAST_DISCONNECT,
            lastDisconnectLabel,
            null,
            lastDisconnectValue
    );

    @AndroidFindBy(accessibility = "Last upload time title")
    private WebElement lastUploadLabel;

    @AndroidFindBy(accessibility = "Last upload time summary")
    private WebElement lastUploadValue;

    public ConfigUiField lastUploadField = new ConfigUiField(
            driver,
            LAST_UPLOAD,
            lastUploadLabel,
            null,
            lastUploadValue
    );

    @AndroidFindBy(accessibility = "Developer options title")
    private WebElement developerOptionsLabel;

    public ConfigUiField developerOptionsField = new ConfigUiField(
            driver,
            DEV_OPTIONS,
            developerOptionsLabel,
            null,
            developerOptionsLabel
    );

    @AndroidFindBy(accessibility = "Enable debug notifications title")
    private WebElement enableDebugNotificationsLabel;

    @AndroidFindBy(accessibility = "Enable debug notifications switch")
    private WebElement enableDebugNotificationsControl;

    @AndroidFindBy(accessibility = "Enable debug notifications summary")
    private WebElement enableDebugNotificationsValue;

    public ConfigUiField enableDebugNotificationsField = new ConfigUiField(
            driver,
            ENABLE_DEBUG_NOTIFICATIONS,
            enableDebugNotificationsLabel,
            enableDebugNotificationsControl,
            enableDebugNotificationsValue
    );

    @AndroidFindBy(accessibility = "Publish topic title")
    private WebElement publishTopicLabel;

    @AndroidFindBy(accessibility = "Publish topic summary")
    private WebElement publishTopicValue;

    public ConfigUiField publishTopicField = new ConfigUiField(
            driver,
            PUBLISH_TOPIC,
            publishTopicLabel,
            null,
            publishTopicValue
    );

    @AndroidFindBy(accessibility = "Buffer size title")
    private WebElement bufferSizeLabel;

    @AndroidFindBy(accessibility = "Buffer size summary")
    private WebElement bufferSizeValue;

    public ConfigUiField bufferSizeField = new ConfigUiField(
            driver,
            BUFFER_SIZE,
            bufferSizeLabel,
            null,
            bufferSizeValue
    );

    @AndroidFindBy(accessibility = "List recent metrics title")
    private WebElement listMetricsLabel;

    public ConfigUiField listMetricsField = new ConfigUiField(
            driver,
            RECENT_METRICS,
            listMetricsLabel,
            listMetricsLabel,
            null
    );

    @AndroidFindBy(accessibility = "Capture battery metrics title")
    private WebElement captureBatteryLabel;

    public ConfigUiField captureBatteryField = new ConfigUiField(
            driver,
            BATTERY_METRICS,
            captureBatteryLabel,
            captureBatteryLabel,
            null
    );

    @AndroidFindBy(accessibility = "Capture network metrics title")
    private WebElement captureNetworkLabel;

    public ConfigUiField captureNetworkField = new ConfigUiField(
            driver,
            NETWORK_METRICS,
            captureNetworkLabel,
            captureNetworkLabel,
            null
    );

    @AndroidFindBy(accessibility = "Capture device metrics title")
    private WebElement captureDeviceLabel;

    public ConfigUiField captureDeviceField = new ConfigUiField(
            driver,
            DEVICE_METRICS,
            captureDeviceLabel,
            captureDeviceLabel,
            null
    );

    @FindBy(id = "com.spectralink.amieagent:id/amie_status")
    private WebElement connectedBannerLabel;

    public ConfigUiField connectedBannerField = new ConfigUiField(
            driver,
            CONNECTION_BANNER,
            connectedBannerLabel,
            null,
            connectedBannerLabel
    );

    @AndroidFindBy(accessibility = "Navigate up")
    private WebElement backButton;

    public ConfigUiField backButtonField = new ConfigUiField(
            driver,
            BACK_ARROW,
            null,
            backButton,
            null
    );

    @FindBy(id = "android:id/button1")
    private WebElement emptyEndpointChangeButton;

    public AmieAgentUi(AndroidDriver driver) {
        super(driver);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(OVERFLOW_MENU.title().toLowerCase(), overflowButtonField);
                put(ENABLE_AMIE.title().toLowerCase(), enableAmieField);
                put(ENDPOINT_URL.title().toLowerCase(), endpointUrlField);
                put(EDIT_ENDPOINT_URL.title().toLowerCase(), editEndpointUrlField);
                put(CONNECTION.title().toLowerCase(), connectionDetailsField);
                put(NETWORK_FREQUENCY.title().toLowerCase(), networkFrequencyField);
                put(DEVICE_FREQUENCY.title().toLowerCase(), deviceFrequencyField);
                put(BATTERY_FREQUENCY.title().toLowerCase(), batteryFrequencyField);
                put(LAST_CONNECT.title().toLowerCase(), lastConnectField);
                put(LAST_DISCONNECT.title().toLowerCase(), lastDisconnectField);
                put(LAST_UPLOAD.title().toLowerCase(), lastUploadField);
                put(DEV_OPTIONS.title().toLowerCase(), developerOptionsField);
                put(ENABLE_DEBUG_NOTIFICATIONS.title().toLowerCase(), enableDebugNotificationsField);
                put(PUBLISH_TOPIC.title().toLowerCase(), publishTopicField);
                put(BUFFER_SIZE.title().toLowerCase(), bufferSizeField);
                put(RECENT_METRICS.title().toLowerCase(), listMetricsField);
                put(BATTERY_METRICS.title().toLowerCase(), captureBatteryField);
                put(NETWORK_METRICS.title().toLowerCase(), captureNetworkField);
                put(DEVICE_METRICS.title().toLowerCase(), captureDeviceField);
            }
        };
    }

    public WebElement getAmieAgentIcon() {
        return aboutIconButton;
    }

    public Point getAmieAgentIconPosition() {
        int centerX = aboutIconButton.getLocation().getX() + aboutIconButton.getSize().getWidth() / 2;
        int centerY = aboutIconButton.getLocation().getY() + aboutIconButton.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }

    public void tapExposeButton() {
        clickOnPageEntity(exposeButton);
    }

    public boolean exposeBannerVisible() {
        try {
            if (exposeButton.isDisplayed()) {
                return true;
            }
        } catch (NoSuchElementException nsee) {

        }
        return false;
    }

    public void clickOverflowMenu() {
        clickOnPageEntity(overflowButton);
        Util.sleepSeconds(1);
    }

    public void tapBackButton() {
        clickOnPageEntity(backButton);
    }

    public void dismissApp() {
        clickOnPageEntity(backButton);
    }

    public void tapChangeButton() {
        clickOnPageEntity(emptyEndpointChangeButton);
    }

    public String getBannerText() {
        return connectedBannerLabel.getText();
    }

    public List<Map<String, String>> getRecentMetrics() {
        List<Map<String, String>> messages = new ArrayList<>();
        WebElement viewList = driver.findElement(By.id("com.spectralink.amieagent:id/swiperefresh"));
        List<WebElement> viewGroups = viewList.findElements(By.xpath("//android.view.ViewGroup"));
        for (WebElement group : viewGroups) {
            Map<String, String> messageInfo = new HashMap<>();
            messageInfo.put("type", group.findElement(By.xpath("//android.widget.TextView[1]")).getText());
            messageInfo.put("date", group.findElement(By.xpath("//android.widget.TextView[2]")).getText());
            messageInfo.put("payload", group.findElement(By.xpath("//android.widget.TextView[3]")).getText());
            messages.add(messageInfo);
        }
        return messages;
    }

    public List<WebElement> getAllObjects() {
        return driver.findElements(By.xpath("//*"));
    }

    public String getPageSource() {
        return driver.getPageSource();
    }

    public void enterConnectionDetails() {
        clickOnPageEntity(connectionDetailsLabel);
    }
}
