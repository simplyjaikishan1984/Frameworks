package com.spectralink.test_automation.cucumber.framework.common;

import com.vmware.vim25.*;
import com.vmware.vim25.mo.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class VmwareTool {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    public class LeaseProgressUpdater extends Thread {
        private HttpNfcLease httpNfcLease = null;
        private int progressPercent = 0;
        private int updateInterval;

        public LeaseProgressUpdater(HttpNfcLease httpNfcLease, int updateInterval) {
            this.httpNfcLease = httpNfcLease;
            this.updateInterval = updateInterval;
        }

        public void run() {
            while (true) {
                try {
                    httpNfcLease.httpNfcLeaseProgress(progressPercent);
                    Thread.sleep(updateInterval);
                } catch(InterruptedException ie) {
                    break;
                } catch(Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }

        public void setPercent(int percent) {
            this.progressPercent = percent;
        }
    }

    private String address;
    private String url;
    private String account;
    private String password;
    private ServiceInstance service = null;
    private HostSystem host = null;
    private List<String> snapshotNames = new ArrayList<>();

    public VmwareTool(String serverAddress, String account, String password) {
        this.address = serverAddress;
        this.url = "https://" + serverAddress + "/sdk";
        this.account = account;
        this.password = password;
        try {
            service = new ServiceInstance(new URL(getUrl()), getAccount(), getPassword(), true);
            host = (HostSystem) service.getSearchIndex().findByIp(null, serverAddress, false);
        } catch (RemoteException re) {
            log.error("RemoteException occurred: {}", re.getMessage());
        } catch (MalformedURLException mue) {
            log.error("MalformedURLException was thrown: {}", mue.getMessage());
        }
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
        this.url = "https://" + address + "/sdk";
    }

    public String getUrl() {
        return url;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public ServiceInstance getService() {
        return service;
    }

    public void setService(ServiceInstance service) {
        this.service = service;
    }

    public HostSystem getHost() {
        return host;
    }

    public void setHost(HostSystem host) {
        this.host = host;
    }

    // although this operates as spec'd by the vmware interface (null connectable means not removable)
    // they return null even for removables so don't use
    public Boolean deviceIsRemovable(VirtualDevice targetDevice) {
        return targetDevice.getConnectable() == null;
    }

    public VirtualMachine getVm(String vmName) {
        try {
            ServiceInstance service = new ServiceInstance(new URL(getUrl()), getAccount(), getPassword(), true);
            if (service != null) {
                Folder rootFolder = service.getRootFolder();
                ManagedEntity mes = new InventoryNavigator(rootFolder).searchManagedEntity("VirtualMachine", vmName);
                return (VirtualMachine) mes;
            }
        } catch (RemoteException re) {
            log.debug("RemoteException occurred: {}", re.getMessage());
        } catch (MalformedURLException mue) {
            log.debug("MalformedURLException was thrown: {}", mue.getMessage());
        }
        return null;
    }

    public String getVendor(VirtualDevice targetDevice) {
        VirtualUSB usb = (VirtualUSB) targetDevice;
        return String.format("%04d", usb.getVendor());
    }

    public String getProduct(VirtualDevice targetDevice) {
        VirtualUSB usb = (VirtualUSB) targetDevice;
        return String.format("%04d", usb.getProduct());
    }

    public String getLabel(VirtualDevice targetDevice) {
        return targetDevice.getDeviceInfo().getLabel();
    }

    public String getSummary(VirtualDevice targetDevice) {
        return targetDevice.getDeviceInfo().getSummary();
    }

    public VirtualDevice getDeviceBySummary(VirtualMachine vm, String summary) {
        List<VirtualDevice> devices = getVirtualDevicesOfType(VirtualDevice.class, vm);
        for (VirtualDevice device : devices) {
            if (getSummary(device).contains(summary)) {
                return device;
            }
        }
        return null;
    }

    public String getPath(VirtualDevice targetDevice) {
        VirtualUSBUSBBackingInfo backing = (VirtualUSBUSBBackingInfo) targetDevice.getBacking();
        return backing.getDeviceName().split(":")[1];
    }

    public int getControllerKey(VirtualDevice targetDevice) {
        VirtualUSB usb = (VirtualUSB) targetDevice;
        return usb.getControllerKey();
    }

    public String getVmUuid(String targetVm) {
        String uuid = null;
        VirtualMachine vm = getVm(targetVm);
        if (vm != null) {
            uuid = vm.getConfig().getUuid();
            log.trace("Found VM with uuid {}", uuid);
        }
        return uuid;
    }

    public void revertToSnapshot(String vmName, String snapshotName) {
        Folder rootFolder = getService().getRootFolder();
        try {
            VirtualMachine vm = (VirtualMachine) new InventoryNavigator(rootFolder).searchManagedEntity("VirtualMachine", vmName);
            VirtualMachineSnapshot vmSnapshot = getSnapshotInTree(vm, snapshotName);
            if (vmSnapshot != null) {
                Task task = vmSnapshot.revertToSnapshot_Task(null);
                if (task.waitForTask() == Task.SUCCESS) {
                    log.info("Reverted {} to snapshot '{}'", vmName, snapshotName);
                } else {
                    log.error("Failed to revert to snapshot '{}'", snapshotName);
                }
            } else {
                log.error("VM labeled '{}' was not found on server {}", vmName, getAddress());
            }
        } catch (RemoteException re) {
            log.error("Failed to revert to {}: {}", snapshotName, re.getMessage());
        } catch (InterruptedException ie) {
            log.error("Interrupted while waiting for revert");
            Thread.currentThread().interrupt();
        }
    }

    private ManagedObjectReference findSnapshotInTree(VirtualMachineSnapshotTree[] snapTree, String snapshotName) {
        for (int index = 0; index <snapTree.length; index++) {
            VirtualMachineSnapshotTree node = snapTree[index];
            if (snapshotName.equals(node.getName())) {
                return node.getSnapshot();
            } else {
                VirtualMachineSnapshotTree[] childTree = node.getChildSnapshotList();
                if (childTree != null) {
                    ManagedObjectReference mor = findSnapshotInTree(childTree, snapshotName);
                    if (mor != null) {
                        return mor;
                    }
                }
            }
        }
        return null;
    }

    public VirtualMachineSnapshot getSnapshotInTree(VirtualMachine vm, String snapshotName) {
        if (vm != null && snapshotName != null) {
            VirtualMachineSnapshotTree[] snapTree = vm.getSnapshot().getRootSnapshotList();
            if (snapTree != null) {
                ManagedObjectReference mor = findSnapshotInTree(snapTree, snapshotName);
                if (mor != null) {
                    return new VirtualMachineSnapshot(vm.getServerConnection(), mor);
                }
            }
        }
        return null;
    }

    private List<String> findSnapshots(VirtualMachineSnapshotTree[] snapTree) {
        List<String> snapshotNames = new ArrayList<>();
        for (int index = 0; snapTree != null && index < snapTree.length; index++) {
            VirtualMachineSnapshotTree node = snapTree[index];
            snapshotNames.add(node.getName());
            VirtualMachineSnapshotTree[] childTree = node.getChildSnapshotList();
            if (childTree != null) {
                snapshotNames.addAll(findSnapshots(childTree));
            }
        }
        return snapshotNames;
    }

    public List<String> getSnapshotList(VirtualMachine vm) {
        List<String> snapshotNames = new ArrayList<>();
        VirtualMachineSnapshotInfo snapInfo = vm.getSnapshot();
        if (snapInfo != null) {
            VirtualMachineSnapshotTree[] snapTree = snapInfo.getRootSnapshotList();
            snapshotNames.addAll(findSnapshots(snapTree));
        }
        return snapshotNames;
    }

    public HostSystem getServer() {
        HostSystem server = null;
        try {
            if (service != null) {
                Folder rootFolder = getService().getRootFolder();
                ManagedEntity[] mes = new InventoryNavigator(rootFolder).searchManagedEntities("HostSystem");
                // assuming only connections to single ESX instances
                HostSystem hostServer = (HostSystem) mes[0];
                log.trace("Found server {}", hostServer.getName());
                return hostServer;
            }
        } catch (RemoteException re) {
            log.error("RemoteException occurred: {}", re.getMessage());
        }
        return server;
    }

    public VirtualDevice[] getVmConnectedPhones(VirtualMachine vm) {
        VirtualDevice[] devices = null;
        List<VirtualDevice> phoneDevices = new ArrayList<>();
        if (vm != null) {
            VirtualHardware hardware = vm.getConfig().getHardware();
            devices = hardware.getDevice();
            for (VirtualDevice device : devices) {
                if (device.getDeviceInfo().getSummary().matches("^Spectralink.*")) {
                    log.trace("Found device {}", device.getDeviceInfo().getSummary());
                    phoneDevices.add(device);
                }
            }
            VirtualDevice[] phones = new VirtualDevice[phoneDevices.size()];
            for (int index = 0; index < phoneDevices.size(); index++) {
                phones[index] = phoneDevices.get(index);
            }
            return phones;
        }
        return devices;
    }

    private <T extends VirtualController> VirtualController createControllerInstance(Class<T> clazz) {
        VirtualController vc = null;
        try {
            vc = (T) clazz.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return vc;
    }

    public <T extends VirtualDevice> List<T> getVirtualDevicesOfType(Class<T> clazz, VirtualMachine vm) {
        List<T> result = new ArrayList<T>();
        VirtualDevice[] devices = (VirtualDevice[]) vm.getPropertyByPath("config.hardware.device");
        for (VirtualDevice dev : devices) {
            if (clazz.isInstance(dev)) {
                result.add((T)dev);
            }
        }
        return result;
    }

    private <T extends VirtualController> T getFirstAvailableController(Class<T> clazz, VirtualMachine vm) {
        VirtualController vc = createControllerInstance(clazz);
        for (T controller : getVirtualDevicesOfType(clazz, vm)) {
            if (controller.device == null) {
                return controller;
            }
        }
        return null;
    }

    public Task processChanges(VirtualMachine vm, List<VirtualDeviceConfigSpec> configSpecList) {
        if (configSpecList.size() > 0) {
            VirtualMachineConfigSpec config = new VirtualMachineConfigSpec();
            config.setDeviceChange(new VirtualDeviceConfigSpec[configSpecList.size()]);
            for (int index = 0; index < configSpecList.size(); index++) {
                config.getDeviceChange()[index] = configSpecList.get(index);
            }
            try {
                Task task = vm.reconfigVM_Task(config);
                return task;
            } catch (RemoteException re) {
                log.error("Remote exception occurred: {}", re.getMessage());
                log.error("Cause: {}", re.toString());
            }
        }
        return null;
    }

    public void disconnectUsbDeviceFromVm(VirtualMachine vm, VirtualDevice targetDevice) {
        List<VirtualDeviceConfigSpec> configSpecList = new ArrayList<>();
        if (vm != null) {
            List<VirtualUSBController> contollerList = getVirtualDevicesOfType(VirtualUSBController.class, vm);
            for (VirtualUSBController controller : contollerList) {
                if (controller.getKey() == targetDevice.getControllerKey()) {
                    if (controller.device.length == 1 && controller.device[0] == targetDevice.key) {
                        VirtualDeviceConfigSpec controllerSpec = new VirtualDeviceConfigSpec();
                        controllerSpec.setOperation(VirtualDeviceConfigSpecOperation.remove);
                        controllerSpec.setDevice(controller);
                        configSpecList.add(controllerSpec);
                        log.debug("Removed controller {}", controllerSpec.getDevice().getDeviceInfo().getLabel());
                    }
                    break;
                }
            }
            VirtualDeviceConfigSpec deviceSpec = new VirtualDeviceConfigSpec();
            deviceSpec.setOperation(VirtualDeviceConfigSpecOperation.remove);
            deviceSpec.setDevice(targetDevice);
            configSpecList.add(deviceSpec);
            Task task = processChanges(vm, configSpecList);
            try {
                String result = task.waitForTask();
                log.debug("Disconnect {}", targetDevice.getDeviceInfo().getSummary());
                log.debug("Result: {}", result);
            } catch (RemoteException re) {
                log.error("Remote exception: {}", re.getMessage());
                log.error("Cause: {}", re.toString());
            } catch (InterruptedException ie) {
                log.error("Interrupted: " + ie.getMessage());
            }
        }
    }

    public void connectUsbDeviceToVm(VirtualMachine vm, String vmwareDeviceName) {
        List<VirtualDeviceConfigSpec> configSpecList = new ArrayList<>();
        if (vm != null) {
            List<VirtualUSBController> contollerList = getVirtualDevicesOfType(VirtualUSBController.class, vm);
            if (contollerList.size() == 0) {
                VirtualDeviceConfigSpec controllerSpec = new VirtualDeviceConfigSpec();
                controllerSpec.setOperation(VirtualDeviceConfigSpecOperation.add);
                VirtualUSBController controller = new VirtualUSBController();
                controller.setAutoConnectDevices(true);
                controller.setKey(-1);
                controller.setBusNumber(-1);
                controller.setControllerKey(100);
                VirtualDeviceConnectInfo connect = new VirtualDeviceConnectInfo();
                connect.setConnected(true);
                connect.setStartConnected(true);
                connect.setAllowGuestControl(false);
                controller.setConnectable(connect);
                controllerSpec.setDevice(controller);
                configSpecList.add(controllerSpec);
                log.debug("Added USB controller since none were available");
            }

            VirtualDeviceConfigSpec deviceSpec = new VirtualDeviceConfigSpec();
            deviceSpec.setOperation(VirtualDeviceConfigSpecOperation.add);
            VirtualUSB usb = new VirtualUSB();
            usb.setKey(-100);

            VirtualUSBUSBBackingInfo backing = new VirtualUSBUSBBackingInfo();
            //String hostId = getHostAutoConnectString();
            //Other filtering options:
            //String deviceName = String.join(" ", "pid:" + productId, "vid:" + vendorId, "hostId:" + hostId);
            //String deviceName = String.join(" ", "path:5/0", "hostId:" + hostId);
            String deviceName = "name:" + vmwareDeviceName;
            backing.setDeviceName(deviceName);
            usb.setBacking(backing);

            VirtualDeviceConnectInfo connect = new VirtualDeviceConnectInfo();
            connect.setStartConnected(true);
            connect.setAllowGuestControl(false);
            connect.setConnected(true);
            usb.setConnectable(connect);
            usb.setConnected(false);
            deviceSpec.setDevice(usb);

            configSpecList.add(deviceSpec);
            Task task = processChanges(vm, configSpecList);
            try {
                String result = task.waitForTask();
                log.debug("Connecting USB device {}", vmwareDeviceName);
                log.debug("Result: {}", result);
            } catch (RemoteException re) {
                log.error("Remote exception: {}", re.getMessage());
                log.error("Cause: {}", re.toString());
            } catch (InterruptedException ie) {
                log.error("Interrupted: {}", ie.getMessage());
            }
        }
    }

    public String getHostAutoConnectString() {
        String uuid = getServer().getHardware().getSystemInfo().getUuid().replace("-", "");
        String[] chunks = new String[2];
        chunks[0] = uuid.substring(0, 16);
        chunks[1] = uuid.substring(16);
        for (int chunkIndex = 0; chunkIndex < chunks.length; chunkIndex += 1) {
            String[] hexCode = new String[8];
            int hexIndex = 0;
            int offset = 0;
            while (offset < chunks[chunkIndex].length()) {
                hexCode[hexIndex] = chunks[chunkIndex].substring(offset, offset + 2);
                hexIndex += 1;
                offset += 2;
            }
            chunks[chunkIndex] = String.join("\\ ", hexCode);
        }
        return String.join("-", chunks);
    }

    private VirtualDevice findVirtualDevice(VirtualMachineConfigInfo vmConfig, String name) {
        VirtualDevice [] devices = vmConfig.getHardware().getDevice();
        for (int index = 0; index < devices.length; index++) {
            if (devices[index].getDeviceInfo().getLabel().equals(name)) {
                return devices[index];
            }
        }
        return null;
    }

    public VirtualDevice[] getDefaultDevices() {
        VirtualDevice[] defaultDevs = null;
        try {
            Folder rootFolder = getService().getRootFolder();
            ManagedEntity[] hosts = (ManagedEntity[]) new InventoryNavigator(rootFolder).searchManagedEntities("HostSystem");
            HostSystem host = (HostSystem) hosts[0];
            HostHardwareInfo hw = host.getHardware();
            ComputeResource cr = (ComputeResource) host.getParent();
            EnvironmentBrowser envBrowser = cr.getEnvironmentBrowser();

            VirtualMachineConfigOption cfgOpt = envBrowser.queryConfigOption(null, host);
            if (cfgOpt == null) {
                log.error("No VirtualMachineConfigOption found in EnvironmentBrowser");
            } else {
                defaultDevs = cfgOpt.getDefaultDevice();
                if (defaultDevs == null) {
                    log.error("No defaultDevs found in VirtualMachineConfigOption");
                }
            }
        } catch (RemoteException re) {
            log.error("RemoteException: {}", re.getMessage());
        }
        return defaultDevs;
    }

    private LeaseProgressUpdater leaseUpdater;

    public void importRemoteOvf(String ovfUrl, String newVmName, String network, String datastore) throws RemoteException, IOException {
        log.debug("Target host: {}", getHost().getName());
        log.debug("Target network: {}", getNetwork(network).getName());
        log.debug("Target datastore: {}", getDatastore(datastore).getName());

        Folder vmFolder = (Folder) getHost().getVms()[0].getParent();

        OvfCreateImportSpecParams importSpecParams = new OvfCreateImportSpecParams();
        importSpecParams.setHostSystem(getHost().getMOR());
        importSpecParams.setIpAllocationPolicy("DHCP");
        importSpecParams.setIpProtocol("IPv4");
        //monolithicSparse monolithicFlat twoGbMaxExtentSparse twoGbMaxExtentFlat thin thick sparse flat
        //importSpecParams.setDiskProvisioning("thin");
        importSpecParams.setLocale("US");
        importSpecParams.setEntityName(newVmName);
        importSpecParams.setDeploymentOption("");
        OvfNetworkMapping networkMapping = new OvfNetworkMapping();
        networkMapping.setName("NAT");
        networkMapping.setNetwork(getNetwork(network).getMOR());
        importSpecParams.setNetworkMapping(new OvfNetworkMapping[] { networkMapping });
        importSpecParams.setPropertyMapping(null);

        String ovfDescriptor = readOvfContent(ovfUrl);
        if (ovfDescriptor == null) {
            return;
        }

        ResourcePool rp = ((ComputeResource) getHost().getParent()).getResourcePool();

        OvfCreateImportSpecResult ovfImportResult = getService().getOvfManager().createImportSpec(
                ovfDescriptor, rp, getDatastore(datastore), importSpecParams);

        if (ovfImportResult == null) {
            log.error("Failed to create import spec: ovfUrl: {}, vmName: {}", ovfUrl, newVmName);
            return;
        }

        if (ovfImportResult.getError() != null && ovfImportResult.getError().length > 0) {
            for (LocalizedMethodFault fault : ovfImportResult.getError()) {
                log.error("createImportSpec error: {}", fault.getLocalizedMessage());
            }
            return;
        }

        if (ovfImportResult.getWarning() != null && ovfImportResult.getWarning().length > 0) {
            for (LocalizedMethodFault fault : ovfImportResult.getError()) {
                log.warn("createImportSpec warning: {}", fault.getLocalizedMessage());
            }
        }

        long totalBytes = addTotalBytes(ovfImportResult);

        HttpNfcLease httpNfcLease = rp.importVApp(ovfImportResult.getImportSpec(), vmFolder, getHost());

        // Wait until the HttpNfcLeaseState is ready
        HttpNfcLeaseState hls;
        while (true) {
            hls = httpNfcLease.getState();
            if(hls == HttpNfcLeaseState.ready || hls == HttpNfcLeaseState.error) {
                break;
            }
        }

        if (hls.equals(HttpNfcLeaseState.ready)) {
            log.debug("HttpNfcLeaseState: ready ");
            HttpNfcLeaseInfo httpNfcLeaseInfo = httpNfcLease.getInfo();
            updateLeaseInfo(httpNfcLeaseInfo);

            leaseUpdater = new LeaseProgressUpdater(httpNfcLease, 5000);
            leaseUpdater.start();

            HttpNfcLeaseDeviceUrl[] deviceUrls = httpNfcLeaseInfo.getDeviceUrl();

            long bytesAlreadyWritten = 0;
            for (HttpNfcLeaseDeviceUrl deviceUrl : deviceUrls) {
                String deviceKey = deviceUrl.getImportKey();
                for (OvfFileItem ovfFileItem : ovfImportResult.getFileItem()) {
                    if (deviceKey.equals(ovfFileItem.getDeviceId())) {
                        log.debug("Import key==OvfFileItem device id: {}", deviceKey);
                        String[] urlChunks = ovfUrl.split("/");
                        urlChunks[urlChunks.length - 1] = ovfFileItem.getPath();
                        URL vmdkUrl = new URL(String.join("/", urlChunks));

                        String urlToPost = deviceUrl.getUrl().replace("*", getAddress());
                        Long totalSize = getFileSize(vmdkUrl);
                        printVmdkDetails(ovfFileItem.isCreate(), vmdkUrl, urlToPost, bytesAlreadyWritten, totalSize);
                        uploadVmdkFile(ovfFileItem.isCreate(), vmdkUrl, urlToPost, bytesAlreadyWritten, totalSize);
                        bytesAlreadyWritten += ovfFileItem.getSize();
                        log.debug("Completed uploading the VMDK file: {}", vmdkUrl);
                    }
                }
            }

            leaseUpdater.interrupt();
            httpNfcLease.httpNfcLeaseProgress(100);
            httpNfcLease.httpNfcLeaseComplete();
        }
    }

    private Datastore getDatastore(String targetStore) {
        try {
            for (Datastore eachStore : getHost().getDatastores()) {
                if (eachStore.getName().contains(targetStore)) {
                    return eachStore;
                }
            }
        } catch (RemoteException re) {
            log.error("Exception getting datastore: {}", re.getMessage());
        }
        return null;
    }

    private Network getNetwork(String targetNet) {
        try {
            Datacenter datacenter = (Datacenter) getHost().getParent().getParent().getParent();
            for (Network eachNet : datacenter.getNetworks()) {
                if (eachNet.getName().contains(targetNet)) {
                    return eachNet;
                }
            }
        } catch (RemoteException re) {
            log.error("Exception getting networks: {}", re.getMessage());
        }
        return null;
    }

    public long addTotalBytes(OvfCreateImportSpecResult ovfImportResult) {
        OvfFileItem[] fileItemArr = ovfImportResult.getFileItem();

        long totalBytes = 0;
        if (fileItemArr != null) {
            for (OvfFileItem fi : fileItemArr) {
                printOvfFileItem(fi);
                totalBytes += fi.getSize();
            }
        }
        return totalBytes;
    }

    private void uploadVmdkFile(boolean put, URL diskFileUrl, String urlStr,
        long bytesAlreadyWritten, long totalBytes) throws IOException {

        int chunkLength = 64 * 1024;
        HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
            public boolean verify(String urlHostName, SSLSession session)
            {
                return true;
            }
        });

        HttpsURLConnection conn = (HttpsURLConnection) new URL(urlStr).openConnection();
        conn.setUseCaches(false);
        conn.setDoOutput(true);
        conn.setChunkedStreamingMode(chunkLength);
        conn.setRequestMethod(put ? "PUT" : "POST"); // Use a post method to write the file.
        conn.setRequestProperty("Connection", "Keep-Alive");
        conn.setRequestProperty("Content-Type", "application/x-vnd.vmware-streamVmdk");
        conn.setRequestProperty("Content-Length", Long.toString(totalBytes));
        conn.connect();

        BufferedOutputStream bos = new BufferedOutputStream(conn.getOutputStream());
        BufferedInputStream diskis = new BufferedInputStream(diskFileUrl.openStream());

        byte[] buffer = new byte[chunkLength];

        long totalBytesWritten = 0;
        String lastMessage = "";
        while (true) {
            int bytesRead = diskis.read(buffer, 0, chunkLength);
            if (bytesRead == -1) {
                log.debug("Total bytes written: {}", totalBytesWritten);
                break;
            }

            totalBytesWritten += bytesRead;
            bos.write(buffer, 0, bytesRead);
            bos.flush();

            int progressPercent = (int) (((bytesAlreadyWritten + totalBytesWritten) * 100) / totalBytes);
            if (progressPercent % 10 == 0 && progressPercent != 0) {
                String message = String.format("%d percent uploaded ", progressPercent);
                if (!lastMessage.contains(message)) {
                    log.debug(message);
                }
                lastMessage = message;
            }
            leaseUpdater.setPercent(progressPercent);
        }

        diskis.close();
        bos.flush();
        bos.close();
        conn.disconnect();
    }

    public long getFileSize(URL url) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("HEAD");
            return conn.getContentLengthLong();
        } catch (IOException e) {
            return -1;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    public static String readOvfContent(String ovfFilePath) throws IOException {
        URL ovfLink = new URL(ovfFilePath);
        StringBuffer strContent = new StringBuffer();
        BufferedReader in = new BufferedReader(new InputStreamReader(ovfLink.openStream()));
        String lineStr;
        while ((lineStr = in.readLine()) != null) {
            strContent.append(lineStr);
        }
        in.close();
        return strContent.toString();
    }

    private void updateLeaseInfo(HttpNfcLeaseInfo info) {
        log.debug("================ HttpNfcLeaseInfo ================");
        HttpNfcLeaseDeviceUrl[] deviceUrlArr = info.getDeviceUrl();
        for (HttpNfcLeaseDeviceUrl durl : deviceUrlArr) {
            log.debug("Device URL Import Key: {}", durl.getImportKey());
            log.debug("Device URL Key: {}", durl.getKey());
            log.debug("Device URL: {}", durl.getUrl());
            //durl.setUrl(durl.getUrl().replace("*", getAddress()));
            log.debug("Updated device URL: {}", durl.getUrl());
        }
        log.debug("Lease Timeout: {}", info.getLeaseTimeout());
        log.debug("Total Disk capacity: {}", info.getTotalDiskCapacityInKB());
        log.debug("--------------------------------------------------");
    }

    private void printOvfFileItem(OvfFileItem fi) {
        log.debug("================== OvfFileItem ===================");
        log.debug("chunkSize: {}", fi.getChunkSize());
        log.debug("create: {}", fi.isCreate());
        log.debug("deviceId: {}", fi.getDeviceId());
        log.debug("path: {}", fi.getPath());
        log.debug("size: {}", fi.getSize());
        log.debug("---------------------------------------------------");
    }

    private void printVmdkDetails(Boolean put, URL ovfSource, String ovfDestination, Long bytesWritten, Long ovfSize) {
        log.debug("================== OvfFileItem ===================");
        log.debug("Request method: {}", (put ? "PUT" : "POST"));
        log.debug("OVF Source: {}", ovfSource);
        log.debug("OVF Destination: {}", ovfDestination);
        log.debug("OVF Size: {}", ovfSize);
        log.debug("Bytes written: {}", bytesWritten);
        log.debug("==================================================");
    }

    public Boolean vmwareToolsInstalled(VirtualMachine vm) {
        GuestInfo guestInfo = vm.getGuest();
        if (guestInfo == null) {
            log.trace("VM " + vm.getName() + " does not have tools installed");
            return false;
        } else {
            return true;
        }
    }

    public Boolean hasVm(String vmName) {
        Folder rootFolder = getService().getRootFolder();
        try {
            VirtualMachine vm = (VirtualMachine) new InventoryNavigator(rootFolder).searchManagedEntity("VirtualMachine", vmName);
            return vm != null;
        } catch (RemoteException re) {
            return false;
        }
    }

    public Boolean vmPoweredOn(VirtualMachine vm) {
        VirtualMachineRuntimeInfo vmri = vm.getRuntime();
        return vmri.getPowerState() == VirtualMachinePowerState.poweredOn;
    }

    public Boolean vmPoweredOff(VirtualMachine vm) {
        VirtualMachineRuntimeInfo vmri = vm.getRuntime();
        return vmri.getPowerState() == VirtualMachinePowerState.poweredOff;
    }

    public Boolean vmSuspended(VirtualMachine vm) {
        VirtualMachineRuntimeInfo vmri = vm.getRuntime();
        return (vmri.getPowerState() == VirtualMachinePowerState.suspended);
    }

    public void destroy(String vmName) throws RemoteException, InterruptedException {
        Folder rootFolder = getService().getRootFolder();
        VirtualMachine vm = (VirtualMachine) new InventoryNavigator(rootFolder).searchManagedEntity("VirtualMachine", vmName);
        if (vm != null) {
            Task task = vm.destroy_Task();
            task.waitForTask();
            log.debug("Destroyed VM {}", vmName);
        } else {
            log.warn("VM {} was already destroyed", vmName);
        }
    }

    public void power(String vmname, String operation) {
        Folder rootFolder = getService().getRootFolder();
        if (vmname == null) {
            log.error("No VM name was specified");
            return;
        }

        try {
            VirtualMachine vm = (VirtualMachine) new InventoryNavigator(rootFolder).searchManagedEntity("VirtualMachine", vmname);

            if (vm == null) {
                log.warn("VM {} was not found", vmname);
            } else if (operation.equalsIgnoreCase("reboot")) {
                if (vmwareToolsInstalled(vm)) {
                    vm.rebootGuest();
                    log.info("VM {} guest OS rebooted", vmname);
                } else {
                    log.warn("VM {} does not have Vmware Tools installed", vmname);
                }
            } else if (operation.equalsIgnoreCase("poweron") && (vmPoweredOff(vm) || vmSuspended(vm))) {
                Task task = vm.powerOnVM_Task(null);
                if (task.waitForTask() == Task.SUCCESS) {
                    log.info("VM {} powered on", vmname);
                }
            } else if (operation.equalsIgnoreCase("poweroff") && (vmPoweredOn(vm) || vmSuspended(vm))) {
                Task task = vm.powerOffVM_Task();
                if (task.waitForTask() == Task.SUCCESS) {
                    log.info("VM {} powered off", vmname);
                }
            } else if (operation.equalsIgnoreCase("reset")) {
                Task task = vm.resetVM_Task();
                if (task.waitForTask() == Task.SUCCESS) {
                    log.info("VM {} reset", vmname);
                }
            } else if (operation.equalsIgnoreCase("standby") && vmPoweredOn(vm)) {
                if (vmwareToolsInstalled(vm)) {
                    vm.standbyGuest();
                    log.info("VM {} guest OS set to standby", vmname);
                } else {
                    log.warn("VM {} does not have Vmware Tools installed", vmname);
                }
            } else if (operation.equalsIgnoreCase("suspend") && vmPoweredOn(vm)) {
                Task task = vm.suspendVM_Task();
                if (task.waitForTask() == Task.SUCCESS) {
                    log.info("VM {} suspended", vmname);
                }
            } else if (operation.equalsIgnoreCase("shutdown") && vmPoweredOn(vm)) {
                if (vmwareToolsInstalled(vm)) {
                    vm.shutdownGuest();
                    log.info("VM {} guest OS shut down", vmname);
                } else {
                    log.warn("VM {} does not have Vmware Tools installed", vmname);
                }
            } else {
                log.warn("Invalid power operation {} for VM {}", operation, vmname);
            }
        } catch (InvalidProperty ip) {
            log.error("Invalid property used: {}", ip.getMessage());
        } catch (RuntimeFault rtf) {
            log.error("Runtime fault occurred: {}", rtf.getMessage());
        } catch (RemoteException re) {
            log.error("Remote exception occurred: {}", re.getMessage());
        } catch (InterruptedException ie) {
            log.error("Interrupted during power operation: {}", ie.getMessage());
            Thread.currentThread().interrupt();
        }
    }
}
