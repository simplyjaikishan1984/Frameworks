package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamDeviceListPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.sam.pages.SamDeviceListPage.DeviceListColumns.*;

public class SamDeviceListSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I select only the \"([^\"]*)\" device$")
    public void selectOnlyDevice(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.enableOnlyCheckboxWithAddress(Environment.getPhone(arg1.trim()).getMacAddress());
        log.debug("Selected device {}", Environment.getPhone(arg1.trim()).getSerialNumber());
    }

    @When("^I select the \"([^\"]*)\" device$")
    public void selectDevice(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.enableCheckboxWithAddress(Environment.getPhone(arg1.trim()).getMacAddress());
        log.debug("Selected device {}", Environment.getPhone(arg1.trim()).getSerialNumber());
    }

    @When("^I select all devices$")
    public void selectAllDevices() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.enableSelectAll();
        log.debug("Selected all devices");
    }

    @When("^I deselect all devices$")
    public void deselectAllDevices() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.disableSelectAll();
        log.debug("Deselected all devices");
    }

    @When("^I select \"([^\"]*)\" from the Device List action menu$")
    public void selectDeviceAction(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        switch (arg1.trim()) {
            case "Change config":
                Environment.setCurrentPage(devicePage.selectChangeConfig(), Environment.SamPage.BARCODE);
                break;
            case "Re-apply config":
                devicePage.selectReapplyConfig();
                break;
            case "Trigger Heartbeat":
                devicePage.selectTriggerHeartbeat();
                break;
            case "Export All device(s)":
                devicePage.selectExportAllDevices();
                sleepSeconds(5);
                break;
            default:
                log.error("Cannot select '{}' from action menu", arg1);
                Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^I enter \"([^\"]*)\" into the Device List search field$")
    public void enterGroupSearchValue(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.enterSearchValue(arg1.trim());
    }

    private String getSearchString(VersityPhone phone, SamDeviceListPage.DeviceListColumns column, boolean full, boolean positive) {
        String query = "";
        String operator = positive ? " = " : " != ";
        switch (column) {
            case MAC:
                query = full ? MAC.title() + operator + Util.qquote(phone.getMacAddress()) : phone.getMacAddress();
                break;
            case SERIAL_NUMBER:
                query = full ? SERIAL_NUMBER.title() + operator + Util.qquote(phone.getSerialNumber()) : phone.getSerialNumber();
                break;
            case FIRMWARE_VERSION:
                query = full ? FIRMWARE_VERSION.title() + operator + Util.qquote(phone.getBuildDisplayId()): phone.getBuildDisplayId();
                break;
            case MODEL:
                String modifiedModel = phone.getModel().toUpperCase().replace(" ", "_");
                query = full ? MODEL.title() + operator + Util.qquote(modifiedModel) : modifiedModel;
                break;
            case NETWORK_RSSI:
                Long rssi = Environment.getSam().keyDatabase().getDeviceRssi(phone.getSerialNumber());
                query = full ? NETWORK_RSSI.title() + operator + Util.qquote(rssi) : rssi.toString();
                break;
            case NETWORK_IP:
                query = full ? NETWORK_IP.title() + operator + Util.qquote(phone.getIpAddress()) : phone.getIpAddress();
                break;
            case DEVICE_INFO_1:
                String info1 = Environment.getSam().keyDatabase().getDeviceInfo1(phone.getSerialNumber());
                query = full ? DEVICE_INFO_1.title() + operator + Util.qquote(info1) : info1;
                break;
            case DEVICE_INFO_2:
                String info2 = Environment.getSam().keyDatabase().getDeviceInfo2(phone.getSerialNumber());
                query = full ? DEVICE_INFO_2.title() + operator + Util.qquote(info2): info2;
                break;
            case DEVICE_INFO_3:
                String info3 = Environment.getSam().keyDatabase().getDeviceInfo3(phone.getSerialNumber());
                query = full ? DEVICE_INFO_3.title() + operator + Util.qquote(info3) : info3;
                break;
            case DEVICE_INFO_4:
                String info4 = Environment.getSam().keyDatabase().getDeviceInfo4(phone.getSerialNumber());
                query = full ? DEVICE_INFO_4.title() + operator + Util.qquote(info4): info4;
                break;
            case GROUP:
                String group = Environment.getSam().keyDatabase().getGroupForPhone(phone.getSerialNumber());
                query = full ? GROUP.title() + operator + Util.qquote(group) : group;
                break;
            case SIP_1_EXTENSION:
                String extension1 = Environment.getSam().keyDatabase().getSipExtension(phone.getSerialNumber());
                query = full ? SIP_1_EXTENSION.title() + operator + Util.qquote(extension1): extension1;
                break;
            case SIP_2_EXTENSION:
                String extension2 = Environment.getSam().keyDatabase().getSecondarySipExtension(phone.getSerialNumber());
                query = full ? SIP_2_EXTENSION.title() + operator + Util.qquote(extension2): extension2;
                break;
            case ANDROID_VERSION:
                String[] androidInfo = phone.getBuildDisplayId().split("\\s+");
                query = full ? ANDROID_VERSION.title() + operator + Util.qquote(androidInfo[1]): androidInfo[1];
                break;
            case UPDATER_ID:
                String[] updaterInfo = phone.getBuildDisplayId().split("\\s+");
                query = full ? UPDATER_ID.title() + operator + Util.qquote(updaterInfo[3]) : updaterInfo[3];
                break;
        }
        return query;
    }

    @When("^I enter the \"([^\"]*)\" of device \"([^\"]*)\" into the Device List search field$")
    public void enterSearchValue(String arg1, String arg2) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if (phone != null) {
            SamDeviceListPage.DeviceListColumns column = devicePage.getDeviceListColumn(arg1.trim());
            if (column != null) {
                devicePage.enterSearchValue(getSearchString(phone, column, false, false));
            } else {
                log.error("Column with title '{}' does not exist", arg1);
                Assert.fail("SAM UI Interaction Error");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @When("^I click the 'Search' button$")
    public void clickSearchButton() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.clickSearchButton();
    }

    @When("^I clear the search field$")
    public void clearSearchField() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.clickSearchClearButton();
    }

    @When("^I clear the advanced search field$")
    public void clearAdvancedSearchField() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.clickAdvancedSearchClear();
    }

    @When("^I click the 'Advanced' button$")
    public void clickAdvancedButton() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.clickAdvancedSearchLink();
    }

    @When("^I enter the query \"([^\"]*)\" into the Device List advanced search field$")
    public void enterAdvancedSearchQuery(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.enterAdvancedSearchValue(arg1.trim());
    }

    @When("^I enter a query for the \"([^\"]*)\" of device \"([^\"]*)\" into the Device List advanced search field$")
    public void enterRelativeSearchQuery(String arg1, String arg2) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if (phone != null) {
            SamDeviceListPage.DeviceListColumns column = devicePage.getDeviceListColumn(arg1.trim());
            if (column != null) {
                devicePage.enterAdvancedSearchValue(getSearchString(phone, column, true, true));
            } else {
                log.error("Column with title '{}' does not exist", arg1);
                Assert.fail("SAM UI Interaction Error");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @When("^I enter a negative query for the \"([^\"]*)\" of device \"([^\"]*)\" into the Device List advanced search field$")
    public void enterRelativeNegativeSearchQuery(String arg1, String arg2) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if (phone != null) {
            SamDeviceListPage.DeviceListColumns column = devicePage.getDeviceListColumn(arg1.trim());
            if (column != null) {
                devicePage.enterAdvancedSearchValue(getSearchString(phone, column, true, false));
            } else {
                log.error("Column with title '{}' does not exist", arg1);
                Assert.fail("SAM UI Interaction Error");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @When("^I click the advanced search magnifying glass button$")
    public void clickAdvancedSearchButton() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.clickAdvancedSearchButton();
        sleepSeconds(2);
    }

    @When("^I select \"([^\"]*)\" from the Device List search menu$")
    public void selectSearchField(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        if (devicePage.getSearchTypes().contains(arg1.trim())) {
            devicePage.selectSearchType(arg1.trim());
        } else {
            log.error("Menu option '{}' is not available from field search menu", arg1);
            Assert.fail("SAM Menu Option Not Found");
        }
    }

    @When("^I click the 'Change Columns' button$")
    public void clickChangeColumn() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.clickChangeColumns();
    }

    @When("^I click the Device List 'OK' button$")
    public void clickDeviceListColumnOkButton() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        devicePage.clickOkButton();
    }

    @When("^I enable the \"([^\"]*)\" column$")
    public void enableColumn(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        if (!devicePage.deviceListColumnModalDisplayed()) devicePage.clickChangeColumns();
        if (devicePage.getField(arg1.trim()) != null) {
            devicePage.getField(arg1.trim()).enable();
        } else {
            log.error("Cannot find checkbox for column {}", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^I disable the \"([^\"]*)\" column$")
    public void disableColumn(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        if (!devicePage.deviceListColumnModalDisplayed()) devicePage.clickChangeColumns();
        if (devicePage.getField(arg1.trim()) != null) {
            devicePage.getField(arg1.trim()).disable();
        } else {
            log.error("Cannot find checkbox for column {}", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("^the number of attributes sent to \"([^\"]*)\" in the last heartbeat should be over \"([^\"]*)\"$")
    public void verifyAttributeCount(String arg1, String arg2) {
        sleepSeconds(8);
        String targetSerial = Environment.getPhone(arg1.trim()).getSerialNumber();
        int threshold = Integer.valueOf(arg2);
        int attributeCount = Environment.getSam().jarvisLog().getLastResponseCount(targetSerial);
        log.debug("SAM sent {} attributes in its last heartbeat to {}", attributeCount, arg1);
        if (attributeCount > threshold) {
            log.debug("Acceptable number to attributes was sent to {}", arg1);
        } else {
            log.fatal("SAM sent {} attributes but expected at least {} after re-apply", attributeCount, threshold);
            Environment.getSam().jarvisLog().logLastFullResponse(targetSerial);
            Assert.fail("Minimum Sent Attribute Count Failure");
        }
    }

    @Then("^column \"([^\"]*)\" is visible$")
    public void verifyColumnVisible(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        if (devicePage.columnIsVisible(arg1.trim())) {
            log.debug("Column {} was displayed", arg1);
        } else {
            log.error("Column {} was not displayed", arg1);
            Assert.fail("Column Was Not Visible");
        }
    }

    @Then("^column \"([^\"]*)\" is not visible$")
    public void verifyColumnInvisible(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        if (devicePage.columnIsNotVisible(arg1.trim())) {
            log.debug("Column {} was hidden", arg1);
        } else {
            log.error("Column {} was not hidden", arg1);
            Assert.fail("Column Was Visible");
        }
    }

    @Then("^at least one device match is found$")
    public void verifyMatch() {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        int matches = devicePage.getDeviceRowCount();
        if (matches >= 1) {
            log.debug("Found {} device matches", matches);
        } else {
            log.error("No matches were found");
            Assert.fail("Device Search Failed");
        }
    }

    @Then("^exactly \"([^\"]*)\" matches are found$")
    public void verifyExactMatch(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        int matches = devicePage.getDeviceRowCount();
        int expectedMatches = Integer.parseInt(arg1.trim());
        if (matches == expectedMatches) {
            log.debug("Found {} device matches", matches);
        } else {
            log.error("{} matches were not found (actual {})", arg1, matches);
            Assert.fail("Device Search Failed");
        }
    }

    @Then("^device \"([^\"]*)\" is visible$")
    public void verifyDeviceVisible(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone != null) {
            if (devicePage.deviceIsVisible(phone.getMacAddress(), MAC.title())) {
                log.debug("Device {} was visible", arg1);
            } else {
                log.error("{} was not visible", arg1);
                Assert.fail("Device Search Failed");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @When("^I click the \"([^\"]*)\" Device List column heading$")
    public void clickColumnHeading(String arg1) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        if (devicePage.columnIsVisible(arg1.trim())) {
            devicePage.clickColumnHeading(arg1.trim());
        } else {
            log.error("Cannot find heading titled {}", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("^the sort direction for Device List column \"([^\"]*)\" should be \"([^\"]*)\"$")
    public void verifySortDirection(String arg1, String arg2) {
        SamDeviceListPage devicePage = (SamDeviceListPage) Environment.getCurrentPage();
        if (devicePage.columnIsVisible(arg1.trim())) {
            String direction = devicePage.getSortDirection(arg1.trim());
            if (direction.contains(arg2.trim())) {
                log.debug("Sort direction {} was verified", arg2);
            } else {
                log.fatal("Sort direction was not expected {}", arg2);
                Assert.fail("SAM Device Sort Failure");
            }
        } else {
            log.error("Cannot find heading titled {}", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }
}