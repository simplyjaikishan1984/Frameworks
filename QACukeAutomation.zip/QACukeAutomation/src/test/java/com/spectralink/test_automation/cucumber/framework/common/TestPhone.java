package com.spectralink.test_automation.cucumber.framework.common;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;

public interface TestPhone {

	public String getSerialNumber();

	public void setSerialNumber(String serialNumber);

	public Integer getPortNumber();

	public void setPortNumber(Integer portNumber);

	public Integer getBootstrapPortNumber();

	public void setBootstrapPortNumber(Integer bootstrapPortNumber);

	public String getStatus();

	public void setStatus(String status);

	public String getUsbPath();

	public void setUsbPath(String path);

	public UsbHost getHost();

	public void setHost(UsbHost host);

	public String getTransportId();

	public void setTransportId(String transportid);

	public String getBuildNumber();

	public String getBuildRelease();

	public String getBuildDisplayId();

	public String getVmwareName();

	public String getHardware();

	public String getWifiInterface();

	public String getTimezone();

	public String getModel();

	public boolean propertiesLoaded();

	public void loadSystemProperties();

	public Map<String, String> getProperties();

	public String getProperty(String propertyName);

	public boolean tableSettingsLoaded(String table);

	public void loadSettings(String table);

	public Map<String, String> getSettings(String table);

	public String getSetting(String table, String settingName);

	public JSONObject getSection(String table, String section);

	public String getServiceDump(String service);

	public Boolean getBatteryAcPowered();

	public Boolean getBatteryUsbPowered();

	public Integer getUptime();

	public String getScreenSize();

	public CliResult pullFileFromDevice(String deviceFile, String localFile);

	public CliResult pushFileToDevice(String localFile, String deviceFile);

	public CliResult sendAdbCommand(List<String> adbParameters);

	public String getIdentity();

	public String getIpAddress();

	public String getMacAddress();

	public boolean isConnectedViaAdb();

	public void setConnectedViaAdb(boolean connectedViaAdb);

	public boolean isRooted();

	public void setRooted(boolean rooted);

	public boolean hasCamera();

	public boolean hasBarcodeScanner();

	public AndroidPhone.PhoneType getPhoneType();
}





