package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.common.AndroidPhone;
import com.spectralink.test_automation.cucumber.framework.common.AppiumPhone;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.device.DeviceAutomation;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleep;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class AppiumUi extends DeviceAutomation {

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    protected Map<String, ConfigUiField> pageFields = new HashMap<>();
    protected AndroidDriver driver;

    @FindBy(id = "android:id/button1")
    private WebElement okButton;

    @FindBy(id = "android:id/button2")
    private WebElement cancelButton;

    public AppiumUi(AndroidDriver driver) {
        super(driver);
        this.driver = driver;
    }

    public void scrollIntoView(String label) {
        driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text(\"" + label + "\"));");
    }

    public ConfigUiField getField(String title) {
        ConfigUiField field = pageFields.get(title.toLowerCase());
        if (field != null) {
            return field;
        } else {
            log.error("Field '{}' does not exist or is not defined", title);
            Assert.fail("FIELD NOT FOUND");
            return null;
        }
    }

    public ConfigUiField getField(FieldData fieldName) {
        ConfigUiField field = pageFields.get(fieldName.title().toLowerCase());
        if (field != null) {
            return field;
        } else {
            log.error("Field '{}' does not exist or is not defined", fieldName.title());
            Assert.fail("FIELD NOT FOUND");
            return null;
        }
    }

    public List<String> getMenuOptions() {
        List<String> values = new ArrayList<>();
        List<WebElement> options = driver.findElements(By.xpath("//android.widget.CheckedTextView"));
        for (WebElement element : options) {
            values.add(element.getText());
        }
        return values;
    }

    public void tapOkButton() {
        if (isPresent(By.xpath("//android.widget.Button[(@resource-id ='android:id/button1')]"))) {
            clickOnPageEntity(okButton);
            sleep(800);
        } else {
            log.error("OK button was not visible");
        }
    }

    public void tapCancelButton() {
        if (isPresent(By.id("android:id/button2"))) {
            clickOnPageEntity(cancelButton);
            sleep(800);
        } else {
            log.error("Cancel button was not visible");
        }
    }

    public void bringAppToForeground(AndroidPhone.Application packageName, AppiumPhone.Activity activityName){
        Activity activity = new Activity(packageName.getPackage(), activityName.getIntent());
        driver.startActivity(activity);
        sleepSeconds(10);
    }

    public WebElement scrollIdIntoView(String id) {
        return driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().resourceId(\"" + id + "\"))");
    }

    public WebElement scrollDescriptionIntoView(String description) {
        WebElement target;
        try {
            target = driver.findElementByAccessibilityId(description);
            return target;
        } catch (NoSuchElementException nsee) {
            return driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().descriptionContains(\"" + description + "\"))");
        }
    }

    /*public boolean isPresent(By by) {
        boolean detected = false;
        detected = !driver.findElements(by).isEmpty();
        return detected;
    }

    public WebElement getElement(By by) {
        List<WebElement> elements = driver.findElements(by);
        if (elements.isEmpty()) {
            return null;
        } else if (elements.size() == 1) {
            return elements.get(0);
        } else {
            return null;
        }
    }

    public void moveToElement(WebElement element) {
        Actions actions = new Actions(driver);
        actions.moveToElement(element);
        actions.perform();
    }

    // Standard web page access methods with integrated waits. These should be under all calls to
    // web objects in the Page classes.*/

    public String getEntityTag(WebElement element) {
        try {
            waitForElementExistence(element);
            return element.getTagName();
        } catch (TimeoutException te) {
            log.error("Timeout looking for tag on {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not get tag on {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return null;
    }

    private String getEntitylabel(WebElement element) {
        try {
            if (element.getText() != null && !element.getText().isEmpty() && !element.getText().matches("\\s+") && !element.getText().contains("\n")) {
                return element.getText();
            } else if (element.getAttribute("id") != null && !element.getAttribute("id").isEmpty()) {
                return element.getAttribute("id");
            } else if (element.getCssValue("class") != null && !element.getCssValue("class").isEmpty()) {
                String[] classes = element.getCssValue("class").split("\\s");
                return classes[0];
            } else {
                return element.getTagName();
            }
        } catch (TimeoutException te) {
            log.error("Timeout looking for tag on {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not get tag on {}", element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
        return "missing element";
    }

    /*public void clickOnPageEntity(WebElement element) {
        try {
            waitForElement(element);
            log.debug("Clicking element {}", getEntitylabel(element));
            element.click();
        } catch (TimeoutException te) {
            log.error("Timeout trying to click {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not click {}", element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void typeIntoPageEntity(WebElement element, String text) {
        try {
            waitForElement(element);
            element.clear();
            element.sendKeys(text);
            log.debug("Entering into element {}: {}", getEntitylabel(element), text.trim());
        } catch (TimeoutException te) {
            log.error("Timeout entering {} into {}", text, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not find {}", element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void selectMenuByValue(WebElement element, String value) {
        try {
            waitForElement(element);
            Select listbox = new Select(element);
            log.debug("Selecting value {} from element {}", value, getEntitylabel(element));
            listbox.selectByValue(value);
        } catch (TimeoutException te) {
            log.error("Timeout selecting value {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not select value {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void selectMenuByText(WebElement element, String value) {
        try {
            waitForElement(element);
            Select listbox = new Select(element);
            log.debug("Selecting text '{}' from element {}", value, getEntitylabel(element));
            listbox.selectByVisibleText(value);
        } catch (TimeoutException te) {
            log.error("Timeout selecting text {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not select text {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element.toString());
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void selectMenuByIndex(WebElement element, Integer value) {
        try {
            waitForElement(element);
            Integer optionNumber = value + 1;
            Select listbox = new Select(element);
            log.debug("Selecting option {} (index {}) from element {}", optionNumber, value, getEntitylabel(element));
            listbox.selectByIndex(value);
        } catch (TimeoutException te) {
            log.error("Timeout selecting index {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not select index {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void selectMenuByIndexWithPresence(WebElement element, By by, Integer value) {
        try {
            waitForElementPresence(by);
            Integer optionNumber = value + 1;
            Select listbox = new Select(element);
            log.debug("Selecting option {} (index {}) from element {}", optionNumber, value, getEntitylabel(element));
            listbox.selectByIndex(value);
        } catch (TimeoutException te) {
            log.error("Timeout selecting index {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not select index {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void deselectMenuByIndex(WebElement element, Integer value) {
        try {
            waitForElement(element);
            Integer optionNumber = value + 1;
            Select listbox = new Select(element);
            log.debug("Deselecting option {} (index {}) from element {}", optionNumber, value, getEntitylabel(element));
            listbox.deselectByIndex(value);
        } catch (TimeoutException te) {
            log.error("Timeout deselecting menu option {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not deselect menu index {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public WebElement locateElement(By by) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, explicitWait);
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(by));
            return element;
        } catch (TimeoutException te) {
            log.error("Could not locate element with {}", by.toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Found stale element with {}", by.toString());
        }
        return null;
    }

    public WebElement getElement(By by, int position) {
        try {
            return waitForElements(by, position);
        } catch (TimeoutException te) {
            log.error("Could not get element with {}", by.toString());
        }
        return null;
    }

    public Boolean isEntitySelected(WebElement element) {
        try {
            return element.isSelected();
        } catch (NoSuchElementException nsee) {
            log.error("Could not check if selected element {}", element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Could not access stale element {}", element);
        }
        return false;
    }

    public Boolean isEntityEnabled(WebElement element) {
        Boolean answer = false;
        try {
            waitForElement(element);
            answer = element.isEnabled();
        } catch (TimeoutException te) {
            log.error("Timeout checking if enabled element {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not check if enabled element {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return answer;
    }

    public void clearPageEntity(WebElement element) {
        try {
            waitForElement(element);
            element.clear();
            log.debug("Clearing element {}", getEntitylabel(element));
        } catch (TimeoutException te) {
            log.error("Timeout clearing element {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not clear element {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
    }

    public WebElement getChildEntity(WebElement element, By by) {
        try {
            //waitForChildElementPresence(element, by);
            return element.findElement(by);
        } catch (TimeoutException te) {
            log.debug("Timeout getting child for element {}", element);
        } catch (NoSuchElementException nsee) {
            log.trace("Could not get child for element {}", element);
        }
        return null;
    }

    public String getEntityText(WebElement element) {
        try {
            waitForElement(element);
            return element.getText();
        } catch (TimeoutException te) {
            log.error("Timeout getting text for {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not get text for {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return null;
    }

    public String getEntityAttribute(WebElement element, String attribute) {
        try {
            waitForElementExistence(element);
            return element.getAttribute(attribute);
        } catch (TimeoutException te) {
            log.error("Timeout getting attribute for {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not get attribute for {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return null;
    }

    public String getMenuSelectedOption(WebElement element) {
        String selectedAnswer = null;
        try {
            waitForElement(element);
            Select box = new Select(element);
            WebElement selection = box.getFirstSelectedOption();
            selectedAnswer = selection.getText();
            log.info("Found option {} was selected in menu {}", selectedAnswer, getEntitylabel(element));
        } catch (TimeoutException te) {
            log.error("Timeout getting selected option for {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not find page element {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return selectedAnswer;
    }

    public void deletePageSetting(By by) {
        if (isPresent(by)) {
            WebElement element = locateElement(by);
            clickOnPageEntity(element);
            sleepSeconds(1);
            WebElement deleteButton = locateElement(By.xpath("//button[@ng-click=\"ok()\"]"));
            clickOnPageEntity(deleteButton);
            sleepSeconds(1);
        } else {
            log.trace("Element not found with {}", by.toString());
        }
    }

    public boolean isEntityDisplayed(WebElement element) {
        try {
            waitForElement(element);
            return element.isDisplayed();
        } catch (TimeoutException te) {
            log.error("Timeout checking if displayed {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not find page element {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return false;
    }

    public boolean isEntityClickable(WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, getExplicitWait());
            wait.until(ExpectedConditions.elementToBeClickable(element));
            return true;
        } catch (TimeoutException te) {
            // expected failures
        } catch (NoSuchElementException nsee) {
            log.trace("Could not find if clickable {}", element);
        } catch (StaleElementReferenceException sere) {
            log.trace("Could not access stale element {}", element);
        }
        return false;
    }*/
}
