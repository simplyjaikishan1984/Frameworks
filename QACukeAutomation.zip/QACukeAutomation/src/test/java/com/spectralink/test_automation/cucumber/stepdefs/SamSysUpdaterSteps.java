package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamSysUpdaterPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.SYS_UPDATER;

public class SamSysUpdaterSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I click the 'Trigger OTA' SysUpdater button$")
	public void clickSysUpdaterButton() {
		SamSysUpdaterPage updaterPage = (SamSysUpdaterPage) Environment.getCurrentPage();
		updaterPage.clickOnPageEntity(updaterPage.getField("Trigger OTA").getTargetElement());
	}

	@When("^I record the current trigger values of all phones$")
	public void clickSendConfiguration() throws Throwable {
		for (String phoneName : Environment.getPhones().keySet()) {
			VersityPhone thisPhone = Environment.getPhones().get(phoneName);
			String lastTrigger = Environment.getSam().keyDatabase().getLastTriggerSetting(thisPhone.getSerialNumber());
			Environment.setTemporaryValue(phoneName, lastTrigger);
			log.debug("OTA trigger value for {} is initially set to {}", phoneName, lastTrigger);
		}
	}

	@When("^I check the \"([^\"]*)\" SysUpdater field$")
	public void checkSysUpdaterCheckbox(String arg1) {
		SamSysUpdaterPage updaterPage = (SamSysUpdaterPage) Environment.getCurrentPage();
		if (updaterPage.getField(arg1.trim()) != null) {
			updaterPage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I uncheck the \"([^\"]*)\" SysUpdater field$")
	public void uncheckSysUpdaterCheckbox(String arg1) {
		SamSysUpdaterPage updaterPage = (SamSysUpdaterPage) Environment.getCurrentPage();
		if (updaterPage.getField(arg1.trim()) != null) {
			updaterPage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" SysUpdater field$")
	public void selectSysUpdaterMenuOption(String arg1, String arg2) {
		SamSysUpdaterPage updaterPage = (SamSysUpdaterPage) Environment.getCurrentPage();
		if (updaterPage.getField(arg2) != null) {
			updaterPage.getField(arg2.trim()).updateMenuByLabel(arg1.trim());
		} else {
			log.error("Field with label '{}' does not exist", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" SysUpdater field$")
	public void enterSysUpdaterFieldValue(String arg1, String arg2) {
		SamSysUpdaterPage updaterPage = (SamSysUpdaterPage) Environment.getCurrentPage();
		if (updaterPage.getField(arg2.trim()) != null) {
			updaterPage.getField(arg2.trim()).updateTextbox(arg1.trim());
		} else {
			log.error("No matching field with label '{}'", arg2);
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the \"([^\"]*)\" SysUpdater setting$")
	public void verifySysUpdaterValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(SYS_UPDATER, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(SYS_UPDATER, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(SYS_UPDATER)) phone.loadAppPreferences(SYS_UPDATER);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("Field with label '{}' does not exist", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("the SysUpdater trigger value for \"([^\"]*)\" should not have changed$")
	public void verifySysUpdaterTriggerSame(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (!phone.getCurrentAppSettings().equals(SYS_UPDATER)) phone.loadAppPreferences(SYS_UPDATER);
			Environment.addScenarioFailure(phone.compare("ota_trigger_setting", Environment.getTemporaryValue(arg1.trim())));
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("the SysUpdater trigger value for \"([^\"]*)\" should have changed$")
	public void verifySysUpdaterTriggerDifferent(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (!phone.getCurrentAppSettings().equals(SYS_UPDATER)) phone.loadAppPreferences(SYS_UPDATER);
			Environment.addScenarioFailure(phone.contrast("ota_trigger_setting", Environment.getTemporaryValue(arg1.trim())));
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I delete the \"([^\"]*)\" SysUpdater field$")
	public void deleteSysUpdaterSetting(String arg1) {
		SamSysUpdaterPage updaterPage = (SamSysUpdaterPage) Environment.getCurrentPage();
		updaterPage.getField(arg1.trim()).delete();
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the SysUpdater custom attribute \"([^\"]*)\" setting$")
	public void checkSysUpdaterCustomAttributeSetting(String arg1, String arg2, String arg3) {
		if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
			VersityPhone phone = Environment.getPhone(arg1.trim());
			if (phone != null) {
				if (!phone.getCurrentAppSettings().equals(SYS_UPDATER)) phone.loadAppPreferences(SYS_UPDATER);
				Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
			} else {
				log.error("Phone with label '{}' does not exist", arg1);
				Assert.fail("Specified Phone Not Available");
			}
		} else {
			log.debug("Skipped checking attribute '{}' since custom attribute testing is turned off", arg3);
		}
	}

	@Then("^the SysUpdater page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifySysUpdaterPageValue(String arg1, String arg2) {
		SamSysUpdaterPage updaterPage = (SamSysUpdaterPage) Environment.getCurrentPage();
		if (updaterPage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(updaterPage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(updaterPage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Sysupdater field with label '{}' does not exist", arg2);
		}
	}
}