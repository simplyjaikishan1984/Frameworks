package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Date;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Database {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	protected String dbIP;
	protected Integer dbPort;
	protected String dbUsername;
	protected String dbPassword;
	protected Connection dbConnection;
	protected String dbName;
	protected String url = "";

	public Database(String dbIP, Integer dbPort, String dbName, String dbUsername, String dbPassword) {
		this.dbIP = dbIP;
		this.dbPort = dbPort;
		this.dbName = dbName;
		this.dbUsername = dbUsername;
		this.dbPassword = dbPassword;

		try {
			Class.forName("org.postgresql.Driver");
			url = "jdbc:postgresql://" + dbIP + ":" + dbPort + "/" + dbName;
			dbConnection = DriverManager.getConnection(url, dbUsername, dbPassword);
			log.debug("Opened database connection to {}", dbName);
		} catch (ClassNotFoundException | SQLException e) {
			log.error("DB connection error {}", e.getMessage());
			throw new RuntimeException("Database connect error for url: " + url);
		}

		if (dbConnection == null) {
			log.debug("Received null from Drivermanager.getConnection");
			throw new RuntimeException("Database connect error for IP:" + dbIP + ", name: " + dbName);
		}
	}

	public void reconnect() {
		try {
			close();
			Class.forName("org.postgresql.Driver");
			dbConnection = DriverManager.getConnection(url, dbUsername, dbPassword);
			log.debug("Opened database connection to {}", dbName);
		} catch (ClassNotFoundException | SQLException e) {
			log.error("Failed to reconnect to {}: {}", dbName, e.getMessage());
			throw new RuntimeException("Database reconnect error for url: " + url);
		}
	}

	public String getDbIP() {
		return dbIP;
	}

	public Integer getDbPort() {
		return dbPort;
	}

	public String getDbUsername() {
		return dbUsername;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public Connection getDbConnection() {
		return dbConnection;
	}

	public String getDbName() {
		return dbName;
	}

	public Iterator<HashMap<String, Object>> query(String sql) {
		ResultSet results = null;
		Statement st = null;

		List<HashMap<String, Object>> list = null;

		try {
			st = dbConnection.createStatement();
			log.trace("Query: " + sql);
			results = st.executeQuery(sql);

			ResultSetMetaData md = results.getMetaData();
			int columns = md.getColumnCount();
			list = new ArrayList<HashMap<String, Object>>();

			while (results.next()) {
				HashMap<String, Object> row = new HashMap<String, Object>(columns);
				for (int i = 1; i <= columns; ++i) {
					row.put(md.getColumnName(i), results.getObject(i));
				}
				list.add(row);
			}
		} catch (SQLException e) {
			log.error("SQL query error; ", e.getMessage());
			log.error("QUERY: {}", sql);
		} finally {
			// close connections
			if (st != null) {
				try {
					st.close();
				} catch (SQLException e) {
					log.error("DB close error {}", e.getMessage());
				}
			}
			if (results != null) {
				try {
					results.close();
				} catch (SQLException e) {
					log.error("DB close error {}", e.getMessage());
				}
			}
		}
		return list.iterator();
	}

	public int update(String sql) {
		Statement statement = null;
		int result = 0;

		try {
			statement = dbConnection.createStatement();
			result = statement.executeUpdate(sql);
		} catch (SQLException sqle) {
			log.error("SQL query error; ", sqle.getMessage());
			log.error("QUERY: {}", sql);
		} finally {
			try {
				if (statement != null) statement.close();
			} catch (SQLException e) {
				log.error("statement close error {}", e.getMessage());
			}
		}
		return result;
	}

	public String convertTimestampToCmsTime(Timestamp timestamp) {
		LocalDateTime creation = timestamp.toLocalDateTime().withNano(0);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.US);
		return formatter.format(creation);
	}

	public String queryString(String queryString, String column) {
		Iterator<HashMap<String, Object>> iter = query(queryString);
		if (iter.hasNext()) {
			HashMap<String, Object> row = iter.next();
			return (String) row.get(column);
		} else {
			log.warn("Query '{}' yielded no results", queryString);
			return null;
		}
	}

	public String queryStringNew(String queryString, String column) {
		Iterator<HashMap<String, Object>> iter = query(queryString);
		if (iter.hasNext()) {
			HashMap<String, Object> row = iter.next();
			return (String) row.get(column).toString();
		} else {
			log.warn("Query '{}' yielded no results", queryString);
			return null;
		}
	}

	public Boolean queryBoolean(String queryString, String column) {
		Iterator<HashMap<String, Object>> iter = query(queryString);
		if (iter.hasNext()) {
			HashMap<String, Object> row = iter.next();
			return (Boolean) row.get(column);
		} else {
			log.warn("Query '{}' yielded no results", queryString);
			return null;
		}
	}

	public Long queryLong(String queryString, String column) {
		Iterator<HashMap<String, Object>> iter = query(queryString);
		if (iter.hasNext()) {
			HashMap<String, Object> row = iter.next();
			return (Long) row.get(column);
		} else {
			log.warn("Query '{}' yielded no results", queryString);
			return null;
		}
	}

	public Integer queryInteger(String queryString, String column) {
		Iterator<HashMap<String, Object>> iter = query(queryString);
		if (iter.hasNext()) {
			HashMap<String, Object> row = iter.next();
			Long longValue = (Long) row.get(column);
			return longValue.intValue();
		} else {
			log.warn("Query '{}' yielded no results", queryString);
			return null;
		}
	}

	public Timestamp queryTime(String queryString, String column) {
		Iterator<HashMap<String, Object>> iter = query(queryString);
		if (iter.hasNext()) {
			HashMap<String, Object> row = iter.next();
			return (Timestamp) row.get(column);
		} else {
			log.warn("Query '{}' yielded no results", queryString);
			return null;
		}
	}

	public Date queryDate(String queryString, String column) {
		Iterator<HashMap<String, Object>> iter = query(queryString);
		if (iter.hasNext()) {
			HashMap<String, Object> row = iter.next();
			return (Date) row.get(column);
		} else {
			log.warn("Query '{}' yielded no results", queryString);
			return null;
		}
	}

	public Double queryDouble(String queryString, String column) {
		Iterator<HashMap<String, Object>> iter = query(queryString);
		if (iter.hasNext()) {
			HashMap<String, Object> row = iter.next();
			return (Double) row.get(column);
		} else {
			log.warn("Query '{}' yielded no results", queryString);
			return null;
		}
	}

	public void execute(String sql) {
		Statement st = null;
		try {
			st = dbConnection.createStatement();
			log.trace("query: " + sql);
			st.execute(sql);
		} catch (SQLException e) {
			log.error("SQL query error; ", e.getMessage());
			log.error("QUERY: {}", sql);
		} finally {
			try {
				st.close();
			} catch (SQLException e) {
				log.error("statement close error {}", e.getMessage());
			}
		}
	}

	public Boolean executeGroup(String sql) {
		Statement st = null;
		try {
			st = dbConnection.createStatement();
			return st.execute(sql);
		} catch (SQLException e) {
			log.error("SQL query error; ", e.getMessage());
			log.error("QUERY: {}", sql);
			return false;
		} finally {
			try {
				st.close();
			} catch (SQLException e) {
				log.error("statement close error {}", e.getMessage());
				return false;
			}
		}
	}

	public void clearTable(String tableName) {
		Statement st = null;
		String truncateSql = "TRUNCATE TABLE " + tableName;
		try {
			st = dbConnection.createStatement();
			st.execute(truncateSql);
		} catch (SQLException e) {
			log.error("SQL query error; ", e.getMessage());
			log.error("QUERY: {}", truncateSql);
		} finally {
			try {
				st.close();
			} catch (SQLException e) {
				log.error("statement close error {}", e.getMessage());
			}
		}
	}

	public void clearTableCascade(String tableName) {
		Statement stmt = null;
		String truncateSql = "TRUNCATE TABLE " + tableName + " CASCADE";
		try {
			stmt = dbConnection.createStatement();
			stmt.execute(truncateSql);
		} catch (SQLException e) {
			log.error("SQL query error; ", e.getMessage());
			log.error("QUERY: {}", truncateSql);
		} finally {
			try {
				stmt.close();
			} catch (SQLException e) {
				log.error("statement close error {}", e.getMessage());
			}
		}
	}

	public void close() {
		log.info("Closing database connection to {} ", dbName);
		try {
			dbConnection.close();
		} catch (SQLException e) {
			log.error("Connection close error {}", e.getMessage());
		}
	}

	public void removeAllCertificatesFromDatabase() {
		PreparedStatement preparedStatement = null;
		if (!getDbName().contentEquals("im") && !getDbName().contentEquals("postgress")) {
			String query = "DELETE FROM certificate";
			try {
				preparedStatement = dbConnection.prepareStatement(query);
				preparedStatement.executeUpdate();
				log.trace("Deleted all certificates");
			} catch (SQLException e) {
				log.error("SQL query error: {}", e.getMessage());
				log.error("QUERY: {}", query);
			} finally {
				try {
					if (preparedStatement != null) preparedStatement.close();
				} catch (SQLException e) {
					log.error("statement close error {}", e.getMessage());
				}
			}
		}
	}
}
