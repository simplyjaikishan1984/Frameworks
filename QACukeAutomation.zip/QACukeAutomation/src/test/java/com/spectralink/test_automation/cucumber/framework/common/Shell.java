package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.commons.exec.*;
import org.apache.commons.exec.environment.EnvironmentUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public class Shell {
    private final Logger log = LogManager.getLogger(this.getClass().getName());

    public Shell() {
    }

    private CommandLine buildCommandLine(ArrayList<String> commandChunks) {
        CommandLine commandLine = null;
        if (!commandChunks.isEmpty()) {
            commandLine = new CommandLine(commandChunks.get(0));
            for (int chunkIndex = 1; chunkIndex < commandChunks.size(); chunkIndex++) {
                commandLine.addArgument(commandChunks.get(chunkIndex), false);
            }
        } else {
            log.error("Shell command was empty");
        }
        return commandLine;
    }

    public CliResult executeCommand(ArrayList<String> command) {
        CliResult result = new CliResult();
        ByteArrayOutputStream stdout = new ByteArrayOutputStream();
        ByteArrayOutputStream stderr = new ByteArrayOutputStream();
        CommandLine commandLine = buildCommandLine(command);
        if (commandLine != null) {
            DefaultExecutor executor = new DefaultExecutor();
            PumpStreamHandler streamHandler = new PumpStreamHandler(stdout, stderr);
            try {
                executor.setExitValues(new int[] {0, 1});
                executor.setStreamHandler(streamHandler);
                Map env = EnvironmentUtils.getProcEnvironment();
                int exitCode = executor.execute(commandLine, env);
                result.setExitCode(exitCode);
            } catch (ExecuteException ee) {
                result.setExitCode(2);
                result.setStderr(ee.getMessage() + "\n" + ee.getCause());
                return result;
            } catch (IOException ioe) {
                result.setExitCode(2);
                result.setStderr(ioe.getMessage());
                return result;
            }
        } else {
            result.setExitCode(2);
            result.setStderr("No command to execute");
            return result;
        }
        result.setStdout(stdout.toString());
        result.setStderr(stderr.toString());
        return result;
    }

    public CliResult executeAsynchronousCommand(ArrayList<String> command, Long timeLimit) {
        CliResult result = new CliResult();
        ByteArrayOutputStream stdout = new ByteArrayOutputStream();
        ByteArrayOutputStream stderr = new ByteArrayOutputStream();
        CommandLine commandLine = buildCommandLine(command);
        if (commandLine != null) {
            DefaultExecuteResultHandler resultHandler = new DefaultExecuteResultHandler();
            DefaultExecutor executor = new DefaultExecutor();
            PumpStreamHandler streamHandler = new PumpStreamHandler(stdout, stderr);
            try {
                executor.setExitValue(1);
                executor.setStreamHandler(streamHandler);
                ExecuteWatchdog watchDog;
                if (timeLimit != null && !timeLimit.equals(0)) {
                    watchDog = new ExecuteWatchdog(timeLimit);
                } else {
                    watchDog = new ExecuteWatchdog(21600000);
                }
                executor.setWatchdog(watchDog);
                executor.execute(commandLine, resultHandler);
                Util.sleepSeconds(2);
                if (resultHandler.hasResult()) {
                    result.setExitCode(resultHandler.getExitValue());
                } else {
                    result.setCallback(watchDog);
                }
            } catch (ExecuteException ee) {
                result.setExitCode(2);
                result.setStderr(ee.getMessage() + "\n" + ee.getCause());
            } catch (IOException ioe) {
                result.setExitCode(2);
                result.setStderr(ioe.getMessage());
            }
        } else {
            result.setExitCode(2);
            result.setStderr("No command to execute");
        }

        result.setStdout(stdout.toString());
        result.setStderr(stderr.toString());
        return result;
    }
}
