package com.spectralink.test_automation.cucumber.framework.sam.fields;

import com.spectralink.test_automation.cucumber.framework.common.FieldData;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application;

public class SamFields {

	public enum AmieAgentStrings implements FieldData {
		ENABLE_AMIE_AGENT("AMiE Agent Enabled", "amie_agent_enabled"),
		ENDPOINT_URL("Endpoint URL", "cloud_endpoint"),
		UPLOAD_OVER_METERED("Upload Over LTE", "upload_over_metered"),
		NETWORK_FREQUENCY("Network Metrics Frequency", "network_metrics_frequency"),
		DEVICE_FREQUENCY("Device Metrics Frequency", "device_metrics_frequency"),
		BATTERY_FREQUENCY("Battery Metrics Frequency", "battery_metrics_frequency"),
		MQTTS_CERTIFICATE("MQTTS Certificate", "custom_cert"),
		BUFFER_SIZE("Max Buffer Size", "max_rows");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		AmieAgentStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

    public enum SsoStatusStrings implements FieldData {
        ENABLE_SSO("Enable SSO", "sso_enable"),
        IDENTITY_SYSTEM("Identity management system", "sso_management_system");

        private final String title;
        private final String attribute;

        public String attribute() {
            return attribute;
        }

        public String title() {
            return title;
        }

        SsoStatusStrings(String title, String attribute) {
            this.title = title;
            this.attribute = attribute;
        }
    }

	public enum BarcodeStrings implements FieldData {
		ENABLE_BARCODE_SCANNER("Enable Barcode Scanner", "enable_barcode_scanner"),
		ILLUMINATION_POWER("Illumination Power", "barcode_illum_power"),
		DECODE_TIMEOUT("Decode Session Timeout", "decode_session_timeout"),
		CARRIAGE_RETURN("Automatic carriage return", "barcode_auto_enter_enabled"),
		VIBRATE_SUCCESS("Vibrate", "barcode_vibrate_enabled"),
		SOUND_SUCCESS("Sound", "barcode_sound_enabled"),
		SUCCESS_TONE("Scan Success Sound", "barcode_tone"),
		CODE128_SYMBOLOGY("Code 128", "enable_code128"),
		CODE32_SYMBOLOGY("Code 32", "enable_code32"),
		CODE93_SYMBOLOGY("Code 93", "enable_code93"),
		EAN13_SYMBOLOGY("EAN 13", "enable_ean13"),
		GS1_128_SYMBOLOGY("GS1-128", "enable_gs1128"),
		HAN_XIN_SYMBOLOGY("Han Xin Code", "enable_hanxin"),
		MICRO_PDF417_SYMBOLOGY("Micro PDF417", "enable_micropdf"),
		MICRO_QR_SYMBOLOGY("Micro QR", "enable_microqr"),
		PDF417_SYMBOLOGY("PDF 417", "enable_pdf417"),
		AZTEC_SYMBOLOGY("Aztec", "enable_aztec"),
		AZTEC_POLARITY("Aztec-Polarity", "polarity_aztec"),
		CODABAR_SYMBOLOGY("Codabar", "enable_codabar"),
		CODABAR_LENGTH("Codabar-Minimum Length", "length_codabar"),
		CODABAR_ENABLE_NOTIS("Codabar-Enable Codabar NOTIS editing", "strip_startstop_codabar"),
		CODE11_SYMBOLOGY("Code 11", "enable_code11"),
		CODE11_CHECKDIGIT("Code 11-Check Digit Verification", "checkdigit_verification_code11"),
		CODE11_TRANSMIT_CHECKDIGIT("Code 11-Enable Transmit Code 11 Check Digit", "transmit_checkdigit_code11"),
		CODE39_SYMBOLOGY("Code 39", "enable_code39"),
		CODE39_ASCII("Code 39-ASCII mode", "ascii_code39"),
		CODE39_CHECKDIGIT("Code 39-Enable Code 39 Check Digit Verification", "checkdigit_code39"),
		CODE39_TRANSMIT_CHECKDIGIT("Code 39-Enable Transmit Code 39 Check Digit", "transmit_checkdigit_code39"),
		DATA_MATRIX_SYMBOLOGY("Data Matrix", "enable_datamatrix"),
		DATA_MATRIX_MIRROR("Data Matrix-Mirror Images", "mirror_datamatrix"),
		DATA_MATRIX_POLARITY("Data Matrix-Polarity", "polarity_datamatrix"),
		EAN8_SYMBOLOGY("EAN 8", "enable_ean8"),
		EAN8_CONVERT_EAN13("EAN 8-Convert to EAN 13", "convert_to_ean13_ean8"),
		GS1_DATABAR_14_SYMBOLOGY("GS1 DataBar 14", "enable_gs1databar_14"),
		GS1_DATABAR_14_CCAB("GS1 DataBar 14-Enable GS1 DataBar Composite CC-A/B", "enable_gs1databar_ccab"),
		GS1_DATABAR_14_CCC("GS1 DataBar 14-Enable GS1 DataBar Composite CC-C", "enable_gs1databar_ccc"),
		GS1_DATABAR_14_EXPANDED("GS1 DataBar 14-Enable GS1 DataBar Expanded", "enable_gs1databar_expanded"),
		GS1_DATABAR_14_LIMITED("GS1 DataBar 14-Enable GS1 DataBar Limited", "enable_gs1databar_limited"),
		INTERLEAVED_2OF5_SYMBOLOGY("Interleaved 2 of 5", "enable_interleaved2of5"),
		INTERLEAVED_2OF5_CHECKDIGIT("Interleaved 2 of 5-Interleaved 2 of 5 check digit verification", "checkdigit_interleaved2of5"),
		INTERLEAVED_2OF5_TRANSMIT_CHECKDIGIT("Interleaved 2 of 5-Enable Transmit Interleaved 2 of 5 check digit", "transmit_checkdigit_interleaved2of5"),
		INTERLEAVED_2OF5_QUIET_ZONE("Interleaved 2 of 5-Enable Interleaved 2 of 5 quiet zone", "quietzone_interleaved2of5"),
		INTERLEAVED_2OF5_LENGTH_TYPE("Interleaved 2 of 5-Interleaved 2 of 5 scan length type", "length_type_interleaved2of5"),
		INTERLEAVED_2OF5_LENGTH_1("Interleaved 2 of 5-Allowed Length 1", "length1_interleaved2of5"),
		INTERLEAVED_2OF5_LENGTH_2("Interleaved 2 of 5-Allowed Length 2", "length2_interleaved2of5"),
		MATRIX_2OF5_SYMBOLOGY("Matrix 2 of 5", "enable_matrix2of5"),
		MATRIX_2OF5_CHECKDIGIT("Matrix 2 of 5-Enable Matrix 2 of 5 check digit", "checkdigit_matrix2of5"),
		MATRIX_2OF5_TRANSMIT_CHECKDIGIT("Matrix 2 of 5-Enable Transmit Matrix 2 of 5 check digit", "transmit_checkdigit_matrix2of5"),
		MSI_PLESSEY_SYMBOLOGY("MSI Plessey", "enable_msiplessey"),
		MSI_PLESSEY_CHECKDIGITS("MSI Plessey-Number of MSI check digits", "numcheckdigits_msiplessey"),
		MSI_PLESSEY_TRANSMIT_CHECKDIGIT("MSI Plessey-Enable Transmit MSI check digit", "transmit_checkdigit_msiplessey"),
		MSI_PLESSEY_CHECKDIGIT_ALGORITHM("MSI Plessey-Check Digit Algorithm", "checkdigitalgo_msiplessey"),
		QR_SYMBOLOGY("QR", "enable_qr"),
		QR_POLARITY("QR-QR Inverse Decoding", "polarity_qr"),
		UPCA_SYMBOLOGY("UPC-A", "enable_upca"),
		UPCA_TRANSMIT_PREAMBLE("UPC-A-Transmit UPC-A preamble", "preamble_upca"),
		UPCA_TRANSMIT_CHECKDIGIT("UPC-A-Enable Transmit UPC-A check digit", "checkdigit_upca"),
		UPCE_SYMBOLOGY("UPC-E", "enable_upce"),
		UPCE_TRANSMIT_PREAMBLE("UPC-E-Transmit Preamble", "preamble_upce"),
		UPCE_TRANSMIT_CHECKDIGIT("UPC-E-Enable Transmit UPC-E check digit", "checkdigit_upce"),
		ISBT128_SYMBOLOGY("ISBT-128", "enable_isbt128"),
		ISBT128_TABLE("ISBT-128-Check ISBT Table for Valid Concatenation Pairs", "check_isbt_table"),
		ISBT128_CONCATENATION("ISBT-128-Concatenation", "isbt_concatenation"),
		ISBT128_CONCATENATION_REDUNDANCY("ISBT-128-Concatenation Redundancy", "isbt_concatenation_redundancy"),
		EAN_UPC_SUPPLEMENTAL("Scan EAN/UPC Supplemental", "ean_upc_supplemental");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		BarcodeStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum BattLifeStrings implements FieldData {
		ENABLE_BATTERY_MONITORING("Enable Battery Monitoring", "batt_life_enabled"),
		VIBRATE_WARNING("Vibrate", "vibrate_enabled"),
		SOUND_WARNING("Sound", "sound_enabled"),
		LOW_THRESHOLD_LEVEL("Low Battery Threshold", "alert_level"),
		LOW_WARNING_SNOOZE_TIME("Snooze Time", "batt_alarm_snooze_time"),
		LOW_ALARM_TONE("Alarm Tone", "batt_alarm_tone");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		BattLifeStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum BizPhoneStrings implements FieldData {
		ENABLE_SIP("Enable SIP", "sip_enabled"),
		SIP_1_SERVER_ADDRESS("Reg 1-Server Address", "sip1_server_address"),
		SIP_1_SERVER_PORT("Reg 1-SIP Server Port", "sip1_server_port"),
		SIP_1_TRANSPORT("Reg 1-Transport", "sip1_transport"),
		SIP_1_EXTENSION("Reg 1-Extension Number", "sip1_extension"),
		SIP_1_USERNAME("Reg 1-Username", "sip1_username"),
		SIP_1_PASSWORD("Reg 1-Password", "sip1_password"),
		SIP_1_SHOW_PASSWORD("Reg 1-Show Password", ""),
		SIP_1_VOICEMAIL_ADDRESS("Reg 1-Voice Mail Retrieval Address", "sip1_voicemail_retrieval_address"),
		SIP_1_HOLD_SIGNALING("Reg 1-Use SIP Standard Hold Signaling", "sip1_standard_hold_signaling"),
		SIP_1_FORCE_SUBSCRIPTION("Reg 1-Force Subscription To Message Waiting Notification", "sip1_force_subs_message"),
		SIP_1_ALLOW_CONTACT_UPDATES("Reg 1-Allow Contact Header Updates", "sip1_allow_contact_header"),
		SIP_1_SPECIFY_TCP_PORT("Reg 1-Specify New TCP Port In Contact Header", "sip1_use_new_tcp_port"),
		SIP_1_VENDOR_PROTOCOL("Reg 1-Use Vendor Protocol If Licensed", "sip1_vendor_protocol"),
		SIP_1_CALL_FORWARDING("Reg 1-Allow Call Forwarding", "sip1_callfeature_callforwarding_enable"),
		SIP_1_CALL_WAITING("Reg 1-Disable Call Waiting", "sip1_disable_call_waiting"),
		SIP_2_SERVER_ADDRESS("Reg 2-Server Address", "sip2_server_address"),
		SIP_2_SERVER_PORT("Reg 2-SIP Server Port", "sip2_server_port"),
		SIP_2_TRANSPORT("Reg 2-Transport", "sip2_transport"),
		SIP_2_EXTENSION("Reg 2-Extension Number", "sip2_extension"),
		SIP_2_USERNAME("Reg 2-Username", "sip2_username"),
		SIP_2_PASSWORD("Reg 2-Password", "sip2_password"),
		SIP_2_SHOW_PASSWORD("Reg 2-Show Password", ""),
		SIP_2_VOICEMAIL_ADDRESS("Reg 2-Voice Mail Retrieval Address", "sip2_voicemail_retrieval_address"),
		SIP_2_HOLD_SIGNALING("Reg 2-Use SIP Standard Hold Signaling", "sip2_standard_hold_signaling"),
		SIP_2_FORCE_SUBSCRIPTION("Reg 2-Force Subscription To Message Waiting Notification", "sip2_force_subs_message"),
		SIP_2_ALLOW_CONTACT_UPDATES("Reg 2-Allow Contact Header Updates", "sip2_allow_contact_header"),
		SIP_2_SPECIFY_TCP_PORT("Reg 2-Specify New TCP Port In Contact Header", "sip2_use_new_tcp_port"),
		SIP_2_VENDOR_PROTOCOL("Reg 2-Use Vendor Protocol If Licensed", "sip2_vendor_protocol"),
		SIP_2_CALL_WAITING("Reg 2-Disable Call Waiting", "sip2_disable_call_waiting"),
		CISCO_I_DIVERT("Allow iDivert", "sip1_callfeature_idivert_enable"),
		CISCO_CALL_PARK("Allow Call Park", "sip1_callfeature_callpark_enable"),
		CISCO_HUNT_GROUP_LOGON("Allow Hunt Group Login/Logout", "sip1_callfeature_hunt_group_logon_enable"),
		CISCO_VOICEMAIL("Voicemail Enable", "voicemail_enable"),
		CISCO_UNITY_SERVER_ADDRESS("Cisco Unity Server Address", "cisco_unity_connection_server_address"),
		CISCO_SERVER_USERNAME("Cisco Unity Server-Username", "cisco_unity_server_username"),
		CISCO_SERVER_PASSWORD("Cisco Unity Server-Password", "cisco_unity_server_password"),
		CISCO_SERVER_SHOW_PASSWORD("Cisco Unity Server-Show Password", ""),
		CISCO_CONTACT_SEARCH("Cisco Contact Search", "cisco_contact_search_enable"),
		CISCO_ADVANCED_SEARCH("Advanced contact search enable", "cisco_advanced_search_directory_enable"),
		CISCO_DIRECTORY_SERVER_ADDRESS("Cisco Server Address", "cisco_advanced_search_directory_server_address"),
		CISCO_DIRECTORY_SERVER_ACCOUNT("Cisco Advanced Directory Server-Username", "cisco_advanced_search_directory_server_username"),
		CISCO_DIRECTORY_SERVER_PASSWORD("Cisco Advanced Directory Server-Password", "cisco_advanced_search_directory_server_password"),
		CISCO_DIRECTORY_SERVER_SHOW_PASSWORD("Cisco Advanced Directory Server-Show Password", ""),
		CISCO_DIRECTORY_SERVER_SEARCH_FIELD("Search Field", "cisco_advanced_search_directory_parameter"),
		CISCO_DIRECTORY_SERVER_SEARCH_VALUES("Search value", "cisco_advanced_search_directory_values"),
		AUDIO_DSCP("Audio DSCP", "sip_common_audio_dscp"),
		CALL_CONTROL_DSCP("Call Control DSCP", "sip_common_call_control_dscp"),
		OVERRIDE_TCP_SWITCH("Override Automatic Switch From UDP To TCP", "sip_common_override_switch_to_tcp"),
		DTMF_PAYLOAD_TYPE("DTMF Relay Payload Type", "sip_common_dtmf_relay_payload_type"),
		FORCE_IN_BAND_TONES("Force In-Band DTMF Tones", "sip_common_force_in_band"),
		CODEC_G_711U_PRIORITY("G.711u", "sip_common_codec_g711u_priority"),
		CODEC_G_711A_PRIORITY("G.711a", "sip_common_codec_g711a_priority"),
		CODEC_G_729A_PRIORITY("G.729a", "sip_common_codec_g729a_priority"),
		CODEC_G_722_PRIORITY("G.722", "sip_common_codec_g722_priority"),
		LDAP_SERVER_ADDRESS("Server Address", "ldap_server_address"),
		LDAP_SERVER_PORT("Server Port", "ldap_server_port"),
		LDAP_SECURITY_TYPE("Communication Security Type", "ldap_comm_security_type"),
		LDAP_BIND_DN("Bind DN", "ldap_bind_dn"),
		LDAP_BIND_PASSWORD("Bind Password", "ldap_bind_pw"),
		LDAP_BASE_DN("Base DN", "ldap_base_dn"),
		LDAP_PRIMARY_EMAIL("Primary Email Attribute", "ldap_primary_email_attribute"),
		LDAP_ALTERNATE_EMAIL("Alternate Email Attribute", "ldap_alternate_email_attribute"),
		CONTACT_NAME_1("Emergency Contact Name 1", "sip_ice_contact_name_1"),
		CONTACT_NUMBER_1("Emergency Contact Number 1", "sip_ice_contact_number_1"),
		CONTACT_NAME_2("Emergency Contact Name 2", "sip_ice_contact_name_2"),
		CONTACT_NUMBER_2("Emergency Contact Number 2", "sip_ice_contact_number_2"),
		CONTACT_NAME_3("Emergency Contact Name 3", "sip_ice_contact_name_3"),
		CONTACT_NUMBER_3("Emergency Contact Number 3", "sip_ice_contact_number_3"),
		CONTACT_NAME_4("Emergency Contact Name 4", "sip_ice_contact_name_4"),
		CONTACT_NUMBER_4("Emergency Contact Number 4", "sip_ice_contact_number_4"),
		CONTACT_NAME_5("Emergency Contact Name 5", "sip_ice_contact_name_5"),
		CONTACT_NUMBER_5("Emergency Contact Number 5", "sip_ice_contact_number_5");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		BizPhoneStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum ButtonsStrings implements FieldData {
		LEFT_BUTTON_USER_CONTROL("Left Button User Assigned", "enable_user_control_left_button"),
		LEFT_BUTTON("Left Button", "button_left"),
		LEFT_BUTTON_APPLICTION("Application (Left Button)", "button_left_run_application"),
		RIGHT_BUTTON_USER_CONTROL("Right Button User Assigned", "enable_user_control_right_button"),
		RIGHT_BUTTON("Right Button", "button_right"),
		RIGHT_BUTTON_APPLICATION("Application (Right Button)", "button_right_run_application"),
		TOP_BUTTON_USER_CONTROL("Top Button User Assigned", "enable_user_control_top_button"),
		TOP_BUTTON("Top Button", "button_top"),
		TOP_BUTTON_APPLICATION("Application (Top Button)", "button_top_run_application"),
		FINGERPRINT_USER_CONTROL("Fingerprint Button User Assigned", "enable_user_control_fingerprint_button"),
		FINGERPRINT("Finger Print", "button_fingerprint"),
		FINGERPRINT_APPLICATION("Application (Fingerprint Button)", "button_fingerprint_run_application"),
		VOLUME_UP_BUTTON_USER_CONTROL("Volume Up Button User Assigned", "enable_user_control_vol_up_button"),
		VOLUME_UP_BUTTON("Volume Up", "button_vol_up"),
		VOLUME_UP_BUTTON_APPLICATION("Application (Volume Up Button)", "button_vol_up_run_application"),
		VOLUME_DOWN_BUTTON_USER_CONTROL("Volume Down Button User Assigned", "enable_user_control_vol_down_button"),
		VOLUME_DOWN_BUTTON("Volume Down", "button_vol_down"),
		VOLUME_DOWN_BUTTON_APPLICATION("Application (Volume Down Button)", "button_vol_down_run_application");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		ButtonsStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum DeviceSettingsStrings implements FieldData {
		ENABLE_DEVICE_SETTINGS("Enable Device Settings", "enable_device_settings"),
		WIFI("User Wi-Fi Config", "allow_wifi_toggle"),
		AIRPLANE_MODE("User Airplane Mode Config", "allow_airplane_mode_toggle"),
		QUICK_SETTINGS_TILES("Allow All Quick Settings Tiles", "allow_all_qs_tiles"),
		DND_CONFIG("User DND Config", "allow_dnd_qs_tile"),
		NOTIFICATION_SHADE("Allow Notification Shade Settings Gear", "allow_notif_shade_settings_gear"),
		TIMEZONE_CONFIG("User Timezone Config", "allow_config_timezone"),
		TIME_FORMAT_CONFIG("User Time Format Config", "allow_config_timeformat"),
		AUTO_TIMEZONE_CONFIG("User Auto Timezone Config", "allow_config_auto_timezone"),
		AUTO_TIMEZONE("Automatic Timezone", "auto_timezone"),
		NTP_SERVER("NTP Server Address", "ntp_server"),
		TIMEZONE("Time Zone", "timezone"),
		TIME_DISPLAY_FORMAT("Time Display Format", "timeformat"),
		INFO_DISPLAY("Display Device Info", "allow_display_device_info"),
		DEVICE_INFO_1("Device Info 1", "device_info_1"),
		DEVICE_INFO_2("Device Info 2", "device_info_2"),
		DEVICE_INFO_3("Device Info 3", "device_info_3"),
		DEVICE_INFO_4("Device Info 4", "device_info_4"),
		DEVICE_NAME("Device Name", "device_name"),
		APPLICATION_WHITELIST("Application Battery Optimization Whitelist", "app_battery_opt_whitelist"),
		BATTERY_SAVER("Allow Battery Saver", "enable_battery_saver"),
		SECURE_KEYBOARD("SKeyboard", "secure_keyboard"),
		VOICE_TYPING("Google Voice Typing", "google_voice_typing"),
		INACTIVITY_SLEEP("Time To Sleep After Inactivity", "time_to_sleep"),
		DIALPAD_TONES("Dialpad Tones", "enable_dialpad_tones"),
		TOUCH_SOUNDS("Touch Sounds", "enable_touch_sounds"),
		VIBRATE_TAP("Vibrate On Tap", "enable_vibrate_on_tap"),
		AMBER_ALERTS("Amber Alerts", "enable_amber_alerts"),
		EXTREME_THREATS("Extreme Threats", "enable_extreme_threats"),
		SEVERE_THREATS("Severe Threats", "enable_severe_threats"),
		JUMP_TO_CAMERA("Jump To Camera", "enable_jump_to_camera"),
		ENABLE_WIFI_VOLTE_CALLING("Enable Wi-Fi Calling/VoLTE", "enable_wifi_calling");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		DeviceSettingsStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum LensGridStrings implements FieldData {
		ENABLE_LENS_GRID("Enable lens grid", "grid_camera_enable"),
		GRID_SIZE("Lens Grid Size", "grid_camera_size");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		LensGridStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

    public enum LoggingStrings implements FieldData {
        ENABLE_SYSLOG("Enable Syslog", "log_enable"),
        LOG_SERVER_ADDRESS("Server Address", "server_address"),
        LOG_SERVER_PORT("Server Port", "server_port"),
        LOGCAT_PARAMETERS("Logcat Parameters", "logcat_param"),
		DEBUGGING_PASSWORD("Advanced Debugging Password", "adv_debug_pass"),
		SHOW_PASSWORD("Show Password", ""),
		ALLOW_OVERRIDE("Allow On-Device Configuration", "slnklogger_edit_override"),
		CAPTURE_BUG_REPORT("Capture Bug Report", "slnklogger_bugreport"),
		CRASH_DUMP_MODE("Enable crash dump USB download mode", "slnklogger_dload"),
		CAPTURE_NETWORK_TRAFFIC("Capture Network Traffic", "slnklogger_slnkdump"),
		NETWORK_TRAFFIC_LENGTH("Network Traffic Snapshot Length", "slnkdump_snaplen"),
		CAPTURE_LOGCAT("Capture Logcat", "slnklogger_logcat"),
		LOGCAT_FILE_SIZE("Logcat File Size", "slnklogger_logcat_size"),
		CAPTURE_QXDM_LOG("Capture QXDM Log", "slnklogger_qxdm_log"),
		QXDM_CONFIGURATION("QXDM Filter Set", "slnklogger_qxdm_configuration"),
		UPLOAD_SERVER("File Upload Server", "slnklogger_server_address"),
		UPLOAD_SERVER_PORT("File Upload Port", "slnklogger_server_port"),
		UPLOAD_PROTOCOL("File Upload Protocol", "slnklogger_transport_settings"),
		PASSWORD_PROTECT("Password Protect Files", "slnklogger_zip_password");

        private final String title;
        private final String attribute;

        public String attribute() {
            return attribute;
        }

        public String title() {
            return title;
        }

        LoggingStrings(String title, String attribute) {
            this.title = title;
            this.attribute = attribute;
        }
    }

	public enum PttStrings implements FieldData {
		ENABLE_PTT("Enable Push To Talk (PTT)", "enable_ptt"),
		USERNAME("Username", "username"),
		MULTICAST_ADDRESS("Multi-cast Address", "multicast_address"),
		CODEC("Codec", "codec"),
		CHANNEL_1("Channel 1", "channel1"),
		CHANNEL_1_TRANSMIT("Channel 1-Can Transmit", "channel1_can_transmit"),
		CHANNEL_1_SUBSCRIBE("Channel 1-Can Listen", "channel1_subscribe"),
		CHANNEL_2("Channel 2", "channel2"),
		CHANNEL_2_TRANSMIT("Channel 2-Can Transmit", "channel2_can_transmit"),
		CHANNEL_2_SUBSCRIBE("Channel 2-Can Listen", "channel2_subscribe"),
		CHANNEL_3("Channel 3", "channel3"),
		CHANNEL_3_TRANSMIT("Channel 3-Can Transmit", "channel3_can_transmit"),
		CHANNEL_3_SUBSCRIBE("Channel 3-Can Listen", "channel3_subscribe"),
		CHANNEL_4("Channel 4", "channel4"),
		CHANNEL_4_TRANSMIT("Channel 4-Can Transmit", "channel4_can_transmit"),
		CHANNEL_4_SUBSCRIBE("Channel 4-Can Listen", "channel4_subscribe"),
		CHANNEL_5("Channel 5", "channel5"),
		CHANNEL_5_TRANSMIT("Channel 5-Can Transmit", "channel5_can_transmit"),
		CHANNEL_5_SUBSCRIBE("Channel 5-Can Listen", "channel5_subscribe"),
		CHANNEL_6("Channel 6", "channel6"),
		CHANNEL_6_TRANSMIT("Channel 6-Can Transmit", "channel6_can_transmit"),
		CHANNEL_6_SUBSCRIBE("Channel 6-Can Listen", "channel6_subscribe"),
		CHANNEL_7("Channel 7", "channel7"),
		CHANNEL_7_TRANSMIT("Channel 7-Can Transmit", "channel7_can_transmit"),
		CHANNEL_7_SUBSCRIBE("Channel 7-Can Listen", "channel7_subscribe"),
		CHANNEL_8("Channel 8", "channel8"),
		CHANNEL_8_TRANSMIT("Channel 8-Can Transmit", "channel8_can_transmit"),
		CHANNEL_8_SUBSCRIBE("Channel 8-Can Listen", "channel8_subscribe"),
		CHANNEL_9("Channel 9", "channel9"),
		CHANNEL_9_TRANSMIT("Channel 9-Can Transmit", "channel9_can_transmit"),
		CHANNEL_9_SUBSCRIBE("Channel 9-Can Listen", "channel9_subscribe"),
		CHANNEL_10("Channel 10", "channel10"),
		CHANNEL_10_TRANSMIT("Channel 10-Can Transmit", "channel10_can_transmit"),
		CHANNEL_10_SUBSCRIBE("Channel 10-Can Listen", "channel10_subscribe"),
		CHANNEL_11("Channel 11", "channel11"),
		CHANNEL_11_TRANSMIT("Channel 11-Can Transmit", "channel11_can_transmit"),
		CHANNEL_11_SUBSCRIBE("Channel 11-Can Listen", "channel11_subscribe"),
		CHANNEL_12("Channel 12", "channel12"),
		CHANNEL_12_TRANSMIT("Channel 12-Can Transmit", "channel12_can_transmit"),
		CHANNEL_12_SUBSCRIBE("Channel 12-Can Listen", "channel12_subscribe"),
		CHANNEL_13("Channel 13", "channel13"),
		CHANNEL_13_TRANSMIT("Channel 13-Can Transmit", "channel13_can_transmit"),
		CHANNEL_13_SUBSCRIBE("Channel 13-Can Listen", "channel13_subscribe"),
		CHANNEL_14("Channel 14", "channel14"),
		CHANNEL_14_TRANSMIT("Channel 14-Can Transmit", "channel14_can_transmit"),
		CHANNEL_14_SUBSCRIBE("Channel 14-Can Listen", "channel14_subscribe"),
		CHANNEL_15("Channel 15", "channel15"),
		CHANNEL_15_TRANSMIT("Channel 15-Can Transmit", "channel15_can_transmit"),
		CHANNEL_15_SUBSCRIBE("Channel 15-Can Listen", "channel15_subscribe"),
		CHANNEL_16("Channel 16", "channel16"),
		CHANNEL_16_TRANSMIT("Channel 16-Can Transmit", "channel16_can_transmit"),
		CHANNEL_16_SUBSCRIBE("Channel 16-Can Listen", "channel16_subscribe"),
		CHANNEL_17("Channel 17", "channel17"),
		CHANNEL_17_TRANSMIT("Channel 17-Can Transmit", "channel17_can_transmit"),
		CHANNEL_17_SUBSCRIBE("Channel 17-Can Listen", "channel17_subscribe"),
		CHANNEL_18("Channel 18", "channel18"),
		CHANNEL_18_TRANSMIT("Channel 18-Can Transmit", "channel18_can_transmit"),
		CHANNEL_18_SUBSCRIBE("Channel 18-Can Listen", "channel18_subscribe"),
		CHANNEL_19("Channel 19", "channel19"),
		CHANNEL_19_TRANSMIT("Channel 19-Can Transmit", "channel19_can_transmit"),
		CHANNEL_19_SUBSCRIBE("Channel 19-Can Listen", "channel19_subscribe"),
		CHANNEL_20("Channel 20", "channel20"),
		CHANNEL_20_TRANSMIT("Channel 20-Can Transmit", "channel20_can_transmit"),
		CHANNEL_20_SUBSCRIBE("Channel 20-Can Listen", "channel20_subscribe"),
		CHANNEL_21("Channel 21", "channel21"),
		CHANNEL_21_TRANSMIT("Channel 21-Can Transmit", "channel21_can_transmit"),
		CHANNEL_21_SUBSCRIBE("Channel 21-Can Listen", "channel21_subscribe"),
		CHANNEL_22("Channel 22", "channel22"),
		CHANNEL_22_TRANSMIT("Channel 22-Can Transmit", "channel22_can_transmit"),
		CHANNEL_22_SUBSCRIBE("Channel 22-Can Listen", "channel22_subscribe"),
		CHANNEL_23("Channel 23", "channel23"),
		CHANNEL_23_TRANSMIT("Channel 23-Can Transmit", "channel23_can_transmit"),
		CHANNEL_23_SUBSCRIBE("Channel 23-Can Listen", "channel23_subscribe"),
		CHANNEL_24("Channel 24", "channel24"),
		CHANNEL_24_TRANSMIT("Channel 24-Can Transmit", "channel24_can_transmit"),
		CHANNEL_24_SUBSCRIBE("Channel 24-Can Listen", "channel24_subscribe"),
		CHANNEL_25("Channel 25", "channel25"),
		CHANNEL_25_TRANSMIT("Channel 25-Can Transmit", "channel25_can_transmit"),
		CHANNEL_25_SUBSCRIBE("Channel 25-Can Listen", "channel25_subscribe");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		PttStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum SafeStrings implements FieldData {
		ENABLE_MONITORING("Monitoring", "safe_enabled"),
		MOVEMENT_SENSITIVITY("No Movement Sensitivity", "safe_no_move_sensitivity"),
		MOVEMENT_TIMEOUT("No Movement Timeout", "safe_no_move_timeout"),
		TILT_SENSITIVITY("Tilt Sensitivity", "safe_not_vertical_sensitivity"),
		TILT_TIMEOUT("Tilt Timeout", "safe_not_vertical_timeout"),
		RUNNING_SENSITIVITY("Running Sensitivity", "safe_running_sensitivity"),
		RUNNING_TIMEOUT("Running Timeout", "safe_running_timeout"),
		SNOOZE_TIMEOUT("Snooze Timeout", "safe_snooze_timeout"),
		WARNING_TIMEOUT("Warning Timeout", "safe_warning_state_timeout"),
		PANIC_BUTTON("Panic Button", "safe_panic_button"),
		PANIC_SILENT_ALARM("Panic Button Silent Alarm", "safe_panic_silent_alarm"),
		EMERGENCY_CALL("Emergency Call", "safe_emergency_dial_enabled"),
		EMERGENCY_CALL_SPEAKER("Emergency Dial Force Speaker", "safe_emergency_dial_force_speaker_enabled"),
		EMERGENCY_NUMBER("Emergency Dial Number", "safe_emergency_dial_number"),
		WARNING_TONE("Warning Tone", "safe_warning_tone"),
		ALARM_TONE("Alarm Tone", "safe_alarm_tone");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		SafeStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum SysUpdaterStrings implements FieldData {
		TRIGGER_VALUE("Trigger OTA", "ota_trigger_setting"),
		FORCE_REBOOT("Force Reboot After OTA Update", "ota_auto_reboot_phone"),
		OTA_OVER_METERED("Allow OTA Over Metered Network", "allow_on_metered_network"),
		SERVER_ADDRESS("Server Address", "ota_server_address"),
		SERVER_PORT("Port", "ota_server_port"),
		OTA_PATH("Relative Path On The Server", "ota_relative_path"),
		TRANSPORT_PROTOCOL("Network Protocol", "ota_transport_settings"),
		POLLING_INTERVAL("Polling Interval", "ota_check_frequency_settings"),
		REVERT_PASSWORD("Revert Last Upgrade", "revert_last_upgrade_password"),
		SHOW_PASSWORD("Show Password", "revert_last_upgrade_password");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		SysUpdaterStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum VqoStrings implements FieldData {
		ENABLE_VQO("Voice Quality Optimization (VQO)", "enable_vqo"),
		WIFI_THRESHOLD("Wifi Low RSSI Threshold", "vqo_low_rssi_threshold"),
		WIFI_AUTO_BAND("Wifi Auto Band Selection", "key_wifi_band_auto"),
		WIFI_24_GHZ_BAND("Wifi 2.4 GHz Band Selection", "key_wifi_band_2_4GHz"),
		WIFI_5_GHZ_BAND("Wifi 5 GHz Band Selection", "key_wifi_band_5GHz"),
		CHANNEL_1("Channel 1 (2412 MHz)", "vqo_channel_1"),
		CHANNEL_2("Channel 2 (2417 MHz)", "vqo_channel_2"),
		CHANNEL_3("Channel 3 (2422 MHz)", "vqo_channel_3"),
		CHANNEL_4("Channel 4 (2427 MHz)", "vqo_channel_4"),
		CHANNEL_5("Channel 5 (2432 MHz)", "vqo_channel_5"),
        CHANNEL_6("Channel 6 (2437 MHz)", "vqo_channel_6"),
        CHANNEL_7("Channel 7 (2442 MHz)", "vqo_channel_7"),
        CHANNEL_8("Channel 8 (2447 MHz)", "vqo_channel_8"),
        CHANNEL_9("Channel 9 (2452 MHz)", "vqo_channel_9"),
        CHANNEL_10("Channel 10 (2457 MHz)", "vqo_channel_10"),
        CHANNEL_11("Channel 11 (2462 MHz)", "vqo_channel_11"),
        CHANNEL_12("Channel 12 (2467 MHz)", "vqo_channel_12"),
        CHANNEL_13("Channel 13 (2472 MHz)", "vqo_channel_13"),
        CHANNEL_14("Channel 14 (2477 MHz)", "vqo_channel_14"),
        CHANNEL_36("Channel 36 (5180 MHz)", "vqo_channel_36"),
        CHANNEL_40("Channel 40 (5200 MHz)", "vqo_channel_40"),
        CHANNEL_44("Channel 44 (5220 MHz)", "vqo_channel_44"),
        CHANNEL_48("Channel 48 (5240 MHz)", "vqo_channel_48"),
        CHANNEL_52("Channel 52 DFS (5260 MHz)", "vqo_channel_52"),
        CHANNEL_56("Channel 56 DFS (5280 MHz)", "vqo_channel_56"),
        CHANNEL_60("Channel 60 DFS (5300 MHz)", "vqo_channel_60"),
        CHANNEL_64("Channel 64 DFS (5320 MHz)", "vqo_channel_64"),
        CHANNEL_100("Channel 100 DFS (5500 MHz)", "vqo_channel_100"),
        CHANNEL_104("Channel 104 DFS (5520 MHz)", "vqo_channel_104"),
        CHANNEL_108("Channel 108 DFS (5540 MHz)", "vqo_channel_108"),
        CHANNEL_112("Channel 112 DFS (5560 MHz)", "vqo_channel_112"),
        CHANNEL_116("Channel 116 DFS (5580 MHz)", "vqo_channel_116"),
        CHANNEL_120("Channel 120 DFS (5600 MHz)", "vqo_channel_120"),
        CHANNEL_124("Channel 124 DFS (5620 MHz)", "vqo_channel_124"),
        CHANNEL_128("Channel 128 DFS (5640 MHz)", "vqo_channel_128"),
        CHANNEL_132("Channel 132 DFS (5660 MHz)", "vqo_channel_132"),
        CHANNEL_136("Channel 136 DFS (5680 MHz)", "vqo_channel_136"),
        CHANNEL_140("Channel 140 DFS (5700 MHz)", "vqo_channel_140"),
        CHANNEL_144("Channel 144 DFS (5720 MHz)", "vqo_channel_144"),
        CHANNEL_149("Channel 149 (5745 MHz)", "vqo_channel_149"),
        CHANNEL_153("Channel 153 (5765 MHz)", "vqo_channel_153"),
        CHANNEL_157("Channel 157 (5785 MHz)", "vqo_channel_157"),
        CHANNEL_161("Channel 161 (5805 MHz)", "vqo_channel_161"),
        CHANNEL_165("Channel 165 (5825 MHz)", "vqo_channel_165");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}


		VqoStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum WebApiStrings implements FieldData {
		ENABLE_WEBAPI("Enable Web API", "web_api_enable_disable"),
		DATA_FORMAT("Data format", "web_api_format_type"),
		POLL_USERNAME("Poll-Username", "web_api_polling_username"),
		POLL_PASSWORD("Poll-Password", "web_api_polling_password"),
		POLL_SHOW_PASSWORD("Poll-Show Password", ""),
		POLL_RESPONSE("Respond Mode", "polling_respond_method"),
		POLL_RESPONSE_URL("URL To Receive Response", "polling_url_to_respond"),
		PUSH_USERNAME("Push-Username", "web_api_push_username"),
		PUSH_PASSWORD("Push-Password", "web_api_push_password"),
		PUSH_SHOW_PASSWORD("Push-Show Password", ""),
		PUSH_ALERT_PRIORITY("Push Alert Priority", "push_message_priority"),
		PUSH_NOTIFICATION_RINGTONE("Enable Notification Ringtone", "push_notification_ringtone_enable"),
		PUSH_RINGTONE_VOLUME("Push Notification Ringtone Volume", "webapi_volume"),
		PUSH_SERVER_ROOT("Server Root URL", "push_server_root_url"),

		EVENT_1_LABEL("Event 1-Label", "web_api_event_label_1"),
		EVENT_1_URL("Event 1-URL", "web_api_event_url_1"),
		EVENT_1_NONE("Event 1-None", "web_api_event_none_1"),
		EVENT_1_ALL("Event 1-All", "web_api_event_all_1"),
		EVENT_1_STATE("Event 1-State Change", "web_api_event_state_change_1"),
		EVENT_1_INCOMING("Event 1-Incoming", "web_api_event_incoming_1"),
		EVENT_1_REGISTRATION("Event 1-Registration", "web_api_event_registration_1"),
		EVENT_1_UNREGISTRATION("Event 1-Unregistration", "web_api_event_unregistration_1"),
		EVENT_1_OFF_HOOK("Event 1-Off Hook", "web_api_event_off_hook_1"),
		EVENT_1_ON_HOOK("Event 1-On Hook", "web_api_event_on_hook_1"),
		EVENT_1_OUTGOING("Event 1-Outgoing", "web_api_event_outgoing_1"),
		EVENT_1_LOGIN("Event 1-User Login", "web_api_event_user_login_1"),
		EVENT_1_SAFE_ALARM("Event 1-Safe Alarm", "web_api_event_safe_alarm_1"),

		EVENT_2_LABEL("Event 2-Label", "web_api_event_label_2"),
		EVENT_2_URL("Event 2-URL", "web_api_event_url_2"),
		EVENT_2_NONE("Event 2-None", "web_api_event_none_2"),
		EVENT_2_ALL("Event 2-All", "web_api_event_all_2"),
		EVENT_2_STATE("Event 2-State Change", "web_api_event_state_change_2"),
		EVENT_2_INCOMING("Event 2-Incoming", "web_api_event_incoming_2"),
		EVENT_2_REGISTRATION("Event 2-Registration", "web_api_event_registration_2"),
		EVENT_2_UNREGISTRATION("Event 2-Unregistration", "web_api_event_unregistration_2"),
		EVENT_2_OFF_HOOK("Event 2-Off Hook", "web_api_event_off_hook_2"),
		EVENT_2_ON_HOOK("Event 2-On Hook", "web_api_event_on_hook_2"),
		EVENT_2_OUTGOING("Event 2-Outgoing", "web_api_event_outgoing_2"),
		EVENT_2_LOGIN("Event 2-User Login", "web_api_event_user_login_2"),
		EVENT_2_SAFE_ALARM("Event 2-Safe Alarm", "web_api_event_safe_alarm_2"),

		EVENT_3_LABEL("Event 3-Label", "web_api_event_label_3"),
		EVENT_3_URL("Event 3-URL", "web_api_event_url_3"),
		EVENT_3_NONE("Event 3-None", "web_api_event_none_3"),
		EVENT_3_ALL("Event 3-All", "web_api_event_all_3"),
		EVENT_3_STATE("Event 3-State Change", "web_api_event_state_change_3"),
		EVENT_3_INCOMING("Event 3-Incoming", "web_api_event_incoming_3"),
		EVENT_3_REGISTRATION("Event 3-Registration", "web_api_event_registration_3"),
		EVENT_3_UNREGISTRATION("Event 3-Unregistration", "web_api_event_unregistration_3"),
		EVENT_3_OFF_HOOK("Event 3-Off Hook", "web_api_event_off_hook_3"),
		EVENT_3_ON_HOOK("Event 3-On Hook", "web_api_event_on_hook_3"),
		EVENT_3_OUTGOING("Event 3-Outgoing", "web_api_event_outgoing_3"),
		EVENT_3_LOGIN("Event 3-User Login", "web_api_event_user_login_3"),
		EVENT_3_SAFE_ALARM("Event 3-Safe Alarm", "web_api_event_safe_alarm_3"),

		EVENT_4_LABEL("Event 4-Label", "web_api_event_label_4"),
		EVENT_4_URL("Event 4-URL", "web_api_event_url_4"),
		EVENT_4_NONE("Event 4-None", "web_api_event_none_4"),
		EVENT_4_ALL("Event 4-All", "web_api_event_all_4"),
		EVENT_4_STATE("Event 4-State Change", "web_api_event_state_change_4"),
		EVENT_4_INCOMING("Event 4-Incoming", "web_api_event_incoming_4"),
		EVENT_4_REGISTRATION("Event 4-Registration", "web_api_event_registration_4"),
		EVENT_4_UNREGISTRATION("Event 4-Unregistration", "web_api_event_unregistration_4"),
		EVENT_4_OFF_HOOK("Event 4-Off Hook", "web_api_event_off_hook_4"),
		EVENT_4_ON_HOOK("Event 4-On Hook", "web_api_event_on_hook_4"),
		EVENT_4_OUTGOING("Event 4-Outgoing", "web_api_event_outgoing_4"),
		EVENT_4_LOGIN("Event 4-User Login", "web_api_event_user_login_4"),
		EVENT_4_SAFE_ALARM("Event 4-Safe Alarm", "web_api_event_safe_alarm_4"),

		EVENT_5_LABEL("Event 5-Label", "web_api_event_label_5"),
		EVENT_5_URL("Event 5-URL", "web_api_event_url_5"),
		EVENT_5_NONE("Event 5-None", "web_api_event_none_5"),
		EVENT_5_ALL("Event 5-All", "web_api_event_all_5"),
		EVENT_5_STATE("Event 5-State Change", "web_api_event_state_change_5"),
		EVENT_5_INCOMING("Event 5-Incoming", "web_api_event_incoming_5"),
		EVENT_5_REGISTRATION("Event 5-Registration", "web_api_event_registration_5"),
		EVENT_5_UNREGISTRATION("Event 5-Unregistration", "web_api_event_unregistration_5"),
		EVENT_5_OFF_HOOK("Event 5-Off Hook", "web_api_event_off_hook_5"),
		EVENT_5_ON_HOOK("Event 5-On Hook", "web_api_event_on_hook_5"),
		EVENT_5_OUTGOING("Event 5-Outgoing", "web_api_event_outgoing_5"),
		EVENT_5_LOGIN("Event 5-User Login", "web_api_event_user_login_5"),
		EVENT_5_SAFE_ALARM("Event 5-Safe Alarm", "web_api_event_safe_alarm_5"),

		EVENT_6_LABEL("Event 6-Label", "web_api_event_label_6"),
		EVENT_6_URL("Event 6-URL", "web_api_event_url_6"),
		EVENT_6_NONE("Event 6-None", "web_api_event_none_6"),
		EVENT_6_ALL("Event 6-All", "web_api_event_all_6"),
		EVENT_6_STATE("Event 6-State Change", "web_api_event_state_change_6"),
		EVENT_6_INCOMING("Event 6-Incoming", "web_api_event_incoming_6"),
		EVENT_6_REGISTRATION("Event 6-Registration", "web_api_event_registration_6"),
		EVENT_6_UNREGISTRATION("Event 6-Unregistration", "web_api_event_unregistration_6"),
		EVENT_6_OFF_HOOK("Event 6-Off Hook", "web_api_event_off_hook_6"),
		EVENT_6_ON_HOOK("Event 6-On Hook", "web_api_event_on_hook_6"),
		EVENT_6_OUTGOING("Event 6-Outgoing", "web_api_event_outgoing_6"),
		EVENT_6_LOGIN("Event 6-User Login", "web_api_event_user_login_6"),
		EVENT_6_SAFE_ALARM("Event 6-Safe Alarm", "web_api_event_safe_alarm_6"),

		EVENT_7_LABEL("Event 7-Label", "web_api_event_label_7"),
		EVENT_7_URL("Event 7-URL", "web_api_event_url_7"),
		EVENT_7_NONE("Event 7-None", "web_api_event_none_7"),
		EVENT_7_ALL("Event 7-All", "web_api_event_all_7"),
		EVENT_7_STATE("Event 7-State Change", "web_api_event_state_change_7"),
		EVENT_7_INCOMING("Event 7-Incoming", "web_api_event_incoming_7"),
		EVENT_7_REGISTRATION("Event 7-Registration", "web_api_event_registration_7"),
		EVENT_7_UNREGISTRATION("Event 7-Unregistration", "web_api_event_unregistration_7"),
		EVENT_7_OFF_HOOK("Event 7-Off Hook", "web_api_event_off_hook_7"),
		EVENT_7_ON_HOOK("Event 7-On Hook", "web_api_event_on_hook_7"),
		EVENT_7_OUTGOING("Event 7-Outgoing", "web_api_event_outgoing_7"),
		EVENT_7_LOGIN("Event 7-User Login", "web_api_event_user_login_7"),
		EVENT_7_SAFE_ALARM("Event 7-Safe Alarm", "web_api_event_safe_alarm_7"),

		EVENT_8_LABEL("Event 8-Label", "web_api_event_label_8"),
		EVENT_8_URL("Event 8-URL", "web_api_event_url_8"),
		EVENT_8_NONE("Event 8-None", "web_api_event_none_8"),
		EVENT_8_ALL("Event 8-All", "web_api_event_all_8"),
		EVENT_8_STATE("Event 8-State Change", "web_api_event_state_change_8"),
		EVENT_8_INCOMING("Event 8-Incoming", "web_api_event_incoming_8"),
		EVENT_8_REGISTRATION("Event 8-Registration", "web_api_event_registration_8"),
		EVENT_8_UNREGISTRATION("Event 8-Unregistration", "web_api_event_unregistration_8"),
		EVENT_8_OFF_HOOK("Event 8-Off Hook", "web_api_event_off_hook_8"),
		EVENT_8_ON_HOOK("Event 8-On Hook", "web_api_event_on_hook_8"),
		EVENT_8_OUTGOING("Event 8-Outgoing", "web_api_event_outgoing_8"),
		EVENT_8_LOGIN("Event 8-User Login", "web_api_event_user_login_8"),
		EVENT_8_SAFE_ALARM("Event 8-Safe Alarm", "web_api_event_safe_alarm_8"),

		EVENT_9_LABEL("Event 9-Label", "web_api_event_label_9"),
		EVENT_9_URL("Event 9-URL", "web_api_event_url_9"),
		EVENT_9_NONE("Event 9-None", "web_api_event_none_9"),
		EVENT_9_ALL("Event 9-All", "web_api_event_all_9"),
		EVENT_9_STATE("Event 9-State Change", "web_api_event_state_change_9"),
		EVENT_9_INCOMING("Event 9-Incoming", "web_api_event_incoming_9"),
		EVENT_9_REGISTRATION("Event 9-Registration", "web_api_event_registration_9"),
		EVENT_9_UNREGISTRATION("Event 9-Unregistration", "web_api_event_unregistration_9"),
		EVENT_9_OFF_HOOK("Event 9-Off Hook", "web_api_event_off_hook_9"),
		EVENT_9_ON_HOOK("Event 9-On Hook", "web_api_event_on_hook_9"),
		EVENT_9_OUTGOING("Event 9-Outgoing", "web_api_event_outgoing_9"),
		EVENT_9_LOGIN("Event 9-User Login", "web_api_event_user_login_9"),
		EVENT_9_SAFE_ALARM("Event 9-Safe Alarm", "web_api_event_safe_alarm_9"),

		EVENT_10_LABEL("Event 10-Label", "web_api_event_label_10"),
		EVENT_10_URL("Event 10-URL", "web_api_event_url_10"),
		EVENT_10_NONE("Event 10-None", "web_api_event_none_10"),
		EVENT_10_ALL("Event 10-All", "web_api_event_all_10"),
		EVENT_10_STATE("Event 10-State Change", "web_api_event_state_change_10"),
		EVENT_10_INCOMING("Event 10-Incoming", "web_api_event_incoming_10"),
		EVENT_10_REGISTRATION("Event 10-Registration", "web_api_event_registration_10"),
		EVENT_10_UNREGISTRATION("Event 10-Unregistration", "web_api_event_unregistration_10"),
		EVENT_10_OFF_HOOK("Event 10-Off Hook", "web_api_event_off_hook_10"),
		EVENT_10_ON_HOOK("Event 10-On Hook", "web_api_event_on_hook_10"),
		EVENT_10_OUTGOING("Event 10-Outgoing", "web_api_event_outgoing_10"),
		EVENT_10_LOGIN("Event 10-User Login", "web_api_event_user_login_10"),
		EVENT_10_SAFE_ALARM("Event 10-Safe Alarm", "web_api_event_safe_alarm_10"),

		EVENT_11_LABEL("Event 11-Label", "web_api_event_label_11"),
		EVENT_11_URL("Event 11-URL", "web_api_event_url_11"),
		EVENT_11_NONE("Event 11-None", "web_api_event_none_11"),
		EVENT_11_ALL("Event 11-All", "web_api_event_all_11"),
		EVENT_11_STATE("Event 11-State Change", "web_api_event_state_change_11"),
		EVENT_11_INCOMING("Event 11-Incoming", "web_api_event_incoming_11"),
		EVENT_11_REGISTRATION("Event 11-Registration", "web_api_event_registration_11"),
		EVENT_11_UNREGISTRATION("Event 11-Unregistration", "web_api_event_unregistration_11"),
		EVENT_11_OFF_HOOK("Event 11-Off Hook", "web_api_event_off_hook_11"),
		EVENT_11_ON_HOOK("Event 11-On Hook", "web_api_event_on_hook_11"),
		EVENT_11_OUTGOING("Event 11-Outgoing", "web_api_event_outgoing_11"),
		EVENT_11_LOGIN("Event 11-User Login", "web_api_event_user_login_11"),
		EVENT_11_SAFE_ALARM("Event 11-Safe Alarm", "web_api_event_safe_alarm_11"),

		EVENT_12_LABEL("Event 12-Label", "web_api_event_label_12"),
		EVENT_12_URL("Event 12-URL", "web_api_event_url_12"),
		EVENT_12_NONE("Event 12-None", "web_api_event_none_12"),
		EVENT_12_ALL("Event 12-All", "web_api_event_all_12"),
		EVENT_12_STATE("Event 12-State Change", "web_api_event_state_change_12"),
		EVENT_12_INCOMING("Event 12-Incoming", "web_api_event_incoming_12"),
		EVENT_12_REGISTRATION("Event 12-Registration", "web_api_event_registration_12"),
		EVENT_12_UNREGISTRATION("Event 12-Unregistration", "web_api_event_unregistration_12"),
		EVENT_12_OFF_HOOK("Event 12-Off Hook", "web_api_event_off_hook_12"),
		EVENT_12_ON_HOOK("Event 12-On Hook", "web_api_event_on_hook_12"),
		EVENT_12_OUTGOING("Event 12-Outgoing", "web_api_event_outgoing_12"),
		EVENT_12_LOGIN("Event 12-User Login", "web_api_event_user_login_12"),
		EVENT_12_SAFE_ALARM("Event 12-Safe Alarm", "web_api_event_safe_alarm_12"),

		APP_SHORTCUT_1("Web Application 1-Label", "web_app_shortcut_1"),
		APP_URI_1("Web Application 1-URL", "web_app_uri_1"),
		APP_SHORTCUT_2("Web Application 2-Label", "web_app_shortcut_2"),
		APP_URI_2("Web Application 2-URL", "web_app_uri_2"),
		APP_SHORTCUT_3("Web Application 3-Label", "web_app_shortcut_3"),
		APP_URI_3("Web Application 3-URL", "web_app_uri_3"),
		APP_SHORTCUT_4("Web Application 4-Label", "web_app_shortcut_4"),
		APP_URI_4("Web Application 4-URL", "web_app_uri_4"),
		APP_SHORTCUT_5("Web Application 5-Label", "web_app_shortcut_5"),
		APP_URI_5("Web Application 5-URL", "web_app_uri_5"),
		APP_SHORTCUT_6("Web Application 6-Label", "web_app_shortcut_6"),
		APP_URI_6("Web Application 6-URL", "web_app_uri_6"),
		APP_SHORTCUT_7("Web Application 7-Label", "web_app_shortcut_7"),
		APP_URI_7("Web Application 7-URL", "web_app_uri_7"),
		APP_SHORTCUT_8("Web Application 8-Label", "web_app_shortcut_8"),
		APP_URI_8("Web Application 8-URL", "web_app_uri_8"),
		APP_SHORTCUT_9("Web Application 9-Label", "web_app_shortcut_9"),
		APP_URI_9("Web Application 9-URL", "web_app_uri_9"),
		APP_SHORTCUT_10("Web Application 10-Label", "web_app_shortcut_10"),
		APP_URI_10("Web Application 10-URL", "web_app_uri_10"),
		APP_SHORTCUT_11("Web Application 11-Label", "web_app_shortcut_11"),
		APP_URI_11("Web Application 11-URL", "web_app_uri_11"),
		APP_SHORTCUT_12("Web Application 12-Label", "web_app_shortcut_12"),
		APP_URI_12("Web Application 12-URL", "web_app_uri_12");


		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}


		WebApiStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public static FieldData getStrings(Application app, String cukeTitle) {
		switch (app) {
			case AMIE_AGENT:
				for (AmieAgentStrings strings : AmieAgentStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
			case BARCODE:
				for (BarcodeStrings strings : BarcodeStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case BATTLIFE:
				for (BattLifeStrings strings : BattLifeStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case BIZ_PHONE:
				for (BizPhoneStrings strings : BizPhoneStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case BUTTONS:
				for (ButtonsStrings strings : ButtonsStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case DEVICE:
				for (DeviceSettingsStrings strings : DeviceSettingsStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case LENS_GRID:
				for (LensGridStrings strings : LensGridStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
            case LOGGING:
                for (LoggingStrings strings : LoggingStrings.values()) {
                    if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
                        return strings;
                    }
                }
                break;
			case PTT:
				for (PttStrings strings : PttStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case SAFE:
				for (SafeStrings strings : SafeStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case SYS_UPDATER:
				for (SysUpdaterStrings strings : SysUpdaterStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case VQO:
				for (VqoStrings strings : VqoStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case WEBAPI:
				for (WebApiStrings strings : WebApiStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
            case SSO_STATUS:
                for (SsoStatusStrings strings : SsoStatusStrings.values()) {
                    if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
                        return strings;
                    }
                }
                break;
		}
		return null;
	}
}
