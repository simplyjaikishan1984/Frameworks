package com.spectralink.test_automation.cucumber.framework;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleep;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class WebAutomation {
    protected final String projectDirectory = System.getProperty("user.dir");
    private final Logger log = LogManager.getLogger(this.getClass().getName());
    protected WebDriver driver;
    protected int explicitWait;
    protected Deque<Integer> stack = new ArrayDeque<Integer>();

    public WebAutomation() {
        driver = WebBrowser.getDriver();
        PageFactory.initElements(driver, this);
    }

    public int getExplicitWait() {
        return explicitWait;
    }

    public void setExplicitWait(int wait) {
        explicitWait = wait;
    }

    public void setTemporaryWait(int wait) {
        stack.push(explicitWait);
        explicitWait = wait;
    }

    public void removeTemporaryWait() {
        if (!stack.isEmpty()) explicitWait = stack.pop();
    }

    public void refresh() {
        log.debug("Refreshing current page");
        driver.navigate().refresh();
    }

    public boolean isPresent(By by) {
        boolean detected = false;
        detected = !driver.findElements(by).isEmpty();
        return detected;
    }

    public WebElement getElement(By by) {
        List<WebElement> elements = driver.findElements(by);
        if (elements.isEmpty()) {
            return null;
        } else if (elements.size() == 1) {
            return elements.get(0);
        } else {
            return null;
        }
    }

    public void moveToElement(WebElement element) {
        Actions actions = new Actions(driver);
        actions.moveToElement(element);
        actions.perform();
    }

    // Standard web page access methods with integrated waits. These should be under all calls to
    // web objects in the Page classes.

    public String getEntityTag(WebElement element) {
        try {
            waitForElementExistence(element);
            return element.getTagName();
        } catch (TimeoutException te) {
            log.error("Timeout looking for tag on {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not get tag on {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return null;
    }

    private String getEntitylabel(WebElement element) {
        try {
            if (element.getText() != null && !element.getText().isEmpty() && !element.getText().matches("\\s+") && !element.getText().contains("\n")) {
                return element.getText();
            } else if (element.getAttribute("id") != null && !element.getAttribute("id").isEmpty()) {
                return element.getAttribute("id");
            } else if (element.getCssValue("class") != null && !element.getCssValue("class").isEmpty()) {
                String[] classes = element.getCssValue("class").split("\\s");
                return classes[0];
            } else {
                return element.getTagName();
            }
        } catch (TimeoutException te) {
            log.error("Timeout looking for tag on {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not get tag on {}", element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
        return "missing element";
    }

    public void clickOnPageEntity(WebElement element) {
        try {
            waitForElement(element);
            log.debug("Clicking element {}", getEntitylabel(element));
            element.click();
        } catch (TimeoutException te) {
            log.error("Timeout trying to click {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not click {}", element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void typeIntoPageEntity(WebElement element, String text) {
        try {
            waitForElement(element);
            element.clear();
            element.sendKeys(text);
            log.debug("Entering into element {}: {}", getEntitylabel(element), text.trim());
        } catch (TimeoutException te) {
            log.error("Timeout entering {} into {}", text, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not find {}", element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void selectMenuByValue(WebElement element, String value) {
        try {
            waitForElement(element);
            Select listbox = new Select(element);
            log.debug("Selecting value {} from element {}", value, getEntitylabel(element));
            listbox.selectByValue(value);
        } catch (TimeoutException te) {
            log.error("Timeout selecting value {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not select value {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void selectMenuByText(WebElement element, String value) {
        try {
            waitForElement(element);
            Select listbox = new Select(element);
            log.debug("Selecting text '{}' from element {}", value, getEntitylabel(element));
            listbox.selectByVisibleText(value);
        } catch (TimeoutException te) {
            log.error("Timeout selecting text {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not select text {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element.toString());
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void selectMenuByIndex(WebElement element, Integer value) {
        try {
            waitForElement(element);
            Integer optionNumber = value + 1;
            Select listbox = new Select(element);
            log.debug("Selecting option {} (index {}) from element {}", optionNumber, value, getEntitylabel(element));
            listbox.selectByIndex(value);
        } catch (TimeoutException te) {
            log.error("Timeout selecting index {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not select index {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void selectMenuByIndexWithPresence(WebElement element, By by, Integer value) {
        try {
            waitForElementPresence(by);
            Integer optionNumber = value + 1;
            Select listbox = new Select(element);
            log.debug("Selecting option {} (index {}) from element {}", optionNumber, value, getEntitylabel(element));
            listbox.selectByIndex(value);
        } catch (TimeoutException te) {
            log.error("Timeout selecting index {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not select index {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public void deselectMenuByIndex(WebElement element, Integer value) {
        try {
            waitForElement(element);
            Integer optionNumber = value + 1;
            Select listbox = new Select(element);
            log.debug("Deselecting option {} (index {}) from element {}", optionNumber, value, getEntitylabel(element));
            listbox.deselectByIndex(value);
        } catch (TimeoutException te) {
            log.error("Timeout deselecting menu option {} from {}", value, element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not deselect menu index {} from {}", value, element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Stale reference to element {}", element);
            log.trace(sere.getStackTrace().toString());
        }
    }

    public WebElement locateElement(By by) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, explicitWait);
            WebElement element = wait.until(ExpectedConditions.elementToBeClickable(by));
            return element;
        } catch (TimeoutException te) {
            log.error("Could not locate element with {}", by.toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Found stale element with {}", by.toString());
        }
        return null;
    }

    public WebElement getElement(By by, int position) {
        try {
            return waitForElements(by, position);
        } catch (TimeoutException te) {
            log.error("Could not get element with {}", by.toString());
        }
        return null;
    }

    public Boolean isEntitySelected(WebElement element) {
        try {
            return element.isSelected();
        } catch (NoSuchElementException nsee) {
            log.error("Could not check if selected element {}", element);
            log.trace(nsee.getStackTrace().toString());
        } catch (StaleElementReferenceException sere) {
            log.error("Could not access stale element {}", element);
        }
        return false;
    }

    public Boolean isEntityEnabled(WebElement element) {
        Boolean answer = false;
        try {
            waitForElement(element);
            answer = element.isEnabled();
        } catch (TimeoutException te) {
            log.error("Timeout checking if enabled element {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not check if enabled element {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return answer;
    }

    public void clearPageEntity(WebElement element) {
        try {
            waitForElement(element);
            element.clear();
            log.debug("Clearing element {}", getEntitylabel(element));
        } catch (TimeoutException te) {
            log.error("Timeout clearing element {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not clear element {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
    }

    public WebElement getChildEntity(WebElement element, By by) {
        try {
            //waitForChildElementPresence(element, by);
            return element.findElement(by);
        } catch (TimeoutException te) {
            log.debug("Timeout getting child for element {}", element);
        } catch (NoSuchElementException nsee) {
            log.trace("Could not get child for element {}", element);
        }
        return null;
    }

    public String getEntityText(WebElement element) {
        try {
            waitForElement(element);
            return element.getText();
        } catch (TimeoutException te) {
            log.error("Timeout getting text for {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not get text for {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return null;
    }

    public String getEntityAttribute(WebElement element, String attribute) {
        try {
            waitForElementExistence(element);
            return element.getAttribute(attribute);
        } catch (TimeoutException te) {
            log.error("Timeout getting attribute for {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not get attribute for {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return null;
    }

    public String getMenuSelectedOption(WebElement element) {
        String selectedAnswer = null;
        try {
            waitForElement(element);
            Select box = new Select(element);
            WebElement selection = box.getFirstSelectedOption();
            selectedAnswer = selection.getText();
            log.info("Found option {} was selected in menu {}", selectedAnswer, getEntitylabel(element));
        } catch (TimeoutException te) {
            log.error("Timeout getting selected option for {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not find page element {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return selectedAnswer;
    }

    public void deletePageSetting(By by) {
        if (isPresent(by)) {
            WebElement element = locateElement(by);
            clickOnPageEntity(element);
            sleepSeconds(1);
            WebElement deleteButton = locateElement(By.xpath("//button[@ng-click=\"ok()\"]"));
            clickOnPageEntity(deleteButton);
            sleepSeconds(1);
        } else {
            log.trace("Element not found with {}", by.toString());
        }
    }

    public boolean isEntityDisplayed(WebElement element) {
        try {
            waitForElement(element);
            return element.isDisplayed();
        } catch (TimeoutException te) {
            log.error("Timeout checking if displayed {}", element);
            log.trace(te.getStackTrace().toString());
        } catch (NoSuchElementException nsee) {
            log.error("Could not find page element {}", element);
            log.trace(nsee.getStackTrace().toString());
        }
        return false;
    }

    public boolean isEntityClickable(WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, getExplicitWait());
            wait.until(ExpectedConditions.elementToBeClickable(element));
            return true;
        } catch (TimeoutException te) {
            // expected failures
        } catch (NoSuchElementException nsee) {
            log.trace("Could not find if clickable {}", element);
        } catch (StaleElementReferenceException sere) {
            log.trace("Could not access stale element {}", element);
        }
        return false;
    }

    public Boolean elementExists(String xpath) {
        List<WebElement> targets = driver.findElements(By.xpath(xpath));
        return (targets.size() > 0);
    }

    public void waitForElement(WebElement element) throws TimeoutException {
        waitForElement(element, getExplicitWait());
    }

    public void waitForElement(WebElement element, int waitForSeconds) throws TimeoutException {
        WebDriverWait wait = new WebDriverWait(driver, waitForSeconds);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitForVisibleElement(WebElement element) throws TimeoutException {
        waitForVisibleElement(element, getExplicitWait());
    }

    public void waitForVisibleElement(WebElement element, int waitForSeconds) throws TimeoutException {
        WebDriverWait wait = new WebDriverWait(driver, waitForSeconds);
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void waitForElementPresence(By by) throws TimeoutException {
        waitForElementPresence(by, getExplicitWait());
    }

    public void waitForElementPresence(By by, int waitForSeconds) throws TimeoutException {
        WebDriverWait wait = new WebDriverWait(driver, waitForSeconds);
        wait.until(ExpectedConditions.presenceOfElementLocated(by));
    }

    public void waitForChildElementPresence(WebElement element, By by) throws TimeoutException {
        waitForChildElementPresence(element, by, getExplicitWait());
    }

    public void waitForChildElementPresence(WebElement element, By by, int waitForSeconds) throws TimeoutException {
        WebDriverWait wait = new WebDriverWait(driver, waitForSeconds);
        wait.until(ExpectedConditions.presenceOfNestedElementLocatedBy(element, by));
    }

    public void waitForElementExistence(WebElement element) {
        waitForElementExistence(element, getExplicitWait());
    }

    public void waitForElementExistence(WebElement element, int waitForSeconds) throws TimeoutException {
        WebDriverWait wait = new WebDriverWait(driver, waitForSeconds);
        wait.until(ExpectedConditions.or(
                ExpectedConditions.visibilityOf(element),
                ExpectedConditions.invisibilityOf(element)
                )
        );
    }

    public WebElement waitForElements(By by, int position) throws TimeoutException {
        Long durationLimit = getExplicitWait() * 1000L;
        Long startTime = System.currentTimeMillis();
        List<WebElement> elements = driver.findElements(by);
        while (elements.size() >= position && System.currentTimeMillis() - startTime < durationLimit) {
            elements = driver.findElements(by);
            if (elements.size() > position) {
                return elements.get(position);
            }
            sleep(500);
        }
        throw new TimeoutException("Could not locate element by " + by);
    }

    public void waitForIdElement(String id, int waitForSeconds) throws TimeoutException {
        waitForElement(driver.findElement(By.id(id)), waitForSeconds);
    }

    public void waitForIdElement(String id) throws TimeoutException {
        waitForIdElement(id, getExplicitWait());
    }


    public void waitForNameElement(String name, int waitForSeconds) throws TimeoutException {
        waitForElement(driver.findElement(By.name(name)), waitForSeconds);
    }

    public void waitForNameElement(String name) throws TimeoutException {
        waitForNameElement(name, getExplicitWait());
    }


    public void waitForLinkTextElement(String linkText, int waitForSeconds) throws TimeoutException {
        waitForElement(driver.findElement(By.linkText(linkText)), waitForSeconds);
    }

    public void waitForLinkTextElement(String linkText) throws TimeoutException {
        waitForLinkTextElement(linkText, getExplicitWait());
    }


    public void waitForPartialLinkTextElement(String partialLinkText, int waitForSeconds) throws TimeoutException {
        waitForElement(driver.findElement(By.partialLinkText(partialLinkText)), waitForSeconds);
    }

    public void waitForPartialLinkTextElement(String partialLinkText) throws TimeoutException {
        waitForPartialLinkTextElement(partialLinkText, getExplicitWait());
    }


    public void waitForXpathElement(String xpath, int waitForSeconds) throws TimeoutException {
        waitForElement(driver.findElement(By.xpath(xpath)), waitForSeconds);
    }

    public void waitForXpathElement(String xpath) throws TimeoutException {
        waitForXpathElement(xpath, getExplicitWait());
    }
}

