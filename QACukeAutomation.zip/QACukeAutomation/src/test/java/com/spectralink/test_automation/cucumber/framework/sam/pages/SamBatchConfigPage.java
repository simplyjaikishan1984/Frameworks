package com.spectralink.test_automation.cucumber.framework.sam.pages;

import com.spectralink.test_automation.cucumber.framework.WebBrowser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.File;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamBatchConfigPage extends SamBasePage {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@FindBy(id = "batch_files_browse_button")
	private WebElement batchFilesButton;

	@FindBy(xpath = "//a[@download=\"batch-import-no-group.csv\"]")
	private WebElement batchFileNoGroupLink;

	@FindBy(xpath = "//a[@download=\"batch-import-with-group.csv\"]")
	private WebElement batchFileWithGroupLink;


	public SamBatchConfigPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public String getBodyText() {
		return locateElement(By.tagName("body")).getText();
	}

	public void clickBrowseFilesButton() {
		clickOnPageEntity(batchFilesButton);
	}

	public void clickBatchFileNoGroupLink() {
		clickOnPageEntity(batchFileNoGroupLink);
		sleepSeconds(4);
	}

	public void clickBatchFileWithGroupLink() {
		clickOnPageEntity(batchFileWithGroupLink);
		sleepSeconds(4);
	}

	public void selectBatchFile(File csvFile) {
		driver.switchTo().activeElement();
		WebBrowser.fileUpload(csvFile.getPath());
		driver.switchTo().activeElement();
		sleepSeconds(2);
	}

	public boolean uploadSuccessful() {
		return isPresent(By.xpath("//span[contains(text(), 'Imported successfully')]"));
	}

	public boolean uploadFailed() {
		return isPresent(By.xpath("//span[contains(text(), 'Errors in batch file')]"));
	}
}
