package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamWebApiPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.WEBAPI;

public class SamWebApiSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I click the Application Shortcuts Plus button")
	public void clickShortcutsPlusIcon() {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		webapiPage.clickAddWebApp();
	}

	@When("^I click the Application Shortcuts Minus button")
	public void clickShortcutsMinusIcon() {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		webapiPage.clickRemoveWebApp();
	}

	@When("^I click the Event Plus button")
	public void clickEventPlusIcon() {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		webapiPage.clickAddApiEvent();
	}

	@When("^I click the Event Minus button")
	public void clickEventMinusIcon() {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		webapiPage.clickRemoveApiEvent();
	}

	@When("^I click the 'Web Application Shortcuts' tab")
	public void clickShortcutsTab() {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		webapiPage.clickAppUrlsTab();
	}

	@When("^I click the 'WebAPI' tab")
	public void clickWebApiTab() {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		webapiPage.clickWebApiTab();
	}

	@When("^I check the \"([^\"]*)\" WebAPI field$")
	public void checkWebApiCheckbox(String arg1) {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		if (webapiPage.getField(arg1.trim()) != null) {
			webapiPage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I uncheck the \"([^\"]*)\" WebAPI field$")
	public void uncheckWebApiCheckbox(String arg1) {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		if (webapiPage.getField(arg1.trim()) != null) {
			webapiPage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" WebAPI field$")
	public void selectWebApiMenuOption(String arg1, String arg2) {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		if (webapiPage.getField(arg2.trim()) != null) {
			webapiPage.getField(arg2.trim()).updateMenuByLabel(arg1.trim());
		} else {
			log.error("Field with label '{}' does not exist", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" WebAPI field$")
	public void enterWebApiFieldValue(String arg1, String arg2) {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		if (webapiPage.getField(arg2.trim()) != null) {
			webapiPage.getField(arg2.trim()).updateTextbox(arg1);
		} else {
			log.error("No matching field with label '{}'", arg2);
		}
	}

	@When("^I click the \"([^\"]*)\" radio button of the \"([^\"]*)\" WebAPI field$")
	public void activateWebApiRadio(String arg1, String arg2) throws Throwable {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		if (webapiPage.getField(arg2.trim()) != null) {
			String appendedKey = arg1.trim().toLowerCase() + arg2.trim();
			if (webapiPage.getField(appendedKey) != null) {
				webapiPage.getField(appendedKey).updateRadioButton();
			} else {
				log.error("No matching radio button value with title '{}'", arg1);
				Assert.fail("SAM Radio Button Not Found");
			}
		} else {
			log.error("No matching field with title '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I drag the slider to \"([^\"]*)\" on the \"([^\"]*)\" WebAPI field$")
	public void moveWebApiSlider(String arg1, String arg2) {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		if (webapiPage.getField(arg2.trim()) != null) {
			Integer newValue = Integer.valueOf(arg1.trim());
			if (newValue < 101 && newValue > -1) {
				webapiPage.ringtoneVolumeField.updateSliderValue(newValue);
			} else {
				log.error("Requested slider value {} is out of range (0-100)", newValue);
				Assert.fail("Invalid Slider Value");
			}
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the \"([^\"]*)\" WebAPI setting$")
	public void verifyWebApiValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(WEBAPI, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(WEBAPI, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(WEBAPI)) phone.loadAppPreferences(WEBAPI);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("Field with label '{}' does not exist", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("^\"([^\"]*)\" should have the approximate value of \"([^\"]*)\" in the \"([^\"]*)\" WebAPI setting$")
	public void verifyApproximateWebApiValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(WEBAPI, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(WEBAPI, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(WEBAPI)) phone.loadAppPreferences(WEBAPI);
				Environment.addScenarioFailure(phone.compareApproximate(fieldKey, arg2.trim(), 2));
			} else {
				log.error("No matching field with label '{}'", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I delete the \"([^\"]*)\" WebAPI field$")
	public void deleteWebApiSetting(String arg1) {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		webapiPage.getField(arg1.trim()).delete();
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the custom attribute \"([^\"]*)\" WebAPI setting$")
	public void checkWebApiCustomAttributeSetting(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (!phone.getCurrentAppSettings().equals(WEBAPI)) phone.loadAppPreferences(WEBAPI);
			Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("^the WebAPI page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyPttPageValue(String arg1, String arg2) {
		SamWebApiPage webapiPage = (SamWebApiPage) Environment.getCurrentPage();
		if (webapiPage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(webapiPage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(webapiPage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Field with label '{}' does not exist", arg2);
		}
	}
}