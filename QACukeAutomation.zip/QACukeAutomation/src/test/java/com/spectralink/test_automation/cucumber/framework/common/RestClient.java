package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.net.ssl.SSLContext;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class RestClient {

    private String server;
    private Integer port = 443;
    private String uri;
    private String userName;
    private String password;
    private Boolean secure = true;
    private String postResult = "";
    private final Logger log = LogManager.getLogger(this.getClass().getName());

    public RestClient(String server) {
        this.server = server;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getSecure() {
        return secure;
    }

    public void setSecure(Boolean secure) {
        this.secure = secure;
        this.port = secure ? 443 : 80;
    }

    public String getResultJson() {
        return postResult;
    }

    public void setResultJson(String postResult) {
        this.postResult = postResult;
    }

    private java.net.URI formatUrl(String uri) {
        List<String> chunks = new ArrayList<>();
        chunks.add(secure ? "https:/" : "http:/");
        chunks.add(getPort() == 80 || getPort() == 443 ? getServer() : getServer() + ":" + getPort());
        String cleanUri = uri.startsWith("/") ? uri.substring(1) : uri;
        chunks.add(cleanUri);
        String finalUri = String.join("/", chunks);
        try {
            return new URI(finalUri);
        } catch (URISyntaxException use) {
            log.error("Bad URL '{}' encountered: {}", finalUri, use.getMessage());
        }
        return null;
    }

    public Integer getGetRequest(String uri) {
        int statusCode = -1;
        try {
            TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

            Registry<ConnectionSocketFactory> socketFactoryRegistry =
                    RegistryBuilder.<ConnectionSocketFactory>create()
                            .register("https", sslsf)
                            .register("http", new PlainConnectionSocketFactory())
                            .build();

            BasicHttpClientConnectionManager connectionManager = new BasicHttpClientConnectionManager(socketFactoryRegistry);
            HttpClient httpClient;
            HttpResponse response;
            if (getUserName() != null && getPassword() != null) {
                CredentialsProvider credsProvider = new BasicCredentialsProvider();
                credsProvider.setCredentials(
                        AuthScope.ANY,
                        new UsernamePasswordCredentials(getUserName(), getPassword())
                );
                HttpHost host = new HttpHost(getServer(), getPort(), "https");
                AuthCache auth = new BasicAuthCache();
                auth.put(host, new BasicScheme());
                HttpClientContext context = HttpClientContext.create();
                context.setCredentialsProvider(credsProvider);
                context.setAuthCache(auth);
                httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
                        .setDefaultCredentialsProvider(credsProvider)
                        .setConnectionManager(connectionManager).build();
                response = httpClient.execute(new HttpGet(formatUrl(uri).toASCIIString()), context);
            } else {
                httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
                        .setConnectionManager(connectionManager).build();
                response = httpClient.execute(new HttpGet(formatUrl(uri).toASCIIString()));
            }
            if (response != null) {
                statusCode = response.getStatusLine().getStatusCode();
                log.trace("GET returned code {}", response.getStatusLine().getStatusCode());
                HttpEntity entity = response.getEntity();
                if (entity != null) setResultJson(EntityUtils.toString(entity));
            }
        } catch (Exception e) {
            log.error("Exception occurred: {}", e.getMessage());
        }
        return statusCode;
    }

    public Integer getGetFileRequest(String uri, Path destinationPath) {
        int statusCode = -1;
        try {
            TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

            Registry<ConnectionSocketFactory> socketFactoryRegistry =
                    RegistryBuilder.<ConnectionSocketFactory>create()
                            .register("https", sslsf)
                            .register("http", new PlainConnectionSocketFactory())
                            .build();

            BasicHttpClientConnectionManager connectionManager = new BasicHttpClientConnectionManager(socketFactoryRegistry);
            HttpClient httpClient;
            HttpResponse response;
            if (getUserName() != null && getPassword() != null) {
                CredentialsProvider credsProvider = new BasicCredentialsProvider();
                credsProvider.setCredentials(
                        AuthScope.ANY,
                        new UsernamePasswordCredentials(getUserName(), getPassword())
                );
                HttpHost host = new HttpHost(getServer(), getPort(), "https");
                AuthCache auth = new BasicAuthCache();
                auth.put(host, new BasicScheme());
                HttpClientContext context = HttpClientContext.create();
                context.setCredentialsProvider(credsProvider);
                context.setAuthCache(auth);
                httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
                        .setDefaultCredentialsProvider(credsProvider)
                        .setConnectionManager(connectionManager).build();
                response = httpClient.execute(new HttpGet(formatUrl(uri).toASCIIString()), context);
            } else {
                httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
                        .setConnectionManager(connectionManager).build();
                response = httpClient.execute(new HttpGet(formatUrl(uri).toASCIIString()));
            }
            if (response != null) {
                statusCode = response.getStatusLine().getStatusCode();
                log.trace("GET returned code {}", response.getStatusLine().getStatusCode());
                HttpEntity entity = response.getEntity();
                InputStream fileContent = entity.getContent();
                FileOutputStream downloadFile = new FileOutputStream(destinationPath.toFile());
                int inByte;
                while ((inByte = fileContent.read()) != -1) {
                    downloadFile.write(inByte);
                }

                fileContent.close();
                downloadFile.close();
                setResultJson("");
            }
        } catch (Exception e) {
            log.error("Exception occurred: {}", e.getMessage());
        }
        return statusCode;
    }

    public Integer getPostRequest(String uri, String jsonPayload) {
        int statusCode = -1;
        try {
            TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

            Registry<ConnectionSocketFactory> socketFactoryRegistry =
                    RegistryBuilder.<ConnectionSocketFactory>create()
                            .register("https", sslsf)
                            .register("http", new PlainConnectionSocketFactory())
                            .build();

            BasicHttpClientConnectionManager connectionManager = new BasicHttpClientConnectionManager(socketFactoryRegistry);
            HttpClient httpClient;
            HttpResponse response;
            if (getUserName() != null && getPassword() != null) {
                httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
                        .setConnectionManager(connectionManager).build();

                HttpPost httpPost = new HttpPost(formatUrl(uri));
                StringEntity entity = new StringEntity(jsonPayload);
                httpPost.setEntity(entity);
                httpPost.setHeader("Accept", "application/json");
                httpPost.setHeader("Content-type", "application/json");
                UsernamePasswordCredentials creds = new UsernamePasswordCredentials(getUserName(), getPassword());
                httpPost.addHeader(new BasicScheme().authenticate(creds, httpPost, null));
                response = httpClient.execute(httpPost);
            } else {
                httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
                        .setConnectionManager(connectionManager).build();
                HttpPost httpPost = new HttpPost(formatUrl(uri));
                StringEntity entity = new StringEntity(jsonPayload);
                httpPost.setEntity(entity);
                httpPost.setHeader("Accept", "application/json");
                httpPost.setHeader("Content-type", "application/json");
                response = httpClient.execute(httpPost);
            }
            if (response != null) {
                statusCode = response.getStatusLine().getStatusCode();
                log.trace("POST returned code {}", statusCode);
                HttpEntity entity = response.getEntity();
                if (entity != null) setResultJson(EntityUtils.toString(entity));
            }
        } catch (Exception e) {
            log.error("Exception occurred: {}", e.getMessage());
        }
        return statusCode;
    }

    public Integer getPutRequest(String uri, String jsonPayload) {
        int statusCode = -1;
        try {
            TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

            Registry<ConnectionSocketFactory> socketFactoryRegistry =
                    RegistryBuilder.<ConnectionSocketFactory>create()
                            .register("https", sslsf)
                            .register("http", new PlainConnectionSocketFactory())
                            .build();

            BasicHttpClientConnectionManager connectionManager = new BasicHttpClientConnectionManager(socketFactoryRegistry);
            HttpClient httpClient;
            HttpResponse response;
            if (getUserName() != null && getPassword() != null) {
                httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
                        .setConnectionManager(connectionManager).build();

                HttpPut httpPut = new HttpPut(formatUrl(uri));
                StringEntity entity = new StringEntity(jsonPayload);
                httpPut.setEntity(entity);
                httpPut.setHeader("Accept", "application/json");
                httpPut.setHeader("Content-type", "application/json");
                UsernamePasswordCredentials creds = new UsernamePasswordCredentials(getUserName(), getPassword());
                httpPut.addHeader(new BasicScheme().authenticate(creds, httpPut, null));
                response = httpClient.execute(httpPut);
            } else {
                httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
                        .setConnectionManager(connectionManager).build();
                HttpPut httpPut = new HttpPut(formatUrl(uri));
                StringEntity entity = new StringEntity(jsonPayload);
                httpPut.setEntity(entity);
                httpPut.setHeader("Accept", "application/json");
                httpPut.setHeader("Content-type", "application/json");
                response = httpClient.execute(httpPut);
            }
            statusCode = response.getStatusLine().getStatusCode();
            log.trace("PUT returned code {}", statusCode);
            HttpEntity entity = response.getEntity();
            if (entity != null) setResultJson(EntityUtils.toString(entity));
        } catch (Exception e) {
            log.error("Exception occurred: {}", e.getMessage());
        }
        return statusCode;
    }

}
