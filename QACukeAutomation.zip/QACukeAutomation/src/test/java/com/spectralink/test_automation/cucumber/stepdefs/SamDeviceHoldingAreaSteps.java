package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamDeviceHoldingAreaPage;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamDeviceListPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamDeviceHoldingAreaSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I click the 'Pending' tab$")
    public void clickPending() {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        holdingPage.clickPendingTab();
    }

    @When("^I click the 'Approved' tab$")
    public void clickApproved() {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        holdingPage.clickApprovedTab();
    }

    @When("^I click the 'Rejected' tab$")
    public void clickRejected() {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        holdingPage.clickRejectedTab();
    }

    @When("^I select all devices in the Device Holding Area$")
    public void clickAllDevices() {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        holdingPage.clickSelectAllDevices();
    }

    @When("^I click \"([^\"]*)\" in the Device Holding Area$")
    public void selectDeviceFromCsv(String arg1) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        holdingPage.clickPhoneCheckbox(phone.getSerialNumber());
    }

    @When("^I select \"([^\"]*)\" from the Device Holding Area action menu$")
    public void selectDeviceAction(String arg1) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        switch (arg1.trim()) {
            case "Approve Device(s)":
                holdingPage.selectApproveAction();
                break;
            case "Reject Device(s)":
                holdingPage.selectRejectAction();
                break;
            case "Delete Device(s)":
                holdingPage.selectDeleteAction();
                break;
            case "Export All device(s)":
                holdingPage.selectExportAllDevices();
                break;
            default:
                log.error("Cannot select '{}' from action menu", arg1);
                Assert.fail("SAM UI Interaction Error");
        }
        sleepSeconds(2);
    }

    @When("^I clear the Device Holding Area search field$")
    public void clearHoldingAreaSearchField() {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        holdingPage.clickSearchClearButton();
    }

    @When("^I select \"([^\"]*)\" from the Device Holding Area search menu$")
    public void selectSearchType(String arg1) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        SamDeviceListPage.DeviceListColumns column = holdingPage.getHoldingAreaColumn(arg1.trim());
        if (column != null) {
            holdingPage.selectSearchType(column.title());
        } else {
            log.error("Cannot select '{}' from search menu", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^I enter \"([^\"]*)\" into the Device Holding Area search field$")
    public void enterGroupSearchValue(String arg1) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        holdingPage.enterSearchValue(arg1.trim());
        sleepSeconds(1);
    }

    @When("^I click the \"([^\"]*)\" Device Holding Area column heading$")
    public void clickColumnHeading(String arg1) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        holdingPage.clickColumnHeading(arg1.trim());
        sleepSeconds(1);
    }

    @When("^I enter the \"([^\"]*)\" of device \"([^\"]*)\" into the Device Holding Area search field$")
    public void enterSearchValue(String arg1, String arg2) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if (phone != null) {
            SamDeviceListPage.DeviceListColumns column = holdingPage.getHoldingAreaColumn(arg1.trim());
            if (column != null) {
                switch (column) {
                    case MAC:
                        holdingPage.enterSearchValue(phone.getMacAddress());
                        break;
                    case SERIAL_NUMBER:
                        holdingPage.enterSearchValue(phone.getSerialNumber());
                        break;
                    case MODEL:
                        String modifiedModel = phone.getModel().toUpperCase().replace(" ", "_");
                        holdingPage.enterSearchValue(modifiedModel);
                        break;
                    case DEVICE_INFO_1:
                        String info1 = Environment.getSam().keyDatabase().getDeviceInfo1(phone.getSerialNumber());
                        holdingPage.enterSearchValue(info1);
                        break;
                    case DEVICE_INFO_2:
                        String info2 = Environment.getSam().keyDatabase().getDeviceInfo2(phone.getSerialNumber());
                        holdingPage.enterSearchValue(info2);
                        break;
                    case DEVICE_INFO_3:
                        String info3 = Environment.getSam().keyDatabase().getDeviceInfo3(phone.getSerialNumber());
                        holdingPage.enterSearchValue(info3);
                        break;
                    case DEVICE_INFO_4:
                        String info4 = Environment.getSam().keyDatabase().getDeviceInfo4(phone.getSerialNumber());
                        holdingPage.enterSearchValue(info4);
                        break;
                }
            } else {
                log.error("Column with title '{}' does not exist", arg1);
                Assert.fail("SAM UI Interaction Error");
            }
        } else {
            log.error("Phone with label '{}' does not exist", arg2);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @Then("^\"([^\"]*)\" is visible in the Device Holding Area list$")
    public void verifyDeviceVisible(String arg1) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (holdingPage.phoneInList(phone.getSerialNumber())) {
            log.debug("Device '{}' was found in the list", phone.getSerialNumber());
        } else {
            log.fatal("Device '{}' was not found in the list", phone.getSerialNumber());
            Assert.fail("SAM Failed To Find Device");
        }
    }

    @Then("^\"([^\"]*)\" is not visible in the Device Holding Area list$")
    public void verifyDeviceNotVisible(String arg1) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (holdingPage.phoneInList(phone.getSerialNumber())) {
            log.fatal("Device '{}' was still found in the list", phone.getSerialNumber());
            Assert.fail("SAM Failed To Remove Device");
            log.debug("Device '{}' was found in the list", phone.getSerialNumber());
        } else {
            log.debug("Device '{}' was not found in the list", phone.getSerialNumber());
        }
    }

    @Then("^at least one device match is found in the Device Holding Area list$")
    public void verifyMatch() {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        int matches = holdingPage.getDeviceRowCount();
        if (matches >= 1) {
            log.debug("Found {} device matches", matches);
        } else {
            log.error("No matches were found");
            Assert.fail("Device Search Failed");
        }
    }

    @Then("^exactly \"([^\"]*)\" matches are found in the Device Holding Area list$")
    public void verifyExactMatch(String arg1) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        int matches = holdingPage.getDeviceRowCount();
        int expectedMatches = Integer.parseInt(arg1.trim());
        if (matches == expectedMatches) {
            log.debug("Found {} device matches", matches);
        } else {
            log.error("{} matches were not found", arg1);
            Assert.fail("Device Search Failed");
        }
    }

    @Then("^the sort direction for Device Holding Area column \"([^\"]*)\" should be \"([^\"]*)\"$")
    public void verifySortDirection(String arg1, String arg2) {
        SamDeviceHoldingAreaPage holdingPage = (SamDeviceHoldingAreaPage) Environment.getCurrentPage();
        String direction = holdingPage.getSortDirection(arg1.trim());
        if (direction.contains(arg2.trim())) {
            log.debug("Sort direction {} was verified", arg2);
        } else {
            log.fatal("Sort direction was not expected {}", arg2);
            Assert.fail("SAM Device Holding Area Sort Failed");
        }
    }
}