package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import io.cucumber.java.en.Then;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class SamCsvSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @Then("^the file \"([^\"]*)\" contains valid data for device\\(s\\) \"([^\"]*)\"$")
    public void verifyFileValid(String arg1, String arg2) {
        Path exportFilePath = Paths.get(Environment.getProjectDirectory(), "src/test/resources", arg1.trim());
        File exportFile = exportFilePath.toFile();
        List<String> expectedPhones = new ArrayList<>();
        for (String eachPhone : arg2.trim().split("\\s*,\\s*")) {
            VersityPhone phone = Environment.getPhone(eachPhone);
            expectedPhones.add(phone.getSerialNumber());
        }
        try {
            Reader exportCsv = new FileReader(exportFile);
            Iterable<CSVRecord> records = CSVFormat.RFC4180.parse(exportCsv);
            int phonesFound = 0;
            for (CSVRecord record : records) {
                String serial = record.get(1);
                if (expectedPhones.contains(serial)) {
                    log.debug("Device {} had data in the CSV", serial);
                    phonesFound += 1;
                }
            }
            exportFile.delete();
            if (phonesFound == expectedPhones.size()) {
                log.debug("All phones were found in the export file");
            } else {
                log.fatal("File {} did not contain all phones", arg1);
                Assert.fail("All Phones Not Exported");
            }
        } catch (FileNotFoundException fnfe) {
            log.error("File {} could not be located", arg1);
            Assert.fail("File Could Not Be Found");
        } catch (IOException ioe) {
            log.error("File {} could not be opened", arg1);
            Assert.fail("File Could Not Be Opened");
        }
    }
}