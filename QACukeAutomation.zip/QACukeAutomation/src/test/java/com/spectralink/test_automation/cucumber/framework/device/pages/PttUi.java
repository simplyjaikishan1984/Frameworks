package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.PttStrings.*;

public class PttUi extends AppiumUi {

    @AndroidFindBy(id = "com.spectralink.slnkptt:id/toolbar_current_channel_title")
    private WebElement currentChannelLabel;

    @AndroidFindBy(id = "com.spectralink.slnkptt:id/toolbar_title")
    private WebElement currentChannelValue;

    public ConfigUiField currentChannelField = new ConfigUiField(
            driver,
            CURRENT_CHANNEL,
            currentChannelLabel,
            null,
            currentChannelValue
    );

    @AndroidFindBy(accessibility = "Ptt audio termination view")
    private WebElement audioIndicator;

    public ConfigUiField audioIndicatorField = new ConfigUiField(
            driver,
            AUDIO_INDICATOR,
            audioIndicator,
            audioIndicator,
            null
    );

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    public ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            overflowButton,
            overflowButton,
            null
    );

    @AndroidFindBy(accessibility = "Transmit tab")
    private WebElement transmitTabControl;

    public ConfigUiField transmitTabField = new ConfigUiField(
            driver,
            TRANSMIT_TAB,
            transmitTabControl,
            transmitTabControl,
            null
    );

    @AndroidFindBy(accessibility = "Activity tab")
    private WebElement activityTabControl;

    public ConfigUiField activityTabField = new ConfigUiField(
            driver,
            ACTIVITY_TAB,
            activityTabControl,
            activityTabControl,
            null
    );

    @AndroidFindBy(accessibility = "Channels tab")
    private WebElement channelsTabControl;

    public ConfigUiField channelsTabField = new ConfigUiField(
            driver,
            CHANNELS_TAB,
            channelsTabControl,
            channelsTabControl,
            null
    );

    @AndroidFindBy(accessibility = "TRANSMIT")
    private WebElement transmitButton;

    public ConfigUiField transmitButtonField = new ConfigUiField(
            driver,
            TRANSMIT,
            transmitButton,
            transmitButton,
            null
    );

    @AndroidFindBy(xpath = "//android.widget.ListView[1]")
    private WebElement activityList;

    public ConfigUiField activityListField = new ConfigUiField(
            driver,
            ACTIVITY_LIST,
            activityList,
            null,
            activityList
    );

    @AndroidFindBy(xpath = "//android.widget.ScrollView[2]")
    private WebElement channelList;

    public ConfigUiField channelListField = new ConfigUiField(
            driver,
            CHANNEL_LIST,
            activityList,
            null,
            activityList
    );

    @AndroidFindBy(id = "com.spectralink.slnkptt:id/lbl_ptt_status")
    private WebElement connectionBanner;

    public ConfigUiField connectionBannerField = new ConfigUiField(
            driver,
            RUNNING_BANNER,
            connectionBanner,
            null,
            connectionBanner
    );

    @AndroidFindBy(accessibility = "PTT volume title")
    private WebElement pttVolumeLabel;

    @AndroidFindBy(accessibility = "PTT volume seekbar")
    private WebElement pttVolumeSlider;

    public ConfigUiField pttVolumeField = new ConfigUiField(
            driver,
            PTT_VOLUME,
            pttVolumeLabel,
            pttVolumeSlider,
            null
    );

    @AndroidFindBy(accessibility = "Default channel title")
    private WebElement defaultChannelLabel;

    @AndroidFindBy(accessibility = "Default channel summary")
    private WebElement defaultChannelValue;

    public ConfigUiField defaultChannelField = new ConfigUiField(
            driver,
            DEFAULT_CHANNEL,
            defaultChannelLabel,
            null,
            defaultChannelValue
    );

    @AndroidFindBy(accessibility = "Enable PTT title")
    private WebElement enablePttLabel;

    @AndroidFindBy(accessibility = "Enable PTT switch")
    private WebElement enablePttControl;

    @AndroidFindBy(accessibility = "Enable PTT summary")
    private WebElement enablePttValue;

    public ConfigUiField enablePttField = new ConfigUiField(
            driver,
            ENABLE_PTT,
            enablePttLabel,
            enablePttControl,
            enablePttValue
    );

    @AndroidFindBy(accessibility = "Username title")
    private WebElement usernameLabel;

    @AndroidFindBy(accessibility = "Username summary")
    private WebElement usernameValue;

    public ConfigUiField usernameField = new ConfigUiField(
            driver,
            USER_NAME,
            usernameLabel,
            null,
            usernameValue
    );

    @AndroidFindBy(id = "com.spectralink.slnkptt:id/alertTitle")
    private WebElement editBoxLabel;

    @AndroidFindBy(id = "android:id/edit")
    private WebElement editBoxValue;

    public ConfigUiField editBoxField = new ConfigUiField(
            driver,
            EDIT_BOX,
            editBoxLabel,
            editBoxValue,
            null
    );

    @AndroidFindBy(accessibility = "Multicast address title")
    private WebElement multicastAddressLabel;

    @AndroidFindBy(accessibility = "Multicast address summary")
    private WebElement multicastAddressValue;

    public ConfigUiField multicastAddressField = new ConfigUiField(
            driver,
            MULTICAST_ADDRESS,
            multicastAddressLabel,
            null,
            multicastAddressValue
    );

    @AndroidFindBy(accessibility = "Codec title")
    private WebElement codecLabel;

    @AndroidFindBy(accessibility = "Codec summary")
    private WebElement codecValue;

    public ConfigUiField codecField = new ConfigUiField(
            driver,
            CODEC,
            codecLabel,
            null,
            codecValue
    );

    @AndroidFindBy(accessibility = "Channel setup title")
    private WebElement channelSetupLabel;

    @AndroidFindBy(accessibility = "Channel setup summary")
    private WebElement channelSetupValue;

    public ConfigUiField channelSetupField = new ConfigUiField(
            driver,
            CHANNEL_SETUP,
            channelSetupLabel,
            null,
            channelSetupValue
    );

    @AndroidFindBy(accessibility = "Navigate up")
    private WebElement backButton;

    public ConfigUiField backButtonField = new ConfigUiField(
            driver,
            BACK_ARROW,
            backButton,
            backButton,
            null
    );

    @AndroidFindBy(accessibility = "Channel #1 title")
    private WebElement channel1Label;

    @AndroidFindBy(accessibility = "Channel #1 summary")
    private WebElement channel1Value;

    public ConfigUiField channel1Field = new ConfigUiField(
            driver,
            CHANNEL_1,
            channel1Label,
            null,
            channel1Value
    );

    @AndroidFindBy(accessibility = "Channel #2 title")
    private WebElement channel2Label;

    @AndroidFindBy(accessibility = "Channel #2 summary")
    private WebElement channel2Value;

    public ConfigUiField channel2Field = new ConfigUiField(
            driver,
            CHANNEL_2,
            channel2Label,
            null,
            channel2Value
    );

    @AndroidFindBy(accessibility = "Channel #3 title")
    private WebElement channel3Label;

    @AndroidFindBy(accessibility = "Channel #3 summary")
    private WebElement channel3Value;

    public ConfigUiField channel3Field = new ConfigUiField(
            driver,
            CHANNEL_3,
            channel3Label,
            null,
            channel3Value
    );

    @AndroidFindBy(accessibility = "Channel #4 title")
    private WebElement channel4Label;

    @AndroidFindBy(accessibility = "Channel #4 summary")
    private WebElement channel4Value;

    public ConfigUiField channel4Field = new ConfigUiField(
            driver,
            CHANNEL_4,
            channel4Label,
            null,
            channel4Value
    );

    @AndroidFindBy(accessibility = "Channel #5 title")
    private WebElement channel5Label;

    @AndroidFindBy(accessibility = "Channel #5 summary")
    private WebElement channel5Value;

    public ConfigUiField channel5Field = new ConfigUiField(
            driver,
            CHANNEL_5,
            channel5Label,
            null,
            channel5Value
    );

    @AndroidFindBy(accessibility = "Channel #6 title")
    private WebElement channel6Label;

    @AndroidFindBy(accessibility = "Channel #6 summary")
    private WebElement channel6Value;

    public ConfigUiField channel6Field = new ConfigUiField(
            driver,
            CHANNEL_6,
            channel6Label,
            null,
            channel6Value
    );

    @AndroidFindBy(accessibility = "Channel #7 title")
    private WebElement channel7Label;

    @AndroidFindBy(accessibility = "Channel #7 summary")
    private WebElement channel7Value;

    public ConfigUiField channel7Field = new ConfigUiField(
            driver,
            CHANNEL_7,
            channel7Label,
            null,
            channel7Value
    );

    @AndroidFindBy(accessibility = "Channel #8 title")
    private WebElement channel8Label;

    @AndroidFindBy(accessibility = "Channel #8 summary")
    private WebElement channel8Value;

    public ConfigUiField channel8Field = new ConfigUiField(
            driver,
            CHANNEL_8,
            channel8Label,
            null,
            channel8Value
    );

    @AndroidFindBy(accessibility = "Channel #9 title")
    private WebElement channel9Label;

    @AndroidFindBy(accessibility = "Channel #9 summary")
    private WebElement channel9Value;

    public ConfigUiField channel9Field = new ConfigUiField(
            driver,
            CHANNEL_9,
            channel9Label,
            null,
            channel9Value
    );

    @AndroidFindBy(accessibility = "Channel #10 title")
    private WebElement channel10Label;

    @AndroidFindBy(accessibility = "Channel #10 summary")
    private WebElement channel10Value;

    public ConfigUiField channel10Field = new ConfigUiField(
            driver,
            CHANNEL_10,
            channel10Label,
            null,
            channel10Value
    );

    @AndroidFindBy(accessibility = "Channel #11 title")
    private WebElement channel11Label;

    @AndroidFindBy(accessibility = "Channel #11 summary")
    private WebElement channel11Value;

    public ConfigUiField channel11Field = new ConfigUiField(
            driver,
            CHANNEL_11,
            channel11Label,
            null,
            channel11Value
    );

    @AndroidFindBy(accessibility = "Channel #12 title")
    private WebElement channel12Label;

    @AndroidFindBy(accessibility = "Channel #12 summary")
    private WebElement channel12Value;

    public ConfigUiField channel12Field = new ConfigUiField(
            driver,
            CHANNEL_12,
            channel12Label,
            null,
            channel12Value
    );

    @AndroidFindBy(accessibility = "Channel #13 title")
    private WebElement channel13Label;

    @AndroidFindBy(accessibility = "Channel #13 summary")
    private WebElement channel13Value;

    public ConfigUiField channel13Field = new ConfigUiField(
            driver,
            CHANNEL_13,
            channel13Label,
            null,
            channel13Value
    );

    @AndroidFindBy(accessibility = "Channel #14 title")
    private WebElement channel14Label;

    @AndroidFindBy(accessibility = "Channel #14 summary")
    private WebElement channel14Value;

    public ConfigUiField channel14Field = new ConfigUiField(
            driver,
            CHANNEL_14,
            channel14Label,
            null,
            channel14Value
    );

    @AndroidFindBy(accessibility = "Channel #15 title")
    private WebElement channel15Label;

    @AndroidFindBy(accessibility = "Channel #15 summary")
    private WebElement channel15Value;

    public ConfigUiField channel15Field = new ConfigUiField(
            driver,
            CHANNEL_15,
            channel15Label,
            null,
            channel15Value
    );

    @AndroidFindBy(accessibility = "Channel #16 title")
    private WebElement channel16Label;

    @AndroidFindBy(accessibility = "Channel #16 summary")
    private WebElement channel16Value;

    public ConfigUiField channel16Field = new ConfigUiField(
            driver,
            CHANNEL_16,
            channel16Label,
            null,
            channel16Value
    );

    @AndroidFindBy(accessibility = "Channel #17 title")
    private WebElement channel17Label;

    @AndroidFindBy(accessibility = "Channel #17 summary")
    private WebElement channel17Value;

    public ConfigUiField channel17Field = new ConfigUiField(
            driver,
            CHANNEL_17,
            channel17Label,
            null,
            channel17Value
    );

    @AndroidFindBy(accessibility = "Channel #18 title")
    private WebElement channel18Label;

    @AndroidFindBy(accessibility = "Channel #18 summary")
    private WebElement channel18Value;

    public ConfigUiField channel18Field = new ConfigUiField(
            driver,
            CHANNEL_18,
            channel18Label,
            null,
            channel18Value
    );

    @AndroidFindBy(accessibility = "Channel #19 title")
    private WebElement channel19Label;

    @AndroidFindBy(accessibility = "Channel #19 summary")
    private WebElement channel19Value;

    public ConfigUiField channel19Field = new ConfigUiField(
            driver,
            CHANNEL_19,
            channel19Label,
            null,
            channel19Value
    );

    @AndroidFindBy(accessibility = "Channel #20 title")
    private WebElement channel20Label;

    @AndroidFindBy(accessibility = "Channel #20 summary")
    private WebElement channel20Value;

    public ConfigUiField channel20Field = new ConfigUiField(
            driver,
            CHANNEL_20,
            channel20Label,
            null,
            channel20Value
    );

    @AndroidFindBy(accessibility = "Channel #21 title")
    private WebElement channel21Label;

    @AndroidFindBy(accessibility = "Channel #21 summary")
    private WebElement channel21Value;

    public ConfigUiField channel21Field = new ConfigUiField(
            driver,
            CHANNEL_21,
            channel21Label,
            null,
            channel21Value
    );

    @AndroidFindBy(accessibility = "Channel #22 title")
    private WebElement channel22Label;

    @AndroidFindBy(accessibility = "Channel #22 summary")
    private WebElement channel22Value;

    public ConfigUiField channel22Field = new ConfigUiField(
            driver,
            CHANNEL_22,
            channel22Label,
            null,
            channel22Value
    );

    @AndroidFindBy(accessibility = "Channel #23 title")
    private WebElement channel23Label;

    @AndroidFindBy(accessibility = "Channel #23 summary")
    private WebElement channel23Value;

    public ConfigUiField channel23Field = new ConfigUiField(
            driver,
            CHANNEL_23,
            channel23Label,
            null,
            channel23Value
    );

    @AndroidFindBy(accessibility = "Channel #24 title")
    private WebElement channel24Label;

    @AndroidFindBy(accessibility = "Channel #24 summary")
    private WebElement channel24Value;

    public ConfigUiField channel24Field = new ConfigUiField(
            driver,
            CHANNEL_24,
            channel24Label,
            null,
            channel24Value
    );

    @AndroidFindBy(accessibility = "Channel #25 title")
    private WebElement channel25Label;

    @AndroidFindBy(accessibility = "Channel #25 summary")
    private WebElement channel25Value;

    public ConfigUiField channel25Field = new ConfigUiField(
            driver,
            CHANNEL_25,
            channel25Label,
            null,
            channel25Value
    );

    @AndroidFindBy(id = "com.spectralink.slnkptt:id/title_edittext")
    private WebElement channelEditValue;

    public ConfigUiField channelEditField = new ConfigUiField(
            driver,
            CHANNEL_NAME_EDIT,
            editBoxLabel,
            channelEditValue,
            channelEditValue
    );

    @AndroidFindBy(id = "com.spectralink.slnkptt:id/channel_transmit_switch")
    private WebElement canTransmitEditLabel;

    public ConfigUiField canTransmitEditField = new ConfigUiField(
            driver,
            CHANNEL_TRANSMIT,
            canTransmitEditLabel,
            canTransmitEditLabel,
            canTransmitEditLabel
    );

    @AndroidFindBy(id = "com.spectralink.slnkptt:id/channel_subs_switch")
    private WebElement subscriptionEditLabel;

    public ConfigUiField subscriptionEditField = new ConfigUiField(
            driver,
            CHANNEL_RECEIVE,
            subscriptionEditLabel,
            subscriptionEditLabel,
            subscriptionEditLabel
    );

    public PttUi(AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(currentChannelField.getKey().toLowerCase(), currentChannelField);
                put(audioIndicatorField.getKey().toLowerCase(), audioIndicatorField);
                put(overflowButtonField.getKey().toLowerCase(), overflowButtonField);
                put(transmitTabField.getKey().toLowerCase(), transmitTabField);
                put(activityTabField.getKey().toLowerCase(), activityTabField);
                put(channelsTabField.getKey().toLowerCase(), channelsTabField);
                put(transmitButtonField.getKey().toLowerCase(), transmitButtonField);
                put(activityListField.getKey().toLowerCase(), activityListField);
                put(channelListField.getKey().toLowerCase(), channelListField);
                put(connectionBannerField.getKey().toLowerCase(), connectionBannerField);
                put(pttVolumeField.getKey().toLowerCase(), pttVolumeField);
                put(defaultChannelField.getKey().toLowerCase(), defaultChannelField);
                put(enablePttField.getKey().toLowerCase(), enablePttField);
                put(usernameField.getKey().toLowerCase(), usernameField);
                put(editBoxField.getKey().toLowerCase(), editBoxField);
                put(multicastAddressField.getKey().toLowerCase(), multicastAddressField);
                put(codecField.getKey().toLowerCase(), codecField);
                put(channelSetupField.getKey().toLowerCase(), channelSetupField);
                put(backButtonField.getKey().toLowerCase(), backButtonField);
                put(channel1Field.getKey().toLowerCase(), channel1Field);
                put(channel2Field.getKey().toLowerCase(), channel2Field);
                put(channel3Field.getKey().toLowerCase(), channel3Field);
                put(channel4Field.getKey().toLowerCase(), channel4Field);
                put(channel5Field.getKey().toLowerCase(), channel5Field);
                put(channel6Field.getKey().toLowerCase(), channel6Field);
                put(channel7Field.getKey().toLowerCase(), channel7Field);
                put(channel8Field.getKey().toLowerCase(), channel8Field);
                put(channel9Field.getKey().toLowerCase(), channel9Field);
                put(channel10Field.getKey().toLowerCase(), channel10Field);
                put(channel11Field.getKey().toLowerCase(), channel11Field);
                put(channel12Field.getKey().toLowerCase(), channel12Field);
                put(channel13Field.getKey().toLowerCase(), channel13Field);
                put(channel14Field.getKey().toLowerCase(), channel14Field);
                put(channel15Field.getKey().toLowerCase(), channel15Field);
                put(channel16Field.getKey().toLowerCase(), channel16Field);
                put(channel17Field.getKey().toLowerCase(), channel17Field);
                put(channel18Field.getKey().toLowerCase(), channel18Field);
                put(channel19Field.getKey().toLowerCase(), channel19Field);
                put(channel20Field.getKey().toLowerCase(), channel20Field);
                put(channel21Field.getKey().toLowerCase(), channel21Field);
                put(channel22Field.getKey().toLowerCase(), channel22Field);
                put(channel23Field.getKey().toLowerCase(), channel23Field);
                put(channel24Field.getKey().toLowerCase(), channel24Field);
                put(channel25Field.getKey().toLowerCase(), channel25Field);
                put(channelEditField.getKey().toLowerCase(), channelEditField);
                put(canTransmitEditField.getKey().toLowerCase(), canTransmitEditField);
                put(subscriptionEditField.getKey().toLowerCase(), subscriptionEditField);
            }
        };
    }

    public void tapOverflowMenu() {
        overflowButtonField.tap();
        Util.sleepSeconds(2);
    }

    public List<Map<String, String>> getActivities() {
        List<Map<String, String>> activities = new ArrayList<>();
        List<WebElement> list = driver.findElements(By.xpath("//android.widget.ListView/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.RelativeLayout"));
        if (list.size() > 0) {
            int counter = 0;
            while (counter < list.size() && counter < 9) {
                WebElement row = list.get(counter);
                Map<String, String> rowInfo = new HashMap<>();
                WebElement channel = row.findElement(By.id("com.spectralink.slnkptt:id/label_text"));
                rowInfo.put("channel", channel.getText());
                WebElement sender = row.findElement(By.id("com.spectralink.slnkptt:id/name_text"));
                rowInfo.put("sender", sender.getText());
                WebElement timestamp = row.findElement(By.id("com.spectralink.slnkptt:id/time_text"));
                rowInfo.put("timestamp", timestamp.getText());
                activities.add(rowInfo);
                counter += 1;
            }
        }
        return activities;
    }

    public Map<String, String> getActivity(int index) {
        WebElement row = driver.findElement(By.xpath("//android.widget.ListView/android.widget.RelativeLayout[" + index + "]"));
        Map<String, String> rowInfo = new HashMap<>();
        if (row != null) {
            WebElement channel = row.findElement(By.id("com.spectralink.slnkptt:id/label_text"));
            rowInfo.put("channel", channel.getText());
            WebElement sender = row.findElement(By.id("com.spectralink.slnkptt:id/name_text"));
            rowInfo.put("sender", sender.getText());
            WebElement timestamp = row.findElement(By.id("com.spectralink.slnkptt:id/time_text"));
            rowInfo.put("timestamp", timestamp.getText());
        }
        return rowInfo;
    }

    public List<Map<String, Object>> getChannels() {
        List<Map<String, Object>> channels = new ArrayList<>();
        List<WebElement> list = driver.findElements(By.xpath("//android.widget.LinearLayout[@resource-id='com.spectralink.slnkptt:id/channels_view_layout']/android.widget.RelativeLayout"));
        if (list.size() > 0) {
            for (WebElement row : list) {
                Map<String, Object> rowInfo = new HashMap<>();
                WebElement subscribeImage = row.findElement(By.id("com.spectralink.slnkptt:id/mic_image"));
                boolean transmit = subscribeImage.getAttribute("content-desc").contains("enabled");
                rowInfo.put("transmit", transmit);
                WebElement channelName = row.findElement(By.id("com.spectralink.slnkptt:id/channel_label_text"));
                rowInfo.put("name", channelName.getText());
                rowInfo.put("element", channelName);
                try {
                    row.findElement(By.id("com.spectralink.slnkptt:id/default_channel_image"));
                    rowInfo.put("default", true);
                } catch (NoSuchElementException nee) {
                    rowInfo.put("default", false);
                }
                channels.add(rowInfo);
            }
        }
        return channels;
    }

    public Map<String, Object> getChannelInfo(String name) {
        List<Map<String, Object>> channels = getChannels();
        Map<String, Object> channelInfo = new HashMap<>();
        for (Map<String, Object> row : channels) {
            if (row.get("name").toString().contentEquals(name)) {
                channelInfo = row;
                break;
            }
        }
        return channelInfo;
    }

    public List<Map<String, String>> getChannelSetup() {
        List<Map<String, String>> channels = new ArrayList<>();
        List<WebElement> list = driver.findElements(By.xpath("//android.widget.ListView/android.widget.LinearLayout"));
        for (WebElement row : list) {
            try {
                Map<String, String> rowInfo = new HashMap<>();
                WebElement channelName = row.findElement(By.id("android:id/title"));
                rowInfo.put("name", channelName.getText().trim());
                String status = row.findElement(By.id("android:id/summary")).getText();
                String[] chunks = status.split(",\\s*");
                rowInfo.put("transmit", chunks[0].split(":\\s*")[1]);
                rowInfo.put("subscribed", chunks[1].split(":\\s*")[1]);
                channels.add(rowInfo);
            } catch (NoSuchElementException nee) {
                break;
            }
        }
        return channels;
    }

    public List<Map<String, String>> getFullChannelSetup() {
        List<Map<String, String>> channels = new ArrayList<>();
        for (Integer channelIndex = 1; channelIndex < 26; channelIndex++) {
            Map<String, String> rowInfo = new HashMap<>();
            WebElement title = scrollDescriptionIntoView("Channel #" + channelIndex + " title");
            rowInfo.put("name", title.getText().trim());
            WebElement summary;
            if (channelIndex.equals(8)) {
                summary = scrollDescriptionIntoView("Channe #" + channelIndex + " summary");
            } else {
                summary = scrollDescriptionIntoView("Channel #" + channelIndex + " summary");
            }
            String[] chunks = summary.getText().split(",\\s*");
            rowInfo.put("transmit", chunks[0].split(":\\s*")[1]);
            rowInfo.put("subscribed", chunks[1].split(":\\s*")[1]);
            channels.add(rowInfo);
        }
        return channels;
    }

    public String getDefaultChannel() {
        String defaultChannel = "unknown";
        List<WebElement> list = driver.findElements(By.xpath("//android.widget.LinearLayout[@resource-id='com.spectralink.slnkptt:id/channels_view_layout']/android.widget.RelativeLayout"));
        if (list.size() > 0) {
            for (WebElement row : list) {
                WebElement channelName = row.findElement(By.id("com.spectralink.slnkptt:id/channel_label_text"));
                defaultChannel = channelName.getText();
                try {
                    row.findElement(By.id("com.spectralink.slnkptt:id/default_channel_image"));
                    break;
                } catch (NoSuchElementException nee) {

                }
            }
        }
        return defaultChannel;
    }

    public String getCurrentChannel() {
        return currentChannelField.getValue();
    }

    public boolean serviceRunningBannerDisplayed() {
        return connectionBannerField != null;
    }

    public List<Map<String, String>> getChannels(int index) {
        List<Map<String, String>> channels = new ArrayList<>();
        return channels;
    }

    public void navigateBackOneScreen() {
        backButton.click();
    }

    public void dismissApp() {
        backButton.click();
    }

    public void enterChannelSetup() {
        channelSetupLabel.click();
    }
}
