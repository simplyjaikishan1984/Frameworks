package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.LensGridStrings.ENABLE_LENS_GRID;
import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.LensGridStrings.GRID_SIZE;

public class SamLensGridPage extends SamConfigurationPage {

	@FindBy(id = "enable_lens_grid_label")
	private WebElement lensGridEnabledLabel;

	@FindBy(id = "enable_lens_grid")
	private WebElement lensGridEnabledCheckbox;

	@FindBy(id = "delete_setting_gridCameraEnable")
	private WebElement lensGridEnabledDelete;

	@FindBy(id = "edit_setting_gridCameraEnable")
	private WebElement lensGridEnabledEdit;

	public ConfigPageField lensGridEnabledField = new ConfigPageField(
			ENABLE_LENS_GRID,
			lensGridEnabledLabel,
			lensGridEnabledCheckbox,
			lensGridEnabledDelete,
			lensGridEnabledEdit
	);

	@FindBy(id = "gridCameraSize")
	private WebElement gridSizeMenu;

	@FindBy(id = "delete_setting_gridCameraSize")
	private WebElement gridSizeDelete;

	@FindBy(id = "edit_setting_gridCameraSize")
	private WebElement gridSizeEdit;

	public ConfigPageField gridSizeField = new ConfigPageField(
			GRID_SIZE,
			gridSizeMenu,
			gridSizeDelete,
			gridSizeEdit
	);

	public SamLensGridPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(lensGridEnabledField.getTitle(), lensGridEnabledField);
				put(gridSizeField.getTitle(), gridSizeField);
			}
		};
	}
}
