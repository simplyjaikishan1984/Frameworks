package com.spectralink.test_automation.cucumber.framework.common;

import java.sql.Timestamp;

public class ImDatabase extends Database {

	private final String cmsAccount;

	public ImDatabase(String dbIP, Integer dbPort, String dbUsername, String dbPassword, String cmsAccount) {
		super(dbIP, dbPort, "im", dbUsername, dbPassword);
		this.cmsAccount = cmsAccount;
	}

	public Long getAccountId() {
		String query = String.format("SELECT id FROM users WHERE username = '%s'", cmsAccount);
		return queryLong(query, "id");
	}

	public String getAccountKey() {
		String query = String.format("SELECT key FROM accounts WHERE id = 1", cmsAccount);
		return queryString(query, "key");
	}

	public Timestamp getAccountCreated() {
		String query = String.format("SELECT created FROM users WHERE username = '%s'", cmsAccount);
		return queryTime(query, "created");
	}

	public Boolean getPasswordResetRequired() {
		String query = String.format("SELECT password_reset_required FROM users WHERE username = '%s'", cmsAccount);
		return queryBoolean(query, "password_reset_required");
	}

	public Integer getLoginAttempts() {
		String query = String.format("SELECT login_attempts FROM users WHERE username = '%s'", cmsAccount);
		return queryInteger(query, "login_attempts");
	}

	public Boolean getLocked() {
		String query = String.format("SELECT locked FROM users WHERE username = '%s'", cmsAccount);
		return queryBoolean(query, "locked");
	}

	public String getDeviceFamily() {
		String query = String.format("SELECT device_family FROM users WHERE username = '%s'", cmsAccount);
		return queryString(query, "device_family");
	}

	public String getAppName() {
		String query = String.format("SELECT app_name FROM app_info WHERE id = '%s'", getAccountId());
		return queryString(query, "app_name");
	}

	public String getAppVersion() {
		String query = "SELECT app_version FROM app_info WHERE id = " + getAccountId();
		return queryString(query, "app_version");
	}

	public String getAppContactEmail() {
		String query = "SELECT app_contact_email FROM app_info WHERE id = " + getAccountId();
		return queryString(query, "app_contact_email");
	}

	public Boolean getIsOnPremise() {
		String query = "SELECT is_onpremise FROM app_info WHERE id = " + getAccountId();
		return queryBoolean(query, "is_onpremise");
	}

	public Boolean getCreateOnPremiseUser() {
		String query = "SELECT create_onpremise_user FROM app_info WHERE id = " + getAccountId();
		return queryBoolean(query, "create_onpremise_user");
	}

	public int getDevicesPerPagePreference() {
		String query = "SELECT display_preferences FROM users WHERE device_family = 'PIVOT'";
		String preferenceJson = queryString(query, "display_preferences");
		org.json.JSONObject jsonObj = new org.json.JSONObject(preferenceJson);
		if (jsonObj.getJSONObject("PIVOT") != null && jsonObj.getJSONObject("PIVOT").getJSONObject("gridLimits") != null) {
			return jsonObj.getJSONObject("PIVOT").getJSONObject("gridLimits").getInt("device");
		} else {
			return -1;
		}
	}

	public int getPhoenixDevicesPerPagePreference() {
		String query = "SELECT display_preferences FROM users WHERE device_family = 'PHOENIX'";
		String preferenceJson = queryString(query, "display_preferences");
		org.json.JSONObject jsonObj = new org.json.JSONObject(preferenceJson);
		if (jsonObj.getJSONObject("PHOENIX") != null && jsonObj.getJSONObject("PHOENIX").getJSONObject("gridLimits") != null) {
			return jsonObj.getJSONObject("PHOENIX").getJSONObject("gridLimits").getInt("device");
		} else {
			return -1;
		}
	}

	public String getSamAccountNumber() {
		String query = String.format("SELECT account_number FROM accounts WHERE name = '%s'", cmsAccount);
		return queryString(query, "account_number");
	}
}
