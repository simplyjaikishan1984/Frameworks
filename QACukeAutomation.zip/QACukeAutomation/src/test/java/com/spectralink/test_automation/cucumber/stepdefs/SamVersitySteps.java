package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import io.cucumber.java.en.Then;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SamVersitySteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @Then("^I log the last SamClient processed attributes from phone \"([^\"]*)\"")
    public void logLastSamClientProcessing(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.logcatInspector().logLastResponse();
    }

    @Then("^there should be no difference between what SAM sent and what phone \"([^\"]*)\" processed")
    public void compareJarvisToSamClient(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.logcatInspector().compareSentToProcessed(Environment.getSam().jarvisLog().getLastResponseJson(false, phone.getSerialNumber()));
    }
}