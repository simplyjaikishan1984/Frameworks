package com.spectralink.test_automation.cucumber.framework.common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class CliResult {
    private String stdout;
    private String stderr;
    private int exitCode;
    private Object callback;
    private int pid;
    private String command;

    public CliResult() {
    }

    public CliResult(String command) {
        this.command = command;
    }

    public String getStdout() {
        return stdout.trim();
    }

    public String[] getStdoutLines() {
        return stdout.trim().split("\n");
    }

    public void setStdout(String stdout) {
        this.stdout = stdout;
    }

    public String getStderr() {
        return stderr.trim();
    }

    public String[] getStderrLines() {
        return stderr.trim().split("\n");
    }

    public void setStderr(String stderr) {
        this.stderr = stderr;
    }

    public int getExitCode() {
        return exitCode;
    }

    public void setExitCode(int exitCode) {
        this.exitCode = exitCode;
    }

    public Object getCallback() {
        return callback;
    }

    public void setCallback(Object callback) {
        this.callback = callback;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public void setCommand(List<String> command) {
        this.command = String.join(" ", command);
    }

    public Boolean commandSucceeded() {
        return getExitCode() == 0;
    }

    public Boolean commandFailed() {
        return getExitCode() != 0;
    }

    @Override
    public String toString() {
        List<String> builder = new ArrayList<>();
        if (command != null) builder.add("Command: " + command);
        builder.add("Exit code: " + exitCode);
        if (stdout != null) builder.add("Stdout: " + stdout);
        if (stderr != null) builder.add("Stderr: " + stderr);
        if (pid != 0) builder.add("PID: " + pid);
        return String.join("\n", builder);
    }

    public void writeFile(File fileName) {
        PrintWriter writer;
        try {
            writer = new PrintWriter(fileName);
            writer.print(this.getStdout());
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}