package com.spectralink.test_automation.cucumber.framework.common;

import com.spectralink.test_automation.cucumber.stepdefs.DeviceAmieAgentSteps;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MqttTool implements MqttCallback {

    public enum AmieAgentMessageType {
        BATTERY_METRICS("battery metrics", "BATTERY_METRICS", "BATTERY_METRICS.json"),
        CALL_METRICS("call metrics", "CALL_METRICS", "CALL_METRICS.json"),
        DEVICE_METRICS("device metrics", "DEVICE_METRICS", "DEVICE_METRICS.json"),
        NETWORK_METRICS("network metrics", "NETWORK_METRICS", "NETWORK_METRICS.json");

        private final String label;
        private final String token;
        private final String validationFile;

        AmieAgentMessageType(String label, String token, String validationFile) {
            this.label = label;
            this.token = token;
            this.validationFile = validationFile;
        }

        public String getLabel() {
            return label;
        }

        public String getToken() {
            return token;
        }

        public String getValidationFile() {
            return validationFile;
        }
    }

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    private String server;
    private String protocol;
    private String port;
    private boolean connected = false;
    private boolean subscribed = false;
    private MqttAsyncClient mqttClient = null;
    private String topic;
    private boolean cleanSession = true;
    private boolean reconnect = true;
    private boolean blocking = true;
    private int keepAliveInterval = 60000;
    private int timeout = 10;
    private int qos = 1;
    private List<String> responses = new ArrayList<>();
    private CountDownLatch receivedSignal;

    public MqttTool(String serial) {
        this.topic = String.format("devices/spectralink/%s", serial);
        this.server = RunDefaults.getStringSetting("mqttBroker");
        this.protocol = RunDefaults.getStringSetting("mqttprotocol");
        this.port = RunDefaults.getStringSetting("mqttPort");
    }

    public MqttTool(String serial, String url) {
        this.topic = String.format("devices/spectralink/%s", serial);
        String[] urlPattern = url.split(":");
        this.protocol = urlPattern[0];
        String cleanServer = urlPattern[1].replace("/", "");
        this.server = cleanServer;
        this.port = urlPattern.length > 2 ? urlPattern[2] : "";
    }

    public static AmieAgentMessageType findMessageType(String messageLabel) {
        for (AmieAgentMessageType strings : AmieAgentMessageType.values()) {
            if (strings.getLabel().toLowerCase().contentEquals(messageLabel.trim().toLowerCase())) {
                return strings;
            }
        }
        return null;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public boolean isConnected() {
        return connected;
    }

    private void setConnected(boolean connected) {
        this.connected = connected;
    }

    public boolean isSubscribed() {
        return subscribed;
    }

    private void setSubscribed(boolean subscribed) {
        this.subscribed = subscribed;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public boolean isCleanSession() {
        return cleanSession;
    }

    public void setCleanSession(boolean cleanSession) {
        this.cleanSession = cleanSession;
    }

    public boolean isReconnect() {
        return reconnect;
    }

    public void setReconnect(boolean reconnect) {
        this.reconnect = reconnect;
    }

    public boolean isBlocking() {
        return blocking;
    }

    public void setBlocking(boolean blocking) {
        this.blocking = blocking;
    }

    public int getKeepAliveInterval() {
        return keepAliveInterval;
    }

    public void setKeepAliveInterval(int keepAliveInterval) {
        this.keepAliveInterval = keepAliveInterval;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public int getQos() {
        return qos;
    }

    public void setQos(int qos) {
        this.qos = qos;
    }

    public List<String> getResponses() {
        return responses;
    }

    public void addResponse(String response) {
        synchronized (responses) {
            responses.add(response);
        }
    }

    public int getResponseCount() {
        synchronized (responses) {
            return responses.size();
        }
    }

    public void deleteResponses() {
        synchronized (responses) {
            responses.clear();
        }
    }

    public CountDownLatch getReceivedSignal() {
        synchronized (receivedSignal) {
            return receivedSignal;
        }
    }

    public void decrementCountdown() {
        synchronized (receivedSignal) {
            receivedSignal.countDown();
        }
    }

    public String findMessageType(AmieAgentMessageType type) {
        for (String json : getResponses()) {
            if (json.contains(type.getToken())) {
                return json;
            }
        }
        return null;
    }

    public boolean validate(AmieAgentMessageType type, String json) {
        try {
            JSONObject jsonSchema = new JSONObject(
                    new JSONTokener(DeviceAmieAgentSteps.class.getResourceAsStream("/json-schemas/" + type.getValidationFile())));
            JSONObject jsonSubject = new JSONObject(
                    new JSONTokener(new ByteArrayInputStream(json.getBytes())));
            Schema schema = SchemaLoader.load(jsonSchema);
            schema.validate(jsonSubject);
            return true;
        } catch(ValidationException ve) {
            log.fatal("JSON validation failed", ve);
            for (ValidationException eachException : ve.getCausingExceptions()) {
                log.fatal("Error: {}; Location {}", eachException.getMessage(), eachException.getPointerToViolation());
            }
            log.fatal(json);
            return false;
        }
    }

    private MqttAsyncClient getClient() {
        if (mqttClient == null) {
            try {
                String url = String.format("%s://%s:%s", protocol, server, port);
                mqttClient = new MqttAsyncClient(url, MqttClient.generateClientId(), new MemoryPersistence());
                mqttClient.setCallback(this);
            } catch (MqttException me) {
                log.error("Could not instantiate MQTT client: {}", me.getMessage());
            }
        }
        return mqttClient;
    }

    public void connect() {
        if (!isConnected()) {
            try {
                MqttConnectOptions options = new MqttConnectOptions();
                options.setCleanSession(isCleanSession());
                options.setAutomaticReconnect(isReconnect());
                options.setConnectionTimeout(getTimeout());
                IMqttToken token = getClient().connect(options);
                while (!token.isComplete()) {
                    Util.sleepSeconds(1);
                }
                if (getClient().isConnected()) {
                    setConnected(true);
                    log.debug("Connected to MQTT broker at {}", getServer());
                } else {
                    log.error("Error occurred while connecting to MQTT broker at {}", getServer());
                }
            } catch(MqttException me) {
                log.error("Could not connect to MQTT broker at {}: {}", getServer(), me.getMessage());
                setConnected(false);
            }
        }
    }

    public void reconnect() {
        try {
            if (!getClient().isConnected()) {
                getClient().reconnect();
                Util.sleepSeconds(2);
                if (getClient().isConnected()) {
                    setConnected(getClient().isConnected());
                    log.debug("Connected to MQTT broker at {}", getServer());
                } else {
                    log.error("Error occurred while connecting to MQTT broker at {}", getServer());
                }
            }
        } catch(MqttException me) {
            log.error("Could not disconnect from MQTT broker at {}: {}", getServer(), me.getMessage());
        }
    }

    public void disconnect() {
        try {
            if (isConnected()) {
                getClient().disconnect(4000);
                setConnected(false);
            }
        } catch(MqttException me) {
            log.error("Could not disconnect from MQTT broker at {}: {}", getServer(), me.getMessage());
        }
    }

    public void destroy() {
        try {
            if (isConnected()) {
                getClient().disconnectForcibly(4000);
                getClient().close();
                setConnected(false);
            }
        } catch(MqttException me) {
            log.error("Could not destroy MQTT client at {}: {}", getServer(), me.getMessage());
        }
    }

    public void subscribe(int messageCount) {
        connect();
        setBlocking(true);
        deleteResponses();
        receivedSignal = new CountDownLatch(messageCount);
        log.debug("Waiting for {} message(s) with topic '{}'", messageCount, getTopic());
        try {
            getClient().subscribe(getTopic(), getQos());
            setSubscribed(true);
            receivedSignal.await(10, TimeUnit.MINUTES);
        } catch(MqttException me) {
            log.error("Could not subscribe to topic '{}': {}", getTopic(), me.getMessage());
        } catch(InterruptedException ie) {
            log.error("Exceeded time limit while waiting for {} messages", messageCount);
            Thread.currentThread().interrupt();
        } finally {
            unsubscribe();
        }
    }

    public void subscribe() {
        connect();
        setBlocking(false);
        deleteResponses();
        log.debug("Monitoring for messages with topic '{}'", getTopic());
        try {
            getClient().subscribe(getTopic(), getQos());
            setSubscribed(true);
        } catch(MqttException me) {
            log.error("Could not subscribe to topic '{}': {}", getTopic(), me.getMessage());
            setSubscribed(false);
        }
    }

    public void unsubscribe() {
        if (isConnected() && isSubscribed()) {
            log.debug("Unsubscribing for topic '{}'", getTopic());
            try {
                getClient().unsubscribe(getTopic());
                setSubscribed(false);
            } catch (MqttException me) {
                log.error("Could not unsubscribe to topic '{}': {}", getTopic(), me.getMessage());
                setSubscribed(false);
            }
        } else {
            log.error("MQTT client was not previously connected or subscribed");
        }
    }

    public void send(String payload) {
        connect();
        setBlocking(true);
        MqttMessage message = new MqttMessage(payload.getBytes());
        message.setQos(getQos());
        MqttAsyncClient reusableClient = getClient();
        try {
            reusableClient.publish(getTopic(), message);
        } catch(MqttException me) {
            log.error("Could not publish to topic '{}' with message '{}': {}", getTopic(), payload, me.getMessage());
        } finally {
            disconnect();
        }
    }

    @Override
    public void connectionLost(Throwable cause) {
        log.warn("Connection lost due to {}", cause.getCause());
        reconnect();
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) {
        byte[] payload = message.getPayload();
        addResponse(new String(payload));
        if (isBlocking()) decrementCountdown();
    }

}
