package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BizPhoneStrings.*;
import static io.appium.java_client.touch.offset.PointOption.point;

public class CiscoPhoneUi extends AppiumUi {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @AndroidFindBy(accessibility = "App logo")
    private WebElement aboutIconButton;

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    private final ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            null,
            overflowButton,
            null
    );

    @AndroidFindBy(accessibility = "Cancel")
    private WebElement cancelTransferButton;

    private final ConfigUiField cancelTransferButtonField = new ConfigUiField(
            driver,
            CANCEL_TRANSFER,
            null,
            cancelTransferButton,
            null
    );

    @AndroidFindBy(id = "com.cisco.phone:id/snackbar_text")
    private WebElement exposeButtonLabel;

    @AndroidFindBy(id = "com.cisco.phone:id/snackbar_action")
    private WebElement exposeButton;

    private final ConfigUiField exposeButtonField = new ConfigUiField(
            driver,
            EXPOSE_BUTTON,
            exposeButtonLabel,
            exposeButton,
            null
    );


    @AndroidFindBy(accessibility = "Navigate up")
    private WebElement backButton;

    private final ConfigUiField backButtonField = new ConfigUiField(
            driver,
            BACK_ARROW,
            null,
            backButton,
            null
    );

    @AndroidFindBy(accessibility = "Close icon")
    private WebElement crossButton;

    private final ConfigUiField crossButtonField = new ConfigUiField(
            driver,
            CROSS_BUTTON,
            null,
            crossButton,
            null
    );

    @AndroidFindBy(accessibility = "Dialer")
    private WebElement dialpadTab;

    private final ConfigUiField dialpadTabField = new ConfigUiField(
            driver,
            DIALPAD_TAB,
            null,
            dialpadTab,
            null
    );

    @AndroidFindBy(accessibility = "Dialpad entry text")
    private WebElement dialpadEditText;

    private final ConfigUiField dialpadEditTextField = new ConfigUiField(
            driver,
            DIALPAD_EDIT_TEXT,
            null,
            dialpadEditText,
            null
    );

    @AndroidFindBy(id = "com.cisco.phone:id/dialer_back")
    private WebElement dialpadBackButton;

    private final ConfigUiField dialpadBackButtonField = new ConfigUiField(
            driver,
            DIALPAD_BACK_BUTTON,
            null,
            dialpadBackButton,
            null
    );

    @AndroidFindBy(accessibility = "Favorites")
    private WebElement favoritesTab;

    private final ConfigUiField favoritesTabField = new ConfigUiField(
            driver,
            FAVORITES_TAB,
            null,
            favoritesTab,
            null
    );

    @AndroidFindBy(accessibility = "Recent")
    private WebElement callLogsTab;

    private final ConfigUiField callLogsTabField = new ConfigUiField(
            driver,
            CALL_LOGS_TAB,
            null,
            callLogsTab,
            null
    );

    @AndroidFindBy(accessibility = "Recents")
    private WebElement recentsTab;

    private final ConfigUiField recentsTabField = new ConfigUiField(
            driver,
            RECENTS_TAB,
            null,
            recentsTab,
            null
    );

    @AndroidFindBy(accessibility = "Missed")
    private WebElement missedTab;

    private final ConfigUiField missedTabField = new ConfigUiField(
            driver,
            MISSED_TAB,
            null,
            missedTab,
            null
    );

    @AndroidFindBy(accessibility = "Contacts")
    private WebElement contactsTab;

    private final ConfigUiField contactsTabField = new ConfigUiField(
            driver,
            CONTACTS_TAB,
            null,
            contactsTab,
            null
    );

    @AndroidFindBy(accessibility = "Voicemail")
    private WebElement voicemailTab;

    private final ConfigUiField voicemailTabField = new ConfigUiField(
            driver,
            VOICEMAIL_TAB,
            null,
            voicemailTab,
            null
    );

    @AndroidFindBy(accessibility = "Reg 1 ringtone title")
    private WebElement ringtoneLabel1;

    @AndroidFindBy(accessibility = "Reg 1 ringtone summary")
    private WebElement ringtoneValue1;

    private final ConfigUiField ringtoneField1 = new ConfigUiField(
            driver,
            RINGTONE_REG_1,
            ringtoneLabel1,
            ringtoneLabel1,
            ringtoneValue1
    );

    @AndroidFindBy(accessibility = "Reg 2 ringtone title")
    private WebElement ringtoneLabel2;

    @AndroidFindBy(accessibility = "Reg 2 ringtone summary")
    private WebElement ringtoneValue2;

    private final ConfigUiField ringtoneField2 = new ConfigUiField(
            driver,
            RINGTONE_REG_2,
            ringtoneLabel2,
            ringtoneLabel2,
            ringtoneValue2
    );

    @AndroidFindBy(accessibility = "Hearing aid compatibility title")
    private WebElement hacLabel;

    @AndroidFindBy(accessibility = "Hearing aid compatibility switch")
    private WebElement hacControl;

    @AndroidFindBy(accessibility = "Hearing aid compatibility summary")
    private WebElement hacValue;

    private final ConfigUiField hacField = new ConfigUiField(
            driver,
            HAC,
            hacLabel,
            hacControl,
            hacValue
    );

    @AndroidFindBy(accessibility = "Automatic noise cancellation title")
    private WebElement ancLabel;

    @AndroidFindBy(accessibility = "Automatic noise cancellation switch")
    private WebElement ancControl;

    @AndroidFindBy(accessibility = "Automatic noise cancellation summary")
    private WebElement ancValue;

    private final ConfigUiField ancField = new ConfigUiField(
            driver,
            ANC,
            ancLabel,
            ancControl,
            ancValue
    );

    @AndroidFindBy(accessibility = "Automatically answer calls title")
    private WebElement enableAutoAnswerLabel;

    @AndroidFindBy(accessibility = "Automatically answer calls switch")
    private WebElement enableAutoAnswerControl;

    @AndroidFindBy(accessibility = "Automatically answer calls summary")
    private WebElement enableAutoAnswerValue;

    private final ConfigUiField enableAutoAnswerField = new ConfigUiField(
            driver,
            AUTO_ANSWER,
            enableAutoAnswerLabel,
            enableAutoAnswerControl,
            enableAutoAnswerValue
    );

    @AndroidFindBy(accessibility = "Vibrate before ring title")
    private WebElement vibrateBeforeRingLabel;

    @AndroidFindBy(accessibility = "Vibrate before ring switch")
    private WebElement vibrateBeforeRingControl;

    @AndroidFindBy(accessibility = "Vibrate before ring summary")
    private WebElement vibrateBeforeRingValue;

    private final ConfigUiField vibrateBeforeRingField = new ConfigUiField(
            driver,
            VIBRATE_BEFORE_RING,
            vibrateBeforeRingLabel,
            vibrateBeforeRingControl,
            vibrateBeforeRingValue
    );

    @AndroidFindBy(accessibility = "Fade in ring title")
    private WebElement fadeInRingLabel;

    @AndroidFindBy(accessibility = "Fade in ring switch")
    private WebElement fadeInRingControl;

    @AndroidFindBy(accessibility = "Fade in ring summary")
    private WebElement fadeInRingValue;

    private final ConfigUiField fadeInRingField = new ConfigUiField(
            driver,
            FADE_IN_RING,
            fadeInRingLabel,
            fadeInRingControl,
            fadeInRingValue
    );

    @AndroidFindBy(accessibility = "Enable autodial title")
    private WebElement autodialLabel;

    @AndroidFindBy(accessibility = "Enable autodial switch")
    private WebElement autodialControl;

    @AndroidFindBy(accessibility = "Enable autodial summary")
    private WebElement autodialValue;

    private final ConfigUiField autodialField = new ConfigUiField(
            driver,
            AUTO_DIAL,
            autodialLabel,
            autodialControl,
            autodialValue
    );

    @AndroidFindBy(accessibility = "Dialpad as default tab title")
    private WebElement dialpadDefaultTabLabel;

    @AndroidFindBy(accessibility = "Dialpad as default tab switch")
    private WebElement dialpadDefaultTabControl;

    @AndroidFindBy(accessibility = "Dialpad as default tab summary")
    private WebElement dialpadDefaultTabValue;

    private final ConfigUiField dialpadDefaultTabField = new ConfigUiField(
            driver,
            DIALPAD_AS_DEFAULT_TAB,
            dialpadDefaultTabLabel,
            dialpadDefaultTabControl,
            dialpadDefaultTabValue
    );

    @AndroidFindBy(accessibility = "Enable SIP title")
    private WebElement sipEnabledLabel;

    @AndroidFindBy(accessibility = "Enable SIP switch")
    private WebElement sipEnabledControl;

    @AndroidFindBy(accessibility = "Enable SIP summary")
    private WebElement sipEnabledValue;

    private final ConfigUiField sipEnabledField = new ConfigUiField(
            driver,
            ENABLE_SIP,
            sipEnabledLabel,
            sipEnabledControl,
            sipEnabledValue
    );

    @AndroidFindBy(accessibility = "Registration 1 title")
    private WebElement registration1Label;

    @AndroidFindBy(accessibility = "Registration 1 summary")
    private WebElement registration1Value;

    private final ConfigUiField registration1Field = new ConfigUiField(
            driver,
            REGISTRATION_1,
            registration1Label,
            registration1Label,
            registration1Value
    );

    @AndroidFindBy(accessibility = "SIP server title")
    private WebElement sipServerLabel;

    @AndroidFindBy(accessibility = "SIP server summary")
    private WebElement sipServerValue;

    private final ConfigUiField sipServerField = new ConfigUiField(
            driver,
            SIP_SERVER,
            sipServerLabel,
            sipServerLabel,
            sipServerValue
    );

    @AndroidFindBy(accessibility = "SIP server port title")
    private WebElement sipPortLabel;

    @AndroidFindBy(accessibility = "SIP server port summary")
    private WebElement sipPortValue;

    private final ConfigUiField sipPortField = new ConfigUiField(
            driver,
            SIP_SERVER_PORT,
            sipPortLabel,
            sipPortLabel,
            sipPortValue
    );

    @AndroidFindBy(accessibility = "Transport title")
    private WebElement transportLabel;

    @AndroidFindBy(accessibility = "Transport summary")
    private WebElement transportValue;

    private final ConfigUiField transportField = new ConfigUiField(
            driver,
            TRANSPORT,
            transportLabel,
            transportLabel,
            transportValue
    );

    @AndroidFindBy(accessibility = "SRTP enable title")
    private WebElement srtpLabel;

    @AndroidFindBy(accessibility = "SRTP enable switch")
    private WebElement srtpControl;

    @AndroidFindBy(accessibility = "SRTP enable summary")
    private WebElement srtpValue;

    private final ConfigUiField srtpField = new ConfigUiField(
            driver,
            SRTP,
            srtpLabel,
            srtpControl,
            srtpValue
    );

    @AndroidFindBy(accessibility = "Extension number title")
    private WebElement extensionNumberLabel;

    @AndroidFindBy(accessibility = "Extension number summary")
    private WebElement extensionNumberValue;

    private final ConfigUiField extensionNumberField = new ConfigUiField(
            driver,
            EXTENSION_NUMBER,
            extensionNumberLabel,
            extensionNumberLabel,
            extensionNumberValue
    );

    @AndroidFindBy(accessibility = "Username title")
    private WebElement usernameLabel;

    @AndroidFindBy(accessibility = "Username summary")
    private WebElement usernameValue;

    private final ConfigUiField usernameField = new ConfigUiField(
            driver,
            USERNAME,
            usernameLabel,
            usernameLabel,
            usernameValue
    );

    @AndroidFindBy(accessibility = "Password title")
    private WebElement passwordLabel;

    @AndroidFindBy(accessibility = "Password summary")
    private WebElement passwordValue;

    private final ConfigUiField passwordField = new ConfigUiField(
            driver,
            PASSWORD,
            passwordLabel,
            passwordLabel,
            passwordValue
    );

    @AndroidFindBy(accessibility = "Voicemail retrieval address title")
    private WebElement voicemailLabel;

    @AndroidFindBy(accessibility = "Voicemail retrieval address summary")
    private WebElement voicemailValue;

    private final ConfigUiField voicemailField = new ConfigUiField(
            driver,
            VOICEMAIL_ADDRESS,
            voicemailLabel,
            voicemailLabel,
            voicemailValue
    );

    @AndroidFindBy(accessibility = "Call server features title")
    private WebElement callServerFeaturesLabel;

    @AndroidFindBy(accessibility = "Call server features summary")
    private WebElement callServerFeaturesValue;

    private final ConfigUiField callServerFeaturesField = new ConfigUiField(
            driver,
            CALL_SERVER_FEATURES,
            callServerFeaturesLabel,
            callServerFeaturesLabel,
            callServerFeaturesValue
    );

    @AndroidFindBy(accessibility = "Allow call forwarding title")
    private WebElement callForwardingLabel;

    @AndroidFindBy(accessibility = "Allow call forwarding switch")
    private WebElement callForwardingControl;

    @AndroidFindBy(accessibility = "Allow call forwarding summary")
    private WebElement callForwardingValue;

    private final ConfigUiField callForwardingField = new ConfigUiField(
            driver,
            CALL_FORWARDING,
            callForwardingLabel,
            callForwardingControl,
            callForwardingValue
    );

    @AndroidFindBy(accessibility = "Use vendor protocol if licensed title")
    private WebElement vendorProtocolLabel;

    @AndroidFindBy(accessibility = "Use vendor protocol if licensed switch")
    private WebElement vendorProtocolControl;

    @AndroidFindBy(accessibility = "Use vendor protocol if licensed summary")
    private WebElement vendorProtocolValue;

    private final ConfigUiField vendorProtocolField = new ConfigUiField(
            driver,
            VENDOR_PROTOCOL,
            vendorProtocolLabel,
            vendorProtocolControl,
            vendorProtocolValue
    );

    @AndroidFindBy(accessibility = "Use SIP standard hold signaling title")
    private WebElement useSipStandardHoldSignalingLabel;

    @AndroidFindBy(accessibility = "Use SIP standard hold signaling switch")
    private WebElement useSipStandardHoldSignalingControl;

    @AndroidFindBy(accessibility = "Use SIP standard hold signaling summary")
    private WebElement useSipStandardHoldSignalingValue;

    private final ConfigUiField useSipStandardHoldSignalingField = new ConfigUiField(
            driver,
            SIP_STANDARD_HOLD_SIGNALING,
            useSipStandardHoldSignalingLabel,
            useSipStandardHoldSignalingControl,
            useSipStandardHoldSignalingValue
    );

    @AndroidFindBy(accessibility = "Force subscription to message waiting notifications title")
    private WebElement forceSubscriptionLabel;

    @AndroidFindBy(accessibility = "Force subscription to message waiting notifications switch")
    private WebElement forceSubscriptionControl;

    @AndroidFindBy(accessibility = "Force subscription to message waiting notifications summary")
    private WebElement forceSubscriptionValue;

    private final ConfigUiField forceSubscriptionField = new ConfigUiField(
            driver,
            FORCE_SUBSCRIPTION,
            forceSubscriptionLabel,
            forceSubscriptionControl,
            forceSubscriptionValue
    );

    @AndroidFindBy(accessibility = "Allow contact header updates title")
    private WebElement contactHeaderUpdatesLabel;

    @AndroidFindBy(accessibility = "Allow contact header updates switch")
    private WebElement contactHeaderUpdatesControl;

    @AndroidFindBy(accessibility = "Allow contact header updates summary")
    private WebElement contactHeaderUpdatesValue;

    private final ConfigUiField contactHeaderUpdatesField = new ConfigUiField(
            driver,
            ALLOW_CONTACT_HEADER_UPDATES,
            contactHeaderUpdatesLabel,
            contactHeaderUpdatesControl,
            contactHeaderUpdatesValue
    );

    @AndroidFindBy(accessibility = "Specify new TCP port in contact header title")
    private WebElement sipUseNewTcpPortLabel;

    @AndroidFindBy(accessibility = "Specify new TCP port in contact header switch")
    private WebElement sipUseNewTcpPortControl;

    @AndroidFindBy(accessibility = "Specify new TCP port in contact header summary")
    private WebElement sipUseNewTcpPortValue;

    private final ConfigUiField sipUseNewTcpPortField = new ConfigUiField(
            driver,
            NEW_TCP_PORT,
            sipUseNewTcpPortLabel,
            sipUseNewTcpPortControl,
            sipUseNewTcpPortValue
    );

    @AndroidFindBy(accessibility = "Disable call waiting title")
    private WebElement disableCallWaitingLabel;

    @AndroidFindBy(accessibility = "Disable call waiting switch")
    private WebElement disableCallWaitingControl;

    @AndroidFindBy(accessibility = "Disable call waiting summary")
    private WebElement disableCallWaitingValue;

    private final ConfigUiField disableCallWaitingField = new ConfigUiField(
            driver,
            CALL_WAITING,
            disableCallWaitingLabel,
            disableCallWaitingControl,
            disableCallWaitingValue
    );


    @AndroidFindBy(accessibility = "Allow video calls title")
    private WebElement allowVideoCallsLabel;

    @AndroidFindBy(accessibility = "Allow video calls switch")
    private WebElement allowVideoCallsControl;

    @AndroidFindBy(accessibility = "Allow video calls summary")
    private WebElement allowVideoCallsValue;

    private final ConfigUiField allowVideoCallsField = new ConfigUiField(
            driver,
            ALLOW_VIDEO_CALLS,
            allowVideoCallsLabel,
            allowVideoCallsControl,
            allowVideoCallsValue
    );

    @AndroidFindBy(accessibility = "Send video SDP offer title")
    private WebElement offerVideoLabel;

    @AndroidFindBy(accessibility = "Send video SDP offer switch")
    private WebElement offerVideoControl;

    @AndroidFindBy(accessibility = "Send video SDP offer summary")
    private WebElement offerVideoValue;

    private final ConfigUiField offerVideoField = new ConfigUiField(
            driver,
            OFFER_VIDEO,
            offerVideoLabel,
            offerVideoControl,
            offerVideoValue
    );

    @AndroidFindBy(accessibility = "Send video SDP answer title")
    private WebElement answerVideoLabel;

    @AndroidFindBy(accessibility = "Send video SDP answer switch")
    private WebElement answerVideoControl;

    @AndroidFindBy(accessibility = "Send video SDP answer summary")
    private WebElement answerVideoValue;

    private final ConfigUiField answerVideoField = new ConfigUiField(
            driver,
            ANSWER_VIDEO,
            answerVideoLabel,
            answerVideoControl,
            answerVideoValue
    );

    @AndroidFindBy(accessibility = "Registration 2 title")
    private WebElement registration2Label;

    @AndroidFindBy(accessibility = "Registration 2 summary")
    private WebElement registration2Value;

    private final ConfigUiField registration2Field = new ConfigUiField(
            driver,
            REGISTRATION_2,
            registration2Label,
            registration2Label,
            registration2Value
    );

    @AndroidFindBy(accessibility = "Common settings title")
    private WebElement commonSettingsLabel;

    @AndroidFindBy(accessibility = "Common settings summary")
    private WebElement commonSettingsValue;

    private final ConfigUiField commonSettingsField = new ConfigUiField(
            driver,
            COMMON_SETTINGS,
            commonSettingsLabel,
            commonSettingsLabel,
            commonSettingsValue
    );

    @AndroidFindBy(accessibility = "Audio DSCP title")
    private WebElement audioDscpLabel;

    @AndroidFindBy(accessibility = "Audio DSCP summary")
    private WebElement audioDscpValue;

    private final ConfigUiField audioDscpField = new ConfigUiField(
            driver,
            AUDIO_DSCP,
            audioDscpLabel,
            audioDscpLabel,
            audioDscpValue
    );

    @AndroidFindBy(accessibility = "Call control DSCP title")
    private WebElement callControlDscpLabel;

    @AndroidFindBy(accessibility = "Call control DSCP summary")
    private WebElement callControlDscpValue;

    private final ConfigUiField callControlDscpField = new ConfigUiField(
            driver,
            CALL_CONTROL_DSCP,
            callControlDscpLabel,
            callControlDscpLabel,
            callControlDscpValue
    );

    @AndroidFindBy(accessibility = "G.711u codec priority title")
    private WebElement g711uPriorityLabel;

    @AndroidFindBy(accessibility = "G.711u codec priority summary")
    private WebElement g711uPriorityValue;

    private final ConfigUiField g711uPriorityField = new ConfigUiField(
            driver,
            CODEC_G_711U_PRIORITY,
            g711uPriorityLabel,
            g711uPriorityLabel,
            g711uPriorityValue
    );

    @AndroidFindBy(accessibility = "G.711a codec priority title")
    private WebElement g711aPriorityLabel;

    @AndroidFindBy(accessibility = "G.711a codec priority summary")
    private WebElement g711aPriorityValue;

    private final ConfigUiField g711aPriorityField = new ConfigUiField(
            driver,
            CODEC_G_711A_PRIORITY,
            g711aPriorityLabel,
            g711aPriorityLabel,
            g711aPriorityValue
    );

    @AndroidFindBy(accessibility = "G.722 codec priority title")
    private WebElement g722PriorityLabel;

    @AndroidFindBy(accessibility = "G.722 codec priority summary")
    private WebElement g722PriorityValue;

    private final ConfigUiField g722PriorityField = new ConfigUiField(
            driver,
            CODEC_G_722_PRIORITY,
            g722PriorityLabel,
            g722PriorityLabel,
            g722PriorityValue
    );

    @AndroidFindBy(accessibility = "G.729A codec priority title")
    private WebElement g729aPriorityLabel;

    @AndroidFindBy(accessibility = "G.729A codec priority summary")
    private WebElement g729aPriorityValue;

    private final ConfigUiField g729aPriorityField = new ConfigUiField(
            driver,
            CODEC_G_729A_PRIORITY,
            g729aPriorityLabel,
            g729aPriorityLabel,
            g729aPriorityValue
    );

    @AndroidFindBy(accessibility = "Opus codec priority title")
    private WebElement opusPriorityLabel;

    @AndroidFindBy(accessibility = "Opus codec priority summary")
    private WebElement opusPriorityValue;

    private final ConfigUiField opusPriorityField = new ConfigUiField(
            driver,
            OPUS_PRIORITY,
            opusPriorityLabel,
            opusPriorityLabel,
            opusPriorityValue
    );

    @AndroidFindBy(accessibility = "DTMF relay payload type title")
    private WebElement dtmfPayloadTypeLabel;

    @AndroidFindBy(accessibility = "DTMF relay payload type summary")
    private WebElement dtmfPayloadTypeValue;

    private final ConfigUiField dtmfPayloadTypeField = new ConfigUiField(
            driver,
            DTMF_PAYLOAD_TYPE,
            dtmfPayloadTypeLabel,
            dtmfPayloadTypeLabel,
            dtmfPayloadTypeValue
    );

    @AndroidFindBy(accessibility = "Force in-band DTMF tones title")
    private WebElement dtmfToneLabel;

    @AndroidFindBy(accessibility = "Force in-band DTMF tones switch")
    private WebElement dtmfToneControl;

    @AndroidFindBy(accessibility = "Force in-band DTMF tones summary")
    private WebElement dtmfToneValue;

    private final ConfigUiField dtmfToneField = new ConfigUiField(
            driver,
            DTMF_PAYLOAD_TYPE,
            dtmfToneLabel,
            dtmfToneControl,
            dtmfToneValue
    );

    @AndroidFindBy(accessibility = "Override automatic switch from UDP to TCP title")
    private WebElement switchFromUdpToTcpLabel;

    @AndroidFindBy(accessibility = "Override automatic switch from UDP to TCP switch")
    private WebElement switchFromUdpToTcpControl;

    @AndroidFindBy(accessibility = "Override automatic switch from UDP to TCP summary")
    private WebElement switchFromUdpToTcpValue;

    private final ConfigUiField switchFromUdpToTcpField = new ConfigUiField(
            driver,
            OVERRIDE_TCP_SWITCH,
            switchFromUdpToTcpLabel,
            switchFromUdpToTcpControl,
            switchFromUdpToTcpValue
    );

    @AndroidFindBy(accessibility = "LDAP settings title")
    private WebElement ldapLabel;

    @AndroidFindBy(accessibility = "LDAP settings summary")
    private WebElement ldapValue;

    private final ConfigUiField ldapField = new ConfigUiField(
            driver,
            LDAP_SETTINGS,
            ldapLabel,
            ldapLabel,
            ldapValue
    );

    @AndroidFindBy(accessibility = "Server address title")
    private WebElement serverAddressLabel;

    @AndroidFindBy(accessibility = "Server address summary")
    private WebElement serverAddressValue;

    private final ConfigUiField serverAddressField = new ConfigUiField(
            driver,
            LDAP_SERVER_ADDRESS,
            serverAddressLabel,
            serverAddressLabel,
            serverAddressValue
    );

    @AndroidFindBy(accessibility = "Server port title")
    private WebElement serverPortLabel;

    @AndroidFindBy(accessibility = "Server port summary")
    private WebElement serverPortValue;

    private final ConfigUiField serverPortField = new ConfigUiField(
            driver,
            LDAP_SERVER_PORT,
            serverPortLabel,
            serverPortLabel,
            serverPortValue
    );

    @AndroidFindBy(accessibility = "Communication security type title")
    private WebElement communicationSecurityTypeLabel;

    @AndroidFindBy(accessibility = "Communication security type summary")
    private WebElement communicationSecurityTypeValue;

    private final ConfigUiField communicationSecurityTypeField = new ConfigUiField(
            driver,
            LDAP_SECURITY_TYPE,
            communicationSecurityTypeLabel,
            communicationSecurityTypeLabel,
            communicationSecurityTypeValue
    );

    @AndroidFindBy(accessibility = "Bind DN title")
    private WebElement bindDnLabel;

    @AndroidFindBy(accessibility = "Bind DN summary")
    private WebElement bindDnValue;

    private final ConfigUiField bindDnField = new ConfigUiField(
            driver,
            LDAP_BIND_DN,
            bindDnLabel,
            bindDnLabel,
            bindDnValue
    );

    @AndroidFindBy(accessibility = "Bind PW title")
    private WebElement bindPwLabel;

    @AndroidFindBy(accessibility = "Bind PW summary")
    private WebElement bindPwValue;

    private final ConfigUiField bindPwField = new ConfigUiField(
            driver,
            LDAP_BIND_PASSWORD,
            bindPwLabel,
            bindPwLabel,
            bindPwValue
    );

    @AndroidFindBy(accessibility = "Base DN title")
    private WebElement baseDnLabel;

    @AndroidFindBy(accessibility = "Base DN summary")
    private WebElement baseDnValue;

    private final ConfigUiField baseDnField = new ConfigUiField(
            driver,
            LDAP_BASE_DN,
            baseDnLabel,
            baseDnLabel,
            baseDnValue
    );

    @AndroidFindBy(accessibility = "Primary email attribute title")
    private WebElement primaryEmailLabel;

    @AndroidFindBy(accessibility = "Primary email attribute summary")
    private WebElement primaryEmailValue;

    private final ConfigUiField primaryEmailField = new ConfigUiField(
            driver,
            LDAP_PRIMARY_EMAIL,
            primaryEmailLabel,
            primaryEmailLabel,
            primaryEmailValue
    );

    @AndroidFindBy(accessibility = "Alternate email attribute title")
    private WebElement alternateEmailLabel;

    @AndroidFindBy(accessibility = "Alternate email attribute summary")
    private WebElement alternateEmailValue;

    private final ConfigUiField alternateEmailField = new ConfigUiField(
            driver,
            LDAP_ALTERNATE_EMAIL,
            alternateEmailLabel,
            alternateEmailLabel,
            alternateEmailValue
    );


    @AndroidFindBy(accessibility = "Emergency contact title")
    private WebElement emergencyContactLabel;

    @AndroidFindBy(accessibility = "Emergency contact summary")
    private WebElement emergencyContactValue;

    private final ConfigUiField emergencyContactField = new ConfigUiField(
            driver,
            EMERGENCY_CONTACT,
            emergencyContactLabel,
            emergencyContactLabel,
            emergencyContactValue
    );

    @AndroidFindBy(accessibility = "Emergency contact 1 title")
    private WebElement emergencyContact1Label;

    @AndroidFindBy(accessibility = "Emergency contact 1 summary")
    private WebElement emergencyContact1Value;

    private final ConfigUiField emergencyContact1Field = new ConfigUiField(
            driver,
            EMERGENCY_CONTACT_1,
            emergencyContact1Label,
            emergencyContact1Label,
            emergencyContact1Value
    );

    @AndroidFindBy(accessibility = "Contact name field")
    private WebElement emergencyContactName;

    private final ConfigUiField emergencyContactNameField = new ConfigUiField(
            driver,
            EMERGENCY_CONTACT_NAME,
            null,
            emergencyContactName,
            null
    );

    @AndroidFindBy(accessibility = "Contact number field")
    private WebElement emergencyContactNumber;

    private final ConfigUiField emergencyContactNumberField = new ConfigUiField(
            driver,
            EMERGENCY_CONTACT_NUMBER,
            null,
            emergencyContactNumber,
            null
    );

    @AndroidFindBy(accessibility = "Emergency contact 2 title")
    private WebElement emergencyContact2Label;

    @AndroidFindBy(accessibility = "Emergency contact 2 summary")
    private WebElement emergencyContact2Value;

    private final ConfigUiField emergencyContact2Field = new ConfigUiField(
            driver,
            EMERGENCY_CONTACT_2,
            emergencyContact2Label,
            emergencyContact2Label,
            emergencyContact2Value
    );

    @AndroidFindBy(accessibility = "Emergency contact 3 title")
    private WebElement emergencyContact3Label;

    @AndroidFindBy(accessibility = "Emergency contact 3 summary")
    private WebElement emergencyContact3Value;

    private final ConfigUiField emergencyContact3Field = new ConfigUiField(
            driver,
            EMERGENCY_CONTACT_3,
            emergencyContact3Label,
            emergencyContact3Label,
            emergencyContact3Value
    );

    @AndroidFindBy(accessibility = "Emergency contact 4 title")
    private WebElement emergencyContact4Label;

    @AndroidFindBy(accessibility = "Emergency contact 4 summary")
    private WebElement emergencyContact4Value;

    private final ConfigUiField emergencyContact4Field = new ConfigUiField(
            driver,
            EMERGENCY_CONTACT_4,
            emergencyContact4Label,
            emergencyContact4Label,
            emergencyContact4Value
    );

    @AndroidFindBy(accessibility = "Emergency contact 5 title")
    private WebElement emergencyContact5Label;

    @AndroidFindBy(accessibility = "Emergency contact 5 summary")
    private WebElement emergencyContact5Value;

    private final ConfigUiField emergencyContact5Field = new ConfigUiField(
            driver,
            EMERGENCY_CONTACT_5,
            emergencyContact5Label,
            emergencyContact5Label,
            emergencyContact5Value
    );

    @AndroidFindBy(accessibility = "Allow iDivert title")
    private WebElement allowiDivertLabel;

    @AndroidFindBy(accessibility = "Allow iDivert switch")
    private WebElement allowiDivertControl;

    @AndroidFindBy(accessibility = "Allow iDivert summary")
    private WebElement allowiDivertValue;

    private final ConfigUiField allowiDivertField = new ConfigUiField(
            driver,
            CISCO_I_DIVERT,
            allowiDivertLabel,
            allowiDivertControl,
            allowiDivertValue
    );

    @AndroidFindBy(accessibility = "Allow call forwarding title")
    private WebElement callForwardingCallServerFeatureLabel;

    @AndroidFindBy(accessibility = "Allow call forwarding switch")
    private WebElement callForwardingCallServerFeatureControl;

    @AndroidFindBy(accessibility = "Allow call forwarding summary")
    private WebElement callForwardingCallServerFeatureValue;

    private final ConfigUiField callForwardingCallServerFeatureField = new ConfigUiField(
            driver,
            CISCO_CALL_FORWARDING,
            callForwardingCallServerFeatureLabel,
            callForwardingCallServerFeatureControl,
            callForwardingCallServerFeatureValue
    );

    @AndroidFindBy(accessibility = "Allow call park title")
    private WebElement allowCallParkLabel;

    @AndroidFindBy(accessibility = "Allow call park switch")
    private WebElement allowCallParkControl;

    @AndroidFindBy(accessibility = "Allow call park summary")
    private WebElement allowCallParkValue;

    private final ConfigUiField allowCallParkField = new ConfigUiField(
            driver,
            CISCO_CALL_PARK,
            allowCallParkLabel,
            allowCallParkControl,
            allowCallParkValue
    );

    @AndroidFindBy(accessibility = "Allow hunt group login/logout title")
    private WebElement huntGroupLabel;

    @AndroidFindBy(accessibility = "Allow hunt group login/logout switch")
    private WebElement huntGroupControl;

    @AndroidFindBy(accessibility = "Allow hunt group login/logout summary")
    private WebElement huntGroupValue;

    private final ConfigUiField huntGroupField = new ConfigUiField(
            driver,
            CISCO_HUNT_GROUP_LOGON,
            huntGroupLabel,
            huntGroupControl,
            huntGroupValue
    );

    @AndroidFindBy(accessibility = "Cisco contact search title")
    private WebElement ciscoContactSearchLabel;

    @AndroidFindBy(accessibility = "Cisco contact search switch")
    private WebElement ciscoContactSearchControl;

    @AndroidFindBy(accessibility = "Cisco contact search summary")
    private WebElement ciscoContactSearchValue;

    private final ConfigUiField ciscoContactSearchField = new ConfigUiField(
            driver,
            CISCO_CONTACT_SEARCH,
            ciscoContactSearchLabel,
            ciscoContactSearchControl,
            ciscoContactSearchValue
    );

    @AndroidFindBy(accessibility = "Advanced contact search enable title")
    private WebElement ciscoAdvancedContactSearchLabel;

    @AndroidFindBy(accessibility = "Advanced contact search enable switch")
    private WebElement ciscoAdvancedContactSearchControl;

    @AndroidFindBy(accessibility = "Advanced contact search enable summary")
    private WebElement ciscoAdvancedContactSearchValue;

    private final ConfigUiField ciscoAdvancedContactSearchField = new ConfigUiField(
            driver,
            CISCO_ADVANCED_CONTACT_SEARCH,
            ciscoAdvancedContactSearchLabel,
            ciscoAdvancedContactSearchControl,
            ciscoAdvancedContactSearchValue
    );

    @AndroidFindBy(accessibility = "Cisco server address title")
    private WebElement ciscoContactSearchServerAddressLabel;

    @AndroidFindBy(accessibility = "Cisco server address summary")
    private WebElement ciscoContactSearchServerAddressValue;

    private final ConfigUiField ciscoContactSearchServerAddressField = new ConfigUiField(
            driver,
            CISCO_CONTACT_SEARCH_SERVER_ADDRESS,
            ciscoContactSearchServerAddressLabel,
            ciscoContactSearchServerAddressLabel,
            ciscoContactSearchServerAddressValue
    );

    @AndroidFindBy(accessibility = "Advanced cisco contact search username title")
    private WebElement ciscoContactSearchUsernameLabel;

    @AndroidFindBy(accessibility = "Advanced cisco contact search username summary")
    private WebElement ciscoContactSearchUsernameValue;

    private final ConfigUiField ciscoContactSearchUsernameField = new ConfigUiField(
            driver,
            CISCO_ADVANCED_CONTACT_SEARCH_SERVER_USERNAME,
            ciscoContactSearchUsernameLabel,
            ciscoContactSearchUsernameLabel,
            ciscoContactSearchUsernameValue
    );

    @AndroidFindBy(accessibility = "Advanced cisco contact search password title")
    private WebElement ciscoContactSearchPasswordLabel;

    @AndroidFindBy(accessibility = "Advanced cisco contact search password summary")
    private WebElement ciscoContactSearchPasswordValue;

    private final ConfigUiField ciscoContactSearchPasswordField = new ConfigUiField(
            driver,
            CISCO_ADVANCED_CONTACT_SEARCH_SERVER_PASSWORD,
            ciscoContactSearchPasswordLabel,
            ciscoContactSearchPasswordLabel,
            ciscoContactSearchPasswordValue
    );

    @AndroidFindBy(accessibility = "Search field title")
    private WebElement ciscoContactSearchFieldLabel;

    @AndroidFindBy(accessibility = "Search field summary")
    private WebElement ciscoContactSearchFieldValue;

    private final ConfigUiField ciscoContactSearchFieldField = new ConfigUiField(
            driver,
            CISCO_CONTACT_SEARCH_FIELD,
            ciscoContactSearchFieldLabel,
            ciscoContactSearchFieldLabel,
            ciscoContactSearchFieldValue
    );

    @AndroidFindBy(accessibility = "Search value title")
    private WebElement ciscoContactSearchValueLabel;

    @AndroidFindBy(accessibility = "Search value summary")
    private WebElement ciscoContactSearchValueValue;

    private final ConfigUiField ciscoContactSearchValueField = new ConfigUiField(
            driver,
            CISCO_CONTACT_SEARCH_VALUE,
            ciscoContactSearchValueLabel,
            ciscoContactSearchValueLabel,
            ciscoContactSearchValueValue
    );

    @AndroidFindBy(accessibility = "Voicemail enable title")
    private WebElement ciscoVoicemailEnableLabel;

    @AndroidFindBy(accessibility = "Voicemail enable switch")
    private WebElement ciscoVoicemailEnableControl;

    @AndroidFindBy(accessibility = "Voicemail enable summary")
    private WebElement ciscoVoicemailEnableValue;

    private final ConfigUiField ciscoVoicemailEnableField = new ConfigUiField(
            driver,
            CISCO_VOICEMAIL,
            ciscoVoicemailEnableLabel,
            ciscoVoicemailEnableControl,
            ciscoVoicemailEnableValue
    );

    @AndroidFindBy(accessibility = "Cisco Unity server address (Primary) title")
    private WebElement ciscoUnityServerAddressPrimaryLabel;

    @AndroidFindBy(accessibility = "Cisco Unity server address (Primary) summary")
    private WebElement ciscoUnityServerAddressPrimaryValue;

    private final ConfigUiField ciscoUnityServerAddressPrimaryField = new ConfigUiField(
            driver,
            CISCO_UNITY_SERVER_ADDRESS_PRIMARY,
            ciscoUnityServerAddressPrimaryLabel,
            ciscoUnityServerAddressPrimaryLabel,
            ciscoUnityServerAddressPrimaryValue
    );

    @AndroidFindBy(accessibility = "Cisco Unity server address (Backup) title")
    private WebElement ciscoUnityServerAddressBakupLabel;

    @AndroidFindBy(accessibility = "Cisco Unity server address (Backup) summary")
    private WebElement ciscoUnityServerAddressBakupValue;

    private final ConfigUiField ciscoUnityServerAddressBackupField = new ConfigUiField(
            driver,
            CISCO_UNITY_SERVER_ADDRESS_BACKUP,
            ciscoUnityServerAddressBakupLabel,
            ciscoUnityServerAddressBakupLabel,
            ciscoUnityServerAddressBakupValue
    );

    @AndroidFindBy(accessibility = "Visual voicemail username title")
    private WebElement ciscoVoicemailUsernameLabel;

    @AndroidFindBy(accessibility = "Visual voicemail username summary")
    private WebElement ciscoVoicemailUsernameValue;

    private final ConfigUiField ciscoVoicemailUsernameField = new ConfigUiField(
            driver,
            CISCO_VOICEMAIL_USERNAME,
            ciscoVoicemailUsernameLabel,
            ciscoVoicemailUsernameLabel,
            ciscoVoicemailUsernameValue
    );

    @AndroidFindBy(accessibility = "Visual voicemail password title")
    private WebElement ciscoVoicemailPasswordLabel;

    @AndroidFindBy(accessibility = "Visual voicemail password summary")
    private WebElement ciscoVoicemailPasswordValue;

    private final ConfigUiField ciscoVoicemailPasswordField = new ConfigUiField(
            driver,
            CISCO_VOICEMAIL_PASSWORD,
            ciscoVoicemailPasswordLabel,
            ciscoVoicemailPasswordLabel,
            ciscoVoicemailPasswordValue
    );

    @AndroidFindBy(accessibility = "Biz Phone")
    private WebElement bizPhoneAppIcon;

    private final ConfigUiField bizPhoneAppIconField = new ConfigUiField(
            driver,
            BIZ_PHONE_ICON,
            null,
            bizPhoneAppIcon,
            null
    );

    @AndroidFindBy(id = "com.cisco.phone:id/text_no_results")
    private WebElement noSearchResults;

    private final ConfigUiField noSearchResultsField = new ConfigUiField(
            driver,
            NO_SEARCH_RESULTS,
            null,
            null,
            noSearchResults
    );

    @AndroidFindBy(accessibility = "Contact name index 0 title")
    private WebElement entryAtIndex0;

    private final ConfigUiField entryAtIndex0Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_0,
            null,
            null,
            entryAtIndex0
    );

    @AndroidFindBy(accessibility = "Contact name index 1 title")
    private WebElement entryAtIndex1;

    private final ConfigUiField entryAtIndex1Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_1,
            null,
            null,
            entryAtIndex1
    );

    @AndroidFindBy(accessibility = "Contact name index 2 title")
    private WebElement entryAtIndex2;

    private final ConfigUiField entryAtIndex2Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_2,
            null,
            null,
            entryAtIndex2
    );

    @AndroidFindBy(accessibility = "Contact name index 3 title")
    private WebElement entryAtIndex3;

    private final ConfigUiField entryAtIndex3Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_3,
            null,
            null,
            entryAtIndex3
    );

    @AndroidFindBy(accessibility = "Contact name index 4 title")
    private WebElement entryAtIndex4;

    private final ConfigUiField entryAtIndex4Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_4,
            null,
            null,
            entryAtIndex4
    );

    @AndroidFindBy(accessibility = "Contact name index 5 title")
    private WebElement entryAtIndex5;

    private final ConfigUiField entryAtIndex5Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_5,
            null,
            null,
            entryAtIndex5
    );

    @AndroidFindBy(accessibility = "Contact name index 6 title")
    private WebElement entryAtIndex6;

    private final ConfigUiField entryAtIndex6Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_6,
            null,
            null,
            entryAtIndex6
    );

    @AndroidFindBy(accessibility = "Contact name index 7 title")
    private WebElement entryAtIndex7;

    private final ConfigUiField entryAtIndex7Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_7,
            null,
            null,
            entryAtIndex7
    );

    @AndroidFindBy(accessibility = "Contact name index 8 title")
    private WebElement entryAtIndex8;

    private final ConfigUiField entryAtIndex8Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_8,
            null,
            null,
            entryAtIndex8
    );

    @AndroidFindBy(accessibility = "Contact name index 9 title")
    private WebElement entryAtIndex9;

    private final ConfigUiField entryAtIndex9Field = new ConfigUiField(
            driver,
            ENTRY_AT_INDEX_9,
            null,
            null,
            entryAtIndex9
    );

    @AndroidFindBy(accessibility = "Contact name index 0 title")
    private WebElement contactNameAtIndex0;

    private final ConfigUiField contactNameAtIndex0Field = new ConfigUiField(
            driver,
            CONTACT_NAME_AT_INDEX_0,
            null,
            null,
            contactNameAtIndex0
    );

    @AndroidFindBy(accessibility = "Contact number index 0 title")
    private WebElement contactNumberAtIndex0;

    private final ConfigUiField contactNumberAtIndex0Field = new ConfigUiField(
            driver,
            CONTACT_NUMBER_AT_INDEX_0,
            null,
            null,
            contactNumberAtIndex0
    );

    @AndroidFindBy(accessibility = "voicemail_unread_count_of_index_0")
    private WebElement voicemailMessagesCountIndex0;

    private final ConfigUiField voicemailMessagesCountAtIndex0Field = new ConfigUiField(
            driver,
            VOICEMAIL_MESSAGES_AT_INDEX_0,
            null,
            null,
            voicemailMessagesCountIndex0
    );

    @AndroidFindBy(accessibility = "Create new contact")
    private WebElement createContact;

    private final ConfigUiField createContactField = new ConfigUiField(
            driver,
            CREATE_CONTACT,
            null,
            createContact,
            null
    );

    @AndroidFindBy(accessibility = "Search icon")
    private WebElement searchContact;

    private final ConfigUiField searchContactField = new ConfigUiField(
            driver,
            SEARCH,
            null,
            searchContact,
            null
    );

    @AndroidFindBy(accessibility = "Search for contacts")
    private WebElement searchEditText;

    private final ConfigUiField searchEditTextField = new ConfigUiField(
            driver,
            SEARCH_EDIT_TEXT,
            null,
            searchEditText,
            null
    );

    @AndroidFindBy(id = "com.google.android.contacts:id/menu_save")
    private WebElement saveContact;

    private final ConfigUiField saveContactField = new ConfigUiField(
            driver,
            SAVE_CONTACT,
            null,
            saveContact,
            null
    );

    @AndroidFindBy(id = "android:id/message")
    private WebElement toast;

    private final ConfigUiField toastMessageField = new ConfigUiField(
            driver,
            TOAST_MESSAGE,
            null,
            toast,
            null
    );

    @AndroidFindBy(accessibility = "No results title")
    private WebElement noResult;

    private final ConfigUiField noResultField = new ConfigUiField(
            driver,
            NO_RESULT,
            null,
            null,
            noResult
    );

    @AndroidFindBy(id = "android:id/edit")
    private WebElement editText;

    private final ConfigUiField editTextField = new ConfigUiField(
            driver,
            EDIT_TEXT,
            null,
            editText,
            null
    );

    @AndroidFindBy(id = "android:id/button1")
    private WebElement okButton;

    private final ConfigUiField okButtonField = new ConfigUiField(
            driver,
            OK_BUTTON,
            null,
            okButton,
            null
    );

    @AndroidFindBy(id = "android:id/button3")
    private WebElement anotherCancelButton;

    private final ConfigUiField anotherCancelButtonField = new ConfigUiField(
            driver,
            ANOTHER_CANCEL_BUTTON,
            null,
            anotherCancelButton,
            null
    );

    @AndroidFindBy(id = "android:id/button2")
    private WebElement cancelButton;

    private final ConfigUiField cancelButtonField = new ConfigUiField(
            driver,
            CANCEL_BUTTON,
            null,
            cancelButton,
            null
    );

    @AndroidFindBy(id = "android:id/button1")
    private WebElement fromDeviceButton;

    private final ConfigUiField fromDeviceButtonField = new ConfigUiField(
            driver,
            FROM_DEVICE_BUTTON,
            null,
            fromDeviceButton,
            null
    );

    @AndroidFindBy(id = "android:id/button2")
    private WebElement fromServeButton;

    private final ConfigUiField fromServeButtonField = new ConfigUiField(
            driver,
            FROM_SERVER_BUTTON,
            null,
            fromServeButton,
            null
    );

    @AndroidFindBy(accessibility = "One")
    private WebElement dialNumber1;

    private final ConfigUiField dialNumber1Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_1,
            null,
            dialNumber1,
            null
    );

    @AndroidFindBy(accessibility = "Two")
    private WebElement dialNumber2;

    private final ConfigUiField dialNumber2Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_2,
            null,
            dialNumber2,
            null
    );

    @AndroidFindBy(accessibility = "Three")
    private WebElement dialNumber3;

    private final ConfigUiField dialNumber3Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_3,
            null,
            dialNumber3,
            null
    );

    @AndroidFindBy(accessibility = "Four")
    private WebElement dialNumber4;

    private final ConfigUiField dialNumber4Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_4,
            null,
            dialNumber4,
            null
    );

    @AndroidFindBy(accessibility = "Five")
    private WebElement dialNumber5;

    private final ConfigUiField dialNumber5Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_5,
            null,
            dialNumber5,
            null
    );

    @AndroidFindBy(accessibility = "Six")
    private WebElement dialNumber6;

    private final ConfigUiField dialNumber6Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_6,
            null,
            dialNumber6,
            null
    );

    @AndroidFindBy(accessibility = "Seven")
    private WebElement dialNumber7;

    private final ConfigUiField dialNumber7Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_7,
            null,
            dialNumber7,
            null
    );

    @AndroidFindBy(accessibility = "Eight")
    private WebElement dialNumber8;

    private final ConfigUiField dialNumber8Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_8,
            null,
            dialNumber8,
            null
    );

    @AndroidFindBy(accessibility = "Nine")
    private WebElement dialNumber9;

    private final ConfigUiField dialNumber9Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_9,
            null,
            dialNumber9,
            null
    );

    @AndroidFindBy(accessibility = "Zero")
    private WebElement dialNumber0;

    private final ConfigUiField dialNumber0Field = new ConfigUiField(
            driver,
            DIAL_NUMBER_0,
            null,
            dialNumber0,
            null
    );

    @AndroidFindBy(accessibility = "Star")
    private WebElement dialNumberStar;

    private final ConfigUiField dialNumberStarField = new ConfigUiField(
            driver,
            DIAL_NUMBER_STAR,
            null,
            dialNumberStar,
            null
    );

    @AndroidFindBy(accessibility = "Pound")
    private WebElement dialNumberPound;

    private final ConfigUiField dialNumberPoundField = new ConfigUiField(
            driver,
            DIAL_NUMBER_POUND,
            null,
            dialNumberPound,
            null
    );

    @AndroidFindBy(accessibility = "Start call")
    private WebElement callButton;

    private final ConfigUiField callButtonField = new ConfigUiField(
            driver,
            CALL_BUTTON,
            null,
            callButton,
            null
    );

    @AndroidFindBy(accessibility = "Start new call")
    private WebElement newCallButton;

    private final ConfigUiField newCallButtonField = new ConfigUiField(
            driver,
            NEW_CALL_BUTTON,
            null,
            newCallButton,
            null
    );

    @AndroidFindBy(accessibility = "End call enabled")
    private WebElement endCallButton;

    private final ConfigUiField endCallField = new ConfigUiField(
            driver,
            END_CALL,
            null,
            endCallButton,
            null
    );

    @AndroidFindBy(accessibility = "Hold enabled")
    private WebElement holdButton;

    private final ConfigUiField holdButtonField = new ConfigUiField(
            driver,
            HOLD_BUTTON,
            null,
            holdButton,
            null
    );

    @AndroidFindBy(accessibility = "Hold disabled")
    private WebElement resumeButton;

    private final ConfigUiField resumeButtonField = new ConfigUiField(
            driver,
            RESUME_BUTTON,
            null,
            resumeButton,
            null
    );

    @AndroidFindBy(accessibility = "More enabled")
    private WebElement moreButton;

    private final ConfigUiField moreButtonField = new ConfigUiField(
            driver,
            MORE_BUTTON,
            null,
            moreButton,
            null
    );

    @AndroidFindBy(accessibility = "Add call")
    private WebElement addCallButton;

    private final ConfigUiField addCallButtonField = new ConfigUiField(
            driver,
            ADD_CALL,
            null,
            addCallButton,
            null
    );

    @AndroidFindBy(accessibility = "Transfer to number")
    private WebElement transferToNumberButton;

    private final ConfigUiField transferToNumberButtonField = new ConfigUiField(
            driver,
            TRANSFER_TO_NUMBER_BUTTON,
            null,
            transferToNumberButton,
            null
    );

    @AndroidFindBy(accessibility = "Transfer to call")
    private WebElement transferToHeldCallButton;

    private final ConfigUiField transferToHeldCallButtonField = new ConfigUiField(
            driver,
            TRANSFER_TO_HELD_CALL_BUTTON,
            null,
            transferToHeldCallButton,
            null
    );

    @AndroidFindBy(accessibility = "Conference")
    private WebElement conferenceButton;

    private final ConfigUiField conferenceButtonField = new ConfigUiField(
            driver,
            CONFERENCE_BUTTON,
            null,
            conferenceButton,
            null
    );

    @AndroidFindBy(accessibility = "Split enabled")
    private WebElement splitButton;

    private final ConfigUiField splitButtonField = new ConfigUiField(
            driver,
            SPLIT_BUTTON,
            null,
            splitButton,
            null
    );

    @AndroidFindBy(id = "com.cisco.phone:id/single_caller_info_layout")
    private WebElement callerInfoLayout1;

    private final ConfigUiField callerInfoLayout1Field = new ConfigUiField(
            driver,
            CALLER_INFO_LAYOUT,
            null,
            callerInfoLayout1,
            null
    );

    @AndroidFindBy(accessibility = "Call id 0")
    private WebElement callToMergeWithCallerId0;

    private final ConfigUiField callToMergeWithCallerId0Field = new ConfigUiField(
            driver,
            MERGE_CALL_0,
            null,
            callToMergeWithCallerId0,
            null
    );

    @AndroidFindBy(accessibility = "Call id 1")
    private WebElement callToMergeWithCallerId1;

    private final ConfigUiField callToMergeWithCallerId1Field = new ConfigUiField(
            driver,
            MERGE_CALL_1,
            null,
            callToMergeWithCallerId1,
            null
    );

    @AndroidFindBy(accessibility = "Call id 2")
    private WebElement callToMergeWithCallerId2;

    private final ConfigUiField callToMergeWithCallerId2Field = new ConfigUiField(
            driver,
            MERGE_CALL_2,
            null,
            callToMergeWithCallerId2,
            null
    );

    @AndroidFindBy(accessibility = "Call id 3")
    private WebElement callToMergeWithCallerId3;

    private final ConfigUiField callToMergeWithCallerId3Field = new ConfigUiField(
            driver,
            MERGE_CALL_3,
            null,
            callToMergeWithCallerId3,
            null
    );

    @AndroidFindBy(accessibility = "Multi call hold icon index 0")
    private WebElement holdCover;

    private final ConfigUiField holdCoverField = new ConfigUiField(
            driver,
            HOLD_COVER,
            null,
            holdCover,
            null
    );

    @AndroidFindBy(accessibility = "Answer")
    private WebElement headsUpAnswer;

    private final ConfigUiField headsUpAnswerField = new ConfigUiField(
            driver,
            ANSWER,
            null,
            headsUpAnswer,
            null
    );

    @AndroidFindBy(accessibility = "Decline")
    private WebElement headsUpDecline;

    private final ConfigUiField headsUpDeclineField = new ConfigUiField(
            driver,
            DECLINE,
            null,
            headsUpDecline,
            null
    );

    @AndroidFindBy(id = "com.cisco.phone:id/content_title")
    private WebElement callerNameHeadsUp;

    private final ConfigUiField callerNameHeadsUpField = new ConfigUiField(
            driver,
            CALLER_NAME_HEADS_UP,
            null,
            callerNameHeadsUp,
            null
    );

    @AndroidFindBy(accessibility = "Caller name title")
    private WebElement callerNameCalledPhone;

    private final ConfigUiField callerNameCallingPhoneField = new ConfigUiField(
            driver,
            CALLER_NAME_ON_CALLING_PHONE,
            null,
            callerNameCalledPhone,
            null
    );

    @AndroidFindBy(accessibility = "Caller name title")
    private WebElement callerNameReceivedPhone;

    private final ConfigUiField callerNameReceivedPhoneField = new ConfigUiField(
            driver,
            CALLER_NAME_ON_RECEIVED_PHONE,
            null,
            callerNameReceivedPhone,
            null
    );

    @AndroidFindBy(accessibility = "Mute enabled")
    private WebElement muteCall;

    private final ConfigUiField muteCallField = new ConfigUiField(
            driver,
            MUTE,
            null,
            muteCall,
            null
    );

    @AndroidFindBy(accessibility = "Mute disabled")
    private WebElement unmuteCall;

    private final ConfigUiField unmuteCallField = new ConfigUiField(
            driver,
            UNMUTE,
            null,
            unmuteCall,
            null
    );

    @AndroidFindBy(accessibility = "Login extension enabled")
    private WebElement extensionEditText;

    private final ConfigUiField extensionEditTextField = new ConfigUiField(
            driver,
            EXTENSION_EDIT_TEXT,
            null,
            extensionEditText,
            null
    );

    @AndroidFindBy(accessibility = "Login username enabled")
    private WebElement usernameEditText;

    private final ConfigUiField usernameEditTextField = new ConfigUiField(
            driver,
            USERNAME_EDIT_TEXT,
            null,
            usernameEditText,
            null
    );

    @AndroidFindBy(accessibility = "Login password enabled")
    private WebElement passwordEditText;

    private final ConfigUiField passwordEditTextField = new ConfigUiField(
            driver,
            PASSWORD_EDIT_TEXT,
            null,
            passwordEditText,
            null
    );

    @AndroidFindBy(accessibility = "Password field")
    private WebElement loggingPasswordEditText;

    private final ConfigUiField loggingPasswordEditTextField = new ConfigUiField(
            driver,
            LOGGING_PASSWORD_EDIT_TEXT,
            null,
            loggingPasswordEditText,
            null
    );

    @AndroidFindBy(accessibility = "Login button enabled")
    private WebElement loginButton;

    private final ConfigUiField loginButtonField = new ConfigUiField(
            driver,
            LOGIN_BUTTON,
            null,
            loginButton,
            null
    );

    @AndroidFindBy(accessibility = "Checkbox use extension as username")
    private WebElement extensionUsernameCheckbox;

    private final ConfigUiField extensionUsernameCheckboxField = new ConfigUiField(
            driver,
            EXTENSION_USERNAME_CHECKBOX,
            null,
            extensionUsernameCheckbox,
            null
    );

    @AndroidFindBy(id = "com.cisco.phone:id/iv_logo")
    private WebElement bizPhoneLogo;

    private final ConfigUiField bizPhoneLogoField = new ConfigUiField(
            driver,
            BIZ_PHONE_LOGO,
            null,
            bizPhoneLogo,
            null
    );

    @AndroidFindBy(accessibility = "Extension image 1")
    private WebElement callIcon1;

    private final ConfigUiField callIcon1Field = new ConfigUiField(
            driver,
            CALL_ICON_1,
            null,
            callIcon1,
            null
    );

    @AndroidFindBy(accessibility = "Extension image 2")
    private WebElement callIcon2;

    private final ConfigUiField callIcon2Field = new ConfigUiField(
            driver,
            CALL_ICON_2,
            null,
            callIcon2,
            null
    );

    @AndroidFindBy(accessibility = "Registration line number index 1 title")
    private WebElement lineNumber1;

    private final ConfigUiField lineNumber1Field = new ConfigUiField(
            driver,
            LINE_NUMBER_1,
            null,
            lineNumber1,
            null
    );

    @AndroidFindBy(accessibility = "Registration line number index 2 title")
    private WebElement lineNumber2;

    private final ConfigUiField lineNumber2Field = new ConfigUiField(
            driver,
            LINE_NUMBER_2,
            null,
            lineNumber2,
            null
    );

    @AndroidFindBy(xpath = "//android.widget.Toast[1]")
    private WebElement popup;

    private final ConfigUiField popupField = new ConfigUiField(
            driver,
            POPUP,
            null,
            popup,
            null
    );

    @AndroidFindBy(accessibility = "Expand")
    private WebElement expandButton;

    private final ConfigUiField expandButtonField = new ConfigUiField(
            driver,
            EXPAND_BUTTON,
            null,
            expandButton,
            null
    );

    @AndroidFindBy(id = "com.cisco.phone:id/call_forwarding_label")
    private WebElement enableCallForwardingLabel;

    @AndroidFindBy(accessibility = "Enable call forwarding switch")
    private WebElement enableCallForwardingControl;

    private final ConfigUiField enableCallForwardingField = new ConfigUiField(
            driver,
            ENABLE_CALL_FORWARDING,
            enableCallForwardingLabel,
            enableCallForwardingControl,
            null
    );

    @AndroidFindBy(accessibility = "Audio path enabled")
    private WebElement audioPathButton;

    private final ConfigUiField audioPathButtonField = new ConfigUiField(
            driver,
            AUDIO_PATH,
            null,
            audioPathButton,
            null
    );

    @AndroidFindBy(id = "com.cisco.phone:id/search_mag_icon")
    private WebElement searchMagnifyIcon;

    private final ConfigUiField searchMagnifyIconField = new ConfigUiField(
            driver,
            SEARCH_MAGNIFY_ICON,
            null,
            searchMagnifyIcon,
            null
    );

    @AndroidFindBy(accessibility = "Security title")
    private WebElement clientConfigurationSettingsLabel;

    private final ConfigUiField clientConfigurationSettingsField = new ConfigUiField(
            driver,
            CLIENT_CONFIGURATION_SETTINGS,
            clientConfigurationSettingsLabel,
            clientConfigurationSettingsLabel,
            null
    );

    @AndroidFindBy(accessibility = "Clear trust list title")
    private WebElement clearTrustListLabel;

    private final ConfigUiField clearTrustListField = new ConfigUiField(
            driver,
            CLEAR_TRUST_LIST,
            clearTrustListLabel,
            clearTrustListLabel,
            null
    );

    @AndroidFindBy(accessibility = "Alternate TFTP title")
    private WebElement alternateTftpLabel;

    @AndroidFindBy(accessibility = "Alternate TFTP summary")
    private WebElement alternateTftpValue;

    @AndroidFindBy(accessibility = "Alternate TFTP switch")
    private WebElement alternateTftpSwitch;

    private final ConfigUiField alternateTftpField = new ConfigUiField(
            driver,
            ALTERNATE_TFTP,
            alternateTftpLabel,
            alternateTftpSwitch,
            alternateTftpValue
    );

    @AndroidFindBy(accessibility = "TFTP address 1 title")
    private WebElement tftpAddress1Label;

    @AndroidFindBy(accessibility = "TFTP address 1 summary")
    private WebElement tftpAddress1Value;

    private final ConfigUiField tftpAddress1Field = new ConfigUiField(
            driver,
            TFTP_ADDRESS_1,
            tftpAddress1Label,
            tftpAddress1Label,
            tftpAddress1Value
    );

    @AndroidFindBy(accessibility = "TFTP address 2 title")
    private WebElement tftpAddress2Label;

    @AndroidFindBy(accessibility = "TFTP address 2 summary")
    private WebElement tftpAddress2Value;

    private final ConfigUiField tftpAddress2Field = new ConfigUiField(
            driver,
            TFTP_ADDRESS_2,
            tftpAddress2Label,
            tftpAddress2Label,
            tftpAddress2Value
    );

    @AndroidFindBy(id = "com.cisco.phone:id/forward_edit")
    private WebElement callForwardNumber;

    @AndroidFindBy(accessibility = "Add to favourites")
    private WebElement starContact;

    @AndroidFindBy(accessibility = "Remove from favourites")
    private WebElement unstarContact;

    @AndroidFindBy(xpath = "//android.widget.Toast[1]")
    private WebElement pop;

    @AndroidFindBy(accessibility = "Accept call")
    private WebElement acceptCall;

    @AndroidFindBy(accessibility = "Decline call")
    private WebElement declineCall;

    @AndroidFindBy(accessibility = "Merge title")
    private WebElement mergeButton;

    private final ConfigUiField mergeButtonField = new ConfigUiField(
            driver,
            MERGE_BUTTON,
            null,
            mergeButton,
            null
    );

    @AndroidFindBy(accessibility = "Participants")
    private WebElement participantsButton;

    private final ConfigUiField participantsButtonField = new ConfigUiField(
            driver,
            PARTICIPANTS_BUTTON,
            null,
            participantsButton,
            null
    );
    @AndroidFindBy(accessibility = "Transfer title")
    private WebElement transferButton;

    private final ConfigUiField transferButtonField = new ConfigUiField(
            driver,
            TRANSFER,
            null,
            transferButton,
            null
    );

    @AndroidFindBy(accessibility = "Call details")
    private WebElement callDetails;

    private final ConfigUiField callDetailsField = new ConfigUiField(
            driver,
            CALL_DETAILS,
            null,
            callDetails,
            null
    );

    @AndroidFindBy(accessibility = "Caller number title")
    private WebElement callerNumber;

    private final ConfigUiField callerNumberField = new ConfigUiField(
            driver,
            CALLER_NUMBER_ON_CALL_LOG_SCREEN,
            null,
            callerNumber,
            null
    );

    @AndroidFindBy(accessibility = "Advanced debugging title")
    private WebElement advancedDebuggingLabel;

    @AndroidFindBy(accessibility = "Advanced debugging summary")
    private WebElement advancedDebuggingValue;

    private final ConfigUiField advancedDebuggingField = new ConfigUiField(
            driver,
            ADVANCED_DEBUGGING,
            advancedDebuggingLabel,
            advancedDebuggingLabel,
            advancedDebuggingValue
    );

    @AndroidFindBy(accessibility = "Advanced debugging")
    private WebElement advancedDebuggingButtonLabel;

    private final ConfigUiField advancedDebuggingButtonField = new ConfigUiField(
            driver,
            ADVANCED_DEBUGGING_BUTTON,
            null,
            advancedDebuggingButtonLabel,
            null
    );

    @AndroidFindBy(accessibility = "Device information title")
    private WebElement deviceInformationLabel;

    @AndroidFindBy(accessibility = "Device information summary")
    private WebElement deviceInformationValue;

    private final ConfigUiField deviceInformationField = new ConfigUiField(
            driver,
            DEVICE_INFORMATION,
            deviceInformationLabel,
            deviceInformationLabel,
            deviceInformationValue
    );

    @AndroidFindBy(accessibility = "Report problem title")
    private WebElement reportProblemLabel;

    @AndroidFindBy(accessibility = "Report problem summary")
    private WebElement reportProblemValue;

    private final ConfigUiField reportProblemField = new ConfigUiField(
            driver,
            REPORT_PROBLEM,
            reportProblemLabel,
            reportProblemLabel,
            reportProblemValue
    );

    @AndroidFindBy(accessibility = "Device information")
    private WebElement deviceInformationButtonLabel;

    private final ConfigUiField deviceInformationButtonField = new ConfigUiField(
            driver,
            DEVICE_INFORMATION_BUTTON,
            deviceInformationButtonLabel,
            deviceInformationButtonLabel,
            null
    );

    @AndroidFindBy(accessibility = "Registration information")
    private WebElement ciscoPhoneStatusButtonLabel;

    private final ConfigUiField ciscoPhoneStatusButtonField = new ConfigUiField(
            driver,
            CISCO_PHONE_STATUS_BUTTON,
            ciscoPhoneStatusButtonLabel,
            ciscoPhoneStatusButtonLabel,
            null
    );

    @AndroidFindBy(accessibility = "Toolbar left icon")
    private WebElement toolbarCrossButtonLabel;

    private final ConfigUiField toolbarCrossButtonField = new ConfigUiField(
            driver,
            TOOLBAR_CROSS_BUTTON,
            null,
            toolbarCrossButtonLabel,
            null
    );

    @AndroidFindBy(accessibility = "Favorite contacts title")
    private WebElement favoriteContactsLabel;

    private final ConfigUiField favoriteContactsField = new ConfigUiField(
            driver,
            FAVORITES,
            null,
            favoriteContactsLabel,
            null
    );

    @AndroidFindBy(accessibility = "Local contacts title")
    private WebElement localContactsLabel;

    private final ConfigUiField localContactsField = new ConfigUiField(
            driver,
            LOCAL_CONTACTS,
            null,
            localContactsLabel,
            null
    );


    public CiscoPhoneUi(AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(OVERFLOW_MENU.title().toLowerCase(), overflowButtonField);
                put(CANCEL_TRANSFER.title().toLowerCase(), cancelTransferButtonField);
                put(BACK_ARROW.title().toLowerCase(), backButtonField);
                put(FAVORITES_TAB.title().toLowerCase(), favoritesTabField);
                put(CALL_LOGS_TAB.title().toLowerCase(), callLogsTabField);
                put(CONTACTS_TAB.title().toLowerCase(), contactsTabField);
                put(VOICEMAIL_TAB.title().toLowerCase(), voicemailTabField);
                put(DIALPAD_TAB.title().toLowerCase(), dialpadTabField);
                put(DIALPAD_EDIT_TEXT.title().toLowerCase(), dialpadEditTextField);
                put(DIALPAD_BACK_BUTTON.title().toLowerCase(), dialpadBackButtonField);
                put(CROSS_BUTTON.title().toLowerCase(), crossButtonField);
                put(RINGTONE_REG_1.title().toLowerCase(), ringtoneField1);
                put(RINGTONE_REG_2.title().toLowerCase(), ringtoneField2);
                put(HAC.title().toLowerCase(), hacField);
                put(ANC.title().toLowerCase(), ancField);
                put(AUTO_ANSWER.title().toLowerCase(), enableAutoAnswerField);
                put(VIBRATE_BEFORE_RING.title().toLowerCase(), vibrateBeforeRingField);
                put(FADE_IN_RING.title().toLowerCase(), fadeInRingField);
                put(AUTO_DIAL.title().toLowerCase(), autodialField);
                put(DIALPAD_AS_DEFAULT_TAB.title().toLowerCase(), dialpadDefaultTabField);
                put(EXPOSE_BUTTON.title().toLowerCase(), exposeButtonField);
                put(ENABLE_SIP.title().toLowerCase(), sipEnabledField);
                put(REGISTRATION_1.title().toLowerCase(), registration1Field);
                put(SIP_SERVER.title().toLowerCase(), sipServerField);
                put(SIP_SERVER_PORT.title().toLowerCase(), sipPortField);
                put(TRANSPORT.title().toLowerCase(), transportField);
                put(SRTP.title().toLowerCase(), srtpField);
                put(EXTENSION_NUMBER.title().toLowerCase(), extensionNumberField);
                put(USERNAME.title().toLowerCase(), usernameField);
                put(PASSWORD.title().toLowerCase(), passwordField);
                put(VOICEMAIL_ADDRESS.title().toLowerCase(), voicemailField);
                put(CALL_FORWARDING.title().toLowerCase(), callForwardingField);
                put(VENDOR_PROTOCOL.title().toLowerCase(), vendorProtocolField);
                put(SIP_STANDARD_HOLD_SIGNALING.title().toLowerCase(), useSipStandardHoldSignalingField);
                put(FORCE_SUBSCRIPTION.title().toLowerCase(), forceSubscriptionField);
                put(ALLOW_CONTACT_HEADER_UPDATES.title().toLowerCase(), contactHeaderUpdatesField);
                put(NEW_TCP_PORT.title().toLowerCase(), sipUseNewTcpPortField);
                put(CALL_WAITING.title().toLowerCase(), disableCallWaitingField);
                put(ALLOW_VIDEO_CALLS.title().toLowerCase(), allowVideoCallsField);
                put(OFFER_VIDEO.title().toLowerCase(), offerVideoField);
                put(ANSWER_VIDEO.title().toLowerCase(), answerVideoField);
                put(REGISTRATION_2.title().toLowerCase(), registration2Field);
                put(COMMON_SETTINGS.title().toLowerCase(), commonSettingsField);
                put(AUDIO_DSCP.title().toLowerCase(), audioDscpField);
                put(CALL_CONTROL_DSCP.title().toLowerCase(), callControlDscpField);
                put(CODEC_G_711U_PRIORITY.title().toLowerCase(), g711uPriorityField);
                put(CODEC_G_711A_PRIORITY.title().toLowerCase(), g711aPriorityField);
                put(CODEC_G_722_PRIORITY.title().toLowerCase(), g722PriorityField);
                put(CODEC_G_729A_PRIORITY.title().toLowerCase(), g729aPriorityField);
                put(OPUS_PRIORITY.title().toLowerCase(), opusPriorityField);
                put(DTMF_PAYLOAD_TYPE.title().toLowerCase(), dtmfPayloadTypeField);
                put(FORCE_IN_BAND_TONES.title().toLowerCase(), dtmfToneField);
                put(OVERRIDE_TCP_SWITCH.title().toLowerCase(), switchFromUdpToTcpField);
                put(LDAP_SETTINGS.title().toLowerCase(), ldapField);
                put(LDAP_SERVER_ADDRESS.title().toLowerCase(), serverAddressField);
                put(LDAP_SERVER_PORT.title().toLowerCase(), serverPortField);
                put(LDAP_SECURITY_TYPE.title().toLowerCase(), communicationSecurityTypeField);
                put(LDAP_BIND_DN.title().toLowerCase(), bindDnField);
                put(LDAP_BIND_PASSWORD.title().toLowerCase(), bindPwField);
                put(LDAP_BASE_DN.title().toLowerCase(), baseDnField);
                put(LDAP_PRIMARY_EMAIL.title().toLowerCase(), primaryEmailField);
                put(LDAP_ALTERNATE_EMAIL.title().toLowerCase(), alternateEmailField);
                put(EMERGENCY_CONTACT.title().toLowerCase(), emergencyContactField);
                put(EMERGENCY_CONTACT_1.title().toLowerCase(), emergencyContact1Field);
                put(EMERGENCY_CONTACT_NAME.title().toLowerCase(), emergencyContactNameField);
                put(EMERGENCY_CONTACT_NUMBER.title().toLowerCase(), emergencyContactNumberField);
                put(EMERGENCY_CONTACT_2.title().toLowerCase(), emergencyContact2Field);
                put(EMERGENCY_CONTACT_3.title().toLowerCase(), emergencyContact3Field);
                put(EMERGENCY_CONTACT_4.title().toLowerCase(), emergencyContact4Field);
                put(EMERGENCY_CONTACT_5.title().toLowerCase(), emergencyContact5Field);
                put(CALL_SERVER_FEATURES.title().toLowerCase(), callServerFeaturesField);
                put(CISCO_I_DIVERT.title().toLowerCase(), allowiDivertField);
                put(CALL_FORWARDING.title().toLowerCase(), callForwardingCallServerFeatureField);
                put(CISCO_CALL_PARK.title().toLowerCase(), allowCallParkField);
                put(CISCO_HUNT_GROUP_LOGON.title().toLowerCase(), huntGroupField);
                put(CISCO_CONTACT_SEARCH.title().toLowerCase(), ciscoContactSearchField);
                put(CISCO_ADVANCED_CONTACT_SEARCH.title().toLowerCase(), ciscoAdvancedContactSearchField);
                put(CISCO_CONTACT_SEARCH_SERVER_ADDRESS.title().toLowerCase(), ciscoContactSearchServerAddressField);
                put(CISCO_ADVANCED_CONTACT_SEARCH_SERVER_USERNAME.title().toLowerCase(), ciscoContactSearchUsernameField);
                put(CISCO_ADVANCED_CONTACT_SEARCH_SERVER_PASSWORD.title().toLowerCase(), ciscoContactSearchPasswordField);
                put(CISCO_CONTACT_SEARCH_FIELD.title().toLowerCase(), ciscoContactSearchFieldField);
                put(CISCO_CONTACT_SEARCH_VALUE.title().toLowerCase(), ciscoContactSearchValueField);
                put(CISCO_VOICEMAIL.title().toLowerCase(), ciscoVoicemailEnableField);
                put(CISCO_UNITY_SERVER_ADDRESS_PRIMARY.title().toLowerCase(), ciscoUnityServerAddressPrimaryField);
                put(CISCO_UNITY_SERVER_ADDRESS_BACKUP.title().toLowerCase(), ciscoUnityServerAddressBackupField);
                put(CISCO_VOICEMAIL_USERNAME.title().toLowerCase(), ciscoVoicemailUsernameField);
                put(CISCO_VOICEMAIL_PASSWORD.title().toLowerCase(), ciscoVoicemailPasswordField);
                put(BIZ_PHONE_ICON.title().toLowerCase(), bizPhoneAppIconField);
                put(NO_SEARCH_RESULTS.title().toLowerCase(), noSearchResultsField);
                put(ENTRY_AT_INDEX_0.title().toLowerCase(), entryAtIndex0Field);
                put(ENTRY_AT_INDEX_1.title().toLowerCase(), entryAtIndex1Field);
                put(ENTRY_AT_INDEX_2.title().toLowerCase(), entryAtIndex2Field);
                put(ENTRY_AT_INDEX_3.title().toLowerCase(), entryAtIndex3Field);
                put(ENTRY_AT_INDEX_4.title().toLowerCase(), entryAtIndex4Field);
                put(ENTRY_AT_INDEX_5.title().toLowerCase(), entryAtIndex5Field);
                put(ENTRY_AT_INDEX_6.title().toLowerCase(), entryAtIndex6Field);
                put(ENTRY_AT_INDEX_7.title().toLowerCase(), entryAtIndex7Field);
                put(ENTRY_AT_INDEX_8.title().toLowerCase(), entryAtIndex8Field);
                put(ENTRY_AT_INDEX_9.title().toLowerCase(), entryAtIndex9Field);
                put(CLEAR_TRUST_LIST.title().toLowerCase(), clearTrustListField);
                put(ALTERNATE_TFTP.title().toLowerCase(), alternateTftpField);
                put(TFTP_ADDRESS_1.title().toLowerCase(), tftpAddress1Field);
                put(TFTP_ADDRESS_2.title().toLowerCase(), tftpAddress2Field);
                put(CLIENT_CONFIGURATION_SETTINGS.title().toLowerCase(), clientConfigurationSettingsField);
                put(CONTACT_NAME_AT_INDEX_0.title().toLowerCase(), contactNameAtIndex0Field);
                put(CONTACT_NUMBER_AT_INDEX_0.title().toLowerCase(), contactNumberAtIndex0Field);
                put(VOICEMAIL_MESSAGES_AT_INDEX_0.title().toLowerCase(), voicemailMessagesCountAtIndex0Field);
                put(CREATE_CONTACT.title().toLowerCase(), createContactField);
                put(SEARCH.title().toLowerCase(), searchContactField);
                put(SEARCH_EDIT_TEXT.title().toLowerCase(), searchEditTextField);
                put(SAVE_CONTACT.title().toLowerCase(), saveContactField);
                put(TOAST_MESSAGE.title().toLowerCase(), toastMessageField);
                put(NO_RESULT.title().toLowerCase(), noResultField);
                put(EDIT_TEXT.title().toLowerCase(), editTextField);
                put(OK_BUTTON.title().toLowerCase(), okButtonField);
                put(CANCEL_BUTTON.title().toLowerCase(), cancelButtonField);
                put(ANOTHER_CANCEL_BUTTON.title().toLowerCase(), anotherCancelButtonField);
                put(FROM_DEVICE_BUTTON.title().toLowerCase(), fromDeviceButtonField);
                put(FROM_SERVER_BUTTON.title().toLowerCase(), fromServeButtonField);
                put(FAVORITES.title().toLowerCase(), favoriteContactsField);
                put(LOCAL_CONTACTS.title().toLowerCase(), localContactsField);
                put(DIAL_NUMBER_1.title().toLowerCase(), dialNumber1Field);
                put(DIAL_NUMBER_2.title().toLowerCase(), dialNumber2Field);
                put(DIAL_NUMBER_3.title().toLowerCase(), dialNumber3Field);
                put(DIAL_NUMBER_4.title().toLowerCase(), dialNumber4Field);
                put(DIAL_NUMBER_5.title().toLowerCase(), dialNumber5Field);
                put(DIAL_NUMBER_6.title().toLowerCase(), dialNumber6Field);
                put(DIAL_NUMBER_7.title().toLowerCase(), dialNumber7Field);
                put(DIAL_NUMBER_8.title().toLowerCase(), dialNumber8Field);
                put(DIAL_NUMBER_9.title().toLowerCase(), dialNumber9Field);
                put(DIAL_NUMBER_0.title().toLowerCase(), dialNumber0Field);
                put(DIAL_NUMBER_STAR.title().toLowerCase(), dialNumberStarField);
                put(DIAL_NUMBER_POUND.title().toLowerCase(), dialNumberPoundField);
                put(CALL_BUTTON.title().toLowerCase(), callButtonField);
                put(END_CALL.title().toLowerCase(), endCallField);
                put(HOLD_BUTTON.title().toLowerCase(), holdButtonField);
                put(RESUME_BUTTON.title().toLowerCase(), resumeButtonField);
                put(MORE_BUTTON.title().toLowerCase(), moreButtonField);
                put(ADD_CALL.title().toLowerCase(), addCallButtonField);
                put(TRANSFER_TO_NUMBER_BUTTON.title().toLowerCase(), transferToNumberButtonField);
                put(TRANSFER_TO_HELD_CALL_BUTTON.title().toLowerCase(), transferToHeldCallButtonField);
                put(NEW_CALL_BUTTON.title().toLowerCase(), newCallButtonField);
                put(CONFERENCE_BUTTON.title().toLowerCase(), conferenceButtonField);
                put(SPLIT_BUTTON.title().toLowerCase(), splitButtonField);
                put(CALLER_INFO_LAYOUT.title().toLowerCase(), callerInfoLayout1Field);
                put(MERGE_CALL_0.title().toLowerCase(), callToMergeWithCallerId0Field);
                put(MERGE_CALL_1.title().toLowerCase(), callToMergeWithCallerId1Field);
                put(MERGE_CALL_2.title().toLowerCase(), callToMergeWithCallerId2Field);
                put(MERGE_CALL_3.title().toLowerCase(), callToMergeWithCallerId3Field);
                put(MERGE_BUTTON.title().toLowerCase(), mergeButtonField);
                put(PARTICIPANTS_BUTTON.title().toLowerCase(), participantsButtonField);
                put(TRANSFER.title().toLowerCase(), transferButtonField);
                put(HOLD_COVER.title().toLowerCase(), holdCoverField);
                put(ANSWER.title().toLowerCase(), headsUpAnswerField);
                put(DECLINE.title().toLowerCase(), headsUpDeclineField);
                put(CALLER_NAME_HEADS_UP.title().toLowerCase(), callerNameHeadsUpField);
                put(CALLER_NAME_ON_CALLING_PHONE.title().toLowerCase(), callerNameCallingPhoneField);
                put(CALLER_NAME_ON_RECEIVED_PHONE.title().toLowerCase(), callerNameReceivedPhoneField);
                put(MUTE.title().toLowerCase(), muteCallField);
                put(EXTENSION_EDIT_TEXT.title().toLowerCase(), extensionEditTextField);
                put(USERNAME_EDIT_TEXT.title().toLowerCase(), usernameEditTextField);
                put(PASSWORD_EDIT_TEXT.title().toLowerCase(), passwordEditTextField);
                put(LOGIN_BUTTON.title().toLowerCase(), loginButtonField);
                put(EXTENSION_USERNAME_CHECKBOX.title().toLowerCase(), extensionUsernameCheckboxField);
                put(BIZ_PHONE_LOGO.title().toLowerCase(), bizPhoneLogoField);
                put(CALL_ICON_1.title().toLowerCase(), callIcon1Field);
                put(CALL_ICON_2.title().toLowerCase(), callIcon2Field);
                put(LINE_NUMBER_1.title().toLowerCase(), lineNumber1Field);
                put(LINE_NUMBER_2.title().toLowerCase(), lineNumber2Field);
                put(POPUP.title().toLowerCase(), popupField);
                put(EXPAND_BUTTON.title().toLowerCase(), expandButtonField);
                put(AUDIO_PATH.title().toLowerCase(), audioPathButtonField);
                put(ENABLE_CALL_FORWARDING.title().toLowerCase(), enableCallForwardingField);
                put(SEARCH_MAGNIFY_ICON.title().toLowerCase(), searchMagnifyIconField);
                put(CALL_DETAILS.title().toLowerCase(),callDetailsField);
                put(CALLER_NUMBER_ON_CALL_LOG_SCREEN.title().toLowerCase(),callerNumberField);
                put(ADVANCED_DEBUGGING.title().toLowerCase(), advancedDebuggingField);
                put(DEVICE_INFORMATION.title().toLowerCase(),deviceInformationField);
                put(REPORT_PROBLEM.title().toLowerCase(),reportProblemField);
                put(TOOLBAR_CROSS_BUTTON.title().toLowerCase(),toolbarCrossButtonField);
                put(RECENTS_TAB.title().toLowerCase(), recentsTabField);
                put(MISSED_TAB.title().toLowerCase(), missedTabField);
                put(ADVANCED_DEBUGGING_BUTTON.title().toLowerCase(),advancedDebuggingButtonField);
                put(LOGGING_PASSWORD_EDIT_TEXT.title().toLowerCase(),loggingPasswordEditTextField);
            }
        };
    }

    public String getCallerNameCalledPhone() {
        return callerNameCalledPhone.getText();
    }

    public String getCallerNameReceivedCall() {
        return callerNameReceivedPhone.getText();
    }

    public String getCallerNameFromHeadsUpNotification() {
        return callerNameHeadsUp.getText();
    }

    public String entryAtIndex(String index) {
        String value = null;
        switch (index) {
            case "0":
                value = entryAtIndex0.getText();
                break;
            case "1":
                value = entryAtIndex1.getText();
                break;
            case "2":
                value = entryAtIndex2.getText();
                break;
            case "3":
                value = entryAtIndex3.getText();
                break;
            case "4":
                value = entryAtIndex4.getText();
                break;
            case "5":
                value = entryAtIndex5.getText();
                break;
            case "6":
                value = entryAtIndex6.getText();
                break;
            case "7":
                value = entryAtIndex7.getText();
                break;
            case "8":
                value = entryAtIndex8.getText();
                break;
            case "9":
                value = entryAtIndex9.getText();
                break;
            default:
                break;
        }
        return value;
    }

    private Boolean noResultsText() {
        return noSearchResults.isDisplayed();
    }

    public void enterInEditText(String editTextValue) {
        log.debug("Entering: " + editTextValue + " into edit text box");
        editText.sendKeys(editTextValue);
    }

    public void clickOkButton() {
        log.debug("Clicking Ok Button");
        okButton.click();
    }

    private void clickDialNumber1() {
        log.debug("Dialing 1");
        dialNumber1.click();
    }

    private void clickDialNumber2() {
        log.debug("Dialing 2");
        dialNumber2.click();
    }

    private void clickDialNumber3() {
        log.debug("Dialing 3");
        dialNumber3.click();
    }

    private void clickDialNumber4() {
        log.debug("Dialing 4");
        dialNumber4.click();
    }

    private void clickDialNumber5() {
        log.debug("Dialing 5");
        dialNumber5.click();
    }

    private void clickDialNumber6() {
        log.debug("Dialing 6");
        dialNumber6.click();
    }

    private void clickDialNumber7() {
        log.debug("Dialing 7");
        dialNumber7.click();
    }

    private void clickDialNumber8() {
        log.debug("Dialing 8");
        dialNumber8.click();
    }

    private void clickDialNumber9() {
        log.debug("Dialing 9");
        dialNumber9.click();
    }

    private void clickDialNumberStar() {
        log.debug("Dialing *");
        dialNumberStar.click();
    }

    private void clickDialNumber0() {
        log.debug("Dialing 0");
        dialNumber0.click();
    }

    private void clickDialNumberPound() {
        log.debug("Dialing #");
        dialNumberPound.click();
    }

    public Boolean isEndCallButtonVisible() {
        return endCallButton.isDisplayed();
    }

    private Boolean isDialpadTabVisible() {
        return dialpadTab.isDisplayed();
    }

    private Boolean isDialpadBackButtonVisible() {
        return dialpadBackButton.isDisplayed();
    }

    public String noResultText() {
        return noResult.getText();
    }

    public void headsUpAnswer() {
        headsUpAnswer.click();
    }

    public void headsUpDecline() {
        headsUpDecline.click();
    }

    public void holdResumeButton(boolean hold) {
        String callForwardingValue = holdButton.getAttribute("selected");
        if (callForwardingValue.equals("false") && (hold))
            holdButton.click();
        else if (callForwardingValue.equals("true") && (!hold))
            holdButton.click();
    }

    public void clickHeldCallToMerge(String callId) {

        switch (callId) {
            case "0":
                callToMergeWithCallerId0.click();
                break;
            case "1":
                callToMergeWithCallerId1.click();
                break;
            case "2":
                callToMergeWithCallerId2.click();
                break;
            case "3":
                callToMergeWithCallerId3.click();
                break;
            default:
                break;
        }
    }

    public void clickDialNumber(char number) {

        switch (number) {
            case '0':
                clickDialNumber0();
                break;
            case '1':
                clickDialNumber1();
                break;
            case '2':
                clickDialNumber2();
                break;
            case '3':
                clickDialNumber3();
                break;
            case '4':
                clickDialNumber4();
                break;
            case '5':
                clickDialNumber5();
                break;
            case '6':
                clickDialNumber6();
                break;
            case '7':
                clickDialNumber7();
                break;
            case '8':
                clickDialNumber8();
                break;
            case '9':
                clickDialNumber9();
                break;
            case '*':
                clickDialNumberStar();
                break;
            case '#':
                clickDialNumberPound();
                break;
            default:
                break;
        }
    }

    public void endCall() {
        endCallButton.click();
    }

    public void goBack() {
        backButton.click();
    }

    public void checkAncHacBehavior() {
        String enableHAC = hacControl.getAttribute("checked");
        String enableANC = ancControl.getAttribute("checked");
        if (enableHAC.equals("false") && enableANC.equals("false")) {
            hacControl.click();
            ancControl.click();
            if (!toast.getText().equals("Cannot enable ANC because HAC is enabled"))
                Assert.fail("Warning toast not found");
            clickOkButton();

            hacControl.click();
            ancControl.click();
            hacControl.click();

            if (!toast.getText().equals("Cannot enable HAC because ANC is enabled"))
                Assert.fail("Warning toast not found");
            clickOkButton();

            ancControl.click();
        }
    }

    public void clearEditText() {
        log.debug("Clearing edit text");
        editText.clear();
    }

    public void clickExposeButton() {
        exposeButton.click();
    }

    public Point getCiscoPhoneIconPosition() {
        int centerX = aboutIconButton.getLocation().getX() + aboutIconButton.getSize().getWidth() / 2;
        int centerY = aboutIconButton.getLocation().getY() + aboutIconButton.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }

    public Point getAcceptCallIconPosition() {
        int centerX = acceptCall.getLocation().getX() + acceptCall.getSize().getWidth() / 2;
        int centerY = acceptCall.getLocation().getY() + acceptCall.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }

    public Point getDeclineCallIconPosition() {
        int centerX = declineCall.getLocation().getX() + declineCall.getSize().getWidth() / 2;
        int centerY = declineCall.getLocation().getY() + declineCall.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }

    public void answerCall() {
        TouchAction touchAction = new TouchAction(driver);
        Point position = getAcceptCallIconPosition();
        Dimension size = driver.manage().window ().getSize();
        int toPosition = size.getWidth () / 2;
        touchAction.press(point(position.getX(), position.getY())).moveTo(point(position.getX()+toPosition, position.getY())).release().perform();
    }

    public void declineCall() {
        TouchAction touchAction = new TouchAction(driver);
        Point position = getDeclineCallIconPosition();
        Dimension size = driver.manage().window ().getSize();
        int toPosition = size.getWidth () / 2;
        touchAction.press(point(position.getX(), position.getY())).moveTo(point(position.getX()-toPosition, position.getY())).release().perform();
    }


    public void chooseDialpad() {
        try {
            if (isDialpadTabVisible()) {
                log.info("Dialpad is set to default tab.");
                dialpadTab.click();
            }
        } catch (Exception e) {
            log.debug("Dialpad is not set as default tab. Tapping on the floating dialer button");
        }
    }

    public void clearDialpad() {
        try {
            if (isDialpadBackButtonVisible()) {
                log.debug("Clearing dialpad tab stale number");
                dialpadEditText.clear();
            }
        } catch (Exception e) {
            log.debug("Dialpad does not contain stale number");
        }
    }

    public boolean noContactFound() {
        boolean found = false;
        try {
            if (noResultsText()) {
                log.debug("Contact not found");
                found = true;
            }
        } catch (Exception e) {
            log.debug("Contact found");
            found = false;
        }
        return found;
    }

    public void tapCreateNewContact() {
        log.debug("Tapping 'create new contact'");
        createContact.click();
    }

    public void saveContact() {
        log.debug("Saving contact");
        saveContact.click();
    }

    public void tapSearchContact() {
        log.debug("Tapping on Search button");
        searchContact.click();
    }

    public void enterIntoSearchEditText(String contactName) {
        searchEditText.click();
        log.debug("Entering: " + contactName + " into search edit text field");
        searchEditText.sendKeys(contactName);
    }

    public void starContact() {
        starContact.click();
    }

    public void unstarContact() {
        unstarContact.click();
    }

    public String popUpMessage() {
        return pop.getText();
    }

    public void clickRegistration1() {
        log.debug("Entering Registration 1 settings");
        registration1Label.click();
    }

    public void tapOverflowMenu() {
        log.debug("Tapping on more options");
        overflowButton.click();
    }

    public void tapTransportLabel() {
        log.debug("Tapping on transport label");
        transportLabel.click();
    }
    public void muteCall() {
        muteCall.click();
    }

    public void unmuteCall() {
        unmuteCall.click();
    }

    public String getCallerNumber() {
        return callerNumber.getText();
    }

    public boolean isLoginUserNameDisplayed(){
        try {
            if(usernameEditText.isDisplayed())
                return true;
            else
                return false;
        } catch(Exception e){
            return false;
        }
    }
}
