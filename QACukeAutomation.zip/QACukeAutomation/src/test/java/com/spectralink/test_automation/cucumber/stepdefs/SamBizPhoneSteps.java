package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamBizPhonePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.BIZ_PHONE;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleep;

public class SamBizPhoneSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I unfold the SIP Registration 1 section$")
	public void clickSipRegistration1() {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		bizPhonePage.openSipRegistration1();
	}

	@When("^I unfold the SIP Registration 2 section$")
	public void clickSipRegistration2() {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		bizPhonePage.openSipRegistration2();
	}

	@When("^I unfold the Cisco Solution Partner Program section$")
	public void clickCiscoProgram() {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		bizPhonePage.openCiscoProgram();
	}

	@When("^I unfold the Common Settings section$")
	public void clickCommonSettings() {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		bizPhonePage.openCommonSettings();
	}

	@When("^I click the LDAP tab")
	public void clickLdapTab() {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		bizPhonePage.clickLdapTab();
	}

	@When("^I click the Emergency Contacts tab")
	public void clickContactsTab() {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		bizPhonePage.clickEmergencyContactsTab();
	}

	@When("^I click the Contacts Plus button")
	public void clickPlusIcon() {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		bizPhonePage.clickPlusButton();
	}

	@When("^I click the Contacts Minus button")
	public void clickMinusIcon() {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		bizPhonePage.clickMinusButton();
	}

	@When("^I check the \"([^\"]*)\" Biz Phone field$")
	public void checkSip(String arg1) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (bizPhonePage.getField(arg1.trim()) != null) {
			bizPhonePage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I uncheck the \"([^\"]*)\" Biz Phone field$")
	public void uncheckSip(String arg1) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (bizPhonePage.getField(arg1.trim()) != null) {
			bizPhonePage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I check the \"([^\"]*)\" Biz Phone codec field$")
	public void checkCodec(String arg1) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (bizPhonePage.getField(arg1.trim()) != null) {
			bizPhonePage.getField(arg1.trim()).edit();
			sleep(500);
			bizPhonePage.updateCodecFields();
			bizPhonePage.updateCarets();
			bizPhonePage.getField(arg1.trim()).checkUncheck(true);
		} else {
			log.error("No matching field with title '{}'", arg1.trim());
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I uncheck the \"([^\"]*)\" Biz Phone codec field$")
	public void uncheckCodec(String arg1) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (bizPhonePage.getField(arg1.trim()) != null) {
			bizPhonePage.getField(arg1.trim()).edit();
			sleep(500);
			bizPhonePage.updateCodecFields();
			bizPhonePage.updateCarets();
			bizPhonePage.getField(arg1.trim()).checkUncheck(false);
		} else {
			log.error("No matching field with title '{}'", arg1.trim());
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I delete the \"([^\"]*)\" Biz Phone field$")
	public void deleteSip(String arg1) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (bizPhonePage.getField(arg1.trim()) != null) {
			bizPhonePage.getField(arg1.trim()).delete();
		} else {
			log.error("Field with label '{}' does not exist", arg1);
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" Biz Phone field$")
	public void enterFieldValue(String arg1, String arg2) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (bizPhonePage.getField(arg2.trim()) != null) {
			bizPhonePage.getField(arg2.trim()).updateTextbox(arg1);
		} else {
			log.error("Field with label '{}' does not exist", arg1);
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" Biz Phone field$")
	public void selectMenuOption(String arg1, String arg2) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (bizPhonePage.getField(arg2.trim()) != null) {
			bizPhonePage.getField(arg2.trim()).updateMenuByLabel(arg1.trim());
		} else {
			log.error("Field with label '{}' does not exist", arg1);
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the Biz Phone \"([^\"]*)\" setting$")
	public void verifyValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(BIZ_PHONE, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(BIZ_PHONE, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(BIZ_PHONE)) phone.loadAppPreferences(BIZ_PHONE);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("Field with label '{}' does not exist", arg3);
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
		}
	}

	@When("^I move the \"([^\"]*)\" Biz Phone codec field \"([^\"]*)\"$")
	public void moveCodecField(String arg1, String arg2) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (arg2.trim().contentEquals("up")) {
			bizPhonePage.moveCodecUp(arg1.trim());
		} else if (arg2.trim().contentEquals("down")) {
			bizPhonePage.moveCodecDown(arg1.trim());
		} else {
			log.error("'{}' is an undefined direction for field {}", arg2, arg1);
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the Biz Phone custom attribute \"([^\"]*)\" setting$")
	public void checkCustomAttributeSetting(String arg1, String arg2, String arg3) {
		if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
			VersityPhone phone = Environment.getPhone(arg1.trim());
			if (phone != null) {
				if (!phone.getCurrentAppSettings().equals(BIZ_PHONE)) phone.loadAppPreferences(BIZ_PHONE);
				Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2));
			} else {
				log.error("Phone with label '{}' does not exist", arg1);
				Assert.fail("Specified Phone Not Available");
			}
		} else {
			log.debug("Skipped checking attribute {} since custom attribute testing is turned off", arg1);
		}

	}

	@Then("^the Biz Phone page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyBizPhonePageValue(String arg1, String arg2) {
		SamBizPhonePage bizPhonePage = (SamBizPhonePage) Environment.getCurrentPage();
		if (bizPhonePage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(bizPhonePage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(bizPhonePage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Field with label '{}' does not exist", arg2);
		}
	}
}