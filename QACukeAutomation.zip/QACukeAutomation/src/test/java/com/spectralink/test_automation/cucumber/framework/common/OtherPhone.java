package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.regex.Pattern;

public class OtherPhone extends AndroidPhone implements TestPhone {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private final Pattern spectralinkPattern = Pattern.compile("Row: 0 value=(.*)");
	private final Pattern adbPattern = Pattern.compile("id=(\\d+), name=(\\S+), value=(\\S+)");
	private final Pattern tonePattern = Pattern.compile("_display_name=(\\S+),");
	private final String bizPhoneCommand = "com.spectralink.phone cat shared_prefs/preferences.xml";
	private Map<String, AppSetting> appSettings = new LinkedHashMap<>();
	private Application currentAppSettings;

	public enum Application {
		None, BizPhone, WebApi
	}

	public OtherPhone(UsbHost host, String serialNumber, String status, String path) {
		super(host, serialNumber, status, path);
		setPhoneType(PhoneType.OTHER);
		currentAppSettings = Application.None;
	}

	public void loadAppPreferences(Application app) {
		String preferencesFile = null;
		appSettings.clear();
		switch(app) {
			case None:
				return;
			case BizPhone:
				preferencesFile = bizPhoneCommand;
				break;
		}

		List<String> command = new ArrayList<>(Arrays.asList("exec-out", "run-as", preferencesFile));
		CliResult result = sendAdbCommand(command);
		appSettings = XmlTool.loadApolloSettingsFromXml(result.getStdout());
		if (result.commandFailed()) {
			log.error("ADB command failed: {}", result.getStdout());
			currentAppSettings = Application.None;
		} else {
			currentAppSettings = app;
		}
	}

	public void reloadAppPreferences() {
		loadAppPreferences(currentAppSettings);
	}

	public String getApplication() {
		return currentAppSettings.name();
	}

	public Map<String, AppSetting> getAppSettings() {
		return appSettings;
	}

	public AppSetting getSettingForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key);
		}
		return null;
	}

	public Object getValueTypeForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getType();
		}
		return null;
	}

	public Object getValueForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getValue();
		}
		return null;
	}

	public String getStringForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getStringValue();
		}
		return null;
	}

	public Integer getIntegerForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getIntegerValue();
		}
		return null;
	}

	public Boolean getBooleanForAppKey(String key) {
		if (appSettings.containsKey(key)) {
			return appSettings.get(key).getBooleanValue();
		}
		return null;
	}

	public boolean hasCamera() {
		Boolean found = false;
		String camera = getProperty("persist.camera.is_type");
		if (camera != null && camera.matches("\\w+")) {
			found = true;
		}
		return found;
	}

	public boolean hasBarcodeScanner() {
		return hasCamera();
	}
}





