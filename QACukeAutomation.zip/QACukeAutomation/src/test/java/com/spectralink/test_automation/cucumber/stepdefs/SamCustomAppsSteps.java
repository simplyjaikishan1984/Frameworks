package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamCustomAppsPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

public class SamCustomAppsSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I set a custom package with name \"([^\"]*)\" and key \"([^\"]*)\" and type \"([^\"]*)\" to \"([^\"]*)\"$")
    public void setCustomAttribute(String arg1, String arg2, String arg3, String arg4) {
        SamCustomAppsPage appsPage = (SamCustomAppsPage) Environment.getCurrentPage();
        appsPage.setPackageAttribute(arg1, arg2, arg3, arg4);
    }

    @Then("I edit the attribute of package \"([^\"]*)\" with key \"([^\"]*)\"$")
    public void editCustomAttributeSetting(String arg1, String arg2) {
        SamCustomAppsPage appsPage = (SamCustomAppsPage) Environment.getCurrentPage();
        if (appsPage.attributeExists(arg1, arg2))
        appsPage.deleteCustomAttribute(arg1);
    }

    @Then("I delete the attribute of package \"([^\"]*)\" with key \"([^\"]*)\"$")
    public void deleteCustomAttributeSetting(String arg1, String arg2) {
        SamCustomAppsPage appsPage = (SamCustomAppsPage) Environment.getCurrentPage();
        appsPage.deleteCustomAttribute(arg1);
    }

    @Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the package \"([^\"]*)\" and attribute \"([^\"]*)\" setting$")
    public void checkCustomAppAttributeSetting(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone != null) {
            phone.loadAppPreferences(arg3.trim());
            Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
        } else {
            log.error("Phone with label '{}' does not exist", arg1);
            Assert.fail("Specified Phone Not Available");
        }
    }

    @Then("^there were no mismatches between SAM and Custom App settings on \"([^\"]*)\"$")
    public void checkNoMismatches(String arg1) {
        int failures = Environment.getScenarioFailureCount();
        if (failures > 0) {
            for (String phoneName : arg1.trim().split("\\s*,\\s*")) {
                VersityPhone phone = Environment.getPhone(phoneName);
                Environment.getSam().jarvisLog().logLastFullResponse(phone.getSerialNumber());
            }
            Assert.fail(Util.glue("Found", failures, "mismatched settings between SAM and the app"));
        }
        log.debug("No mismatched settings were found between SAM and the application(s)");
    }
}