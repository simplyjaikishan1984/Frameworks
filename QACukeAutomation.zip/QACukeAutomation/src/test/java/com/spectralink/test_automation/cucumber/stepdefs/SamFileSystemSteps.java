package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import io.cucumber.java.en.Then;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class SamFileSystemSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @Then("^the file \"([^\"]*)\" was saved locally$")
    public void verifyFileExists(String arg1) {
        Path exportFilePath = Paths.get(Environment.getProjectDirectory(), "src/test/resources", arg1.trim());
        File exportFile = exportFilePath.toFile();
        if (exportFile.exists() && exportFile.length() > 0) {
            log.debug("File {} was downloaded", exportFilePath);
        } else {
            log.error("File {} was not downloaded", arg1);
            Assert.fail("File Did Not Exist");
        }
    }

    @Then("^the file \"([^\"]*)\" was not empty$")
    public void verifyFileNotEmpty(String arg1) {
        Path exportFilePath = Paths.get(Environment.getProjectDirectory(), "src/test/resources", arg1.trim());
        File exportFile = exportFilePath.toFile();
        if (exportFile.length() > 0) {
            log.debug("File {} was not empty", exportFilePath);
        } else {
            log.error("File {} was empty", arg1);
            Assert.fail("File Did Not Have Data");
        }
    }
}