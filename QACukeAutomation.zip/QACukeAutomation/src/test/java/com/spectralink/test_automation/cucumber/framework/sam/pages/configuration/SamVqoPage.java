package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.VqoStrings.*;

public class SamVqoPage extends SamConfigurationPage {

	@FindBy(id = "enable_vqo_label")
	private WebElement enableVqoLabel;

	@FindBy(id = "enable_vqo")
	private WebElement enableVqoCheckbox;

	@FindBy(id = "delete_setting_vqoEnabled")
	private WebElement enableVqoDelete;

	@FindBy(id = "edit_setting_vqoEnabled")
	private WebElement enableVqoEdit;

	public ConfigPageField enableVqoField = new ConfigPageField(
			ENABLE_VQO,
			enableVqoLabel,
			enableVqoCheckbox,
			enableVqoDelete,
			enableVqoEdit
	);

	@FindBy(id = "wifiNetworksRoamingThreshold")
	private WebElement newRssiThresholdSliderValue;

	@FindBy(id = "wifiNetworksRoamingThreshold")
	private WebElement rssiThresholdSlider;

	@FindBy(id = "edit_setting_wifiNetworksRoamingThreshold")
	private WebElement rssiThresholdEdit;

	@FindBy(id = "delete_setting_wifiNetworksRoamingThreshold")
	private WebElement rssiThresholdDelete;

	public ConfigPageField rssiThresholdField = new ConfigPageField(
			WIFI_THRESHOLD,
			newRssiThresholdSliderValue,
			rssiThresholdSlider,
			rssiThresholdDelete,
			rssiThresholdEdit
	);

	@FindBy(id = "wifi_auto_band")
	private WebElement wifiAutoBandSelectionLabel;

	@FindBy(id = "auto_band_wifi")
	private WebElement wifiAutoBandSelectionCheckbox;

	@FindBy(id = "delete_setting_wifiBandAuto")
	private WebElement wifiAutoBandSelectionDelete;

	@FindBy(id = "edit_setting_wifiBandAuto")
	private WebElement wifiAutoBandSelectionEdit;

	public ConfigPageField wifiAutoBandSelectionField = new ConfigPageField(
			WIFI_AUTO_BAND,
			wifiAutoBandSelectionLabel,
			wifiAutoBandSelectionCheckbox,
			wifiAutoBandSelectionDelete,
			wifiAutoBandSelectionEdit
	);

	@FindBy(id = "wifi_2DOT4")
	private WebElement wifi2Dot4BandSelectionLabel;

	@FindBy(id = "wifi_2DOT_4")
	private WebElement wifi2Dot4BandSelectionCheckbox;

	@FindBy(id = "delete_setting_wifiBand2Dot4GHz")
	private WebElement wifi2Dot4BandSelectionDelete;

	@FindBy(id = "edit_setting_wifiBand2Dot4GHz")
	private WebElement wifi2Dot4BandSelectionEdit;

	public ConfigPageField wifi2Dot4BandSelectionField = new ConfigPageField(
			WIFI_24_GHZ_BAND,
			wifi2Dot4BandSelectionLabel,
			wifi2Dot4BandSelectionCheckbox,
			wifi2Dot4BandSelectionDelete,
			wifi2Dot4BandSelectionEdit
	);

	@FindBy(id = "wifi_band_5")
	private WebElement wifi5BandSelectionLabel;

	@FindBy(id = "wifi_5_ghz")
	private WebElement wifi5BandSelectionCheckbox;

	@FindBy(id = "delete_setting_wifiBand5GHz")
	private WebElement wifi5BandSelectionDelete;

	@FindBy(id = "edit_setting_wifiBand5GHz")
	private WebElement wifi5BandSelectionEdit;

	public ConfigPageField wifi5BandSelectionField = new ConfigPageField(
			WIFI_5_GHZ_BAND,
			wifi5BandSelectionLabel,
			wifi5BandSelectionCheckbox,
			wifi5BandSelectionDelete,
			wifi5BandSelectionEdit
	);

	@FindBy(id = "label_vqoChannel1")
	private WebElement channel1Label;

	@FindBy(id = "Server_vqoChannel1")
	private WebElement channel1Checkbox;

	@FindBy(id = "delete_setting_vqoChannel1")
	private WebElement channel1Delete;

	@FindBy(id = "edit_setting_vqoChannel1")
	private WebElement channel1Edit;

	public ConfigPageField channel1Field = new ConfigPageField(
			CHANNEL_1,
			channel1Label,
			channel1Checkbox,
			channel1Delete,
			channel1Edit
	);

	@FindBy(id = "label_vqoChannel2")
	private WebElement channel2Label;

	@FindBy(id = "Server_vqoChannel2")
	private WebElement channel2Checkbox;

	@FindBy(id = "delete_setting_vqoChannel2")
	private WebElement channel2Delete;

	@FindBy(id = "edit_setting_vqoChannel2")
	private WebElement channel2Edit;

	public ConfigPageField channel2Field = new ConfigPageField(
			CHANNEL_2,
			channel2Label,
			channel2Checkbox,
			channel2Delete,
			channel2Edit
	);

	@FindBy(id = "label_vqoChannel3")
	private WebElement channel3Label;

	@FindBy(id = "Server_vqoChannel3")
	private WebElement channel3Checkbox;

	@FindBy(id = "delete_setting_vqoChannel3")
	private WebElement channel3Delete;

	@FindBy(id = "edit_setting_vqoChannel3")
	private WebElement channel3Edit;

	public ConfigPageField channel3Field = new ConfigPageField(
			CHANNEL_3,
			channel3Label,
			channel3Checkbox,
			channel3Delete,
			channel3Edit
	);

	@FindBy(id = "label_vqoChannel4")
	private WebElement channel4Label;

	@FindBy(id = "Server_vqoChannel4")
	private WebElement channel4Checkbox;

	@FindBy(id = "delete_setting_vqoChannel4")
	private WebElement channel4Delete;

	@FindBy(id = "edit_setting_vqoChannel4")
	private WebElement channel4Edit;

	public ConfigPageField channel4Field = new ConfigPageField(
			CHANNEL_4,
			channel4Label,
			channel4Checkbox,
			channel4Delete,
			channel4Edit
	);

	@FindBy(id = "label_vqoChannel5")
	private WebElement channel5Label;

	@FindBy(id = "Server_vqoChannel5")
	private WebElement channel5Checkbox;

	@FindBy(id = "delete_setting_vqoChannel5")
	private WebElement channel5Delete;

	@FindBy(id = "edit_setting_vqoChannel5")
	private WebElement channel5Edit;

	public ConfigPageField channel5Field = new ConfigPageField(
			CHANNEL_5,
			channel5Label,
			channel5Checkbox,
			channel5Delete,
			channel5Edit
	);

	@FindBy(id = "label_vqoChannel6")
	private WebElement channel6Label;

	@FindBy(id = "Server_vqoChannel6")
	private WebElement channel6Checkbox;

	@FindBy(id = "delete_setting_vqoChannel6")
	private WebElement channel6Delete;

	@FindBy(id = "edit_setting_vqoChannel6")
	private WebElement channel6Edit;

	public ConfigPageField channel6Field = new ConfigPageField(
			CHANNEL_6,
			channel6Label,
			channel6Checkbox,
			channel6Delete,
			channel6Edit
	);

	@FindBy(id = "label_vqoChannel7")
	private WebElement channel7Label;

	@FindBy(id = "Server_vqoChannel7")
	private WebElement channel7Checkbox;

	@FindBy(id = "delete_setting_vqoChannel7")
	private WebElement channel7Delete;

	@FindBy(id = "edit_setting_vqoChannel7")
	private WebElement channel7Edit;

	public ConfigPageField channel7Field = new ConfigPageField(
			CHANNEL_7,
			channel7Label,
			channel7Checkbox,
			channel7Delete,
			channel7Edit
	);

	@FindBy(id = "label_vqoChannel8")
	private WebElement channel8Label;

	@FindBy(id = "Server_vqoChannel8")
	private WebElement channel8Checkbox;

	@FindBy(id = "delete_setting_vqoChannel8")
	private WebElement channel8Delete;

	@FindBy(id = "edit_setting_vqoChannel8")
	private WebElement channel8Edit;

	public ConfigPageField channel8Field = new ConfigPageField(
			CHANNEL_8,
			channel8Label,
			channel8Checkbox,
			channel8Delete,
			channel8Edit
	);

	@FindBy(id = "label_vqoChannel9")
	private WebElement channel9Label;

	@FindBy(id = "Server_vqoChannel9")
	private WebElement channel9Checkbox;

	@FindBy(id = "delete_setting_vqoChannel9")
	private WebElement channel9Delete;

	@FindBy(id = "edit_setting_vqoChannel9")
	private WebElement channel9Edit;

	public ConfigPageField channel9Field = new ConfigPageField(
			CHANNEL_9,
			channel9Label,
			channel9Checkbox,
			channel9Delete,
			channel9Edit
	);

	@FindBy(id = "label_vqoChannel10")
	private WebElement channel10Label;

	@FindBy(id = "Server_vqoChannel10")
	private WebElement channel10Checkbox;

	@FindBy(id = "delete_setting_vqoChannel10")
	private WebElement channel10Delete;

	@FindBy(id = "edit_setting_vqoChannel10")
	private WebElement channel10Edit;

	public ConfigPageField channel10Field = new ConfigPageField(
			CHANNEL_10,
			channel10Label,
			channel10Checkbox,
			channel10Delete,
			channel10Edit
	);

	@FindBy(id = "label_vqoChannel11")
	private WebElement channel11Label;

	@FindBy(id = "Server_vqoChannel11")
	private WebElement channel11Checkbox;

	@FindBy(id = "delete_setting_vqoChannel11")
	private WebElement channel11Delete;

	@FindBy(id = "edit_setting_vqoChannel11")
	private WebElement channel11Edit;

	public ConfigPageField channel11Field = new ConfigPageField(
			CHANNEL_11,
			channel11Label,
			channel11Checkbox,
			channel11Delete,
			channel11Edit
	);

	@FindBy(id = "label_vqoChannel12")
	private WebElement channel12Label;

	@FindBy(id = "Server_vqoChannel12")
	private WebElement channel12Checkbox;

	@FindBy(id = "delete_setting_vqoChannel12")
	private WebElement channel12Delete;

	@FindBy(id = "edit_setting_vqoChannel12")
	private WebElement channel12Edit;

	public ConfigPageField channel12Field = new ConfigPageField(
			CHANNEL_12,
			channel12Label,
			channel12Checkbox,
			channel12Delete,
			channel12Edit
	);

	@FindBy(id = "label_vqoChannel13")
	private WebElement channel13Label;

	@FindBy(id = "Server_vqoChannel13")
	private WebElement channel13Checkbox;

	@FindBy(id = "delete_setting_vqoChannel13")
	private WebElement channel13Delete;

	@FindBy(id = "edit_setting_vqoChannel13")
	private WebElement channel13Edit;

	public ConfigPageField channel13Field = new ConfigPageField(
			CHANNEL_13,
			channel13Label,
			channel13Checkbox,
			channel13Delete,
			channel13Edit
	);

	@FindBy(id = "label_vqoChannel14")
	private WebElement channel14Label;

	@FindBy(id = "Server_vqoChannel14")
	private WebElement channel14Checkbox;

	@FindBy(id = "delete_setting_vqoChannel14")
	private WebElement channel14Delete;

	@FindBy(id = "edit_setting_vqoChannel14")
	private WebElement channel14Edit;

	public ConfigPageField channel14Field = new ConfigPageField(
			CHANNEL_14,
			channel14Label,
			channel14Checkbox,
			channel14Delete,
			channel14Edit
	);

	@FindBy(id = "label_vqoChannel36")
	private WebElement channel36Label;

	@FindBy(id = "Server_vqoChannel36")
	private WebElement channel36Checkbox;

	@FindBy(id = "delete_setting_vqoChannel36")
	private WebElement channel36Delete;

	@FindBy(id = "edit_setting_vqoChannel36")
	private WebElement channel36Edit;

	public ConfigPageField channel36Field = new ConfigPageField(
			CHANNEL_36,
			channel36Label,
			channel36Checkbox,
			channel36Delete,
			channel36Edit
	);

	@FindBy(id = "label_vqoChannel40")
	private WebElement channel40Label;

	@FindBy(id = "Server_vqoChannel40")
	private WebElement channel40Checkbox;

	@FindBy(id = "delete_setting_vqoChannel40")
	private WebElement channel40Delete;

	@FindBy(id = "edit_setting_vqoChannel40")
	private WebElement channel40Edit;

	public ConfigPageField channel40Field = new ConfigPageField(
			CHANNEL_40,
			channel40Label,
			channel40Checkbox,
			channel40Delete,
			channel40Edit
	);

	@FindBy(id = "label_vqoChannel44")
	private WebElement channel44Label;

	@FindBy(id = "Server_vqoChannel44")
	private WebElement channel44Checkbox;

	@FindBy(id = "delete_setting_vqoChannel44")
	private WebElement channel44Delete;

	@FindBy(id = "edit_setting_vqoChannel44")
	private WebElement channel44Edit;

	public ConfigPageField channel44Field = new ConfigPageField(
			CHANNEL_44,
			channel44Label,
			channel44Checkbox,
			channel44Delete,
			channel44Edit
	);

	@FindBy(id = "label_vqoChannel48")
	private WebElement channel48Label;

	@FindBy(id = "Server_vqoChannel48")
	private WebElement channel48Checkbox;

	@FindBy(id = "delete_setting_vqoChannel48")
	private WebElement channel48Delete;

	@FindBy(id = "edit_setting_vqoChannel48")
	private WebElement channel48Edit;

	public ConfigPageField channel48Field = new ConfigPageField(
			CHANNEL_48,
			channel48Label,
			channel48Checkbox,
			channel48Delete,
			channel48Edit
	);

	@FindBy(id = "label_vqoChannel52")
	private WebElement channel52Label;

	@FindBy(id = "Server_vqoChannel52")
	private WebElement channel52Checkbox;

	@FindBy(id = "delete_setting_vqoChannel52")
	private WebElement channel52Delete;

	@FindBy(id = "edit_setting_vqoChannel52")
	private WebElement channel52Edit;

	public ConfigPageField channel52Field = new ConfigPageField(
			CHANNEL_52,
			channel52Label,
			channel52Checkbox,
			channel52Delete,
			channel52Edit
	);

	@FindBy(id = "label_vqoChannel56")
	private WebElement channel56Label;

	@FindBy(id = "Server_vqoChannel56")
	private WebElement channel56Checkbox;

	@FindBy(id = "delete_setting_vqoChannel56")
	private WebElement channel56Delete;

	@FindBy(id = "edit_setting_vqoChannel56")
	private WebElement channel56Edit;

	public ConfigPageField channel56Field = new ConfigPageField(
			CHANNEL_56,
			channel56Label,
			channel56Checkbox,
			channel56Delete,
			channel56Edit
	);

	@FindBy(id = "label_vqoChannel60")
	private WebElement channel60Label;

	@FindBy(id = "Server_vqoChannel60")
	private WebElement channel60Checkbox;

	@FindBy(id = "delete_setting_vqoChannel60")
	private WebElement channel60Delete;

	@FindBy(id = "edit_setting_vqoChannel60")
	private WebElement channel60Edit;

	public ConfigPageField channel60Field = new ConfigPageField(
			CHANNEL_60,
			channel60Label,
			channel60Checkbox,
			channel60Delete,
			channel60Edit
	);

	@FindBy(id = "label_vqoChannel64")
	private WebElement channel64Label;

	@FindBy(id = "Server_vqoChannel64")
	private WebElement channel64Checkbox;

	@FindBy(id = "delete_setting_vqoChannel64")
	private WebElement channel64Delete;

	@FindBy(id = "edit_setting_vqoChannel64")
	private WebElement channel64Edit;

	public ConfigPageField channel64Field = new ConfigPageField(
			CHANNEL_64,
			channel64Label,
			channel64Checkbox,
			channel64Delete,
			channel64Edit
	);

	@FindBy(id = "label_vqoChannel100")
	private WebElement channel100Label;

	@FindBy(id = "Server_vqoChannel100")
	private WebElement channel100Checkbox;

	@FindBy(id = "delete_setting_vqoChannel100")
	private WebElement channel100Delete;

	@FindBy(id = "edit_setting_vqoChannel100")
	private WebElement channel100Edit;

	public ConfigPageField channel100Field = new ConfigPageField(
			CHANNEL_100,
			channel100Label,
			channel100Checkbox,
			channel100Delete,
			channel100Edit
	);

	@FindBy(id = "label_vqoChannel104")
	private WebElement channel104Label;

	@FindBy(id = "Server_vqoChannel104")
	private WebElement channel104Checkbox;

	@FindBy(id = "delete_setting_vqoChannel104")
	private WebElement channel104Delete;

	@FindBy(id = "edit_setting_vqoChannel104")
	private WebElement channel104Edit;

	public ConfigPageField channel104Field = new ConfigPageField(
			CHANNEL_104,
			channel104Label,
			channel104Checkbox,
			channel104Delete,
			channel104Edit
	);

	@FindBy(id = "label_vqoChannel108")
	private WebElement channel108Label;

	@FindBy(id = "Server_vqoChannel108")
	private WebElement channel108Checkbox;

	@FindBy(id = "delete_setting_vqoChannel108")
	private WebElement channel108Delete;

	@FindBy(id = "edit_setting_vqoChannel108")
	private WebElement channel108Edit;

	public ConfigPageField channel108Field = new ConfigPageField(
			CHANNEL_108,
			channel108Label,
			channel108Checkbox,
			channel108Delete,
			channel108Edit
	);

	@FindBy(id = "label_vqoChannel112")
	private WebElement channel112Label;

	@FindBy(id = "Server_vqoChannel112")
	private WebElement channel112Checkbox;

	@FindBy(id = "delete_setting_vqoChannel112")
	private WebElement channel112Delete;

	@FindBy(id = "edit_setting_vqoChannel112")
	private WebElement channel112Edit;

	public ConfigPageField channel112Field = new ConfigPageField(
			CHANNEL_112,
			channel112Label,
			channel112Checkbox,
			channel112Delete,
			channel112Edit
	);

	@FindBy(id = "label_vqoChannel116")
	private WebElement channel116Label;

	@FindBy(id = "Server_vqoChannel116")
	private WebElement channel116Checkbox;

	@FindBy(id = "delete_setting_vqoChannel116")
	private WebElement channel116Delete;

	@FindBy(id = "edit_setting_vqoChannel116")
	private WebElement channel116Edit;

	public ConfigPageField channel116Field = new ConfigPageField(
			CHANNEL_116,
			channel116Label,
			channel116Checkbox,
			channel116Delete,
			channel116Edit
	);

	@FindBy(id = "label_vqoChannel120")
	private WebElement channel120Label;

	@FindBy(id = "Server_vqoChannel120")
	private WebElement channel120Checkbox;

	@FindBy(id = "delete_setting_vqoChannel120")
	private WebElement channel120Delete;

	@FindBy(id = "edit_setting_vqoChannel120")
	private WebElement channel120Edit;

	public ConfigPageField channel120Field = new ConfigPageField(
			CHANNEL_120,
			channel120Label,
			channel120Checkbox,
			channel120Delete,
			channel120Edit
	);

	@FindBy(id = "label_vqoChannel124")
	private WebElement channel124Label;

	@FindBy(id = "Server_vqoChannel124")
	private WebElement channel124Checkbox;

	@FindBy(id = "delete_setting_vqoChannel124")
	private WebElement channel124Delete;

	@FindBy(id = "edit_setting_vqoChannel124")
	private WebElement channel124Edit;

	public ConfigPageField channel124Field = new ConfigPageField(
			CHANNEL_124,
			channel124Label,
			channel124Checkbox,
			channel124Delete,
			channel124Edit
	);

	@FindBy(id = "label_vqoChannel128")
	private WebElement channel128Label;

	@FindBy(id = "Server_vqoChannel128")
	private WebElement channel128Checkbox;

	@FindBy(id = "delete_setting_vqoChannel128")
	private WebElement channel128Delete;

	@FindBy(id = "edit_setting_vqoChannel128")
	private WebElement channel128Edit;

	public ConfigPageField channel128Field = new ConfigPageField(
			CHANNEL_128,
			channel128Label,
			channel128Checkbox,
			channel128Delete,
			channel128Edit
	);

	@FindBy(id = "label_vqoChannel132")
	private WebElement channel132Label;

	@FindBy(id = "Server_vqoChannel132")
	private WebElement channel132Checkbox;

	@FindBy(id = "delete_setting_vqoChannel132")
	private WebElement channel132Delete;

	@FindBy(id = "edit_setting_vqoChannel132")
	private WebElement channel132Edit;

	public ConfigPageField channel132Field = new ConfigPageField(
			CHANNEL_132,
			channel132Label,
			channel132Checkbox,
			channel132Delete,
			channel132Edit
	);

	@FindBy(id = "label_vqoChannel136")
	private WebElement channel136Label;

	@FindBy(id = "Server_vqoChannel136")
	private WebElement channel136Checkbox;

	@FindBy(id = "delete_setting_vqoChannel136")
	private WebElement channel136Delete;

	@FindBy(id = "edit_setting_vqoChannel136")
	private WebElement channel136Edit;

	public ConfigPageField channel136Field = new ConfigPageField(
			CHANNEL_136,
			channel136Label,
			channel136Checkbox,
			channel136Delete,
			channel136Edit
	);

	@FindBy(id = "label_vqoChannel140")
	private WebElement channel140Label;

	@FindBy(id = "Server_vqoChannel140")
	private WebElement channel140Checkbox;

	@FindBy(id = "delete_setting_vqoChannel140")
	private WebElement channel140Delete;

	@FindBy(id = "edit_setting_vqoChannel140")
	private WebElement channel140Edit;

	public ConfigPageField channel140Field = new ConfigPageField(
			CHANNEL_140,
			channel140Label,
			channel140Checkbox,
			channel140Delete,
			channel140Edit
	);

	@FindBy(id = "label_vqoChannel144")
	private WebElement channel144Label;

	@FindBy(id = "Server_vqoChannel144")
	private WebElement channel144Checkbox;

	@FindBy(id = "delete_setting_vqoChannel144")
	private WebElement channel144Delete;

	@FindBy(id = "edit_setting_vqoChannel144")
	private WebElement channel144Edit;

	public ConfigPageField channel144Field = new ConfigPageField(
			CHANNEL_144,
			channel144Label,
			channel144Checkbox,
			channel144Delete,
			channel144Edit
	);

	@FindBy(id = "label_vqoChannel149")
	private WebElement channel149Label;

	@FindBy(id = "Server_vqoChannel149")
	private WebElement channel149Checkbox;

	@FindBy(id = "delete_setting_vqoChannel149")
	private WebElement channel149Delete;

	@FindBy(id = "edit_setting_vqoChannel149")
	private WebElement channel149Edit;

	public ConfigPageField channel149Field = new ConfigPageField(
			CHANNEL_149,
			channel149Label,
			channel149Checkbox,
			channel149Delete,
			channel149Edit
	);

	@FindBy(id = "label_vqoChannel153")
	private WebElement channel153Label;

	@FindBy(id = "Server_vqoChannel153")
	private WebElement channel153Checkbox;

	@FindBy(id = "delete_setting_vqoChannel153")
	private WebElement channel153Delete;

	@FindBy(id = "edit_setting_vqoChannel153")
	private WebElement channel153Edit;

	public ConfigPageField channel153Field = new ConfigPageField(
			CHANNEL_153,
			channel153Label,
			channel153Checkbox,
			channel153Delete,
			channel153Edit
	);

	@FindBy(id = "label_vqoChannel157")
	private WebElement channel157Label;

	@FindBy(id = "Server_vqoChannel157")
	private WebElement channel157Checkbox;

	@FindBy(id = "delete_setting_vqoChannel157")
	private WebElement channel157Delete;

	@FindBy(id = "edit_setting_vqoChannel157")
	private WebElement channel157Edit;

	public ConfigPageField channel157Field = new ConfigPageField(
			CHANNEL_157,
			channel157Label,
			channel157Checkbox,
			channel157Delete,
			channel157Edit
	);

	@FindBy(id = "label_vqoChannel161")
	private WebElement channel161Label;

	@FindBy(id = "Server_vqoChannel161")
	private WebElement channel161Checkbox;

	@FindBy(id = "delete_setting_vqoChannel161")
	private WebElement channel161Delete;

	@FindBy(id = "edit_setting_vqoChannel161")
	private WebElement channel161Edit;

	public ConfigPageField channel161Field = new ConfigPageField(
			CHANNEL_161,
			channel161Label,
			channel161Checkbox,
			channel161Delete,
			channel161Edit
	);

	@FindBy(id = "label_vqoChannel165")
	private WebElement channel165Label;

	@FindBy(id = "Server_vqoChannel165")
	private WebElement channel165Checkbox;

	@FindBy(id = "delete_setting_vqoChannel165")
	private WebElement channel165Delete;

	@FindBy(id = "edit_setting_vqoChannel165")
	private WebElement channel165Edit;

	public ConfigPageField channel165Field = new ConfigPageField(
			CHANNEL_165,
			channel165Label,
			channel165Checkbox,
			channel165Delete,
			channel165Edit
	);

	public SamVqoPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(enableVqoField.getTitle(), enableVqoField);
				put(rssiThresholdField.getTitle(), rssiThresholdField);
				put(wifiAutoBandSelectionField.getTitle(), wifiAutoBandSelectionField);
				put(wifi2Dot4BandSelectionField.getTitle(), wifi2Dot4BandSelectionField);
				put(wifi5BandSelectionField.getTitle(), wifi5BandSelectionField);
				put(channel1Field.getTitle(), channel1Field);
				put(channel2Field.getTitle(), channel2Field);
				put(channel3Field.getTitle(), channel3Field);
				put(channel4Field.getTitle(), channel4Field);
				put(channel5Field.getTitle(), channel5Field);
				put(channel6Field.getTitle(), channel6Field);
				put(channel7Field.getTitle(), channel7Field);
				put(channel8Field.getTitle(), channel8Field);
				put(channel9Field.getTitle(), channel9Field);
				put(channel10Field.getTitle(), channel10Field);
				put(channel11Field.getTitle(), channel11Field);
				put(channel12Field.getTitle(), channel12Field);
				put(channel13Field.getTitle(), channel13Field);
				put(channel14Field.getTitle(), channel14Field);
				put(channel36Field.getTitle(), channel36Field);
				put(channel40Field.getTitle(), channel40Field);
				put(channel44Field.getTitle(), channel44Field);
				put(channel48Field.getTitle(), channel48Field);
				put(channel52Field.getTitle(), channel52Field);
				put(channel56Field.getTitle(), channel56Field);
				put(channel60Field.getTitle(), channel60Field);
				put(channel64Field.getTitle(), channel64Field);
				put(channel100Field.getTitle(), channel100Field);
				put(channel104Field.getTitle(), channel104Field);
				put(channel108Field.getTitle(), channel108Field);
				put(channel112Field.getTitle(), channel112Field);
				put(channel116Field.getTitle(), channel116Field);
				put(channel120Field.getTitle(), channel120Field);
				put(channel124Field.getTitle(), channel124Field);
				put(channel128Field.getTitle(), channel128Field);
				put(channel132Field.getTitle(), channel132Field);
				put(channel136Field.getTitle(), channel136Field);
				put(channel140Field.getTitle(), channel140Field);
				put(channel144Field.getTitle(), channel144Field);
				put(channel149Field.getTitle(), channel149Field);
				put(channel153Field.getTitle(), channel153Field);
				put(channel157Field.getTitle(), channel157Field);
				put(channel161Field.getTitle(), channel161Field);
				put(channel165Field.getTitle(), channel165Field);
			}
		};
	}
}
