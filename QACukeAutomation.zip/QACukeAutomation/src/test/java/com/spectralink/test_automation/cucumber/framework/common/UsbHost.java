package com.spectralink.test_automation.cucumber.framework.common;

import com.jcraft.jsch.JSchException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.*;

public class UsbHost {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private Integer nextPort = 5000;
	private Integer nextBootstrapPort = 5100;
	private Boolean localContext = true;
	private List<String> samPhones;
	private Map<String, TestPhone> devices = new HashMap<>();
	private String hostAddress = RunDefaults.getStringSetting("usbHostAddress");
	private String hostAccount = RunDefaults.getDecryptedSetting("usbHostAccount");
	private String hostPassword = RunDefaults.getDecryptedSetting("usbHostPassword");

	public UsbHost(List<String> registeredPhones) {
		samPhones = registeredPhones;

		String hostAddress = RunDefaults.getStringSetting("usbHostAddress");
		InetAddress candidate = null;
		try {
			Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
			for (NetworkInterface nic : Collections.list(nets)) {
				Enumeration<InetAddress> inetAddresses = nic.getInetAddresses();
				for (InetAddress inetAddress : Collections.list(inetAddresses)) {
					if (inetAddress.getHostAddress().matches("^172.*")) {
						localContext = inetAddress.getHostAddress().contains(hostAddress);
						candidate = inetAddress;
						break;
					}
				}
			}
		} catch (SocketException se) {
			log.error(Util.glue("Socket error while getting network interfaces:", se.getMessage()));
		}

		if (hostAddress == null && candidate != null) hostAddress = candidate.getHostAddress();
		String context = localContext ? "local" : "remote";
		log.info("Accessing USB bus on the {} machine at {}", context, hostAddress);
		loadAdbDevices();
	}

	public UsbHost(String hostAddress, String hostAccount, String hostPassword, List<String> registeredPhones) {
		this.hostAddress = hostAddress;
		this.hostAccount = hostAccount;
		this.hostPassword = hostPassword;
		samPhones = registeredPhones;

		InetAddress candidate = null;
		try {
			Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
			for (NetworkInterface nic : Collections.list(nets)) {
				Enumeration<InetAddress> inetAddresses = nic.getInetAddresses();
				for (InetAddress inetAddress : Collections.list(inetAddresses)) {
					if (inetAddress.getHostAddress().matches("^172.*")) {
						localContext = inetAddress.getHostAddress().contains(hostAddress);
						candidate = inetAddress;
						break;
					}
				}
			}
		} catch (SocketException se) {
			log.error(Util.glue("Socket error while getting network interfaces:", se.getMessage()));
		}

		if (hostAddress == null && candidate != null) hostAddress = candidate.getHostAddress();
		String context = localContext ? "local" : "remote";
		log.info("Accessing USB bus on the {} machine at {}", context, hostAddress);
		loadAdbDevices();
	}

	public Map<String, TestPhone> getDeviceMap() {
		return devices;
	}

	public void reloadDevices() {
		loadAdbDevices();
	}

	public Integer getNextPort() {
		return nextPort++;
	}

	public Integer getNextBootstrapPort() {
		return nextBootstrapPort++;
	}

	public Map<String, TestPhone> getDevices() {
		return devices;
	}

	public Boolean inLocalContext() {
		return localContext;
	}

	public void setLocalContext(Boolean localContext) {
		this.localContext = localContext;
	}

	public String getHostAddress() {
		return hostAddress;
	}

	public String getHostAccount() {
		return hostAccount;
	}

	public String getHostPassword() {
		return hostPassword;
	}

	public TestPhone getPhone(String serialNumber) {
		TestPhone chosenDevice = devices.get(serialNumber);
		if (chosenDevice != null) {
			log.trace(chosenDevice.getIdentity());
			return chosenDevice;
		} else {
			return null;
		}
	}

	public TestPhone getRandomPhone() {
		if (devices.size() == 0) {
			log.error("No devices were present on the USB bus");
			return null;
		} else if (devices.size() == 1) {
			TestPhone onlyDevice = getPhone((String) devices.keySet().toArray()[0]);
			log.debug(onlyDevice.getIdentity());
			return onlyDevice;
		} else {
			Random random = new Random();
			int randomIndex = random.nextInt(devices.size());
			TestPhone chosenDevice = getPhone((String) devices.keySet().toArray()[randomIndex]);
			log.debug(chosenDevice.getIdentity());
			return chosenDevice;
		}
	}

	public VersityPhone getRandomVersityPhone() {
		List<VersityPhone> phones = getVersityPhones();
		if (phones.size() == 0) {
			log.error("No Versity phones were present on the USB bus");
			return null;
		} else if (phones.size() == 1) {
			VersityPhone onlyDevice = phones.get(0);
			return onlyDevice;
		} else {
			Random random = new Random();
			int randomIndex = random.nextInt(phones.size());
			VersityPhone chosenDevice = phones.get(randomIndex);
			return chosenDevice;
		}
	}

	public VersityPhone getRandomVersityScannerPhone() {
		List<VersityPhone> phones = getVersityScannerPhones();
		if (phones.size() == 0) {
			log.error("No Versity scanner phones were present on the USB bus");
			return null;
		} else if (phones.size() == 1) {
			VersityPhone onlyDevice = phones.get(0);
			log.info(onlyDevice.getIdentity());
			return onlyDevice;
		} else {
			Random random = new Random();
			int randomIndex = random.nextInt(phones.size());
			VersityPhone chosenDevice = phones.get(randomIndex);
			log.info(chosenDevice.getIdentity());
			return chosenDevice;
		}
	}

	public List<VersityPhone> getVersityPhoneCount(int count) {
		List<VersityPhone> phones = getVersityPhones();
		List<VersityPhone> phoneList = new ArrayList<>();
		if (phones.size() == 0) {
			log.error("No Versity phones were present on the USB bus");
		} else if (phones.size() == 1) {
			VersityPhone onlyDevice = phones.get(0);
			phoneList.add(onlyDevice);
			log.debug(onlyDevice.getIdentity());
		} else if (phones.size() < count) {
			for (VersityPhone phone : phones) {
				phoneList.add(phone);
				log.debug(phone.getIdentity());
			}
		} else {
			int attempts = 0;
			while (phoneList.size() != count && attempts < 20) {
				VersityPhone candidate = getRandomVersityPhone();
				if (!phoneList.contains(candidate)) {
					VersityPhone phone = getRandomVersityPhone();
					phoneList.add(phone);
					log.debug(phone.getIdentity());
				}
				attempts += 1;
			}
		}
		return phoneList;
	}

	public List<String> getVersityPhoneSerials(int count) {
		List<VersityPhone> phones = getVersityPhones();
		List<String> serialList = new ArrayList<>();
		if (phones.size() == 0) {
			log.error("No Versity phones were present on the USB bus");
		} else if (phones.size() == 1) {
			VersityPhone onlyDevice = phones.get(0);
			serialList.add(onlyDevice.getSerialNumber());
		} else if (phones.size() < count) {
			for (VersityPhone phone : phones) {
				serialList.add(phone.getSerialNumber());
			}
		} else {
			int attempts = 0;
			while (serialList.size() != count && attempts < 20) {
				VersityPhone candidate = getRandomVersityPhone();
				if (!serialList.contains(candidate.getSerialNumber())) {
					serialList.add(candidate.getSerialNumber());
				}
				attempts += 1;
			}
		}
		return serialList;
	}

	public OtherPhone getRandomOtherPhone() {
		List<OtherPhone> phones = getOtherPhones();
		if (phones.size() == 0) {
			log.error("No other phones were present on the USB bus");
			return null;
		} else if (phones.size() == 1) {
			OtherPhone onlyDevice = phones.get(0);
			log.debug(onlyDevice.getIdentity());
			return onlyDevice;
		} else {
			Random random = new Random();
			int randomIndex = random.nextInt(phones.size());
			OtherPhone chosenDevice = phones.get(randomIndex);
			log.debug(chosenDevice.getIdentity());
			return chosenDevice;
		}
	}

	public CliResult executeCommand(ArrayList<String> command) throws JSchException, IOException {
		//setLocalContext(false);
		if (inLocalContext()) {
			Shell shell = new Shell();
			return shell.executeCommand(command);
		} else {
			String remoteAddress = hostAddress;
			String remoteAccount = hostAccount;
			String remotePassword = hostPassword;
			RemoteShell shell = new RemoteShell(remoteAddress, remoteAccount, remotePassword);
			return shell.executeCommand(command);
		}
	}

	public void loadAdbDevices() {
		ArrayList<String> command = new ArrayList<>();
		command.add("adb");
		command.add("devices");
		command.add("-l");
		CliResult result = null;
		try {
			result = executeCommand(command);
			String serial = "unknown";
			String status = "unknown";
			String usbPath = "unknown";
			String productName = "unknown";
			String modelName = "unknown";
			String deviceName ="unknown";
			String transportId = "unknown";
			if (result.getExitCode() == 0) {
				devices.clear();
				for (String line : result.getStdoutLines()) {
					Scanner scanner = new Scanner(line);
					try {
						scanner.findInLine("(^[a-z0-9]+)\\s+");
						serial = scanner.match().group(1);
						scanner.findInLine("(\\w+)\\s+");
						status = scanner.match().group(1);
						if (status.contentEquals("device")) {
							List<String> searchFields = new ArrayList<>();
							try {
								scanner.findInLine("usb:(\\S+)\\s+");
								usbPath = scanner.match().group(1);
							} catch (IllegalStateException ise) {
								//usb path only exists in Linux
							}

							try {
								scanner.findInLine("product:(\\w+)\\s+");
								productName = scanner.match().group(1);
								searchFields.add(productName.toLowerCase());
							} catch (IllegalStateException ise) {
								log.warn("Phone with serial {} is missing product identifier", serial);
								productName = "missing";
							}

							try {
								scanner.findInLine("model:(\\w+)\\s+");
								modelName = scanner.match().group(1);
								searchFields.add(modelName.toLowerCase());
							} catch (IllegalStateException ise) {
								log.warn("Phone with serial {} is missing model identifier", serial);
								modelName = "missing";
							}

							try {
								scanner.findInLine("device:(\\w+)\\s+");
								deviceName = scanner.match().group(1);
								searchFields.add(deviceName.toLowerCase());
							} catch (IllegalStateException ise) {
								log.warn("Phone with serial {} is missing device identifier", serial);
								deviceName = "missing";
							}

							try {
								scanner.findInLine("transport_id:(\\w+)\\s+");
								transportId = scanner.match().group(1);
							} catch (IllegalStateException ise) {
								//transport may get truncated in Windows
							}

							if (samPhones.isEmpty() || samPhones.contains(serial)) {
								TestPhone device;
								log.trace("Found device type {} with serial {}", productName.toLowerCase(), serial);
								if (searchFields.contains("apollo") || searchFields.contains("versity")
										|| searchFields.contains("versity_9540")
										||searchFields.contains("saturn") || searchFields.contains("vc9240")
										|| searchFields.contains("vc9253")) {
									device = new VersityPhone(this, serial, status, usbPath);
								} else {
									device = new OtherPhone(this, serial, status, usbPath);
								}
								device.setPortNumber(getNextPort());
								device.setBootstrapPortNumber(getNextBootstrapPort());
								device.setUsbPath(usbPath);
								device.setTransportId(transportId);
								device.setConnectedViaAdb(true);
								getDevices().put(serial, device);
								log.debug("Found test device {}", device.getSerialNumber());
							}
						} else {
							log.warn("Found test device {} but its status was {}", serial, status);
						}
					} catch (IllegalStateException ise) {
						//catches failure to find serial number
					}
				}
			} else {
				log.error("ADB shell call failed with code {}", result.getExitCode());
			}
		} catch (JSchException je) {
			log.error("Encountered JSch Exception: {}", je.getMessage());
		} catch (IOException ioe) {
			log.error("Encountered IO Exception: {}", ioe.getMessage());
		}
	}

	public List<String> getAdbDeviceSerials() {
		ArrayList<String> serials = new ArrayList<>();
		for (String serialNumber : getDevices().keySet()) {
			serials.add(serialNumber);
		}
		return serials;
	}

	public List<TestPhone> getAdbDevices() {
		ArrayList<TestPhone> allDevices = new ArrayList<>();
		for (String serialNumber : devices.keySet()) {
			allDevices.add(getDevices().get(serialNumber));
		}
		return allDevices;
	}

	public List<VersityPhone> getVersityPhones() {
		ArrayList<VersityPhone> allVersityPhones = new ArrayList<>();
		for (TestPhone phone : getAdbDevices()) {
			if (phone.getPhoneType().equals(AndroidPhone.PhoneType.VERSITY)) {
				allVersityPhones.add((VersityPhone) phone);
			}
		}
		return allVersityPhones;
	}

	public List<VersityPhone> getVersityScannerPhones() {
		ArrayList<VersityPhone> allVersityPhones = new ArrayList<>();
		for (TestPhone phone : getAdbDevices()) {
			if (phone.getPhoneType().equals(AndroidPhone.PhoneType.VERSITY) && phone.hasBarcodeScanner()) {
				allVersityPhones.add((VersityPhone) phone);
			}
		}
		return allVersityPhones;
	}

	public VersityPhone getVersityPhone(String serialNumber) {
		if (devices.containsKey(serialNumber) && devices.get(serialNumber).getPhoneType().equals(AndroidPhone.PhoneType.VERSITY)) {
			return (VersityPhone) devices.get(serialNumber);
		} else {
			log.error("Could not find Versity phone with serial {}", serialNumber);
			return null;
		}
	}

	public List<OtherPhone> getOtherPhones() {
		ArrayList<OtherPhone> allOtherPhones = new ArrayList<>();
		for (TestPhone phone : getAdbDevices()) {
			if (phone.getPhoneType().equals(AndroidPhone.PhoneType.OTHER)) {
				allOtherPhones.add((OtherPhone) phone);
			}
		}
		return allOtherPhones;
	}

	public List<VersityPhone> getAllVersityPhones() {
		ArrayList<VersityPhone> allVersityPhones = new ArrayList<>();
		for (TestPhone phone : getAdbDevices()) {
			if (phone.getPhoneType().equals(AndroidPhone.PhoneType.VERSITY)) {
				allVersityPhones.add((VersityPhone) phone);
			}
		}
		return allVersityPhones;
	}

	public OtherPhone getOtherPhone(String serialNumber) {
		if (devices.containsKey(serialNumber) && devices.get(serialNumber).getPhoneType().equals(AndroidPhone.PhoneType.OTHER)) {
			return (OtherPhone) devices.get(serialNumber);
		} else {
			log.warn("Could not find other phone with serial {}", serialNumber);
			return null;
		}
	}

	public TestPhone getDeviceByMacAddress(String macAddress) {
		for (TestPhone phone : getAdbDevices()) {
			if (phone.getMacAddress().contentEquals(macAddress)) {
				return phone;
			}
		}
		return null;
	}

	public String getSerialByMacAddress(String macAddress) {
		for (TestPhone device : getAdbDevices()) {
			if (macAddress.toLowerCase().contains(device.getMacAddress().toLowerCase())) {
				return device.getSerialNumber();
			}
		}
		return null;
	}

	public VersityPhone getVersityLtePhone() {
		for (VersityPhone phone : getVersityPhones()) {
			if (phone.getModel().toLowerCase().contains("9640") || phone.getModel().toLowerCase().contains("9653"))
				return phone;
		}
		return null;
	}

	public VersityPhone getVersityWifiPhone() {
		for (VersityPhone phone : getVersityPhones()) {
			if (phone.getModel().toLowerCase().contains("9540") || phone.getModel().toLowerCase().contains("9553")) {
				return phone;
			}
		}
		return null;
	}

}





