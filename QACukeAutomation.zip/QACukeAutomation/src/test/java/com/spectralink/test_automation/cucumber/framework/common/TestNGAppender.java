package com.spectralink.test_automation.cucumber.framework.common;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.appender.AppenderLoggingException;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginElement;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.PatternLayout;
import org.testng.Reporter;

import java.io.Serializable;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

// pipe log4j messages into testng report

// note: class name need not match the @Plugin name.
@Plugin(name = "TestNGAppender", category = "Core", elementType = "appender", printObject = true)
public final class TestNGAppender extends AbstractAppender {
	private static final Logger log = LogManager.getLogger(TestNGAppender.class.getName());
	private static final long serialVersionUID = 1L;
	private final ReadWriteLock rwLock = new ReentrantReadWriteLock();
	private final Lock readLock = rwLock.readLock();

	protected TestNGAppender(String name, Filter filter,
                             Layout<? extends Serializable> layout, final boolean ignoreExceptions) {
		super(name, filter, layout, ignoreExceptions);
		log.debug("appender instantiated");
	}


	@Override
	public void append(LogEvent event) {
		readLock.lock();
		try {
			byte[] bytes = getLayout().toByteArray(event);
			String eventStr = new String(bytes);
			Reporter.log(eventStr, /*logToStandardOut=*/ false);

		} catch (Exception ex) {
			if (!ignoreExceptions()) {
				throw new AppenderLoggingException(ex);
			}
		} finally {
			readLock.unlock();
		}
	}


	@PluginFactory
	public static TestNGAppender createAppender(
			@PluginAttribute("name") String name,
			@PluginElement("Layout") Layout<? extends Serializable> layout,
			@PluginElement("Filter") final Filter filter,
			@PluginAttribute("otherAttribute") String otherAttribute) {
		if (name == null) {
			LOGGER.error("No name provided for MyCustomAppenderImpl");
			return null;
		}
		if (layout == null) {
			layout = PatternLayout.createDefaultLayout();
		}
		log.info("TestNG appender started for " + name);
		return new TestNGAppender(name, filter, layout, true);
	}
}

