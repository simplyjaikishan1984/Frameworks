package com.spectralink.test_automation.cucumber.framework.device.common;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class ButtonPressThread implements Runnable {

    private ConfigUiField field;
    private final Integer holdSeconds;
    private final Integer delaySeconds;
    private final Integer waitSeconds;

    public ButtonPressThread(ConfigUiField field, int delaySeconds, int holdSeconds, int waitSeconds) {
        this.field = field;
        this.delaySeconds = delaySeconds;
        this.holdSeconds = holdSeconds;
        this.waitSeconds = waitSeconds;
    }

    public void run() {
        sleepSeconds(delaySeconds);
        field.longPress(holdSeconds);
        sleepSeconds(waitSeconds);
    }
}
