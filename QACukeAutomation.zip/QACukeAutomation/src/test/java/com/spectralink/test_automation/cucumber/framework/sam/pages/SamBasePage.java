package com.spectralink.test_automation.cucumber.framework.sam.pages;

import com.spectralink.test_automation.cucumber.framework.sam.SamAutomation;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamConfigurationPage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamBasePage extends SamAutomation {
	private Logger log = LogManager.getLogger(this.getClass().getName());

	@FindBy(id = "leftPanel-main-0")
	private WebElement devices;

	@FindBy(id = "leftPanel-Devices-sub-holding_area")
	private WebElement deviceHoldingArea;

	@FindBy(id = "leftPanel-Devices-sub-device_list")
	private WebElement deviceList;

	@FindBy(id = "leftPanel-main-1")
	private WebElement applications;

	@FindBy(id = "leftPanel-main-2")
	private WebElement groups;

	@FindBy(id = "leftPanel-main-3")
	private WebElement batchConfiguration;

	@FindBy(id = "leftPanel-main-4")
	private WebElement licenses;

	@FindBy(id = "leftPanel-main-5")
	private WebElement copyConfig;

	@FindBy(id = "leftPanel-main-6")
	private WebElement aboutSam;

	@FindBy(id = "leftPanel-logout")
	private WebElement logout;

	@FindBy(id="menu_toggle")
	private WebElement expandMenu;

	@FindBy(id="leftPanel-icon-expand")
	private WebElement expandMenuBtn;

	@FindBy(id="leftPanel-icon-collapse")
	private WebElement collapseMenuBtn;

	@FindBy(id = "page-title-head")
	private WebElement title;

	@FindBy(id = "myaccount-navbar-username")
	private WebElement accountUserName;

	@FindBy(id = "preferences-link")
	private WebElement preferencesLink;

	public SamBasePage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public SamAboutSamPage goToAboutUsPage() {
		clickOnPageEntity(aboutSam);
		sleepSeconds(1);
		return new SamAboutSamPage();
	}

	public SamDeviceListPage goToDeviceListPage() {
		clickOnPageEntity(devices);
		clickOnPageEntity(deviceList);
		sleepSeconds(1);
		return new SamDeviceListPage();
	}

	public SamDeviceHoldingAreaPage goToDeviceHoldingAreaPage() {
		clickOnPageEntity(devices);
		clickOnPageEntity(deviceHoldingArea);
		sleepSeconds(1);
		return new SamDeviceHoldingAreaPage();
	}

	public SamConfigurationPage goToApplications() {
		clickOnPageEntity(applications);
		sleepSeconds(1);
		return new SamConfigurationPage();
	}

	public SamManageGroupsPage goToManageGroups() {
		clickOnPageEntity(groups);
		sleepSeconds(1);
		return new SamManageGroupsPage();
	}

	public SamBatchConfigPage goToBatchConfig() {
		clickOnPageEntity(batchConfiguration);
		sleepSeconds(1);
		return new SamBatchConfigPage();
	}

	public SamFeatureLicensePage goToFeatureLicense() {
		clickOnPageEntity(licenses);
		sleepSeconds(1);
		return new SamFeatureLicensePage();
	}

	public SamCopyConfigPage goToCopyConfig() {
		clickOnPageEntity(copyConfig);
		sleepSeconds(1);
		return new SamCopyConfigPage();
	}

	public SamLoginPage clickLogOut() {
		clickOnPageEntity(logout);
		sleepSeconds(2);
		return new SamLoginPage();
	}

	public String getAccountName() {
		return accountUserName.getAttribute("innerText");
	}

	public boolean onLoginPage() {
		return isPresent(By.id("loginForm"));
	}
}
