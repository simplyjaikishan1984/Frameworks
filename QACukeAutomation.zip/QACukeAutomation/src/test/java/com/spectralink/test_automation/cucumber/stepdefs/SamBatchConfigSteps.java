package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.CSVHeading;
import com.spectralink.test_automation.cucumber.framework.common.CSVStructuredFile;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamBatchConfigPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.nio.file.Path;
import java.nio.file.Paths;

import static com.spectralink.test_automation.cucumber.stepdefs.SamBatchConfigSteps.BatchHeading.MAC;

public class SamBatchConfigSteps {

    public enum BatchHeading implements CSVHeading {
        MAC("mac address", "mac"),
        GROUP("group", "group"),
        SIP_1_EXT("sip 1 extension", "phone sip1_extension string"),
        SIP_1_NAME("sip 1 username", "phone sip1_username string"),
        SIP_1_PASS("sip 1 password", "phone sip1_password string"),
        SIP_2_EXT("sip 2 extension", "phone sip2_extension string"),
        SIP_2_NAME("sip 2 username", "phone sip2_username string"),
        SIP_2_PASS("sip 2 password", "phone sip2_password string"),
        PTT_NAME("ptt username", "slnkptt username string"),
        DEVICE_INFO_1("device info 1", "slnkdevicesettings device_info_1 string"),
        DEVICE_INFO_2("device info 2", "slnkdevicesettings device_info_2 string"),
        DEVICE_INFO_3("device info 3", "slnkdevicesettings device_info_3 string"),
        DEVICE_INFO_4("device info 4", "slnkdevicesettings device_info_4 string"),
        DEVICE_NAME("device name", "slnkdevicesettings device_name string"),
        BAD_HEADING("bad heading", "wrong"),
        EMPTY_HEADING("empty heading", "");

        private final String key;
        private final String heading;

        BatchHeading(String key, String heading) {
            this.key = key;
            this.heading = heading;
        }

        public String getKey() {
            return key;
        }

        public String getTitle() {
            return heading;
        }
    }

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    private BatchHeading getHeading(String name) {
        for (BatchHeading heading : BatchHeading.values()) {
            if (heading.getKey().toLowerCase().contentEquals(name.trim().toLowerCase())) {
                return heading;
            }
        }
        return null;
    }

    @When("^I click the 'Browse Batch Files' button$")
    public void clickBrowseButton() {
        SamBatchConfigPage batchPage = (SamBatchConfigPage) Environment.getCurrentPage();
        batchPage.clickBrowseFilesButton();
    }

    @When("^I click the 'Click To Download Batch File Sample' link$")
    public void clickDownloadNonGroupSample() {
        SamBatchConfigPage batchPage = (SamBatchConfigPage) Environment.getCurrentPage();
        batchPage.clickBatchFileNoGroupLink();
    }

    @When("^I click the 'Click To Download Batch File\\(WITH GROUP\\) Sample' link$")
    public void clickDownloadGroupSample() {
        SamBatchConfigPage batchPage = (SamBatchConfigPage) Environment.getCurrentPage();
        batchPage.clickBatchFileWithGroupLink();
    }

    @When("^I select the file \"([^\"]*)\" from the Batch Configuration file browser$")
    public void selectFile(String arg1) {
        SamBatchConfigPage batchPage = (SamBatchConfigPage) Environment.getCurrentPage();
        Path exportFilePath = Paths.get(Environment.getProjectDirectory(), "src/test/resources", arg1.trim());
        batchPage.selectBatchFile(exportFilePath.toFile());
    }

    @Then("^the Batch Configuration file \"([^\"]*)\" uploaded successfully$")
    public void uploadSuccessful(String arg1) {
        SamBatchConfigPage batchPage = (SamBatchConfigPage) Environment.getCurrentPage();
        if (batchPage.uploadSuccessful()) {
            log.debug("The file {} uploaded successfully", arg1);
        } else {
            log.error("The file {} was not accepted by SAM", arg1);
            Assert.fail("Batch File Upload Failure");
        }
    }

    @Then("^the Batch Configuration file \"([^\"]*)\" failed to upload$")
    public void uploadFailed(String arg1) {
        SamBatchConfigPage batchPage = (SamBatchConfigPage) Environment.getCurrentPage();
        if (!batchPage.uploadFailed()) {
            log.debug("The file {} failed to upload as expected", arg1);
        } else {
            log.error("The file {} uploaded with a bad column heading", arg1);
            Assert.fail("Batch File Upload Failure");
        }
    }

    @Then("^I delete the Batch Configuration file \"([^\"]*)\"$")
    public void deleteBatchConfig(String arg1) {
        Path exportFilePath = Paths.get(Environment.getProjectDirectory(), "src/test/resources", arg1.trim());
        if (exportFilePath.toFile().delete()) {
            log.debug("Deleted batch configuration file {}", arg1);
        } else {
            log.error("Could not delete batch configuration file {}", arg1);
        }
    }

    @When("^I create a batch file for device\\(s\\) \"([^\"]*)\" named \"([^\"]*)\"$")
    public void createBatchFile(String arg1, String arg2) {
        Path exportFilePath = Paths.get(Environment.getProjectDirectory(), "src/test/resources", arg2.trim());
        CSVStructuredFile csv = new CSVStructuredFile(BatchHeading.class);
        csv.addColumn(MAC);
        for (String device : arg1.trim().split("\\s*,\\s*")) {
            VersityPhone phone = Environment.getPhone(device);
            int row = csv.addRow();
            csv.setCellInRow(row, MAC, phone.getMacAddress());
        }
        csv.setOutputFile(exportFilePath.toFile());
        csv.includeOutputHeadings(true);
        csv.writeFile();
    }

    @When("^I set the column \"([^\"]*)\" for device \"([^\"]*)\" with value \"([^\"]*)\" in batch file \"([^\"]*)\"$")
    public void addBatchFileColumn(String arg1, String arg2, String arg3, String arg4) {
        Path exportFilePath = Paths.get(Environment.getProjectDirectory(), "src/test/resources", arg4.trim());
        CSVStructuredFile csv = new CSVStructuredFile(BatchHeading.class);
        if (exportFilePath.toFile().exists()) {
            csv.parseFile(exportFilePath.toFile());
            SamBatchConfigSteps.BatchHeading column = getHeading(arg1.trim().toLowerCase());
            if (column != null) {
                int targetRow = -1;
                if (!csv.headingExists(column)) {
                    csv.addColumn(column);
                }
                VersityPhone phone = Environment.getPhone(arg2.trim());
                targetRow = csv.findRowWithValue(MAC, phone.getMacAddress());
                if (targetRow != -1) {
                    csv.setCellInRow(targetRow, column, arg3.trim());
                    csv.setOutputFile(exportFilePath.toFile());
                    csv.includeOutputHeadings(true);
                    csv.writeFile();
                } else {
                    log.error("Device {} was not previously added to file {}", arg2, arg4);
                    Assert.fail("SAM UI Interaction Error");
                }
            } else {
                log.error("Heading {} is not an option", arg1);
                Assert.fail("SAM UI Interaction Error");
            }
        } else {
            log.error("File {} has not been created", arg4);
            Assert.fail("File Could Not Be Found");
        }
    }

    @Then("^the file \"([^\"]*)\" contains column \"([^\"]*)\" with the value \"([^\"]*)\"$")
    public void verifyFileIncludesMac(String arg1, String arg2, String arg3) {
        Path exportFilePath = Paths.get(Environment.getProjectDirectory(), "src/test/resources", arg1.trim());
        CSVStructuredFile csv = new CSVStructuredFile(BatchHeading.class);
        if (exportFilePath.toFile().exists()) {
            csv.parseFile(exportFilePath.toFile());
            SamBatchConfigSteps.BatchHeading column = getHeading(arg2.trim().toLowerCase());
            if (column != null) {
                int valueRow = csv.findRowWithValue(column, arg3.trim());
                if (valueRow != -1) {
                    log.debug("File {} contained value '{}' in column {}", arg1, arg3, column.getTitle());
                } else {
                    log.error("Value '{}' was not found in file {}", arg3, arg1);
                    Assert.fail("Sample File Invalid");
                }
            } else {
                log.error("Heading {} is not an option", arg2);
                Assert.fail("SAM UI Interaction Error");
            }
        } else {
            log.error("File {} has not been created", arg1);
            Assert.fail("File Could Not Be Found");
        }
    }
}