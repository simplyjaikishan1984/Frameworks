package com.spectralink.test_automation.cucumber.framework.device.fields;

import com.spectralink.test_automation.cucumber.framework.common.FieldData;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application;

public class DeviceFields {

	public enum BattLifeStrings implements FieldData {
		OVERFLOW_MENU("More options", null),
		OVERFLOW_MENU_SETTINGS("Settings option", null),
		OVERFLOW_MENU_ABOUT("About option", null),
		CHARGE_HOURS_LEFT("Charge hours left", null),
		CHARGE_MINUTES_LEFT("Charge minutes left", null),
		CHARGE_TIME_LEFT("Charge time left", null),
		USB_CONNECTOR("Powered", null),
		BATTERY_CHARGE("Battery charge", null),
		BATTERY_SERIAL("Serial", null),
		BATTERY_CAPACITY("Battery capacity", null),
		SECONDARY_BATTERY_CHARGE("Secondary battery", null),
		BATTERY_TEMPERATURE("Temperature", null),
		BATTERY_HEALTH("Health", null),
		BATTERY_STATUS("Status", null),
		BATTERY_VOLTAGE("Voltage", null),
		BATTERY_TYPE("Type", null),
		BATTERY_CHARGE_CYCLE("Charge cycle completed", null),
		BACK_ARROW("Back arrow", null),
		ALARM_VOLUME("Alarm volume", "batt_alarm_volume"),
		ENABLE_BATTERY_MONITORING("Enable battery monitoring", "batt_life_enabled"),
		VIBRATE_WARNING("Vibrate", "vibrate_enabled"),
		SOUND_WARNING("Sound", "sound_enabled"),
		LOW_ALARM_TONE("Alarm tone", "batt_alarm_tone"),
		LOW_THRESHOLD_LEVEL("Low battery threshold", "alert_level"),
		LOW_WARNING_SNOOZE_TIME("Snooze time", "batt_alarm_snooze_time"),
		ADDITIONAL_OPTIONS("Open additional metrics and options", null),
		WARNING_SNOOZE_MESSAGE("Snooze icon", null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		BattLifeStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum AmieAgentStrings implements FieldData {
		OVERFLOW_MENU("More options", null),
		ENABLE_AMIE("Enable AMiE", "amie_agent_enabled"),
		ENDPOINT_URL("Endpoint URL", "cloud_endpoint"),
		EDIT_ENDPOINT_URL("Endpoint URL prompt", null),
		CONNECTION("Connection details", null),
		NETWORK_FREQUENCY("Network metrics frequency", "network_metrics_frequency"),
		DEVICE_FREQUENCY("Device metrics frequency", "device_metrics_frequency"),
		BATTERY_FREQUENCY("Battery metrics frequency", "battery_metrics_frequency"),
		LAST_CONNECT("Last connect time", null),
		LAST_DISCONNECT("Last disconnect time", null),
		LAST_UPLOAD("Last upload time", null),
		DEV_OPTIONS("Developer options", "developer_options"),
		ENABLE_DEBUG_NOTIFICATIONS("Enable debug notifications", null),
		UPLOAD_TO_CLOUD("Upload to cloud", null),
		PUBLISH_TOPIC("Publish topic", null),
		BUFFER_SIZE("Buffer size", "max_rows"),
		RECENT_METRICS("List recent metrics", null),
		BATTERY_METRICS("Capture battery metrics", null),
		NETWORK_METRICS("Capture network metrics", null),
		DEVICE_METRICS("Capture device metrics", null),
		CONNECTION_BANNER("Connection banner", null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		AmieAgentStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum BizPhoneStrings implements FieldData {
		OVERFLOW_MENU("More options", null),
		CANCEL_TRANSFER("cancel", null),
		OVERFLOW_MENU_SETTINGS("Settings option", null),
		SEARCH_MAGNIFY_ICON("Search magnify", null),
		OVERFLOW_MENU_ABOUT("About option", null),
		OVERFLOW_MENU_BIZ_STATUS("Biz Status", null),
		OVERFLOW_MENU_CISCO_STATUS("Cisco Phone Status", null),
		OVERFLOW_MENU_CLEAR_CALL_LOG("Clear call log", null),
		OVERFLOW_MENU_CALL_FORWARDING("Call forwarding", null),
		OVERFLOW_MENU_SPEED_DIAL("Speed dial", null),
		BACK_ARROW("Back arrow", null),
		CROSS_BUTTON("Cross", null),
		FAVORITES_TAB("Favorites tab", null),
		CALL_LOGS_TAB("Call logs tab", null),
		CONTACTS_TAB("Contacts tab", null),
		VOICEMAIL_TAB("Voicemail tab", null),
		DIALPAD_TAB("Dialpad Tab", null),
		DIALPAD_EDIT_TEXT("Dialpad edit text", null),
		DIALPAD_BACK_BUTTON("Dialpad back button", null),
		FLOATING_DIALER_BUTTON("Dialer", null),
		AUDIO_PATH("Audio path", null),
		RINGTONE_REG_1("Reg 1 ringtone", null),
		RINGTONE_REG_2("Reg 2 ringtone", null),
		HAC("Hearing aid compatibility", null),
		ANC("Automatic noise cancellation", null),
		AUTO_ANSWER("Automatically answer calls", null),
		VIBRATE_BEFORE_RING("Vibrate before ring", null),
		FADE_IN_RING("Fade in ring", null),
		AUTO_DIAL("Enable autodial", null),
		DIALPAD_AS_DEFAULT_TAB("Dialpad as default tab", null),
		ENABLE_SIP("Enable SIP", "sip_enabled"),
		EXPOSE_BUTTON("Expose option", null),
		REGISTRATION_1("Registration 1", null),
		SIP_SERVER("Sip server", null),
		SIP_SERVER_PORT("Sip server port", null),
		TRANSPORT("Transport", null),
		SRTP("SRTP enable", null),
		EXTENSION_NUMBER("Extension number", null),
		USERNAME("Username", null),
		PASSWORD("Password", null),
		VOICEMAIL_ADDRESS("Voicemail retrieval address", null),
		CALL_FORWARDING("Allow call forwarding", null),
		VENDOR_PROTOCOL("Use vendor protocol if licensed", null),
		SIP_STANDARD_HOLD_SIGNALING("Use SIP standard hold signaling", null),
		FORCE_SUBSCRIPTION("Force subscription to message waiting notifications", null),
		ALLOW_CONTACT_HEADER_UPDATES("Allow contact header updates", null),
		NEW_TCP_PORT("Specify new TCP port in contact header", null),
		CALL_WAITING("Disable call waiting", null),
		ALLOW_VIDEO_CALLS("Allow video calls", null),
		OFFER_VIDEO("Send video SDP offer", null),
		ANSWER_VIDEO("Send video SDP answer", null),
		REGISTRATION_2("Registration 2", null),
		COMMON_SETTINGS("Common settings", null),
		AUDIO_DSCP("Audio DSCP", "sip_common_audio_dscp"),
		CALL_CONTROL_DSCP("Call control DSCP", null),
		CODEC_G_711U_PRIORITY("G.711u codec priority", null),
		CODEC_G_711A_PRIORITY("G.711a codec priority", null),
		CODEC_G_729A_PRIORITY("G.729A codec priority", null),
		CODEC_G_722_PRIORITY("G.722 codec priority", null),
		OPUS_PRIORITY("Opus codec priority", null),
		DTMF_PAYLOAD_TYPE("DTMF Relay Payload Type", null),
		FORCE_IN_BAND_TONES("Force In-Band DTMF Tones", null),
		OVERRIDE_TCP_SWITCH("Override Automatic Switch From UDP To TCP", null),
		LDAP_SETTINGS("LDAP settings", null),
		LDAP_SERVER_ADDRESS("Server Address", null),
		LDAP_SERVER_PORT("Server Port", null),
		LDAP_SECURITY_TYPE("Communication Security Type", null),
		LDAP_BIND_DN("Bind DN",null),
		LDAP_BIND_PASSWORD("Bind PW", null),
		LDAP_BASE_DN("Base DN", null),
		LDAP_PRIMARY_EMAIL("Primary email attribute", null),
		LDAP_ALTERNATE_EMAIL("Alternate email attribute", null),
		EMERGENCY_CONTACT("Emergency Contact", null),
		EMERGENCY_CONTACT_1("Emergency contact 1", null),
		EMERGENCY_CONTACT_2("Emergency contact 2", null),
		EMERGENCY_CONTACT_3("Emergency contact 3", null),
		EMERGENCY_CONTACT_4("Emergency contact 4", null),
		EMERGENCY_CONTACT_5("Emergency contact 5", null),
		EMERGENCY_CONTACT_NAME("Emergency Contact Name", null),
		EMERGENCY_CONTACT_NUMBER("Emergency Contact Number", null),
		CALL_SERVER_FEATURES("Call server features", null),
		CISCO_I_DIVERT("Allow iDivert", null),
		CISCO_CALL_FORWARDING("Allow call forwarding", null),
		CISCO_CALL_PARK("Allow call park", null),
		CISCO_HUNT_GROUP_LOGON("Allow hunt group login/logout", null),
		CISCO_CONTACT_SEARCH("Cisco contact search", null),
		CISCO_ADVANCED_CONTACT_SEARCH("Advanced contact search enable", null),
		CISCO_CONTACT_SEARCH_SERVER_ADDRESS("Cisco server address", null),
		CISCO_ADVANCED_CONTACT_SEARCH_SERVER_USERNAME("Cisco Advanced contact search Username", null),
		CISCO_ADVANCED_CONTACT_SEARCH_SERVER_PASSWORD("Cisco Advanced contact search Password", null),
		CISCO_CONTACT_SEARCH_FIELD("Search field", null),
		CISCO_CONTACT_SEARCH_VALUE("Search value", null),
		CISCO_VOICEMAIL("Voicemail enable", null),
		CISCO_UNITY_SERVER_ADDRESS_PRIMARY("Cisco Unity server address (Primary)", null),
		CISCO_UNITY_SERVER_ADDRESS_BACKUP("Cisco Unity server address (Backup)", null),
		CISCO_VOICEMAIL_USERNAME("Voicemail Username", null),
		CISCO_VOICEMAIL_PASSWORD("Voicemail Password", null),
		ENABLE_CALL_FORWARDING("Enable call forwarding", null),
		CLIENT_CONFIGURATION_SETTINGS("Security", null),
		BIZ_PHONE_ICON("BizPhone app icon", null),
		NO_SEARCH_RESULTS("No search results", null),
		ENTRY_AT_INDEX_0("0", null),
		ENTRY_AT_INDEX_1("1", null),
		ENTRY_AT_INDEX_2("2", null),
		ENTRY_AT_INDEX_3("3", null),
		ENTRY_AT_INDEX_4("4", null),
		ENTRY_AT_INDEX_5("5", null),
		ENTRY_AT_INDEX_6("6", null),
		ENTRY_AT_INDEX_7("7", null),
		ENTRY_AT_INDEX_8("8", null),
		ENTRY_AT_INDEX_9("9", null),
		CONTACT_NAME_AT_INDEX_0("Contact name at index 0", null),
		CONTACT_NUMBER_AT_INDEX_0("Contact number at index 0", null),
		VOICEMAIL_MESSAGES_AT_INDEX_0("Voicemail messages at index 0", null),
		CREATE_CONTACT("Create new contact", null),
		SEARCH("Search", null),
		SEARCH_EDIT_TEXT("Enter into search edit text", null),
		FIRST_NAME("First name", null),
		LAST_NAME("Last name", null),
		COMPANY("Company", null),
		TITLE("Title", null),
		PHONE("Phone", null),
		EMAIL("Email", null),
		SAVE_CONTACT("Save contact", null),
		FAVORITES("Favorites", null),
		LOCAL_CONTACTS("Local contacts", null),
		TOAST_MESSAGE("Toast message", null),
		NO_RESULT("No Result message", null),
		EDIT_TEXT("Edit text", null),
		OK_BUTTON("Ok button", null),
		CANCEL_BUTTON("Cancel button", null),
		ANOTHER_CANCEL_BUTTON("Another Cancel button", null),
		CLEAR_TRUST_LIST("Clear trust list", null),
		ALTERNATE_TFTP("Alternate TFTP", null),
		TFTP_ADDRESS_1("TFTP address 1", null),
		TFTP_ADDRESS_2("TFTP address 2", null),
		FROM_DEVICE_BUTTON("From device button", null),
		FROM_SERVER_BUTTON("From server button", null),
		DIAL_NUMBER_1("Dial number 1", null),
		DIAL_NUMBER_2("Dial number 2", null),
		DIAL_NUMBER_3("Dial number 3", null),
		DIAL_NUMBER_4("Dial number 4", null),
		DIAL_NUMBER_5("Dial number 5", null),
		DIAL_NUMBER_6("Dial number 6", null),
		DIAL_NUMBER_7("Dial number 7", null),
		DIAL_NUMBER_8("Dial number 8", null),
		DIAL_NUMBER_9("Dial number 9", null),
		DIAL_NUMBER_0("Dial number 0", null),
		DIAL_NUMBER_STAR("Dial star", null),
		DIAL_NUMBER_POUND("Dial pound", null),
		CALL_BUTTON("Call button", null),
		NEW_CALL_BUTTON("Start new call button", null),
		END_CALL("End call", null),
		HOLD_BUTTON("Hold call", null),
		RESUME_BUTTON("Resume call", null),
		MORE_BUTTON("More button", null),
		ADD_CALL("Add call", null),
		TRANSFER_BUTTON("Transfer call", null),
		DIALER_ACTION("Dialer button", null),
		CONFERENCE_BUTTON("Conference call", null),
		SPLIT_BUTTON("Split call", null),
		CALLER_INFO_LAYOUT("Caller info layout", null),
		MERGE_CALL_0("Merge call 0", null),
		MERGE_CALL_1("Merge call 1", null),
		MERGE_CALL_2("Merge call 2", null),
		MERGE_CALL_3("Merge call 3", null),
		MERGE_BUTTON("Merge button", null),
		TOOLBAR_CROSS_BUTTON("Toolbar cross button", null),
		PARTICIPANTS_BUTTON("Participants button", null),
		HOLD_COVER("Hold cover", null),
		ANSWER("Answer call", null),
		DECLINE("Decline call", null),
		CALLER_NAME_HEADS_UP("Caller name heads up", null),
		CALLER_NAME_ON_CALLING_PHONE("Caller name on calling phone", null),
		CALLER_NAME_ON_RECEIVED_PHONE("Caller name on received phone", null),
		CALLER_NUMBER_ON_CALL_LOG_SCREEN("Caller number on call log screen", null),
		MUTE("Mute call", null),
		UNMUTE("Unmute call", null),
		EXTENSION_EDIT_TEXT("Extension edit text", null),
		USERNAME_EDIT_TEXT("Username edit text", null),
		PASSWORD_EDIT_TEXT("Password edit text", null),
		LOGIN_BUTTON("Login button", null),
		EXTENSION_USERNAME_CHECKBOX("Extension username checkbox", null),
		BIZ_PHONE_LOGO("BizPhone logo", null),
		CALL_ICON_1("Call icon 1", null),
		CALL_ICON_2("Call icon 2", null),
		LINE_NUMBER_1("Line number 1", null),
		LINE_NUMBER_2("Line number 2", null),
		POPUP("Popup message", null),
		EXPAND_BUTTON("Expand button", null),
		CALL_DETAILS("Call details",null),
		TRANSFER_TO_NUMBER_BUTTON("Transfer to number", null),
		TRANSFER_TO_HELD_CALL_BUTTON("Transfer to call", null),
		ADVANCED_DEBUGGING("Advanced debugging",null),
		DEVICE_INFORMATION("Device information", null),
		REPORT_PROBLEM("Report problem", null),
		CISCO_PHONE_STATUS_BUTTON("Cisco phone status button", null),
		DEVICE_INFORMATION_BUTTON("Device information button", null),
		TRANSFER("Transfer", null),
		RECENTS_TAB("Recents tab", null),
		MISSED_TAB("Missed tab", null),
		ADVANCED_DEBUGGING_BUTTON("Advanced debugging button", null),
		LOGGING_PASSWORD_EDIT_TEXT("Logging password edit text",null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		BizPhoneStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum PttStrings implements FieldData {
		CURRENT_CHANNEL("Current channel", null),
		AUDIO_INDICATOR("Audio indicator", null),
		OVERFLOW_MENU("More options", null),
		TRANSMIT_TAB("Transmit", null),
		ACTIVITY_TAB("Activity", null),
		CHANNELS_TAB("Channels", null),
		TRANSMIT("Transmit button", null),
		ACTIVITY_LIST("Activity list", null),
		CHANNEL_LIST("Channel list", null),
		SETTINGS_TITLE("Settings title", null),
		RUNNING_BANNER("Service running banner", null),
		PTT_VOLUME("PTT volume", null),
		DEFAULT_CHANNEL("Default channel", null),
		ENABLE_PTT("Enable PTT", null),
		USER_NAME("Username", null),
		EDIT_BOX("Edit box", null),
		ADDRESS_EDIT("Multicast address edit", null),
		MULTICAST_ADDRESS("Multicast address", null),
		CODEC("Codec", null),
		CHANNEL_SETUP("Channel setup", null),
		CHANNEL_1("Channel #1", null),
		CHANNEL_2("Channel #2", null),
		CHANNEL_3("Channel #3", null),
		CHANNEL_4("Channel #4", null),
		CHANNEL_5("Channel #5", null),
		CHANNEL_6("Channel #6", null),
		CHANNEL_7("Channel #7", null),
		CHANNEL_8("Channel #8", null),
		CHANNEL_9("Channel #9", null),
		CHANNEL_10("Channel #10", null),
		CHANNEL_11("Channel #11", null),
		CHANNEL_12("Channel #12", null),
		CHANNEL_13("Channel #13", null),
		CHANNEL_14("Channel #14", null),
		CHANNEL_15("Channel #15", null),
		CHANNEL_16("Channel #16", null),
		CHANNEL_17("Channel #17", null),
		CHANNEL_18("Channel #18", null),
		CHANNEL_19("Channel #19", null),
		CHANNEL_20("Channel #20", null),
		CHANNEL_21("Channel #21", null),
		CHANNEL_22("Channel #22", null),
		CHANNEL_23("Channel #23", null),
		CHANNEL_24("Channel #24", null),
		CHANNEL_25("Channel #25", null),
		CHANNEL_NAME_EDIT("Channel label", null),
		CHANNEL_TRANSMIT("Channel can transmit", null),
		CHANNEL_RECEIVE("Channel subscription", null),
		BACK_ARROW("Back arrow", null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		PttStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

    public enum DeviceAppStrings implements FieldData {
		OVERFLOW_MENU("More options", null),
		ALLOW_WIFI_TOGGLE("Allow Wi-Fi toggle", null),
		ALLOW_AIRPLANE_MODE("Allow airplane mode toggle", null),
		ALLOW_QUICK_SETTINGS_TILES("Allow quick settings tiles", null),
		QUICK_SETTINGS_TILE("Quick settings tiles", null),
		WIFI("Wi-Fi", null),
		BLUETOOTH("Bluetooth", null),
		DO_NOT_DISTURB("Do not disturb", null),
		FLASHLIGHT("Flashlight", null),
		ROTATION_LOCK("Rotation lock", null),
		BATTERY_SAVER("Battery saver", null),
		MOBILE_DATA("Mobile data", null),
		AIRPLANE_MODE("Airplane mode", null),
		CAST("Cast", null),
		HIGH_TOUCH("High touch", null),
		HOTSPOT("Hotspot", null),
		NIGHT_LIGHT("Night light", null),
		LOCATION("Location", null),
		INVERT_COLORS("Invert colors", null),
		DATA_SAVER("Data saver", null),
		DONE("Done", null),
		ALLOW_NOTIFICATION_SHADE_GEAR("Allow notification shade settings gear", null),
		ALLOW_TIME_ZONE_CONFIGURATION("Allow time zone configuration", null),
		ALLOW_TIME_FORMAT_CONFIGURATION("Allow time format configuration", null),
		ALLOW_AUTO_TIME_ZONE_TOGGLE("Allow automatic time zone toggle", null),
		ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN("Allow emergency call button on lockscreen", null),
		NTP_SERVER_ADDRESS("NTP server address", null),
		TIME_ZONE("Time zone", null),
		TIME_FORMAT("Time format", null),
		AUTOMATIC_TIME_ZONE("Automatic time zone", null),
		DISPLAY_DEVICE_INFO("Display device info", null),
		DEVICE_INFO_1("Device info 1", null),
		DEVICE_INFO_2("Device info 2", null),
		DEVICE_INFO_3("Device info 3", null),
		DEVICE_INFO_4("Device info 4", null),
        DEVICE_NAME("Device name", null),
		BATTERY_OPTIMIZATION_WHITELIST("Battery optimization whitelist", null),
		ALLOW_BATTERY_SAVER("Allow battery saver", null),
		SKEYBOARD("SKeyboard", null),
		GOOGLE_VOICE_TYPING("Google voice typing", null),
		TIME_TO_SLEEP_AFTER_INACTIVITY("Time to sleep after inactivity", null),
		DIALPAD_TONES("Dialpad tones", null),
		DIALPAD_TONES_ANDROID_SETTINGS("Dial pad tones", null),
		TOUCH_SOUNDS("Touch sounds", null),
		VIBRATE_ON_TAP("Vibrate on tap", null),
		APPS_NOTIFICATIONS_ANDROID_SETTINGS("Apps & notifications", null),
		AMBER_ALERTS("AMBER alerts", null),
		EXTREME_THREATS("Extreme threats", null),
		SEVERE_THREATS("Severe threats", null),
		JUMP_TO_CAMERA("Jump to camera", null),
        ENABLE_WIFI_CALLING("Enable Wi-Fi calling/VoLTE", null),
		LOCK_SCREEN_WALLPAPER("Lock screen wallpaper", null),
		HOME_SCREEN_WALLPAPER("Home screen wallpaper", null),
        EDIT_TEXT("Edit text", null),
        OK_BUTTON("Ok button", null),
        CANCEL_BUTTON("Cancel button", null),
        US_ALASKA("US/Alaska", null),
        US_ALEUTIAN("US/Aleutian", null),
        US_ARIZONA("US/Arizona", null),
        US_CENTRAL("US/Central", null),
        US_EAST_INDIANA("US/East-Indiana", null),
        US_EASTERN("US/Eastern", null),
        US_HAWAII("US/Hawaii", null),
        US_INDIANA_STARKE("US/Indiana-Starke", null),
        US_MICHIGAN("US/Michigan", null),
        US_MOUNTAIN("US/Mountain", null),
        US_PACIFIC("US/Pacific", null),
        US_SAMOA("US/Samoa", null),
		DEVELOPER_OPTIONS("Developer options", null),
		RESTORE_DEFAULT_SETTINGS("Restore default android settings", null),
		BACK_ARROW("Back arrow", null),
		EXPOSE_BUTTON("Expose option", null),
		ABOUT_PHONE("About phone", null),
		CONNECTED_DEVICES("Connected devices", null),
		SYSTEM("System", null);

        private final String title;
        private final String attribute;

        public String attribute() {
            return attribute;
        }

        public String title() {
            return title;
        }

        DeviceAppStrings(String title, String attribute) {
            this.title = title;
            this.attribute = attribute;
        }
    }

	public enum SafeStrings implements FieldData {
		OVERFLOW_MENU("More options", null),
		MOTION_SENSOR_CONFIGURATION("Motion sensor configuration", null),
		PANIC_BUTTON_CONFIGURATION("Panic button configuration", null),
		EMERGENCY_CALL_CONFIGURATION("Emergency call configuration", null),
		SAFE_TONE_CONFIGURATION("SAFE tone configuration", null),
		EMERGENCY_TONE_CONFIGURATION("Emergency tone configuration", null),
		MONITORING("Monitoring", null),
		NO_MOVEMENT_SENSITIVITY("No movement sensitivity", null),
		NO_MOVEMENT_TIMEOUT("No movement timeout (seconds)", null),
		TILT_SENSITIVITY("Tilt sensitivity", null),
		TILT_TIMEOUT("Tilt timeout (seconds)", null),
		RUNNING_SENSITIVITY("Running sensitivity", null),
		RUNNING_TIMEOUT("Running timeout (seconds)", null),
		SNOOZE_TIMEOUT("Snooze timeout (seconds)", null),
		WARNING_TIMEOUT("Warning timeout (seconds)", null),
		BACK_ARROW("Back arrow", null),
		PANIC_BUTTON("Panic button", null),
		PANIC_BUTTON_SILENT_ALARM("Panic button silent alarm", null),
		EMERGENCY_CALL("Emergency call", null),
		EMERGENCY_DIAL_FORCE_SPEAKER("Emergency dial force speaker", null),
		EMERGENCY_DIAL_NUMBER("Emergency dial number", null),
		WARNING_TONE("Warning tone", null),
		EDIT_TEXT("Edit text", null),
		OK_BUTTON("Ok button", null),
		ALARM_TONE("Alarm tone", null),
		ALARM_TIMEOUT("Alarm timeout", null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		SafeStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum SysUpdaterStrings implements FieldData {
		APP_NAME("App name", null),
		OVERFLOW_MENU("More options", null),
		SYS_UPDATER_LOGO("Sys Updater logo", null),
		CURRENT_VERSION("Current version", null),
		AVAILABLE_VERSION("Available version", null),
		SYSTEM_UPDATE("System update", null),
		CHECK_BUTTON("Check for update", null),
		SERVER_ADDRESS("Server address", null),
		SERVER_PORT("Server port", null),
		OTA_PATH("Relative path on server", null),
		PROTOCOL("Network protocol", null),
		POLLING_INTERVAL("Polling interval", null),
		METERED_NETWORK("Allow on metered network", null),
		BACK_ARROW("Back arrow", null),
		EDIT_BOX("Edit box", null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		SysUpdaterStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum ButtonStrings implements FieldData {
		OVERFLOW_MENU("More options", null),
		LEFT_BUTTON("Left button", null),
		RIGHT_BUTTON("Right button", null),
		TOP("Top", null),
		FINGERPRINT("Fingerprint", null),
		VOLUME_UP("Volume up", null),
		VOLUME_DOWN("Volume down", null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		ButtonStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum BarcodeStrings implements FieldData {
		ENABLE_BARCODE_SCANNER("Enable barcode scanner", null),
		ENABLE_SCANNER_KEYBOARD_INPUT("Enable scanner keyboard input", null),
		KEYBOARD_INPUT("Keyboard input", null),
		SCANNED_BARCODE_DATA("Scanned barcode data", null),
		BARCODE_SCANNER_STATE("Barcode scanner state", null),
		CLEAR_BUTTON("Clear Button", null),
		BARCODE_BUTTON("Barcode button", null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		BarcodeStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public enum WebApiStrings implements FieldData {
		OVERFLOW_MENU("More options", null),
		BACK_ARROW("Back arrow", null),
		ENABLE_WEBAPI("Enable Web API", null),
		DATA_FORMAT("Data format", null),
		PHONE_STATE_POLLING("Phone state polling", null),
		PUSH_SETTINGS("Push settings", null),
		WEB_APPLICATION_SHORTCUTS("Web application shortcuts", null),
		DEVICE_EVENT_NOTIFICATIONS("Device event notifications", null),
		USERNAME("Username", null),
		PASSWORD("Password", null),
		RESPOND_MODE("Respond mode", null),
		POLLING_URL("URL", null),
		PUSH_ALERT_PRIORITY("Push alert priority", null),
		SERVER_ROOT_URL("Server root URL", null),
		ENABLE_NOTIFICATION_RINGTONE("Enable notification ringtone", null),
		WEB_API_VOLUME("Web API volume", null),
		SHORTCUT_1("Shortcut 1", null),
		SHORTCUT_2("Shortcut 2", null),
		SHORTCUT_3("Shortcut 3", null),
		SHORTCUT_4("Shortcut 4", null),
		SHORTCUT_5("Shortcut 5", null),
		SHORTCUT_6("Shortcut 6", null),
		SHORTCUT_7("Shortcut 7", null),
		SHORTCUT_8("Shortcut 8", null),
		SHORTCUT_9("Shortcut 9", null),
		SHORTCUT_10("Shortcut 10", null),
		SHORTCUT_11("Shortcut 11", null),
		SHORTCUT_12("Shortcut 12", null),
		NOTIFICATION_1("Notification 1", null),
		NOTIFICATION_2("Notification 2", null),
		NOTIFICATION_3("Notification 3", null),
		NOTIFICATION_4("Notification 4", null),
		NOTIFICATION_5("Notification 5", null),
		NOTIFICATION_6("Notification 6", null),
		WEB_APPLICATION_SHORTCUT_TITLE("Enter Web application shortcut title", null),
		WEB_APPLICATION_SHORTCUT_URL("Enter Web application shortcut URL", null),
		POSITIVE_BUTTON("Positive button", null),
		NEGATIVE_BUTTON("Negative button", null),
		NEUTRAL_BUTTON("Neutral button", null),
		EDIT_TEXT("Edit text", null),
		NOTIFICATION_NAME("Enter notification name", null),
		NOTIFICATION_URL("Enter notification URL", null),
		ADD_NEW_NOTIFICATION("Add new notification URL", null),
		ENABLE_WEB_ACCESS("Enable Web access", null),
		EXPAND_BIZ_PHONE_EVENTS("Expand Biz Phone events", null),
		ALL_CHECKBOX("All checkbox", null),
		OUTGOING_CHECKBOX("Outgoing checkbox", null),
		INCOMING_CHECKBOX("Incoming checkbox", null),
		STATE_CHANGE_EVENT_CHECKBOX("State change checkbox", null),
		LOGIN_OUT_CHECKBOX("Login/out checkbox", null),
		REGISTRATION_CHECKBOX("Registration checkbox", null),
		UNREGISTRATION_CHECKBOX("Unregistration checkbox", null),
		SAFE_CHECKBOX("SAFE checkbox", null);

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		WebApiStrings(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	public static FieldData getStrings(Application app, String cukeTitle) {
		switch (app) {
			case BATTLIFE:
				for (BattLifeStrings strings : BattLifeStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case AMIE_AGENT:
				for (AmieAgentStrings strings : AmieAgentStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case BIZ_PHONE:
				for (BizPhoneStrings strings : BizPhoneStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case PTT:
				for (PttStrings strings : PttStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
            case DEVICE:
                for (DeviceAppStrings strings : DeviceAppStrings.values()) {
                    if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
                        return strings;
                    }
                }
                break;
			case SAFE:
				for (SafeStrings strings : SafeStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case SYS_UPDATER:
				for (SysUpdaterStrings strings : SysUpdaterStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
			case BUTTONS:
				for (ButtonStrings strings : ButtonStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;

			case BARCODE_TEST_APP:
				for (BarcodeStrings strings : BarcodeStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;

			case WEBAPI:
				for (WebApiStrings strings : WebApiStrings.values()) {
					if (strings.title().toLowerCase().contentEquals(cukeTitle.trim().toLowerCase())) {
						return strings;
					}
				}
				break;
		}
		return null;
	}
}
