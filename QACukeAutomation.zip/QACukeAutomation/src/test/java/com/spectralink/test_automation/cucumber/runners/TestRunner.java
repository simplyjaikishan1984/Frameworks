package com.spectralink.test_automation.cucumber.runners;

import com.spectralink.test_automation.cucumber.framework.WebBrowser;
import com.spectralink.test_automation.cucumber.framework.common.*;
import gherkin.events.PickleEvent;
import io.cucumber.testng.CucumberFeatureWrapper;
import io.cucumber.testng.PickleEventWrapper;
import io.cucumber.testng.TestNGCucumberRunner;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.*;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import static com.spectralink.test_automation.cucumber.stepdefs.DeviceWebApiSteps.killStaleProcess;

public class TestRunner {
	private TestNGCucumberRunner testNGCucumberRunner;
	private final String projectDirectory = System.getProperty("user.dir");
	private final String configFileName = "AutoConfiguration.json";
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private final String scenarioSeparator = "=";
	private final String sectionSeparator = "-";
	private final int separatorLength = 60;

	private void downloadFeatureFiles(String featurePath) {
		Jira jira = Jira.getInstance();
		jira.downloadTestSetFeatureFiles(featurePath);
	}

	private void uploadResults(String version) {
		Path cucumberResultsPath = Paths.get(projectDirectory, "target/sam-results/run-results.json");
		Jira jira = Jira.getInstance();
		if (jira.uploadResults(cucumberResultsPath)) {
			String jiraKey = Jira.getExecutionId(Jira.returnJson);
			jira.updateSummary(jiraKey, "SAM version " + version);
			jira.updateStatus(jiraKey, "Done");
		}
	}

	@BeforeSuite
	public void loadDefaults() {
		File configFile = Environment.getConfigFile();
		RunDefaults.setConfigFile(configFile);
		String featurePath;
		if (RunDefaults.getBooleanSetting("importFeatures")) {
			featurePath = RunDefaults.getStringSetting("importFeaturePath");
			downloadFeatureFiles(featurePath);
		} else {
			featurePath = RunDefaults.getStringSetting("localFeaturePath");
		}
		log.info("Using feature files in the path {}", projectDirectory + "/" + featurePath);
		String tags;
		if (System.getenv("TAGS") == null) {
			tags = Util.quote(RunDefaults.getStringSetting("tags"));
		} else {
			tags = Util.quote(System.getenv("TAGS"));
		}
		log.info("Executing Cucumber tag set {}", tags);
		String[] cucumberOptions = {"--tags", tags,
				"--glue", "com.spectralink.test_automation.cucumber.stepdefs",
				"--plugin", "json:target/sam-results/run-results.json",
				"--plugin", "html:target/sam-html-results",
				featurePath
		};
        System.setProperty("cucumber.options", String.join(" ", cucumberOptions));
	}

	@BeforeClass(alwaysRun = true)
	public void setUpClass() {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Features", dataProvider = "features")
	public void feature(PickleEventWrapper pickleEvent, CucumberFeatureWrapper cucumberFeature) throws Throwable {
		Environment.setScenarioFailureCount(0);
		Environment.newSoftAssert();
		Environment.clearTemporaryStorage();
		PickleEvent event = pickleEvent.getPickleEvent();
		if (Environment.skipRemaining()) {
			log.info(StringUtils.repeat(scenarioSeparator, separatorLength));
			log.info(" > Skipping scenario: {}", event.pickle.getName());
			log.info(StringUtils.repeat(scenarioSeparator, separatorLength));
		} else {
			log.info(StringUtils.repeat(scenarioSeparator, separatorLength));
			log.info(" > Starting scenario: {}", event.pickle.getName());
			log.info(StringUtils.repeat(sectionSeparator, separatorLength));
			testNGCucumberRunner.runScenario(event);
			log.info(StringUtils.repeat(sectionSeparator, separatorLength));
			log.info(" > Finished scenario: {}", event.pickle.getName());
			log.info(StringUtils.repeat(scenarioSeparator, separatorLength));
		}
		Environment.checkAsserts();
	}

	@DataProvider
	public Object[][] features() {
		return testNGCucumberRunner.provideScenarios();
	}

	@AfterSuite(alwaysRun = true)
	public void tearDownClass() {
		testNGCucumberRunner.finish();
		if (WebBrowser.isDriverSet()) WebBrowser.close();
		if (Environment.isSamSet()) {
			if (RunDefaults.getBooleanSetting("uploadResults")) {
				uploadResults(Environment.getSam().imDatabase().getAppVersion());
			}
			Environment.getSam().imDatabase().close();
			Environment.getSam().keyDatabase().close();
		}
		for (String serial : Environment.getPhones().keySet()) {
			VersityPhone phone = Environment.getPhone(serial);
			if(phone!= null) {
				if (phone.isAppiumRunning()) {
					try {
						phone.appium().quit();
					} catch (Exception e) {
						log.debug("A session is either terminated or not started appium");
					}
					phone.stopAppiumServer();
				}
			}
		}
		killStaleProcess("python");
	}
}
