package com.spectralink.test_automation.cucumber.framework.device.common;

import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;

public class CallServerDetails {

    private final VersityPhone phone;
    public String sipServerAddress = "";
    public String userReg1 = "";
    public String userReg2 = "";
    public String passReg1 = "";
    public String passReg2 = "";
    public String extensionReg1 = "";
    public String extensionReg2 = "";
    public String displayName = "";
    public String voicemailPrimaryServerAddress = "";
    public String voicemailUsername = "";
    public String voicemailPassword = "";
    public String voicemailRetrievalAddress = "";
    public String transportProtocol = "";
    public String huntGroupNumber = "";
    public static final String sipServerSwitchvox = RunDefaults.getStringSetting("sipServerSwitchvox");
    public static final String extensionNumberUsernameSwitchvoxPhone1 = RunDefaults.getStringSetting("sipExtensionNumber1Switchvox");
    public static final String sipPasswordSwitchvox = RunDefaults.getStringSetting("sipPasswordSwitchvox");
    public static final String extensionNumberUsernameSwitchvoxPhone2 = RunDefaults.getStringSetting("sipExtensionNumber2Switchvox");
    public static final String extensionNumberUsernameSwitchvoxPhone3 = RunDefaults.getStringSetting("sipExtensionNumber3Switchvox");
    public static final String extensionNumberUsernameSwitchvoxPhone1Reg2 = RunDefaults.getStringSetting("sipRegistration2Extension1Switchvox");
    public static final String extensionNumberUsernameSwitchvoxPhone2Reg2 = RunDefaults.getStringSetting("sipRegistration2Extension2Switchvox");
    public static final String displayNameSwitchvoxExtension1 = RunDefaults.getStringSetting("sipExtensionDisplayName1Switchvox");
    public static final String displayNameSwitchvoxExtension2 = RunDefaults.getStringSetting("sipExtensionDisplayName2Switchvox");
    public static final String displayNameSwitchvoxExtension3 = RunDefaults.getStringSetting("sipExtensionDisplayName3Switchvox");
    public static final String extensionNumberSaturn1 = RunDefaults.getStringSetting("sipExtensionNumber1Saturn");
    public static final String extensionNumberSaturn2 = RunDefaults.getStringSetting("sipExtensionNumber2Saturn");
    public static final String extensionNumberSaturn3 = RunDefaults.getStringSetting("sipExtensionNumber3Saturn");
    public static final String displayNameSaturn1 = RunDefaults.getStringSetting("sipExtensionDisplayName1Saturn");
    public static final String displayNameSaturn2 = RunDefaults.getStringSetting("sipExtensionDisplayName2Saturn");
    public static final String displayNameSaturn3 = RunDefaults.getStringSetting("sipExtensionDisplayName3Saturn");
    public static final String extensionNumberCisco1 = RunDefaults.getStringSetting("sipExtensionNumber1Cisco");
    public static final String extensionNumberCisco2 = RunDefaults.getStringSetting("sipExtensionNumber2Cisco");
    public static final String extensionNumberCisco3 = RunDefaults.getStringSetting("sipExtensionNumber3Cisco");
    public static final String usernameCisco1 = RunDefaults.getStringSetting("sipUsername1Cisco");
    public static final String usernameCisco2 = RunDefaults.getStringSetting("sipUsername2Cisco");
    public static final String usernameCisco3 = RunDefaults.getStringSetting("sipUsername3Cisco");
    public static final String sipPasswordCisco = RunDefaults.getStringSetting("sipPasswordCisco");
    public static final String sipServerCisco = RunDefaults.getStringSetting("sipServerCisco");
    public static final String displayNameCiscoExtension1 = RunDefaults.getStringSetting("sipExtensionDisplayName1Cisco");
    public static final String displayNameCiscoExtension2 = RunDefaults.getStringSetting("sipExtensionDisplayName2Cisco");
    public static final String displayNameCiscoExtension3 = RunDefaults.getStringSetting("sipExtensionDisplayName3Cisco");
    public static final String extensionNumberAvaya1 = RunDefaults.getStringSetting("sipExtensionNumber1Avaya");
    public static final String extensionNumberAvaya2 = RunDefaults.getStringSetting("sipExtensionNumber2Avaya");
    public static final String extensionNumberAvaya3 = RunDefaults.getStringSetting("sipExtensionNumber3Avaya");
    public static final String usernameAvaya1 = RunDefaults.getStringSetting("sipUsername1Avaya");
    public static final String usernameAvaya2 = RunDefaults.getStringSetting("sipUsername2Avaya");
    public static final String usernameAvaya3 = RunDefaults.getStringSetting("sipUsername3Avaya");
    public static final String sipPasswordMitel = RunDefaults.getStringSetting("sipPasswordMitel");
    public static final String sipServerMitel = RunDefaults.getStringSetting("sipServerMitel");
    public static final String extensionNumberUsernameMitel1 = RunDefaults.getStringSetting("sipExtensionNumber1Mitel");
    public static final String extensionNumberUsernameMitel2 = RunDefaults.getStringSetting("sipExtensionNumber2Mitel");
    public static final String extensionNumberUsernameMitel3 = RunDefaults.getStringSetting("sipExtensionNumber3Mitel");
    public static final String displayNameMitelExtension1 = RunDefaults.getStringSetting("sipExtensionDisplayName1Mitel");
    public static final String displayNameMitelExtension2 = RunDefaults.getStringSetting("sipExtensionDisplayName2Mitel");
    public static final String displayNameMitelExtension3 = RunDefaults.getStringSetting("sipExtensionDisplayName3Mitel");
    public static final String sipPasswordAvaya1 = RunDefaults.getStringSetting("sipPassword1Avaya");
    public static final String sipPasswordAvaya2 = RunDefaults.getStringSetting("sipPassword2Avaya");
    public static final String sipPasswordAvaya3 = RunDefaults.getStringSetting("sipPassword3Avaya");
    public static final String sipServerAvaya = RunDefaults.getStringSetting("sipServerAvaya");
    public static final String displayNameAvayaExtension1 = RunDefaults.getStringSetting("sipExtensionDisplayName1Avaya");
    public static final String displayNameAvayaExtension2 = RunDefaults.getStringSetting("sipExtensionDisplayName2Avaya");
    public static final String displayNameAvayaExtension3 = RunDefaults.getStringSetting("sipExtensionDisplayName3Avaya");
    public static final String voicemailPrimaryServerAddress1Cisco = RunDefaults.getStringSetting("voicemailPrimaryServerAddress1Cisco");
    public static final String voicemailPrimaryServerAddress2Cisco = RunDefaults.getStringSetting("voicemailPrimaryServerAddress2Cisco");
    public static final String voicemailPrimaryServerAddress3Cisco = RunDefaults.getStringSetting("voicemailPrimaryServerAddress3Cisco");
    public static final String voicemailUsername1Cisco = RunDefaults.getStringSetting("voicemailUsername1Cisco");
    public static final String voicemailUsername2Cisco = RunDefaults.getStringSetting("voicemailUsername2Cisco");
    public static final String voicemailUsername3Cisco = RunDefaults.getStringSetting("voicemailUsername3Cisco");
    public static final String voicemailPassword1Cisco = RunDefaults.getStringSetting("voicemailPassword1Cisco");
    public static final String voicemailPassword2Cisco = RunDefaults.getStringSetting("voicemailPassword2Cisco");
    public static final String voicemailPassword3Cisco = RunDefaults.getStringSetting("voicemailPassword3Cisco");
    public static final String voicemailPrimaryServerAddress1Saturn = RunDefaults.getStringSetting("voicemailPrimaryServerAddress1Saturn");
    public static final String voicemailPrimaryServerAddress2Saturn = RunDefaults.getStringSetting("voicemailPrimaryServerAddress2Saturn");
    public static final String voicemailPrimaryServerAddress3Saturn = RunDefaults.getStringSetting("voicemailPrimaryServerAddress3Saturn");
    public static final String voicemailUsername1Saturn = RunDefaults.getStringSetting("voicemailUsername1Saturn");
    public static final String voicemailUsername2Saturn = RunDefaults.getStringSetting("voicemailUsername2Saturn");
    public static final String voicemailUsername3Saturn = RunDefaults.getStringSetting("voicemailUsername3Saturn");
    public static final String voicemailPassword1Saturn = RunDefaults.getStringSetting("voicemailPassword1Saturn");
    public static final String voicemailPassword2Saturn = RunDefaults.getStringSetting("voicemailPassword2Saturn");
    public static final String voicemailPassword3Saturn = RunDefaults.getStringSetting("voicemailPassword3Saturn");
    public static final String voicemailRetrievalAddress1Switchvox = RunDefaults.getStringSetting("voicemailRetrievalServerAddress1Switchvox");
    public static final String voicemailRetrievalAddress2Switchvox = RunDefaults.getStringSetting("voicemailRetrievalServerAddress2Switchvox");
    public static final String voicemailRetrievalAddress3Switchvox = RunDefaults.getStringSetting("voicemailRetrievalServerAddress3Switchvox");
    public static final String voicemailRetrievalAddress1Avaya = RunDefaults.getStringSetting("voicemailRetrievalServerAddress1Avaya");
    public static final String voicemailRetrievalAddress2Avaya = RunDefaults.getStringSetting("voicemailRetrievalServerAddress2Avaya");
    public static final String voicemailRetrievalAddress3Avaya = RunDefaults.getStringSetting("voicemailRetrievalServerAddress3Avaya");
    public static final String voicemailRetrievalAddress1Mitel = RunDefaults.getStringSetting("voicemailRetrievalServerAddress1Mitel");
    public static final String voicemailRetrievalAddress2Mitel = RunDefaults.getStringSetting("voicemailRetrievalServerAddress2Mitel");
    public static final String voicemailRetrievalAddress3Mitel = RunDefaults.getStringSetting("voicemailRetrievalServerAddress3Mitel");
    public static final String voicemailRetrievalAddress1Cisco = RunDefaults.getStringSetting("voicemailRetrievalServerAddress1Cisco");
    public static final String voicemailRetrievalAddress2Cisco = RunDefaults.getStringSetting("voicemailRetrievalServerAddress2Cisco");
    public static final String voicemailRetrievalAddress3Cisco = RunDefaults.getStringSetting("voicemailRetrievalServerAddress3Cisco");
    public static final String voicemailRetrievalAddress1Saturn = RunDefaults.getStringSetting("voicemailRetrievalServerAddress1Saturn");
    public static final String voicemailRetrievalAddress2Saturn = RunDefaults.getStringSetting("voicemailRetrievalServerAddress2Saturn");
    public static final String voicemailRetrievalAddress3Saturn = RunDefaults.getStringSetting("voicemailRetrievalServerAddress3Saturn");
    public static final String transportProtocol1Switchvox = RunDefaults.getStringSetting("transportProtocol1Switchvox");
    public static final String transportProtocol2Switchvox = RunDefaults.getStringSetting("transportProtocol2Switchvox");
    public static final String transportProtocol3Switchvox = RunDefaults.getStringSetting("transportProtocol3Switchvox");
    public static final String transportProtocol1Cisco = RunDefaults.getStringSetting("transportProtocol1Cisco");
    public static final String transportProtocol2Cisco = RunDefaults.getStringSetting("transportProtocol2Cisco");
    public static final String transportProtocol3Cisco = RunDefaults.getStringSetting("transportProtocol3Cisco");
    public static final String transportProtocol1Avaya = RunDefaults.getStringSetting("transportProtocol1Avaya");
    public static final String transportProtocol2Avaya = RunDefaults.getStringSetting("transportProtocol2Avaya");
    public static final String transportProtocol3Avaya = RunDefaults.getStringSetting("transportProtocol3Avaya");
    public static final String transportProtocol1Mitel = RunDefaults.getStringSetting("transportProtocol1Mitel");
    public static final String transportProtocol2Mitel = RunDefaults.getStringSetting("transportProtocol2Mitel");
    public static final String transportProtocol3Mitel = RunDefaults.getStringSetting("transportProtocol3Mitel");
    public static final String transportProtocol1Saturn = RunDefaults.getStringSetting("transportProtocol1Saturn");
    public static final String transportProtocol2Saturn = RunDefaults.getStringSetting("transportProtocol2Saturn");
    public static final String transportProtocol3Saturn = RunDefaults.getStringSetting("transportProtocol3Saturn");
    public static final String huntGroupNumberSaturn = RunDefaults.getStringSetting("huntGroupNumberSaturn");
    public static final String sipServerSaturn = RunDefaults.getStringSetting("sipServerSaturn");

    private SipServerType sipServer = SipServerType.SWITCHVOX;
    public CallServerDetails(VersityPhone phone) {
        this.phone = phone;
    }

    public enum SipServerType {
        CISCO_SPP,
        AVAYA,
        MITEL,
        SWITCHVOX,
        SATURN
    }
    public SipServerType getSipServer() {
        return sipServer;
    }

    public String getHuntGroupNumber() {
        return huntGroupNumber;
    }

    public void setSipServer(SipServerType sipServer, String phone) {
        this.sipServer = sipServer;

        switch (sipServer) {
            case CISCO_SPP:
                this.sipServerAddress = sipServerCisco;
                switch (phone) {
                    case "PHONE A":
                        this.userReg1 = usernameCisco1;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordCisco;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberCisco1;
                        this.extensionReg2 = "";
                        this.displayName = displayNameCiscoExtension1;
                        this.transportProtocol = transportProtocol1Cisco;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress1Cisco;
                        this.voicemailPrimaryServerAddress = voicemailPrimaryServerAddress1Cisco;
                        this.voicemailUsername = voicemailUsername1Cisco;
                        this.voicemailPassword = voicemailPassword1Cisco;
                        break;
                    case "PHONE B":
                        this.userReg1 = usernameCisco2;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordCisco;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberCisco2;
                        this.extensionReg2 = "";
                        this.displayName = displayNameCiscoExtension2;
                        this.transportProtocol = transportProtocol2Cisco;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress2Cisco;
                        this.voicemailPrimaryServerAddress = voicemailPrimaryServerAddress2Cisco;
                        this.voicemailUsername = voicemailUsername2Cisco;
                        this.voicemailPassword = voicemailPassword2Cisco;
                        break;
                    case "PHONE C":
                        this.userReg1 = usernameCisco3;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordCisco;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberCisco3;
                        this.extensionReg2 = "";
                        this.displayName = displayNameCiscoExtension3;
                        this.transportProtocol = transportProtocol3Cisco;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress3Cisco;
                        this.voicemailPrimaryServerAddress = voicemailPrimaryServerAddress3Cisco;
                        this.voicemailUsername = voicemailUsername3Cisco;
                        this.voicemailPassword = voicemailPassword3Cisco;
                        break;
                }
                break;

            case AVAYA:
                this.sipServerAddress = sipServerAvaya;
                switch (phone) {
                    case "PHONE A":
                        this.userReg1 = usernameAvaya1;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordAvaya1;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberAvaya1;
                        this.extensionReg2 = "";
                        this.displayName = displayNameAvayaExtension1;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress1Avaya;
                        this.transportProtocol = transportProtocol1Avaya;
                        break;
                    case "PHONE B":
                        this.userReg1 = usernameAvaya2;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordAvaya2;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberAvaya2;
                        this.extensionReg2 = "";
                        this.displayName = displayNameAvayaExtension2;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress2Avaya;
                        this.transportProtocol = transportProtocol2Avaya;
                        break;
                    case "PHONE C":
                        this.userReg1 = usernameAvaya3;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordAvaya3;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberAvaya3;
                        this.extensionReg2 = "";
                        this.displayName = displayNameAvayaExtension3;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress3Avaya;
                        this.transportProtocol = transportProtocol3Avaya;
                        break;
                }
                break;

            case MITEL:
                this.sipServerAddress = sipServerMitel;
                switch (phone) {
                    case "PHONE A":
                        this.userReg1 = extensionNumberUsernameMitel1;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordMitel;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberUsernameMitel1;
                        this.extensionReg2 = "";
                        this.displayName = displayNameMitelExtension1;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress1Mitel;
                        this.transportProtocol = transportProtocol1Mitel;
                        break;
                    case "PHONE B":
                        this.userReg1 = extensionNumberUsernameMitel2;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordMitel;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberUsernameMitel2;
                        this.extensionReg2 = "";
                        this.displayName = displayNameMitelExtension2;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress2Mitel;
                        this.transportProtocol = transportProtocol2Mitel;
                        break;
                    case "PHONE C":
                        this.userReg1 = extensionNumberUsernameMitel3;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordMitel;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberUsernameMitel3;
                        this.extensionReg2 = "";
                        this.displayName = displayNameMitelExtension3;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress3Mitel;
                        this.transportProtocol = transportProtocol3Mitel;
                        break;
                }
                break;

            case SWITCHVOX:
                this.sipServerAddress = sipServerSwitchvox;
                switch (phone) {
                    case "PHONE A":
                        this.userReg1 = extensionNumberUsernameSwitchvoxPhone1;
                        this.userReg2 = extensionNumberUsernameSwitchvoxPhone1Reg2;
                        this.passReg1 = sipPasswordSwitchvox;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberUsernameSwitchvoxPhone1;
                        this.extensionReg2 = extensionNumberUsernameSwitchvoxPhone1Reg2;
                        this.displayName = displayNameSwitchvoxExtension1;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress1Switchvox;
                        this.transportProtocol = transportProtocol1Switchvox;
                        break;
                    case "PHONE B":
                        this.userReg1 = extensionNumberUsernameSwitchvoxPhone2;
                        this.userReg2 = extensionNumberUsernameSwitchvoxPhone2Reg2;
                        this.passReg1 = sipPasswordSwitchvox;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberUsernameSwitchvoxPhone2;
                        this.extensionReg2 = extensionNumberUsernameSwitchvoxPhone2Reg2;
                        this.displayName = displayNameSwitchvoxExtension2;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress2Switchvox;
                        this.transportProtocol = transportProtocol2Switchvox;
                        break;
                    case "PHONE C":
                        this.userReg1 = extensionNumberUsernameSwitchvoxPhone3;
                        this.userReg2 = "";
                        this.passReg1 = sipPasswordSwitchvox;
                        this.passReg2 = "";
                        this.extensionReg1 = extensionNumberUsernameSwitchvoxPhone3;
                        this.extensionReg2 = "";
                        this.displayName = displayNameSwitchvoxExtension3;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress3Switchvox;
                        this.transportProtocol = transportProtocol3Switchvox;
                        break;
                }
                break;

            case SATURN:
            default:
                this.sipServerAddress = sipServerSaturn;
                this.huntGroupNumber = huntGroupNumberSaturn;
                switch (phone) {
                    case "PHONE A":
                        this.extensionReg1 = extensionNumberSaturn1;
                        this.displayName = displayNameSaturn1;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress1Saturn;
                        this.voicemailPrimaryServerAddress = voicemailPrimaryServerAddress1Saturn;
                        this.voicemailUsername = voicemailUsername1Saturn;
                        this.voicemailPassword = voicemailPassword1Saturn;
                        this.transportProtocol = transportProtocol1Saturn;
                        break;
                    case "PHONE B":
                        this.extensionReg1 = extensionNumberSaturn2;
                        this.displayName = displayNameSaturn2;
                        this.voicemailPrimaryServerAddress = voicemailPrimaryServerAddress2Saturn;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress2Saturn;
                        this.voicemailUsername = voicemailUsername2Saturn;
                        this.voicemailPassword = voicemailPassword2Saturn;
                        this.transportProtocol = transportProtocol2Saturn;
                        break;
                    case "PHONE C":
                        this.extensionReg1 = extensionNumberSaturn3;
                        this.displayName = displayNameSaturn3;
                        this.voicemailPrimaryServerAddress = voicemailPrimaryServerAddress3Saturn;
                        this.voicemailRetrievalAddress = voicemailRetrievalAddress3Saturn;
                        this.voicemailUsername = voicemailUsername3Saturn;
                        this.voicemailPassword = voicemailPassword3Saturn;
                        this.transportProtocol = transportProtocol3Saturn;
                        break;
                }
                break;
        }
    }
}
