package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamLensGridPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.LENS_GRID;

public class SamLensGridSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I check the \"([^\"]*)\" Lens Grid field$")
	public void checkLensGridCheckbox(String arg1) throws Throwable {
		SamLensGridPage gridPage = (SamLensGridPage) Environment.getCurrentPage();
		if (gridPage.getField(arg1.trim()) != null) {
			gridPage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I uncheck the \"([^\"]*)\" Lens Grid field$")
	public void uncheckLensGridCheckbox(String arg1) throws Throwable {
		SamLensGridPage gridPage = (SamLensGridPage) Environment.getCurrentPage();
		if (gridPage.getField(arg1.trim()) != null) {
			gridPage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" Lens Grid field$")
	public void selectLensGridMenuOption(String arg1, String arg2) throws Throwable {
		SamLensGridPage gridPage = (SamLensGridPage) Environment.getCurrentPage();
		if (gridPage.getField(arg2) != null) {
			gridPage.getField(arg2.trim()).updateMenuByLabel(arg1.trim());
		} else {
			log.error("Field with label '{}' does not exist", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the \"([^\"]*)\" Lens Grid setting$")
	public void verifyLensGridValue(String arg1, String arg2, String arg3) throws Throwable {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(LENS_GRID, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(LENS_GRID, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(LENS_GRID)) phone.loadAppPreferences(LENS_GRID);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("Field with label '{}' does not exist", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I delete the \"([^\"]*)\" Lens Grid field$")
	public void deleteLensGridSetting(String arg1) throws Throwable {
		SamLensGridPage gridPage = (SamLensGridPage) Environment.getCurrentPage();
		gridPage.getField(arg1.trim()).delete();
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the Lens Grid custom attribute \"([^\"]*)\" setting$")
	public void checkLensGridCustomAttributeSetting(String arg1, String arg2, String arg3) {
		if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
			VersityPhone phone = Environment.getPhone(arg1.trim());
			if (phone != null) {
				if (!phone.getCurrentAppSettings().equals(LENS_GRID)) phone.loadAppPreferences(LENS_GRID);
				Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
			} else {
				log.error("Phone with label '{}' does not exist", arg1);
				Assert.fail("Specified Phone Not Available");
			}
		} else {
			log.debug("Skipped checking attribute {} since custom attribute testing is turned off", arg1);
		}
	}

	@Then("^the Lens Grid page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyLensGridPageValue(String arg1, String arg2) {
		SamLensGridPage gridPage = (SamLensGridPage) Environment.getCurrentPage();
		if (gridPage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(gridPage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(gridPage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Field with label '{}' does not exist", arg2);
		}
	}
}