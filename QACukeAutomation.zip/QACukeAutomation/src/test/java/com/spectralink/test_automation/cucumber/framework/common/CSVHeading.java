package com.spectralink.test_automation.cucumber.framework.common;

public interface CSVHeading {
	String getTitle();
}
