package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Jira {
    private final static Logger log = LogManager.getLogger(Jira.class.getName());
    public static Integer resultCode = -1;
    public static String returnJson = "";
    private static RestClient client;
    private static Jira INSTANCE;

    private Jira() {
        client = new RestClient(RunDefaults.getStringSetting("tmsServer"));
        client.setUserName(RunDefaults.getStringSetting("tmsAccount"));
        client.setPassword(RunDefaults.getDecryptedSetting("tmsPassword"));
        client.setSecure(true);
    }

    public static Jira getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Jira();
        }
        return INSTANCE;
    }

    public static RestClient getRestClient() {
        return client;
    }

    public static String getExecutionId(String returnJson) {
        JSONParser parser = new JSONParser();
        String executionId = null;
        try {
            Object rawResult = parser.parse(returnJson);
            JSONObject execution = (JSONObject) rawResult;
            Object rawFields = execution.get("testExecIssue");
            JSONObject fields = (JSONObject) rawFields;
            if (fields.get("key") != null) {
                executionId = fields.get("key").toString();
            } else {
                log.error("Could not find execution ID in '{}'", returnJson);
            }
        } catch (ParseException pe) {
            log.error("Could not parse result JSON '{}': {}", returnJson, pe.getMessage());
        }
        return executionId;
    }

    public static JSONObject getUpdateSummaryJson(String newSummary) {
        JSONObject command = new JSONObject();
        command.put("set", newSummary);
        JSONArray commandList = new JSONArray();
        commandList.add(command);
        JSONObject updates = new JSONObject();
        updates.put("summary", commandList);
        JSONObject container = new JSONObject();
        container.put("update", updates);
        return container;
    }

    public static JSONObject getTransitionStatusJson(String newStatus) {
        String id = "0";
        if (newStatus.equalsIgnoreCase("To Do")) {
            id = "11";
        } else if (newStatus.equalsIgnoreCase("In Progress")) {
            id = "21";
        } else if (newStatus.equalsIgnoreCase("In Test")) {
            id = "41";
        } else if (newStatus.equalsIgnoreCase("Done")) {
            id = "31";
        } else {
            log.error("Status of '{}' is invalid", newStatus);
        }
        JSONObject transition = new JSONObject();
        transition.put("id", id);
        JSONObject container = new JSONObject();
        container.put("transition", transition);
        return container;
    }

    public boolean downloadTestSetFeatureFiles(String featurePath) {
        RestClient client = getRestClient();
        JSONParser parser = new JSONParser();
        String testSet = RunDefaults.getStringSetting("testSet");
        log.info("Importing feature files from Test Set {}", testSet);
        Path pathToFile = null;
        boolean success = false;
        String projectDirectory = Environment.getProjectDirectory();
        Pattern locationTag = Pattern.compile("@Location-(\\S+)");
        try {
            Jira.resultCode = client.getGetRequest("rest/raven/1.0/api/testset/" + testSet + "/test");
            if (Jira.resultCode >= 200 && Jira.resultCode < 300) {
                Object parsedJson = parser.parse(client.getResultJson());
                JSONArray foundCases = (JSONArray) parsedJson;
                int fileCounter = 0;
                int unknownEnumerator = 0;
                for (Object rawTestCase : foundCases) {
                    JSONObject testCase = (JSONObject) rawTestCase;
                    String definition = (String) testCase.get("definition");
                    Matcher match = locationTag.matcher(definition);
                    if (match.find()) {
                        pathToFile = Paths.get(projectDirectory, featurePath, match.group(1));
                        definition = match.replaceFirst("@" + testCase.get("key"));
                    } else {
                        pathToFile = Paths.get(projectDirectory, featurePath, "unknown_" + unknownEnumerator + ".feature");
                        log.error("Found test case {} without @Location tag", testCase.get("key"));
                        Pattern testTypeTag = Pattern.compile("@Positive|@Negative");
                        Matcher match2 = testTypeTag.matcher(definition);
                        if (match2.find()) {
                            definition = match2.replaceFirst("@Ignore");
                        }
                        unknownEnumerator += 1;
                    }
                    Files.createDirectories(pathToFile.getParent());
                    Files.write(pathToFile, definition.getBytes());
                    log.trace("Created feature file {}", pathToFile.toString());
                    fileCounter += 1;
                }
                success = true;
                log.debug("Created {} feature files under directory {}", fileCounter, Paths.get(projectDirectory, featurePath));
            } else {
                log.error("Could not complete rest request: GET returned code {}", Jira.resultCode);
            }
        } catch (ParseException pe) {
            log.error("Could not parse test JSON: {}", pe.getMessage());
        } catch (IOException ioe) {
            log.error("Could not write feature file {}: {}", pathToFile, ioe.getMessage());
        }
        return success;
    }

    public boolean uploadResults(Path cucumberResultsPath) {
        RestClient client = getRestClient();
        boolean success = false;
        if (cucumberResultsPath.toFile().exists()) {
            try {
                String jsonResults = new String(Files.readAllBytes(cucumberResultsPath));
                Jira.resultCode = client.getPostRequest("rest/raven/1.0/import/execution/cucumber", jsonResults);
                if (Jira.resultCode >= 200 && Jira.resultCode < 300) {
                    log.debug("Uploaded results file {}", cucumberResultsPath);
                    Jira.returnJson = client.getResultJson();
                    success = true;
                } else {
                    log.error("Failed to upload results file {} with result code {}", cucumberResultsPath, resultCode);
                }
            } catch (IOException ioe) {
                log.error("Could not read results file {}: {}", cucumberResultsPath, ioe.getMessage());
            }
        } else {
            log.error("Results file {} did not exist", cucumberResultsPath);
        }
        return success;
    }

    public boolean updateSummary(String issueKey, String newSummary) {
        JSONObject container = getUpdateSummaryJson(newSummary);
        RestClient client = getRestClient();
        boolean success = false;
        Jira.resultCode = client.getPutRequest("rest/api/2/issue/" + issueKey, container.toJSONString());
        if (Jira.resultCode >= 200 && Jira.resultCode < 300) {
            log.debug("Updated Jira summary of {} to '{}'", issueKey, newSummary);
            returnJson = "";
            success = true;
        } else {
            log.error("Jira Issue update call returned code {}", Jira.resultCode);
        }
        return success;
    }

    public boolean updateStatus(String issueKey, String newStatus) {
        JSONObject container = getTransitionStatusJson(newStatus);
        RestClient client = getRestClient();
        boolean success = false;
        Jira.resultCode = client.getPostRequest("rest/api/2/issue/" + issueKey + "/transitions", container.toJSONString());
        if (Jira.resultCode >= 200 && Jira.resultCode < 300) {
            log.debug("Updated Jira status of {} to '{}'", issueKey, newStatus);
            returnJson = client.getResultJson();
            success = true;
        } else {
            log.error("Jira Issue update call returned code {}", Jira.resultCode);
        }
        return success;
    }
}
