package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.SafeStrings.*;

public class SamSafePage extends SamConfigurationPage {

	@FindBy(className = "md-tab")
	private List<WebElement> tabs;

	@FindBy(id = "add_more_bizPhoneEmer")
	private WebElement sipAddContactButton;

	@FindBy(id = "remove_dynamic_bizPhoneEmer")
	private WebElement sipRemoveContactButton;


	@FindBy(xpath = "//label[@for=\"on-safeEnabled\"]")
	private WebElement onMonitoringLabel;

	@FindBy(id = "on-safeEnabled")
	private WebElement onMonitoringRadio;

	@FindBy(id = "delete_setting_safeEnabled")
	private WebElement monitoringDelete;

	@FindBy(id = "edit_setting_safeEnabled")
	private WebElement monitoringEdit;

	public ConfigPageField onMonitoringField = new ConfigPageField(
			ENABLE_MONITORING,
			onMonitoringLabel,
			onMonitoringRadio,
			monitoringDelete,
			monitoringEdit
	);

	@FindBy(xpath = "//label[@for=\"off-safeEnabled\"]")
	private WebElement offMonitoringLabel;

	@FindBy(id = "off-safeEnabled")
	private WebElement offMonitoringRadio;

	public ConfigPageField offMonitoringField = new ConfigPageField(
			ENABLE_MONITORING,
			offMonitoringLabel,
			offMonitoringRadio,
			monitoringDelete,
			monitoringEdit
	);

	@FindBy(id = "safeNoMoveSensitivity")
	private WebElement moveSensitivityMenu;

	@FindBy(id = "delete_setting_safeNoMoveSensitivity")
	private WebElement moveSensitivityDelete;

	@FindBy(id = "edit_setting_safeNoMoveSensitivity")
	private WebElement moveSensitivityEdit;

	public ConfigPageField moveSensitivityField = new ConfigPageField(
			MOVEMENT_SENSITIVITY,
			moveSensitivityMenu,
			moveSensitivityDelete,
			moveSensitivityEdit
	);

	@FindBy(id = "safeNoMoveTimeout")
	private WebElement moveTimeoutTextbox;

	@FindBy(id = "delete_setting_safeNoMoveTimeout")
	private WebElement moveTimeoutDelete;

	@FindBy(id = "edit_setting_safeNoMoveTimeout")
	private WebElement moveTimeoutEdit;

	public ConfigPageField moveTimeoutField = new ConfigPageField(
			MOVEMENT_TIMEOUT,
			moveTimeoutTextbox,
			moveTimeoutDelete,
			moveTimeoutEdit
	);

	@FindBy(id = "safeNotVerticalSensitivity")
	private WebElement tiltSensitivityMenu;

	@FindBy(id = "delete_setting_safeNotVerticalSensitivity")
	private WebElement tiltSensitivityDelete;

	@FindBy(id = "edit_setting_safeNotVerticalSensitivity")
	private WebElement tiltSensitivityEdit;

	public ConfigPageField tiltSensitivityField = new ConfigPageField(
			TILT_SENSITIVITY,
			tiltSensitivityMenu,
			tiltSensitivityDelete,
			tiltSensitivityEdit
	);

	@FindBy(id = "safeNotVerticalTimeout")
	private WebElement tiltTimeoutTextbox;

	@FindBy(id = "delete_setting_safeNotVerticalTimeout")
	private WebElement tiltTimeoutDelete;

	@FindBy(id = "edit_setting_safeNotVerticalTimeout")
	private WebElement tiltTimeoutEdit;

	public ConfigPageField tiltTimeoutField = new ConfigPageField(
			TILT_TIMEOUT,
			tiltTimeoutTextbox,
			tiltTimeoutDelete,
			tiltTimeoutEdit
	);

	@FindBy(id = "safeRunningSensitivity")
	private WebElement runningSensitivityMenu;

	@FindBy(id = "delete_setting_safeRunningSensitivity")
	private WebElement runningSensitivityDelete;

	@FindBy(id = "edit_setting_safeRunningSensitivity")
	private WebElement runningSensitivityEdit;

	public ConfigPageField runningSensitivityField = new ConfigPageField(
			RUNNING_SENSITIVITY,
			runningSensitivityMenu,
			runningSensitivityDelete,
			runningSensitivityEdit
	);

	@FindBy(id = "safeRunningTimeout")
	private WebElement runningTimeoutTextbox;

	@FindBy(id = "delete_setting_safeRunningTimeout")
	private WebElement runningTimeoutDelete;

	@FindBy(id = "edit_setting_safeRunningTimeout")
	private WebElement runningTimeoutEdit;

	public ConfigPageField runningTimeoutField = new ConfigPageField(
			RUNNING_TIMEOUT,
			runningTimeoutTextbox,
			runningTimeoutDelete,
			runningTimeoutEdit
	);

	@FindBy(id = "safeSnoozeTimeout")
	private WebElement snoozeTimeoutTextbox;

	@FindBy(id = "delete_setting_safeSnoozeTimeout")
	private WebElement snoozeTimeoutDelete;

	@FindBy(id = "edit_setting_safeSnoozeTimeout")
	private WebElement snoozeTimeoutEdit;

	public ConfigPageField snoozeTimeoutField = new ConfigPageField(
			SNOOZE_TIMEOUT,
			snoozeTimeoutTextbox,
			snoozeTimeoutDelete,
			snoozeTimeoutEdit
	);

	@FindBy(id = "safeWarningStateTimeout")
	private WebElement warningTimeoutTextbox;

	@FindBy(id = "delete_setting_safeWarningStateTimeout")
	private WebElement warningTimeoutDelete;

	@FindBy(id = "edit_setting_safeWarningStateTimeout")
	private WebElement warningTimeoutEdit;

	public ConfigPageField warningTimeoutField = new ConfigPageField(
			WARNING_TIMEOUT,
			warningTimeoutTextbox,
			warningTimeoutDelete,
			warningTimeoutEdit
	);

	@FindBy(id = "safePanicButton")
	private WebElement panicButtonMenu;

	@FindBy(id = "delete_setting_safePanicButton")
	private WebElement panicButtonDelete;

	@FindBy(id = "edit_setting_safePanicButton")
	private WebElement panicButtonEdit;

	public ConfigPageField panicButtonField = new ConfigPageField(
			PANIC_BUTTON,
			panicButtonMenu,
			panicButtonDelete,
			panicButtonEdit
	);

	@FindBy(xpath = "//label[@for=\"on-safePanicSilentAlarm\"]")
	private WebElement onSilentAlarmLabel;

	@FindBy(id = "on-safePanicSilentAlarm")
	private WebElement onSilentAlarmRadio;

	@FindBy(id = "delete_setting_safePanicSilentAlarm")
	private WebElement silentAlarmDelete;

	@FindBy(id = "edit_setting_safePanicSilentAlarm")
	private WebElement silentAlarmEdit;

	public ConfigPageField onSilentAlarmField = new ConfigPageField(
			PANIC_SILENT_ALARM,
			onSilentAlarmLabel,
			onSilentAlarmRadio,
			silentAlarmDelete,
			silentAlarmEdit
	);

	@FindBy(xpath = "//label[@for=\"off-safePanicSilentAlarm\"]")
	private WebElement offSilentAlarmLabel;

	@FindBy(id = "off-safePanicSilentAlarm")
	private WebElement offSilentAlarmRadio;

	public ConfigPageField offSilentAlarmField = new ConfigPageField(
			PANIC_SILENT_ALARM,
			offSilentAlarmLabel,
			offSilentAlarmRadio,
			silentAlarmDelete,
			silentAlarmEdit
	);

	@FindBy(xpath = "//label[@for=\"on-safeEmergencyDialEnabled\"]")
	private WebElement onEmergencyDialLabel;

	@FindBy(id = "on-safeEmergencyDialEnabled")
	private WebElement onEmergencyDialRadio;

	@FindBy(id = "delete_setting_safeEmergencyDialEnabled")
	private WebElement emergencyDialDelete;

	@FindBy(id = "edit_setting_safeEmergencyDialEnabled")
	private WebElement emergencyDialEdit;

	public ConfigPageField onEmergencyDialField = new ConfigPageField(
			EMERGENCY_CALL,
			onEmergencyDialLabel,
			onEmergencyDialRadio,
			emergencyDialDelete,
			emergencyDialEdit
	);

	@FindBy(xpath = "//label[@for=\"off-safeEmergencyDialEnabled\"]")
	private WebElement offEmergencyDialLabel;

	@FindBy(id = "off-safePanicSilentAlarm")
	private WebElement offEmergencyDialRadio;

	public ConfigPageField offEmergencyDialField = new ConfigPageField(
			EMERGENCY_CALL,
			offEmergencyDialLabel,
			offEmergencyDialRadio,
			emergencyDialDelete,
			emergencyDialEdit
	);

	@FindBy(xpath = "//label[@for=\"on-safeEmergencyDialForceSpeakerEnabled\"]")
	private WebElement onEmergencyForceSpeakerLabel;

	@FindBy(id = "on-safeEmergencyDialForceSpeakerEnabled")
	private WebElement onEmergencyForceSpeakerRadio;

	@FindBy(id = "delete_setting_safeEmergencyDialForceSpeakerEnabled")
	private WebElement emergencyForceSpeakerDelete;

	@FindBy(id = "edit_setting_safeEmergencyDialForceSpeakerEnabled")
	private WebElement emergencyForceSpeakerEdit;

	public ConfigPageField onEmergencyForceSpeakerField = new ConfigPageField(
			EMERGENCY_CALL_SPEAKER,
			onEmergencyForceSpeakerLabel,
			onEmergencyForceSpeakerRadio,
			emergencyForceSpeakerDelete,
			emergencyForceSpeakerEdit
	);

	@FindBy(xpath = "//label[@for=\"off-safeEmergencyDialForceSpeakerEnabled\"]")
	private WebElement offEmergencyForceSpeakerLabel;

	@FindBy(id = "off-safeEmergencyDialForceSpeakerEnabled")
	private WebElement offEmergencyForceSpeakerRadio;

	public ConfigPageField offEmergencyForceSpeakerField = new ConfigPageField(
			EMERGENCY_CALL_SPEAKER,
			offEmergencyForceSpeakerLabel,
			offEmergencyForceSpeakerRadio,
			emergencyForceSpeakerDelete,
			emergencyForceSpeakerEdit
	);

	@FindBy(id = "safeEmergencyDialNumber")
	private WebElement emergencyNumberTextbox;

	@FindBy(id = "delete_setting_safeEmergencyDialNumber")
	private WebElement emergencyNumberDelete;

	@FindBy(id = "edit_setting_safeEmergencyDialNumber")
	private WebElement emergencyNumberEdit;

	public ConfigPageField emergencyNumberField = new ConfigPageField(
			EMERGENCY_NUMBER,
			emergencyNumberTextbox,
			emergencyNumberDelete,
			emergencyNumberEdit
	);

	@FindBy(id = "safeWarningTone")
	private WebElement warningToneMenu;

	@FindBy(id = "delete_setting_safeWarningTone")
	private WebElement warningToneDelete;

	@FindBy(id = "edit_setting_safeWarningTone")
	private WebElement warningToneEdit;

	public ConfigPageField warningToneField = new ConfigPageField(
			WARNING_TONE,
			warningToneMenu,
			warningToneDelete,
			warningToneEdit
	);

	@FindBy(id = "safeAlarmTone")
	private WebElement alarmToneMenu;

	@FindBy(id = "delete_setting_safeAlarmTone")
	private WebElement alarmToneDelete;

	@FindBy(id = "edit_setting_safeAlarmTone")
	private WebElement alarmToneEdit;

	public ConfigPageField alarmToneField = new ConfigPageField(
			ALARM_TONE,
			alarmToneMenu,
			alarmToneDelete,
			alarmToneEdit
	);

	public SamSafePage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(onMonitoringField.getTitle(), onMonitoringField);
				put("on" + onMonitoringField.getTitle(), onMonitoringField);
				put("off" + onMonitoringField.getTitle(), offMonitoringField);
				put(moveSensitivityField.getTitle(), moveSensitivityField);
				put(moveTimeoutField.getTitle(), moveTimeoutField);
				put(tiltSensitivityField.getTitle(), tiltSensitivityField);
				put(tiltTimeoutField.getTitle(), tiltTimeoutField);
				put(runningSensitivityField.getTitle(), runningSensitivityField);
				put(runningTimeoutField.getTitle(), runningTimeoutField);
				put(snoozeTimeoutField.getTitle(), snoozeTimeoutField);
				put(warningTimeoutField.getTitle(), warningTimeoutField);
				put(panicButtonField.getTitle(), panicButtonField);
				put(onSilentAlarmField.getTitle(), onSilentAlarmField);
				put("on" + onSilentAlarmField.getTitle(), onSilentAlarmField);
				put("off" + offSilentAlarmField.getTitle(), offSilentAlarmField);
				put(onEmergencyDialField.getTitle(), onEmergencyDialField);
				put("on" + onEmergencyDialField.getTitle(), onEmergencyDialField);
				put("off" + offEmergencyDialField.getTitle(), offEmergencyDialField);
				put(onEmergencyForceSpeakerField.getTitle(), onEmergencyForceSpeakerField);
				put("on" + onEmergencyForceSpeakerField.getTitle(), onEmergencyForceSpeakerField);
				put("off" + offEmergencyForceSpeakerField.getTitle(), offEmergencyForceSpeakerField);
				put(emergencyNumberField.getTitle(), emergencyNumberField);
				put(warningToneField.getTitle(), warningToneField);
				put(alarmToneField.getTitle(), alarmToneField);
			}
		};

	}

	public void clickMonitoringTab() {
		clickOnPageEntity(tabs.get(0));
		sleepSeconds(1);
	}

	public void clickPanicAlarmTab() {
		clickOnPageEntity(tabs.get(1));
		sleepSeconds(1);
	}
}
