package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VmwareTool;
import com.vmware.vim25.VirtualMachinePowerState;
import com.vmware.vim25.mo.VirtualMachine;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamVmSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    private String esxServer = RunDefaults.getStringSetting("esxServer");
    private String esxAccount = RunDefaults.getStringSetting("esxAccount");
    private String esxPassword = RunDefaults.getDecryptedSetting("esxPassword");

    @When("^I shutdown the default SAM VM")
    public void shutdownTestVm() {
        String vmLabel = RunDefaults.getStringSetting("vmLabel");
        VmwareTool server = new VmwareTool(esxServer, esxAccount, esxPassword);
        VirtualMachine testVm = server.getVm(vmLabel);
        if (testVm != null) {
            server.power(vmLabel, "shutdown");
            sleepSeconds(60);
            log.debug("Shutdown {}", vmLabel);
        } else {
            Assert.fail("Could not locate test VM named " + vmLabel);
        }
    }

    @When("^I revert the default SAM VM to the default snapshot")
    public void revertTestVm() {
        String vmLabel = RunDefaults.getStringSetting("vmLabel");
        VmwareTool server = new VmwareTool(esxServer, esxAccount, esxPassword);
        VirtualMachine testVm = server.getVm(vmLabel);
        if (testVm != null) {
            String snapshot = RunDefaults.getStringSetting("vmSnapshot");
            if (server.getSnapshotList(testVm).contains(snapshot)) {
                if (Environment.isSamSet()) {
                    Environment.getSam().imDatabase().close();
                    Environment.getSam().keyDatabase().close();
                }
                server.revertToSnapshot(vmLabel, snapshot);
                server.power(vmLabel, "poweron");
                sleepSeconds(60);
                log.debug("Prepared {} for a new test cycle", vmLabel);
            } else {
                log.warn("Could not revert {} since it doesn't have a snapshot named '{}'", vmLabel, snapshot);
            }
        } else {
            Assert.fail("Could not locate test VM named " + vmLabel);
        }
    }

    @When("^I revert the VM named \"([^\"]*)\" to the snapshot \"([^\"]*)\"")
    public void revertTestSpecifiedVm(String vmLabel, String snapshot) {
        VmwareTool server = new VmwareTool(esxServer, esxAccount, esxPassword);
        VirtualMachine testVm = server.getVm(vmLabel.trim());
        if (testVm != null) {
            if (server.getSnapshotList(testVm).contains(snapshot.trim())) {
                if (Environment.isSamSet()) {
                    Environment.getSam().imDatabase().close();
                    Environment.getSam().keyDatabase().close();
                }
                server.revertToSnapshot(vmLabel.trim(), snapshot.trim());
                server.power(vmLabel.trim(), "poweron");
                sleepSeconds(60);
                log.debug("Prepared {} for a new test cycle", vmLabel);
            } else {
                log.warn("Could not revert {} since it doesn't have a snapshot named '{}'", vmLabel, snapshot);
            }
        } else {
            Assert.fail("Could not locate test VM named " + vmLabel);
        }
    }

    @Then("^the default VM is running")
    public void verifyVmRunning() {
        String vmLabel = RunDefaults.getStringSetting("vmLabel");
        VmwareTool server = new VmwareTool(esxServer, esxAccount, esxPassword);
        VirtualMachine testVm = server.getVm(vmLabel.trim());
        if (testVm != null) {
            String snapshot = RunDefaults.getStringSetting("vmSnapshot");
            VirtualMachinePowerState state = testVm.getRuntime().powerState;
            if (state.equals(VirtualMachinePowerState.poweredOn)) {
                log.debug("Verified {} is running", vmLabel);
            } else {
                log.error("Could not revert {} since it doesn't have a snapshot named '{}'", vmLabel, snapshot);
                Assert.fail("Default VM Failed To Revert");
            }
        } else {
            Assert.fail("Could not locate test VM named " + vmLabel);
        }
    }
}
