package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamVqoPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.VQO;

public class SamVqoSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I check the \"([^\"]*)\" VQO field$")
	public void checkVqoCheckbox(String arg1) {
		SamVqoPage vqoPage = (SamVqoPage) Environment.getCurrentPage();
		if (vqoPage.getField(arg1.trim()) != null) {
			vqoPage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I uncheck the \"([^\"]*)\" VQO field$")
	public void uncheckVqoCheckbox(String arg1) {
		SamVqoPage vqoPage = (SamVqoPage) Environment.getCurrentPage();
		if (vqoPage.getField(arg1.trim()) != null) {
			vqoPage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I drag the slider to \"([^\"]*)\" on the \"([^\"]*)\" VQO field$")
	public void movePttSlider(String arg1, String arg2) {
		SamVqoPage vqoPage = (SamVqoPage) Environment.getCurrentPage();
		if (vqoPage.getField(arg2.trim()) != null) {
			Integer newValue = Integer.valueOf(arg1.trim());
			if (newValue < -55 && newValue > -101) {
				vqoPage.rssiThresholdField.updateSliderValue(newValue);
			} else {
				log.error("Requested slider value {} is out of range (0-100)", newValue);
				Assert.fail("Invalid Slider Value");
			}
		} else {
			log.error("No matching field with label '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@Then("^\"([^\"]*)\" should have the approximate value of \"([^\"]*)\" in the \"([^\"]*)\" VQO setting$")
	public void verifyApproximatePttValue(String arg1, String arg2, String arg3) throws Throwable {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(VQO, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(VQO, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(VQO)) phone.loadAppPreferences(VQO);
				Environment.addScenarioFailure(phone.compareApproximate(fieldKey, arg2.trim(), 2));
			} else {
				log.error("No matching field with label '{}'", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the \"([^\"]*)\" VQO setting$")
	public void verifyVqoValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (SamFields.getStrings(VQO, arg3.trim()) != null) {
				String fieldKey = SamFields.getStrings(VQO, arg3.trim()).attribute();
				if (!phone.getCurrentAppSettings().equals(VQO)) phone.loadAppPreferences(VQO);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("Field with label '{}' does not exist", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I delete the \"([^\"]*)\" VQO field$")
	public void deleteVqoSetting(String arg1) {
		SamVqoPage vqoPage = (SamVqoPage) Environment.getCurrentPage();
		vqoPage.getField(arg1.trim()).delete();
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the custom attribute \"([^\"]*)\" VQO setting$")
	public void checkVqoCustomAttributeSetting(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			if (!phone.getCurrentAppSettings().equals(VQO)) phone.loadAppPreferences(VQO);
			Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2.trim()));
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@Then("^the VQO page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyPttPageValue(String arg1, String arg2) {
		SamVqoPage vqoPage = (SamVqoPage) Environment.getCurrentPage();
		if (vqoPage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(vqoPage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(vqoPage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Field with label '{}' does not exist", arg2);
		}
	}
}