package com.spectralink.test_automation.cucumber.framework.device.common;

import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.device.DeviceAutomation;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import java.util.List;
import java.util.logging.Logger;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static io.appium.java_client.touch.offset.PointOption.point;

public class ConfigUiField extends DeviceAutomation {
	private final org.apache.logging.log4j.Logger log = LogManager.getLogger(this.getClass().getName());
	private WebElement labelElement;
	private WebElement controlElement;
	private WebElement valueElement;
	private List<WebElement> imageElements;
	private String key;
	private String attribute;
	private EntityType type;
	private String description;
	private String resourceId;

	public enum EntityType {
		CHECKBOX,
		TextView,
		Password,
		RADIO,
		Button,
		ImageView,
		SeekBar,
		Unknown
	}

	public ConfigUiField(AndroidDriver driver, FieldData strings, WebElement labelElement, WebElement controlElement, WebElement valueElement, WebElement ... images) {
		super(driver);
		this.key = strings.title();
		this.attribute = strings.attribute();
		this.labelElement = labelElement;
		this.controlElement = controlElement;
		this.valueElement = valueElement;
		for (WebElement image : images) {
			this.imageElements.add(image);
		}
	}

	public WebElement getLabelElement() {
		return labelElement;
	}

	public String getLabelElementValue() {
		return labelElement.getText();
	}

	public void setLabelElement(WebElement labelElement) {
		this.labelElement = labelElement;
	}

	public boolean hasLabelElement() {
		return labelElement != null;
	}

	public WebElement getControlElement() {
		return controlElement;
	}

	public void setControlElement(WebElement controlElement) {
		this.controlElement = controlElement;
	}

	public boolean hasControlElement() {
		return controlElement != null;
	}

	public WebElement getValueElement() {
		return valueElement;
	}

	public String getValue() {
		return valueElement.getText();
	}

	public void setValueElement(WebElement valueElement) {
		this.valueElement = valueElement;
	}

	public boolean hasValueElement() {
		return valueElement != null;
	}

	public List<WebElement> getImageElements() {
		return imageElements;
	}

	public void addImageElement(WebElement imageElement) {
		this.imageElements.add(imageElement);
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public EntityType getType() {
		if (type != null) {
			return type;
		} else {
			String entityClass = getEntityClass(controlElement);
			if (entityClass == null) {
				log.error("Cannot locate element {}", controlElement);
				type = EntityType.Unknown;
			} else {
				for (EntityType control : EntityType.values()) {
					if (control.name().contains(entityClass)) {
						type = control;
						description = getEntityDescription(controlElement);
						resourceId = getEntityResourceId(controlElement);
					}
				}
				if (type == null) {
					log.error("Element {} had unknown entity type of {}", controlElement.getText(), entityClass);
					type = EntityType.Unknown;
					description = "";
					resourceId = "";
				}
			}
			return type;
		}
	}


	/*public String getLabelText() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO)) {
			if (labelElement != null) {
				return labelElement.getText();
			}
		} else {
			log.warn("Cannot get label text for an element of type {}", entityType.name());
		}
		return null;
	}*/

	public void enter(String text) {
		if (controlElement != null) {
			typeIntoPageEntity(controlElement, text);
		} else {
			log.error("No control field defined for field");
		}
		sleepSeconds(1);
	}

	public void clear() {
		if (controlElement != null) {
			clearPageEntity(controlElement);
		} else {
			log.error("No control field defined for field");
		}
		sleepSeconds(1);
	}

	public boolean isLabelPresent() {
		try {
			return labelElement != null && labelElement.isDisplayed();
		} catch (NoSuchElementException nsee) {
			return false;
		}
	}

	public boolean isControlPresent() {
		try {
			return controlElement != null && controlElement.isDisplayed();
		} catch (NoSuchElementException nsee) {
			return false;
		}
	}

	public boolean isValuePresent() {
		try {
			return valueElement != null && valueElement.isDisplayed();
		} catch (NoSuchElementException nsee) {
			return false;
		}
	}

	public boolean isValueAccessible() {
		if (hasLabelElement()) {
			scrollIntoView(getKey());
			if (!isValuePresent()) {
				scroll("up", 250);
			}
		}
		return isValuePresent();
	}

	public void tap() {
		if (controlElement != null) {
			clickOnPageEntity(controlElement);
		} else {
			clickOnPageEntity(labelElement);
		}
		sleepSeconds(1);
	}

	public boolean selectScrollableMenuOption(String option) {
		scrollIntoExactViewAttribute(option.trim());
		List<WebElement> options = driver.findElements(By.className("android.widget.CheckedTextView"));
		for (WebElement element : options) {
			if (element.getText().toLowerCase().trim().equals(option.toLowerCase().trim())) {
				clickOnPageEntity(element);
				sleepSeconds(1);
				return true;
			}
		}
		return false;
	}

	public boolean selectCheckedMenuOption(String option) {
		List<WebElement> options = driver.findElements(By.className("android.widget.CheckedTextView"));
		for (WebElement element : options) {
			if (element.getText().toLowerCase().contentEquals(option.toLowerCase())) {
				clickOnPageEntity(element);
				sleepSeconds(1);
				return true;
			}
		}
		return false;
	}

	public boolean selectCheckedMenuOptionForButtons(String option) {
		scrollIntoExactViewAttribute(option.trim());
		List<WebElement> options = driver.findElements(By.id("android:id/text1"));
		for (WebElement element : options) {
			if (element.getText().trim().equals(option.trim())) {
				clickOnPageEntity(element);
				sleepSeconds(1);
				return true;
			}
		}
		return false;
	}

	public boolean selectSameCheckedMenuOptionAsButtonItself(String option) {
		scrollIntoExactViewAttributeDifferentInstance(option.trim(), 1);
		List<WebElement> options = driver.findElements(By.id("android:id/text1"));
		for (WebElement element : options) {
			if (element.getText().trim().equals(option.trim())) {
				clickOnPageEntity(element);
				sleepSeconds(1);
				return true;
			}
		}
		return false;
	}

	public void flingForward() {
		try {
			driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingForward();");
		} catch (Exception e) {
			// ignore
		}
	}

	public void flingBackward() {
		try {
			driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingBackward();");
		} catch (Exception e) {
			// ignore
		}
	}

	public boolean selectApplication(String option) {
		scrollIntoExactViewDescription(option + " checked_text_view");
		List<WebElement> options = driver.findElements(By.className("android.widget.CheckedTextView"));
		for (WebElement element : options) {
			if (element.getText().trim().contentEquals(option.trim())) {
				clickOnPageEntity(element);
				sleepSeconds(1);
				return true;
			}
		}
		return false;
	}

	public boolean selectTextMenuOption(String option) {
		List<WebElement> options = driver.findElements(By.className("android.widget.TextView"));
		for (WebElement element : options) {
			if (element.getText().toLowerCase().contentEquals(option.toLowerCase())) {
				clickOnPageEntity(element);
				sleepSeconds(1);
				return true;
			}
		}
		return false;
	}

	public boolean selectImageMenuOption(int position) {
		List<WebElement> options = driver.findElements(By.className("android.widget.ImageView"));
		if (position > 0 && position < options.size()) {
			clickOnPageEntity(options.get(position - 1));
			sleepSeconds(1);
			return true;
		}
		return false;
	}

	public void scrollDown() {
		sleepSeconds(1);
		Dimension size = driver.manage().window().getSize ();
		int startX = size.getWidth () / 2;
		int startY = (int) (size.height * 0.20);
		int endY = (int) (size.height * 0.80);
		new TouchAction(driver).press(point(startX, startY)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(500))).moveTo(point(startX, endY)).release().perform();
		sleepSeconds(2);
	}

	public void scrollUp() {
		sleepSeconds(1);
		Dimension size = driver.manage().window().getSize ();
		int startX = size.getWidth () / 2;
		int startY = (int) (size.height * 0.835);
		int endY = (int) (size.height * 0.165);
		new TouchAction(driver).press(point(startX, startY)).moveTo(point(startX, endY)).release().perform();
		sleepSeconds(2);
	}

	public void scroll(String direction, int distance) {
		Dimension size = driver.manage().window().getSize ();
		int middleX = size.getWidth() / 2;
		int middleY = size.getHeight() / 2;
		int startY;
		int endY;
		if (direction.contentEquals("up")) {
			startY = middleY + (distance / 2);
			endY = middleY - (distance / 2);
		} else {
			startY = middleY - (distance / 2);
			endY = middleY + (distance / 2);
		}
		new TouchAction(driver).press(point(middleX, startY)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(500))).moveTo(point(middleX, endY)).release().perform();
		Util.sleepSeconds(2);
		log.debug("Scrolled {} {} pixels", direction, distance);
	}

	public void swipeUp() {
		sleepSeconds(1);
		Dimension size = driver.manage().window().getSize();
		Point position = controlElement.getLocation();
		TouchAction touchAction = new TouchAction(driver);
		int finalXPosition = position.getX() - 200 < 0 ? 0 : position.getX() - 200;
		touchAction.press(point(position.getX(), position.getY())).waitAction().moveTo(point(finalXPosition, position.getY())).perform();
		log.debug("Swiped on control element");
		sleepSeconds(1);
	}

	public void longPress(String element) {
		MobileElement mobileElement = (MobileElement)driver.findElementByAccessibilityId(element);
		new TouchAction(driver).longPress(ElementOption.element(mobileElement)).perform();
		sleepSeconds(1);
	}

	public void longPress(int holdSeconds) {
		log.debug("Press and holding for {} seconds on '{}'", holdSeconds, labelElement.getText());
		MobileElement mobileElement = (MobileElement) controlElement;
		new TouchAction(driver).longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(mobileElement)).withDuration(Duration.ofSeconds(holdSeconds))).release().perform();
	}

	/*public boolean isEnabled() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO)) {
			return isEntitySelected(controlElement);
		}
		return false;
	}

	public void enable() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO)) {
			if (labelElement != null && !isEntitySelected(controlElement)) {
				clickOnPageEntity(labelElement);
			}
		} else {
			log.warn("Cannot enable an element of type {}", entityType.name());
		}
	}

	public void disable() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX) || entityType.equals(EntityType.RADIO)) {
			if (labelElement != null && isEntitySelected(controlElement)) {
				clickOnPageEntity(labelElement);
			}
		} else {
			log.warn("Cannot disable an element of type {}", entityType.name());
		}
	}

	public void checkUncheck(Boolean enable) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX)) {
			if (labelElement != null) {
				if (enable != null) {
					if (enable && !isEntitySelected(controlElement)) {
						clickOnPageEntity(labelElement);
					} else if (!enable && isEntitySelected(controlElement)) {
						clickOnPageEntity(labelElement);
					}
				} else {
					log.error("No boolean value set for {}", getControlElement().toString());
				}
			} else {
				log.error("No label defined for {}", getControlElement().toString());
			}
		} else {
			log.warn("Cannot disable an element of type {}", entityType.name());
		}
	}

	public void selectText(String option) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			selectMenuByText(controlElement, option);
		} else {
			log.warn("Cannot select an element of type {}", entityType.name());
		}
	}

	public void selectIndex(int option) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			selectMenuByIndex(controlElement, option);
		} else {
			log.warn("Cannot select an element of type {}", entityType.name());
		}
	}

	public void selectValue(String option) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			selectMenuByValue(controlElement, option);
		} else {
			log.warn("Cannot select an element of type {}", entityType.name());
		}
	}

	public String getSelection() {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			return getMenuSelectedOption(controlElement);
		} else {
			log.warn("Cannot get option for element of type {}", entityType.name());
			return null;
		}
	}*/

	public Integer updateSliderValue(int targetValue, int sliderMin, int sliderMax) {
		EntityType entityType = getType();
		if (entityType.equals(EntityType.SeekBar)) {
			double elementWidth = controlElement.getSize().getWidth();
			double range = sliderMax - sliderMin;
			double middle = sliderMin + (range / 2);
			double travel = targetValue - middle;
			double increments = (elementWidth / range) * 0.91;
			Long travelPixels = Math.round(increments * travel);
			Actions builder = new Actions(driver);
			java.util.logging.Level seleniumLogLevel = Logger.getLogger("org.openqa.selenium").getLevel();
			Logger.getLogger("org.openqa.selenium").setLevel(java.util.logging.Level.SEVERE);
			builder.dragAndDropBy(controlElement, travelPixels.intValue(), 0).build().perform();
			Logger.getLogger("org.openqa.selenium").setLevel(seleniumLogLevel);
			log.debug("Set slider value to {}", targetValue);
			sleepSeconds(1);
			return targetValue;
		} else {
			log.warn("Cannot slide an element of type {}", entityType.name());
			return 0;
		}
	}

	/*public void delete() {
		setTemporaryWait(2);
		if (valueElement != null) {
			if (isEntityClickable(valueElement)) {
				clickOnPageEntity(valueElement);
				WebElement dialogDeleteButton = locateElement(By.xpath("//button[contains(text(), \"Delete\")]"));
				if (dialogDeleteButton != null) {
					try {
						clickOnPageEntity(dialogDeleteButton);
						WebElement toastMessage = locateElement(By.className("default-message-content"));
						sleepSeconds(1);
					} catch (StaleElementReferenceException sere) {
						log.trace("Stale element reference");
					}
				} else {
				    log.error("Could not click delete acknowledgement button");
                }
			} else {
				log.warn("Could not click trash icon {}", valueElement);
			}
		}
		removeTemporaryWait();
	}

	public void edit() {
		setTemporaryWait(0);
		if (imageElements != null && isEntityClickable(imageElements)) {
			clickOnPageEntity(imageElements);
		}
		removeTemporaryWait();
	}

	public void undo() {
		setTemporaryWait(2);
		if (undoButton != null && isEntityClickable(undoButton)) {
			clickOnPageEntity(undoButton);
		}
		removeTemporaryWait();
	}

	public void updateTextbox(Object newText) {
		setTemporaryWait(0);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.TEXTBOX) || entityType.equals(EntityType.PASSWORD)) {
			edit();
			enter(newText.toString());
		} else {
			log.error("Cannot enter text into an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public void updateCheckbox(Boolean newState) {
		setTemporaryWait(1);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.CHECKBOX)) {
			edit();
			checkUncheck(newState);
		} else {
			log.error("Cannot check or uncheck an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public void updateRadioButton() {
		setTemporaryWait(1);
		EntityType targetType = getType();
		if (targetType.equals(EntityType.RADIO)) {
			edit();
			enable();
		} else {
			log.error("Can't click radio on an element of type {}", targetType.name());
		}
		removeTemporaryWait();
	}

	public void updateMenuByLabel(String newLabel) {
		setTemporaryWait(1);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			edit();
			selectText(newLabel);
		} else {
			log.error("Can't choose option on an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public void updateMenuByIndex(Integer newNumber) {
		setTemporaryWait(1);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			edit();
			selectIndex(newNumber);
		} else {
			log.error("Can't choose option index on an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public void updateMenuByValue(String newValue) {
		setTemporaryWait(1);
		EntityType entityType = getType();
		if (entityType.equals(EntityType.MENU)) {
			edit();
			selectValue(newValue);
		} else {
			log.error("Can't choose option value on an element of type {}", type.name());
		}
		removeTemporaryWait();
	}

	public boolean isConfigured() {
		setTemporaryWait(0);
		boolean deleteAvailable = false;
		if (isEntityClickable(valueElement)) {
			deleteAvailable = true;
		}
		removeTemporaryWait();
		return deleteAvailable;
	}

	private WebElement findEntity(WebElement element, String xpath) {
		WebElement targetEntity = null;
		try {
			targetEntity = element.findElement(By.xpath(xpath));
		} catch (NoSuchElementException nsee) {
			log.debug(nsee.getMessage());
		}
		return targetEntity;
	}

	public int compareState(String samValue) {
		String pageValue = controlElement.getAttribute("value");
		if (pageValue == null) {
			log.fatal("Could not get value for page element {}", controlElement);
			return 1;
		} else if (!pageValue.contains(samValue)) {
			log.fatal(String.format("Mismatch on %-40s Data Setting: %-15s Page Setting: %-15s", controlElement.toString(), samValue, pageValue));
			return 1;
		} else {
			return 0;
		}
	}

	public int compareState(Integer samValue) {
		Integer pageValue = Integer.valueOf(controlElement.getAttribute("value"));
		if (pageValue == null) {
			log.fatal("Could not get value for page element {}", controlElement);
			return 1;
		} else if (!samValue.equals(pageValue)) {
			log.fatal(String.format("Mismatch on %-40s Data Setting: %-15s Page Setting: %-15s", controlElement.toString(), samValue, pageValue));
			return 1;
		} else {
			return 0;
		}
	}

	public int compareState(Boolean samValue) {
		Boolean pageValue = controlElement.isSelected();
		if (pageValue == null) {
			log.fatal("Could not get value for page element {}", controlElement);
			return 1;
		} else if (!samValue.equals(pageValue)) {
			log.fatal(String.format("Mismatch on %-40s Data Setting: %-15s Page Setting: %-15s", controlElement.toString(), samValue, pageValue));
			return 1;
		} else {
			return 0;
		}
	}
*/
}
