package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class AppSetting {
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private String type;
	private String parameter;
	private Object parameterValue;
	private List<String> legalValues = new ArrayList<>();

	public AppSetting() {
		legalValues.add("string");
		legalValues.add("int");
		legalValues.add("boolean");
		legalValues.add("long");

		this.type = "string";
		this.parameter = "Unset";
	}

	public AppSetting(String type, String parameter, String value) {
		legalValues.add("string");
		legalValues.add("int");
		legalValues.add("boolean");
		legalValues.add("long");

		if (type != null && legalValues.contains(type.toLowerCase())) {
			this.type = type.toLowerCase();
		} else {
			log.error("Invalid setting type {} used: setting to default {}", Util.quote(type), Util.quote("string"));
			this.type = "string";
		}
		this.type = type != null && legalValues.contains(type.toLowerCase()) ? type : "string";
		this.parameter = parameter;
		switch(this.type) {
			case "int":
				parameterValue = Integer.valueOf(value);
				break;
			case "boolean":
				parameterValue = Boolean.valueOf(value);
				break;
			case "long":
				parameterValue = Long.valueOf(value);
				break;
			default:
				parameterValue = value;
		}
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		if (type != null && legalValues.contains(type.toLowerCase())) {
			this.type = type.toLowerCase();
		} else {
			log.error(Util.glue("Invalid setting type", Util.quote(type), "used: setting to default", Util.quote("string")));
			this.type = "string";
		}
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		if (parameter != null && parameter.length() > 0) {
			this.parameter = parameter;
		} else {
			log.error(Util.glue("Invalid setting parameter name", Util.quote(type), "used: setting to default", Util.quote("none")));
			this.parameter = "none";
		}
	}

	public Object getValue() {
		return parameterValue;
	}

	public Integer getIntegerValue() {
		if (parameterValue instanceof Integer) {
			return (Integer) parameterValue;
		} else {
			log.error(Util.glue("Value", parameterValue, "of parameter", parameter, "is not type Integer"));
			return null;
		}
	}

	public Boolean getBooleanValue() {
		if (parameterValue instanceof Boolean) {
			return (Boolean) parameterValue;
		} else {
			log.error(Util.glue("Value", parameterValue, "of parameter", parameter, "is not type Boolean"));
			return null;
		}
	}

	public String getStringValue() {
		if (parameterValue instanceof String) {
			return (String) parameterValue;
		} else {
			log.error(Util.glue("Value", parameterValue, "of parameter", parameter, "is not type String"));
			return null;
		}
	}

	public Long getLongValue() {
		if (parameterValue instanceof Long) {
			return (Long) parameterValue;
		} else {
			log.error(Util.glue("Value", parameterValue, "of parameter", parameter, "is not type Long"));
			return null;
		}
	}

	public String getForcedStringValue() {
		return parameterValue.toString();
	}

	public void setValue(String value) {
		if (parameter != null && parameter.length() > 0) {
			switch (type) {
				case "int":
					parameterValue = Integer.valueOf(value);
					break;
				case "boolean":
					parameterValue = Boolean.valueOf(value);
					break;
				default:
					parameterValue = value;
			}
		} else {
			parameterValue = "invalid";
		}
	}
}
