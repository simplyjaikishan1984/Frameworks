package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.AndroidPhone;
import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.BizPhoneStrings.*;

public class SamBizPhonePage extends SamConfigurationPage {

	@FindBy(className = "md-tab")
	private List<WebElement> tabs;

	@FindBy(xpath = "//*[contains(text(), 'SIP Registration 1')]")
	private WebElement sipRegistration1Link;

	@FindBy(xpath = "//*[contains(text(), 'SIP Registration 2')]")
	private WebElement sipRegistration2Link;

	@FindBy(xpath = "//*[contains(text(), 'Solution Partner Program')]")
	private WebElement ciscoPartnerProgram;

	@FindBy(xpath = "//*[contains(text(), 'Common Settings')]")
	private WebElement sipCommonSettingsLink;

	@FindBy(xpath = "//*[contains(text(), 'Custom Attributes')]")
	private WebElement customAttributesLink;

	@FindBy(id = "add_more_bizPhoneEmer")
	private WebElement sipAddContactButton;

	@FindBy(id = "remove_dynamic_bizPhoneEmer")
	private WebElement sipRemoveContactButton;

	@FindBy(id = "enable_sip")
	private WebElement enableSipLabel;

	@FindBy(id = "sipEnableDisable")
	private WebElement enableSipCheckbox;

	@FindBy(id = "edit_setting_sipEnableDisable")
	private WebElement editEnableSip;

	@FindBy(id = "delete_setting_sipEnableDisable")
	private WebElement deleteEnableSip;

	@FindBy(id = "sipRegOne")
	private WebElement registration1Accordian;

	@FindBy(id = "sipRegTwo")
	private WebElement registration2Accordian;

	@FindBy(id = "CiscoPartnerProgram")
	private WebElement ciscoAccordian;

	@FindBy(id = "commanSettings")
	private WebElement commonSettingsAccordian;

	@FindBy(id = "item_temSentViaCaller")
	private WebElement customAttributesAccordian;

	public ConfigPageField enableSipField = new ConfigPageField(
			ENABLE_SIP,
			enableSipLabel,
			enableSipCheckbox,
			deleteEnableSip,
			editEnableSip
	);

	@FindBy(id = "sipServerSipDomain")
	private WebElement sip1ServerAddressTextbox;

	@FindBy(id = "delete_setting_sipServerSipDomain")
	private WebElement sip1ServerAddressDelete;

	@FindBy(id = "edit_setting_sipServerSipDomain")
	private WebElement sip1ServerAddressEdit;

	public ConfigPageField sip1ServerAddressField = new ConfigPageField(
			SIP_1_SERVER_ADDRESS,
			sip1ServerAddressTextbox,
			sip1ServerAddressDelete,
			sip1ServerAddressEdit
	);

	@FindBy(id = "sipServerPort")
	private WebElement sip1ServerPortTextbox;

	@FindBy(id = "delete_setting_sipServerPort")
	private WebElement sip1ServerPortDelete;

	@FindBy(id = "edit_setting_sipServerPort")
	private WebElement sip1ServerPortEdit;

	public ConfigPageField sip1ServerPortField = new ConfigPageField(
			SIP_1_SERVER_PORT,
			sip1ServerPortTextbox,
			sip1ServerPortDelete,
			sip1ServerPortEdit
	);

	@FindBy(id = "sipTransport")
	private WebElement sip1TransportMenu;

	@FindBy(id = "delete_setting_sipTransport")
	private WebElement sip1TransportDelete;

	@FindBy(id = "edit_setting_sipTransport")
	private WebElement sip1TransportEdit;

	public ConfigPageField sip1TransportField = new ConfigPageField(
			SIP_1_TRANSPORT,
			sip1TransportMenu,
			sip1TransportDelete,
			sip1TransportEdit
	);

	@FindBy(id = "sipReg1Extension")
	private WebElement sip1ExtensionTextbox;

	@FindBy(id = "delete_setting_sipReg1Extension")
	private WebElement sip1ExtensionDelete;

	@FindBy(id = "edit_setting_sipReg1Extension")
	private WebElement sip1ExtensionEdit;

	public ConfigPageField sip1ExtensionField = new ConfigPageField(
			SIP_1_EXTENSION,
			sip1ExtensionTextbox,
			sip1ExtensionDelete,
			sip1ExtensionEdit
	);

	@FindBy(id = "sipReg1AuthName")
	private WebElement sip1UsernameTextbox;

	@FindBy(id = "delete_setting_sipReg1AuthName")
	private WebElement sip1UsernameDelete;

	@FindBy(id = "edit_setting_sipReg1AuthName")
	private WebElement sip1UsernameEdit;

	public ConfigPageField sip1UsernameField = new ConfigPageField(
			SIP_1_USERNAME,
			sip1UsernameTextbox,
			sip1UsernameDelete,
			sip1UsernameEdit
	);

	@FindBy(id = "sipReg1AuthPassword")
	private WebElement sip1PasswordTextbox;

	@FindBy(id = "delete_setting_sipReg1AuthPassword")
	private WebElement sip1PasswordDelete;

	@FindBy(id = "edit_setting_sipReg1AuthPassword")
	private WebElement sip1PasswordEdit;

	public ConfigPageField sip1PasswordField = new ConfigPageField(
			SIP_1_PASSWORD,
			sip1PasswordTextbox,
			sip1PasswordDelete,
			sip1PasswordEdit
	);

	@FindBy(id = "show-password-checkbox-label")
	private WebElement sip1ShowPasswordLabel;

	@FindBy(id = "show-password-checkbox")
	private WebElement sip1ShowPasswordCheckbox;

	public ConfigPageField sip1ShowPasswordField = new ConfigPageField(
			SIP_1_SHOW_PASSWORD,
			sip1ShowPasswordLabel,
			sip1ShowPasswordCheckbox,
			null,
			null
	);

	@FindBy(id = "sipVoiceMailUri")
	private WebElement sip1VmAddressTextbox;

	@FindBy(id = "delete_setting_sipVoiceMailUri")
	private WebElement sip1VmAddressDelete;

	@FindBy(id = "edit_setting_sipVoiceMailUri")
	private WebElement sip1VmAddressEdit;

	public ConfigPageField sip1VmAddressField = new ConfigPageField(
			SIP_1_VOICEMAIL_ADDRESS,
			sip1VmAddressTextbox,
			sip1VmAddressDelete,
			sip1VmAddressEdit
	);

	@FindBy(id = "enable_sipStandardHoldSignaling_label")
	private WebElement sip1HoldSignallingLabel;

	@FindBy(id = "enable_sipStandardHoldSignaling")
	private WebElement sip1HoldSignallingCheckbox;

	@FindBy(id = "delete_setting_sipStandardHoldSignaling")
	private WebElement sip1HoldSignallingDelete;

	@FindBy(id = "edit_setting_sipStandardHoldSignaling")
	private WebElement sip1HoldSignallingEdit;

	public ConfigPageField sip1HoldSignallingField = new ConfigPageField(
			SIP_1_HOLD_SIGNALING,
			sip1HoldSignallingLabel,
			sip1HoldSignallingCheckbox,
			sip1HoldSignallingDelete,
			sip1HoldSignallingEdit
	);

	@FindBy(id = "enable_sipMwSubcribe_label")
	private WebElement sip1MessageWaitingNotificationLabel;

	@FindBy(id = "enable_sipMwSubcribe")
	private WebElement sip1MessageWaitingNotificationCheckbox;

	@FindBy(id = "delete_setting_sipMwSubcribe")
	private WebElement sip1MessageWaitingNotificationDelete;

	@FindBy(id = "edit_setting_sipMwSubcribe")
	private WebElement sip1MessageWaitingNotificationEdit;

	public ConfigPageField sip1MessageWaitingNotificationField = new ConfigPageField(
			SIP_1_FORCE_SUBSCRIPTION,
			sip1MessageWaitingNotificationLabel,
			sip1MessageWaitingNotificationCheckbox,
			sip1MessageWaitingNotificationDelete,
			sip1MessageWaitingNotificationEdit
	);

	@FindBy(id = "enable_sipContactHeaderUpdate_label")
	private WebElement sip1ContactHeaderUpdatesLabel;

	@FindBy(id = "enable_sipContactHeaderUpdate")
	private WebElement sip1ContactHeaderUpdatesCheckbox;

	@FindBy(id = "delete_setting_sipContactHeaderUpdate")
	private WebElement sip1ContactHeaderUpdatesDelete;

	@FindBy(id = "edit_setting_sipContactHeaderUpdate")
	private WebElement sip1ContactHeaderUpdatesEdit;

	public ConfigPageField sip1ContactHeaderUpdatesField = new ConfigPageField(
			SIP_1_ALLOW_CONTACT_UPDATES,
			sip1ContactHeaderUpdatesLabel,
			sip1ContactHeaderUpdatesCheckbox,
			sip1ContactHeaderUpdatesDelete,
			sip1ContactHeaderUpdatesEdit
	);

	@FindBy(id = "enable_sipReg1UseNewTcpPort_label")
	private WebElement sip1HeaderPortChangeLabel;

	@FindBy(id = "enable_sipReg1UseNewTcpPort")
	private WebElement sip1HeaderPortChangeCheckbox;

	@FindBy(id = "delete_setting_sipReg1UseNewTcpPort")
	private WebElement sip1HeaderPortChangeDelete;

	@FindBy(id = "edit_setting_sipReg1UseNewTcpPort")
	private WebElement sip1HeaderPortChangeEdit;

	public ConfigPageField sip1HeaderPortChangeField = new ConfigPageField(
			SIP_1_SPECIFY_TCP_PORT,
			sip1HeaderPortChangeLabel,
			sip1HeaderPortChangeCheckbox,
			sip1HeaderPortChangeDelete,
			sip1HeaderPortChangeEdit
	);

	@FindBy(id = "enable_sip1VendorProtocol_label")
	private WebElement sip1VendorProtocolLabel;

	@FindBy(id = "enable_sip1VendorProtocol")
	private WebElement sip1VendorProtocolCheckbox;

	@FindBy(id = "delete_setting_sip1VendorProtocol")
	private WebElement sip1VendorProtocolDelete;

	@FindBy(id = "edit_setting_sip1VendorProtocol")
	private WebElement sip1VendorProtocolEdit;

	public ConfigPageField sip1VendorProtocolField = new ConfigPageField(
			SIP_1_VENDOR_PROTOCOL,
			sip1VendorProtocolLabel,
			sip1VendorProtocolCheckbox,
			sip1VendorProtocolDelete,
			sip1VendorProtocolEdit
	);

	@FindBy(id = "enable_sip1CallFeatureCallForwardingEnable_label")
	private WebElement sip1CallForwardingLabel;

	@FindBy(id = "enable_sip1CallFeatureCallForwardingEnable")
	private WebElement sip1CallForwardingCheckbox;

	@FindBy(id = "delete_setting_sip1CallFeatureCallForwardingEnable")
	private WebElement sip1CallForwardingDelete;

	@FindBy(id = "edit_setting_sip1CallFeatureCallForwardingEnable")
	private WebElement sip1CallForwardingEdit;

	public ConfigPageField sip1CallForwardingField = new ConfigPageField(
			SIP_1_CALL_FORWARDING,
			sip1CallForwardingLabel,
			sip1CallForwardingCheckbox,
			sip1CallForwardingDelete,
			sip1CallForwardingEdit
	);

	@FindBy(id = "enable_sip1DisableCallWaiting_label")
	private WebElement sip1DisableCallWaitingLabel;

	@FindBy(id = "enable_sip1DisableCallWaiting")
	private WebElement sip1DisableCallWaitingCheckbox;

	@FindBy(id = "delete_setting_sip1DisableCallWaiting")
	private WebElement sip1DisableCallWaitingDelete;

	@FindBy(id = "edit_setting_sip1DisableCallWaiting")
	private WebElement sip1DisableCallWaitingEdit;

	public ConfigPageField sip1DisableCallWaitingField = new ConfigPageField(
			SIP_1_CALL_WAITING,
			sip1DisableCallWaitingLabel,
			sip1DisableCallWaitingCheckbox,
			sip1DisableCallWaitingDelete,
			sip1DisableCallWaitingEdit
	);

	@FindBy(id = "sipReg2ServerSipDomain")
	private WebElement sip2ServerAddressTextbox;

	@FindBy(id = "delete_setting_sipReg2ServerSipDomain")
	private WebElement sip2ServerAddressDelete;

	@FindBy(id = "edit_setting_sipReg2ServerSipDomain")
	private WebElement sip2ServerAddressEdit;

	public ConfigPageField sip2ServerAddressField = new ConfigPageField(
			SIP_2_SERVER_ADDRESS,
			sip2ServerAddressTextbox,
			sip2ServerAddressDelete,
			sip2ServerAddressEdit
	);

	@FindBy(id = "sipReg2ServerPort")
	private WebElement sip2ServerPortTextbox;

	@FindBy(id = "delete_setting_sipReg2ServerPort")
	private WebElement sip2ServerPortDelete;

	@FindBy(id = "edit_setting_sipReg2ServerPort")
	private WebElement sip2ServerPortEdit;

	public ConfigPageField sip2ServerPortField = new ConfigPageField(
			SIP_2_SERVER_PORT,
			sip2ServerPortTextbox,
			sip2ServerPortDelete,
			sip2ServerPortEdit
	);

	@FindBy(id = "sipReg2Transport")
	private WebElement sip2TransportMenu;

	@FindBy(id = "delete_setting_sipReg2Transport")
	private WebElement sip2TransportDelete;

	@FindBy(id = "edit_setting_sipReg2Transport")
	private WebElement sip2TransportEdit;

	public ConfigPageField sip2TransportField = new ConfigPageField(
			SIP_2_TRANSPORT,
			sip2TransportMenu,
			sip2TransportDelete,
			sip2TransportEdit
	);

	@FindBy(id = "sipReg2Extension")
	private WebElement sip2ExtensionTextbox;

	@FindBy(id = "delete_setting_sipReg2Extension")
	private WebElement sip2ExtensionDelete;

	@FindBy(id = "edit_setting_sipReg2Extension")
	private WebElement sip2ExtensionEdit;

	public ConfigPageField sip2ExtensionField = new ConfigPageField(
			SIP_2_EXTENSION,
			sip2ExtensionTextbox,
			sip2ExtensionDelete,
			sip2ExtensionEdit
	);

	@FindBy(id = "sipReg2AuthName")
	private WebElement sip2UsernameTextbox;

	@FindBy(id = "delete_setting_sipReg2AuthName")
	private WebElement sip2UsernameDelete;

	@FindBy(id = "edit_setting_sipReg2AuthName")
	private WebElement sip2UsernameEdit;

	public ConfigPageField sip2UsernameField = new ConfigPageField(
			SIP_2_USERNAME,
			sip2UsernameTextbox,
			sip2UsernameDelete,
			sip2UsernameEdit
	);

	@FindBy(id = "sipReg2AuthPassword")
	private WebElement sip2PasswordTextbox;

	@FindBy(id = "delete_setting_sipReg2AuthPassword")
	private WebElement sip2PasswordDelete;

	@FindBy(id = "edit_setting_sipReg2AuthPassword")
	private WebElement sip2PasswordEdit;

	public ConfigPageField sip2PasswordField = new ConfigPageField(
			SIP_2_PASSWORD,
			sip2PasswordTextbox,
			sip2PasswordDelete,
			sip2PasswordEdit
	);

	@FindBy(id = "show-reg2-password-checkbox-label")
	private WebElement sip2ShowPasswordLabel;

	@FindBy(id = "show-reg2-password-checkbox")
	private WebElement sip2ShowPasswordCheckbox;

	public ConfigPageField sip2ShowPasswordField = new ConfigPageField(
			SIP_2_SHOW_PASSWORD,
			sip2ShowPasswordLabel,
			sip2ShowPasswordCheckbox,
			null,
			null
	);

	@FindBy(id = "sipReg2VoiceMailUri")
	private WebElement sip2VoiceMailAddressTextbox;

	@FindBy(id = "delete_setting_sipReg2VoiceMailUri")
	private WebElement sip2VoiceMailAddressDelete;

	@FindBy(id = "edit_setting_sipReg2VoiceMailUri")
	private WebElement sip2VoiceMailAddressEdit;

	public ConfigPageField sip2VmAddressField = new ConfigPageField(
			SIP_2_VOICEMAIL_ADDRESS,
			sip2VoiceMailAddressTextbox,
			sip2VoiceMailAddressDelete,
			sip2VoiceMailAddressEdit
	);

	@FindBy(id = "enable_config_manager_label_reg2")
	private WebElement sip2EnableHoldSignallingLabel;

	@FindBy(id = "enable_sipReg2StandardHoldSignaling")
	private WebElement sip2EnableHoldSignallingCheckbox;

	@FindBy(id = "delete_setting_sipReg2StandardHoldSignaling")
	private WebElement sip2HoldSignallingDelete;

	@FindBy(id = "edit_setting_sipReg2StandardHoldSignaling")
	private WebElement sip2HoldSignallingEdit;

	public ConfigPageField sip2HoldSignallingField = new ConfigPageField(
			SIP_2_HOLD_SIGNALING,
			sip2EnableHoldSignallingLabel,
			sip2EnableHoldSignallingCheckbox,
			sip2HoldSignallingDelete,
			sip2HoldSignallingEdit
	);

	@FindBy(id = "enable_sipReg2MwSubcribe_label")
	private WebElement sip2MessageWaitingNotificationLabel;

	@FindBy(id = "enable_sipReg2MwSubcribe")
	private WebElement sip2MessageWaitingNotificationCheckbox;

	@FindBy(id = "delete_setting_sipReg2MwSubcribe")
	private WebElement sip2MessageWaitingNotificationDelete;

	@FindBy(id = "edit_setting_sipReg2MwSubcribe")
	private WebElement sip2MessageWaitingNotificationEdit;

	public ConfigPageField sip2MessageWaitingNotificationField = new ConfigPageField(
			SIP_2_FORCE_SUBSCRIPTION,
			sip2MessageWaitingNotificationLabel,
			sip2MessageWaitingNotificationCheckbox,
			sip2MessageWaitingNotificationDelete,
			sip2MessageWaitingNotificationEdit
	);

	@FindBy(id = "enable_sipReg2ContactHeaderUpdate_label")
	private WebElement sip2ContactHeaderUpdatesLabel;

	@FindBy(id = "enable_sipReg2ContactHeaderUpdate")
	private WebElement sip2ContactHeaderUpdatesCheckbox;

	@FindBy(id = "delete_setting_sipReg2ContactHeaderUpdate")
	private WebElement sip2ContactHeaderUpdatesDelete;

	@FindBy(id = "edit_setting_sipReg2ContactHeaderUpdate")
	private WebElement sip2ContactHeaderUpdatesEdit;

	public ConfigPageField sip2ContactHeaderUpdatesField = new ConfigPageField(
			SIP_2_ALLOW_CONTACT_UPDATES,
			sip2ContactHeaderUpdatesLabel,
			sip2ContactHeaderUpdatesCheckbox,
			sip2ContactHeaderUpdatesDelete,
			sip2ContactHeaderUpdatesEdit
	);

	@FindBy(id = "enable_sipReg2UseNewTcpPort_label")
	private WebElement sip2HeaderPortChange;

	@FindBy(id = "enable_sipReg2UseNewTcpPort")
	private WebElement sip2HeaderPortChangeCheckbox;

	@FindBy(id = "delete_setting_sipReg2UseNewTcpPort")
	private WebElement sip2HeaderPortChangeDelete;

	@FindBy(id = "edit_setting_sipReg2UseNewTcpPort")
	private WebElement sip2HeaderPortChangeEdit;

	public ConfigPageField sip2HeaderPortChangeField = new ConfigPageField(
			SIP_2_SPECIFY_TCP_PORT,
			sip2HeaderPortChange,
			sip2HeaderPortChangeCheckbox,
			sip2HeaderPortChangeDelete,
			sip2HeaderPortChangeEdit
	);

	@FindBy(id = "enable_sip2VendorProtocol_label")
	private WebElement sip2VendorProtocolLabel;

	@FindBy(id = "enable_sip2VendorProtocol")
	private WebElement sip2VendorProtocolCheckbox;

	@FindBy(id = "delete_setting_sip2VendorProtocol")
	private WebElement sip2VendorProtocolDelete;

	@FindBy(id = "edit_setting_sip2VendorProtocol")
	private WebElement sip2VendorProtocolEdit;

	public ConfigPageField sip2VendorProtocolField = new ConfigPageField(
			SIP_2_VENDOR_PROTOCOL,
			sip2VendorProtocolLabel,
			sip2VendorProtocolCheckbox,
			sip2VendorProtocolDelete,
			sip2VendorProtocolEdit
	);

	@FindBy(id = "enable_sip2DisableCallWaiting_label")
	private WebElement sip2DisableCallWaitingLabel;

	@FindBy(id = "enable_sip2DisableCallWaiting")
	private WebElement sip2DisableCallWaitingCheckbox;

	@FindBy(id = "delete_setting_sip2DisableCallWaiting")
	private WebElement sip2DisableCallWaitingDelete;

	@FindBy(id = "edit_setting_sip2DisableCallWaiting")
	private WebElement sip2DisableCallWaitingEdit;

	public ConfigPageField sip2DisableCallWaitingField = new ConfigPageField(
			SIP_2_CALL_WAITING,
			sip2DisableCallWaitingLabel,
			sip2DisableCallWaitingCheckbox,
			sip2DisableCallWaitingDelete,
			sip2DisableCallWaitingEdit
	);

	@FindBy(id = "enable_sip1CallFeatureIDivertEnable_label")
	private WebElement sip1IDivertLabel;

	@FindBy(id = "enable_sip1CallFeatureIDivertEnable")
	private WebElement sip1IDivertCheckbox;

	@FindBy(id = "delete_setting_sip1CallFeatureIDivertEnable")
	private WebElement sip1IDivertDelete;

	@FindBy(id = "edit_setting_sip1CallFeatureIDivertEnable")
	private WebElement sip1IDivertEdit;

	public ConfigPageField sip1IDivertField = new ConfigPageField(
			CISCO_I_DIVERT,
			sip1IDivertLabel,
			sip1IDivertCheckbox,
			sip1IDivertDelete,
			sip1IDivertEdit
	);

	@FindBy(id = "enable_sip1CallfeatureCallParkEnable_label")
	private WebElement sip1CallParkLabel;

	@FindBy(id = "enable_sip1CallfeatureCallParkEnable")
	private WebElement sip1CallParkCheckbox;

	@FindBy(id = "delete_setting_sip1CallfeatureCallParkEnable")
	private WebElement sip1CallParkDelete;

	@FindBy(id = "edit_setting_sip1CallfeatureCallParkEnable")
	private WebElement sip1CallParkEdit;

	public ConfigPageField sip1CallParkField = new ConfigPageField(
			CISCO_CALL_PARK,
			sip1CallParkLabel,
			sip1CallParkCheckbox,
			sip1CallParkDelete,
			sip1CallParkEdit
	);

	@FindBy(id = "enable_sip1CallfeatureHuntGroupLogonEnable_label")
	private WebElement sip1HuntGroupLogonLabel;

	@FindBy(id = "enable_sip1CallfeatureHuntGroupLogonEnable")
	private WebElement sip1HuntGroupLogonCheckbox;

	@FindBy(id = "delete_setting_sip1CallfeatureHuntGroupLogonEnable")
	private WebElement sip1HuntGroupLogonDelete;

	@FindBy(id = "edit_setting_sip1CallfeatureHuntGroupLogonEnable")
	private WebElement sip1HuntGroupLogonEdit;

	public ConfigPageField sip1HuntGroupLogonField = new ConfigPageField(
			CISCO_HUNT_GROUP_LOGON,
			sip1HuntGroupLogonLabel,
			sip1HuntGroupLogonCheckbox,
			sip1HuntGroupLogonDelete,
			sip1HuntGroupLogonEdit
	);

	@FindBy(id = "enable_voicemailEnable_label")
	private WebElement ciscoVoicemailLabel;

	@FindBy(id = "enable_voicemailEnable")
	private WebElement ciscoVoicemailCheckbox;

	@FindBy(id = "delete_setting_voicemailEnable")
	private WebElement ciscoVoicemailDelete;

	@FindBy(id = "edit_setting_voicemailEnable")
	private WebElement ciscoVoicemailEdit;

	public ConfigPageField ciscoVoicemailField = new ConfigPageField(
			CISCO_VOICEMAIL,
			ciscoVoicemailLabel,
			ciscoVoicemailCheckbox,
			ciscoVoicemailDelete,
			ciscoVoicemailEdit
	);

	@FindBy(id = "ciscoUnityConnectionServerAddress")
	private WebElement ciscoServerAddressTextbox;

	@FindBy(id = "delete_setting_ciscoUnityConnectionServerAddress")
	private WebElement ciscoServerAddressDelete;

	@FindBy(id = "edit_setting_ciscoUnityConnectionServerAddress")
	private WebElement ciscoServerAddressEdit;

	public ConfigPageField ciscoServerAddressField = new ConfigPageField(
			CISCO_UNITY_SERVER_ADDRESS,
			ciscoServerAddressTextbox,
			ciscoServerAddressDelete,
			ciscoServerAddressEdit
	);

	@FindBy(id = "ciscoUnityServerUsername")
	private WebElement ciscoServerUsernameTextbox;

	@FindBy(id = "delete_setting_ciscoUnityServerUsername")
	private WebElement ciscoServerUsernameDelete;

	@FindBy(id = "edit_setting_ciscoUnityServerUsername")
	private WebElement ciscoServerUsernameEdit;

	public ConfigPageField ciscoServerUsernameField = new ConfigPageField(
			CISCO_SERVER_USERNAME,
			ciscoServerUsernameTextbox,
			ciscoServerUsernameDelete,
			ciscoServerUsernameEdit
	);

	@FindBy(id = "ciscoUnityServerPassword")
	private WebElement ciscoServerPasswordTextbox;

	@FindBy(id = "delete_setting_ciscoUnityServerPassword")
	private WebElement ciscoServerPasswordDelete;

	@FindBy(id = "edit_setting_ciscoUnityServerPassword")
	private WebElement ciscoServerPasswordEdit;

	public ConfigPageField ciscoServerPasswordField = new ConfigPageField(
			CISCO_SERVER_PASSWORD,
			ciscoServerPasswordTextbox,
			ciscoServerPasswordDelete,
			ciscoServerPasswordEdit
	);

	@FindBy(id = "show-cisco-unity-server-password-label")
	private WebElement ciscoShowPasswordLabel;

	@FindBy(id = "show-cisco-unity-server-password")
	private WebElement ciscoShowPasswordCheckbox;

	public ConfigPageField ciscoShowPasswordField = new ConfigPageField(
			CISCO_SERVER_SHOW_PASSWORD,
			ciscoShowPasswordLabel,
			ciscoShowPasswordCheckbox,
			null,
			null
	);

	@FindBy(id = "enable_ciscoContactSearchEnable_label")
	private WebElement ciscoContactSearchLabel;

	@FindBy(id = "enable_ciscoContactSearchEnable")
	private WebElement ciscoContactSearchCheckbox;

	@FindBy(id = "delete_setting_ciscoContactSearchEnable")
	private WebElement ciscoContactSearchDelete;

	@FindBy(id = "edit_setting_ciscoContactSearchEnable")
	private WebElement ciscoContactSearchEdit;

	@FindBy(id = "undo_setting_ciscoContactSearchEnable")
	private WebElement ciscoContactSearchUndo;

	public ConfigPageField ciscoContactSearchField = new ConfigPageField(
			CISCO_CONTACT_SEARCH,
			ciscoContactSearchLabel,
			ciscoContactSearchCheckbox,
			ciscoContactSearchDelete,
			ciscoContactSearchEdit,
			ciscoContactSearchUndo
	);

	@FindBy(id = "enable_ciscoAdvancedSearchDirectoryEnable_label")
	private WebElement ciscoAdvancedSearchLabel;

	@FindBy(id = "enable_ciscoAdvancedSearchDirectoryEnable")
	private WebElement ciscoAdvancedSearchCheckbox;

	@FindBy(id = "delete_setting_ciscoAdvancedSearchDirectoryEnable")
	private WebElement ciscoAdvancedSearchDelete;

	@FindBy(id = "edit_setting_ciscoAdvancedSearchDirectoryEnable")
	private WebElement ciscoAdvancedSearchEdit;

	@FindBy(id = "undo_setting_ciscoAdvancedSearchDirectoryEnable")
	private WebElement ciscoAdvancedSearchUndo;

	public ConfigPageField ciscoAdvancedSearchField = new ConfigPageField(
			CISCO_ADVANCED_SEARCH,
			ciscoAdvancedSearchLabel,
			ciscoAdvancedSearchCheckbox,
			ciscoAdvancedSearchDelete,
			ciscoAdvancedSearchEdit,
			ciscoAdvancedSearchUndo
	);

	@FindBy(id = "ciscoAdvancedSearchDirectoryServerAddress")
	private WebElement ciscoDirectoryServerAddressTextbox;

	@FindBy(id = "delete_setting_ciscoAdvancedSearchDirectoryServerAddress")
	private WebElement ciscoDirectoryServerAddressDelete;

	@FindBy(id = "edit_setting_ciscoAdvancedSearchDirectoryServerAddress")
	private WebElement ciscoDirectoryServerAddressEdit;

	@FindBy(id = "undo_setting_ciscoAdvancedSearchDirectoryServerAddress")
	private WebElement ciscoDirectoryServerAddressUndo;

	public ConfigPageField ciscoDirectoryServerAddressField = new ConfigPageField(
			CISCO_DIRECTORY_SERVER_ADDRESS,
			null,
			ciscoDirectoryServerAddressTextbox,
			ciscoDirectoryServerAddressDelete,
			ciscoDirectoryServerAddressEdit,
			ciscoDirectoryServerAddressUndo
	);

	@FindBy(id = "ciscoAdvancedSearchDirectoryServerUsername")
	private WebElement ciscoDirectoryServerAccountTextbox;

	@FindBy(id = "delete_setting_ciscoAdvancedSearchDirectoryServerUsername")
	private WebElement ciscoDirectoryServerAccountDelete;

	@FindBy(id = "edit_setting_ciscoAdvancedSearchDirectoryServerUsername")
	private WebElement ciscoDirectoryServerAccountEdit;

	@FindBy(id = "undo_setting_ciscoAdvancedSearchDirectoryServerUsername")
	private WebElement ciscoDirectoryServerAccountUndo;

	public ConfigPageField ciscoDirectoryServerAccountField = new ConfigPageField(
			CISCO_DIRECTORY_SERVER_ACCOUNT,
			null,
			ciscoDirectoryServerAccountTextbox,
			ciscoDirectoryServerAccountDelete,
			ciscoDirectoryServerAccountEdit,
			ciscoDirectoryServerAccountUndo
	);

	@FindBy(id = "ciscoAdvancedSearchDirectoryServerPassword")
	private WebElement ciscoDirectoryServerPasswordTextbox;

	@FindBy(id = "delete_setting_ciscoAdvancedSearchDirectoryServerPassword")
	private WebElement ciscoDirectoryServerPasswordDelete;

	@FindBy(id = "edit_setting_ciscoAdvancedSearchDirectoryServerPassword")
	private WebElement ciscoDirectoryServerPasswordEdit;

	@FindBy(id = "undo_setting_ciscoAdvancedSearchDirectoryServerPassword")
	private WebElement ciscoDirectoryServerPasswordUndo;

	public ConfigPageField ciscoDirectoryServerPasswordField = new ConfigPageField(
			CISCO_DIRECTORY_SERVER_PASSWORD,
			null,
			ciscoDirectoryServerPasswordTextbox,
			ciscoDirectoryServerPasswordDelete,
			ciscoDirectoryServerPasswordEdit,
			ciscoDirectoryServerPasswordUndo
	);

	@FindBy(id = "show-cisco-advanced-search-directory-server-password-label")
	private WebElement ciscoDirectoryServerShowPasswordLabel;

	@FindBy(id = "show-cisco-advanced-search-directory-server-password")
	private WebElement ciscoDirectoryServerShowPasswordCheckbox;

	public ConfigPageField ciscoDirectoryServerShowPasswordField = new ConfigPageField(
			CISCO_DIRECTORY_SERVER_SHOW_PASSWORD,
			ciscoDirectoryServerShowPasswordLabel,
			ciscoDirectoryServerShowPasswordCheckbox,
			null,
			null
	);

	@FindBy(id = "ciscoAdvancedSearchDirectoryParameter")
	private WebElement ciscoDirectoryServerSearchFieldMenu;

	@FindBy(id = "delete_setting_ciscoAdvancedSearchDirectoryParameter")
	private WebElement ciscoDirectoryServerSearchFieldDelete;

	@FindBy(id = "edit_setting_ciscoAdvancedSearchDirectoryParameter")
	private WebElement ciscoDirectoryServerSearchFieldEdit;

	@FindBy(id = "undo_setting_ciscoAdvancedSearchDirectoryParameter")
	private WebElement ciscoDirectoryServerSearchFieldUndo;

	public ConfigPageField ciscoDirectoryServerSearchFieldField = new ConfigPageField(
			CISCO_DIRECTORY_SERVER_SEARCH_FIELD,
			null,
			ciscoDirectoryServerSearchFieldMenu,
			ciscoDirectoryServerSearchFieldDelete,
			ciscoDirectoryServerSearchFieldEdit,
			ciscoDirectoryServerSearchFieldUndo
	);

	@FindBy(id = "ciscoAdvancedSearchDirectoryValue")
	private WebElement ciscoDirectoryServerSearchValueTextbox;

	@FindBy(id = "delete_setting_ciscoAdvancedSearchDirectoryValue")
	private WebElement ciscoDirectoryServerSearchValueDelete;

	@FindBy(id = "edit_setting_ciscoAdvancedSearchDirectoryValue")
	private WebElement ciscoDirectoryServerSearchValueEdit;

	@FindBy(id = "undo_setting_ciscoAdvancedSearchDirectoryValue")
	private WebElement ciscoDirectoryServerSearchValueUndo;

	public ConfigPageField ciscoDirectoryServerSearchValueField = new ConfigPageField(
			CISCO_DIRECTORY_SERVER_SEARCH_VALUES,
			null,
			ciscoDirectoryServerSearchValueTextbox,
			ciscoDirectoryServerSearchValueDelete,
			ciscoDirectoryServerSearchValueEdit,
			ciscoDirectoryServerSearchValueUndo
	);

	@FindBy(id = "sipAudioDscp")
	private WebElement sipAudioDscpTextbox;

	@FindBy(id = "delete_setting_sipAudioDscp")
	private WebElement sipAudioDscpDelete;

	@FindBy(id = "edit_setting_sipAudioDscp")
	private WebElement sipAudioDscpEdit;

	public ConfigPageField sipAudioDscpField = new ConfigPageField(
			AUDIO_DSCP,
			sipAudioDscpTextbox,
			sipAudioDscpDelete,
			sipAudioDscpEdit
	);

	@FindBy(id = "sipCallControlDscp")
	private WebElement sipCallControlDscpTextbox;

	@FindBy(id = "delete_setting_sipCallControlDscp")
	private WebElement sipCallControlDscpDelete;

	@FindBy(id = "edit_setting_sipCallControlDscp")
	private WebElement sipCallControlDscpEdit;

	public ConfigPageField sipCallControlDscpField = new ConfigPageField(
			CALL_CONTROL_DSCP,
			sipCallControlDscpTextbox,
			sipCallControlDscpDelete,
			sipCallControlDscpEdit
	);

	@FindBy(id = "enable_sipOverrideSwitchToTcp_label")
	private WebElement overrideSwitchToTcpLabel;

	@FindBy(id = "enable_sipOverrideSwitchToTcp")
	private WebElement overrideSwitchToTcpCheckbox;

	@FindBy(id = "delete_setting_sipOverrideSwitchToTcp")
	private WebElement overrideSwitchToTcpDelete;

	@FindBy(id = "edit_setting_sipOverrideSwitchToTcp")
	private WebElement overrideSwitchToTcpEdit;

	public ConfigPageField overrideSwitchToTcpField = new ConfigPageField(
			OVERRIDE_TCP_SWITCH,
			overrideSwitchToTcpLabel,
			overrideSwitchToTcpCheckbox,
			overrideSwitchToTcpDelete,
			overrideSwitchToTcpEdit
	);

	@FindBy(id = "sipDtmfRelayPayloadType")
	private WebElement sipDtmfRelayPayloadTextbox;

	@FindBy(id = "delete_setting_sipDtmfRelayPayloadType")
	private WebElement sipDtmfRelayPayloadDelete;

	@FindBy(id = "edit_setting_sipDtmfRelayPayloadType")
	private WebElement sipDtmfRelayPayloadEdit;

	public ConfigPageField sipDtmfRelayPayloadField = new ConfigPageField(
			DTMF_PAYLOAD_TYPE,
			sipDtmfRelayPayloadTextbox,
			sipDtmfRelayPayloadDelete,
			sipDtmfRelayPayloadEdit
	);

	@FindBy(id = "enable_sipDtmfTones_label")
	private WebElement forceInbandDtmfTonesLabel;

	@FindBy(id = "enable_sipDtmfTones")
	private WebElement forceInbandDtmfTonesCheckbox;

	@FindBy(id = "delete_setting_sipDtmfTones")
	private WebElement forceInbandDtmfTonesDelete;

	@FindBy(id = "edit_setting_sipDtmfTones")
	private WebElement forceInbandDtmfTonesEdit;

	public ConfigPageField sipForceInbandDtmfTonesField = new ConfigPageField(
			FORCE_IN_BAND_TONES,
			forceInbandDtmfTonesLabel,
			forceInbandDtmfTonesCheckbox,
			forceInbandDtmfTonesDelete,
			forceInbandDtmfTonesEdit
	);

	@FindBy(id = "delete_setting_sipCodecList")
	private WebElement audioCodecsDelete;

	@FindBy(id = "edit_setting_sipCodecList")
	private WebElement audioCodecsEdit;

	@FindBy(id = "ausiocodec_label_0")
	private WebElement firstAudioCodecLabel;

	@FindBy(id = "enable_ausiocodec_label_0")
	private WebElement firstAudioCodecCheckbox;

	public ConfigPageField sipFirstAudioCodecField = new ConfigPageField(
			CODEC_G_711U_PRIORITY,
			firstAudioCodecLabel,
			firstAudioCodecCheckbox,
			audioCodecsDelete,
			audioCodecsEdit
	);

	@FindBy(id = "ausiocodec_label_1")
	private WebElement secondAudioCodecLabel;

	@FindBy(id = "enable_ausiocodec_label_1")
	private WebElement secondAudioCodecCheckbox;

	public ConfigPageField sipSecondAudioCodecField = new ConfigPageField(
			CODEC_G_711A_PRIORITY,
			secondAudioCodecLabel,
			secondAudioCodecCheckbox,
			audioCodecsDelete,
			audioCodecsEdit
	);

	@FindBy(id = "ausiocodec_label_2")
	private WebElement thirdAudioCodecLabel;

	@FindBy(id = "enable_ausiocodec_label_2")
	private WebElement thirdAudioCodecCheckbox;

	public ConfigPageField sipThirdAudioCodecField = new ConfigPageField(
			CODEC_G_729A_PRIORITY,
			thirdAudioCodecLabel,
			thirdAudioCodecCheckbox,
			audioCodecsDelete,
			audioCodecsEdit
	);

	@FindBy(id = "ausiocodec_label_3")
	private WebElement fourthAudioCodecLabel;

	@FindBy(id = "enable_ausiocodec_label_3")
	private WebElement fourthAudioCodecCheckbox;

	public ConfigPageField sipFourthAudioCodecField = new ConfigPageField(
			CODEC_G_722_PRIORITY,
			fourthAudioCodecLabel,
			fourthAudioCodecCheckbox,
			audioCodecsDelete,
			audioCodecsEdit
	);

	@FindBy(className = "fa-caret-down")
	private List<WebElement> downCarets;

	public ConfigPageField firstCodecDownCaretField = new ConfigPageField(
			downCarets.get(0),
			audioCodecsDelete,
			audioCodecsEdit
	);

	public ConfigPageField secondCodecDownCaretField = new ConfigPageField(
			downCarets.get(1),
			audioCodecsDelete,
			audioCodecsEdit
	);

	public ConfigPageField thirdCodecDownCaretField = new ConfigPageField(
			downCarets.get(2),
			audioCodecsDelete,
			audioCodecsEdit
	);

	public ConfigPageField fourthCodecDownCaretField = new ConfigPageField(
			downCarets.get(3),
			audioCodecsDelete,
			audioCodecsEdit
	);

	@FindBy(className = "fa-caret-up")
	private List<WebElement> upCarets;

	public ConfigPageField firstCodecUpCaretField = new ConfigPageField(
			upCarets.get(0),
			audioCodecsDelete,
			audioCodecsEdit
	);

	public ConfigPageField secondCodecUpCaretField = new ConfigPageField(
			upCarets.get(1),
			audioCodecsDelete,
			audioCodecsEdit
	);

	public ConfigPageField thirdCodecUpCaretField = new ConfigPageField(
			upCarets.get(2),
			audioCodecsDelete,
			audioCodecsEdit
	);

	public ConfigPageField fourthCodecUpCaretField = new ConfigPageField(
			upCarets.get(3),
			audioCodecsDelete,
			audioCodecsEdit
	);

	@FindBy(css = "label[id^='ausiocodec_label']")
	private List<WebElement> codecLabels;

	@FindBy(xpath = "//*[contains(@id,'enable_ausiocodec')]")
	private List<WebElement> codecCheckboxes;

	// LDAP page

	@FindBy(id = "ldapServerAddr")
	private WebElement ldapAddressTextbox;

	@FindBy(id = "delete_setting_ldapServerAddr")
	private WebElement ldapAddressDelete;

	@FindBy(id = "edit_setting_ldapServerAddr")
	private WebElement ldapAddressEdit;

	public ConfigPageField ldapServerAddressField = new ConfigPageField(
			LDAP_SERVER_ADDRESS,
			ldapAddressTextbox,
			ldapAddressDelete,
			ldapAddressEdit
	);

	@FindBy(id = "ldapServerPort")
	private WebElement ldapPortTextbox;

	@FindBy(id = "delete_setting_ldapServerPort")
	private WebElement ldapPortDelete;

	@FindBy(id = "edit_setting_ldapServerPort")
	private WebElement ldapPortEdit;

	public ConfigPageField ldapServerPortField = new ConfigPageField(
			LDAP_SERVER_PORT,
			ldapPortTextbox,
			ldapPortDelete,
			ldapPortEdit
	);

	@FindBy(id = "ldapSecurityType")
	private WebElement ldapSecurityMenu;

	@FindBy(id = "delete_setting_ldapSecurityType")
	private WebElement ldapSecurityDelete;

	@FindBy(id = "edit_setting_ldapSecurityType")
	private WebElement ldapSecurityEdit;

	public ConfigPageField ldapSecurityTypeField = new ConfigPageField(
			LDAP_SECURITY_TYPE,
			ldapSecurityMenu,
			ldapSecurityDelete,
			ldapSecurityEdit
	);

	@FindBy(id = "ldapBindDn")
	private WebElement ldapBindDnTextbox;

	@FindBy(id = "delete_setting_ldapBindDn")
	private WebElement ldapBindDnDelete;

	@FindBy(id = "edit_setting_ldapBindDn")
	private WebElement ldapBindDnEdit;

	public ConfigPageField ldapBindDnField = new ConfigPageField(
			LDAP_BIND_DN,
			ldapBindDnTextbox,
			ldapBindDnDelete,
			ldapBindDnEdit
	);

	@FindBy(id = "ldapBindPw")
	private WebElement ldapBindPasswordTextbox;

	@FindBy(id = "delete_setting_ldapBindPw")
	private WebElement ldapBindPasswordDelete;

	@FindBy(id = "edit_setting_ldapBindPw")
	private WebElement ldapBindPasswordEdit;

	public ConfigPageField ldapBindPasswordField = new ConfigPageField(
			LDAP_BIND_PASSWORD,
			ldapBindPasswordTextbox,
			ldapBindPasswordDelete,
			ldapBindPasswordEdit
	);

	@FindBy(id = "ldapBaseDn")
	private WebElement ldapBaseDnTextbox;

	@FindBy(id = "delete_setting_ldapBaseDn")
	private WebElement ldapBaseDnDelete;

	@FindBy(id = "edit_setting_ldapBaseDn")
	private WebElement ldapBaseDnEdit;

	public ConfigPageField ldapBaseDnField = new ConfigPageField(
			LDAP_BASE_DN,
			ldapBaseDnTextbox,
			ldapBaseDnDelete,
			ldapBaseDnEdit
	);

	@FindBy(id = "ldapPrimaryEmail")
	private WebElement ldapPrimaryEmailTextbox;

	@FindBy(id = "delete_setting_ldapPrimaryEmail")
	private WebElement ldapPrimaryEmailDelete;

	@FindBy(id = "edit_setting_ldapPrimaryEmail")
	private WebElement ldapPrimaryEmailEdit;

	public ConfigPageField ldapPrimaryEmailField = new ConfigPageField(
			LDAP_PRIMARY_EMAIL,
			ldapPrimaryEmailTextbox,
			ldapPrimaryEmailDelete,
			ldapPrimaryEmailEdit
	);

	@FindBy(id = "ldapAltEmail")
	private WebElement ldapAlternateEmailTextbox;

	@FindBy(id = "delete_setting_ldapAltEmail")
	private WebElement ldapAlternateEmailDelete;

	@FindBy(id = "edit_setting_ldapAltEmail")
	private WebElement ldapAlternateEmailEdit;

	public ConfigPageField ldapAlternateEmailField = new ConfigPageField(
			LDAP_ALTERNATE_EMAIL,
			ldapAlternateEmailTextbox,
			ldapAlternateEmailDelete,
			ldapAlternateEmailEdit
	);

	// Emergency contacts page

	@FindBy(id = "iceContactName1")
	private WebElement contact1NameTextbox;

	@FindBy(id = "delete_setting_iceContactName1")
	private WebElement contact1NameDelete;

	@FindBy(id = "edit_setting_iceContactName1")
	private WebElement contact1NameEdit;

	public ConfigPageField contact1NameField = new ConfigPageField(
			CONTACT_NAME_1,
			contact1NameTextbox,
			contact1NameDelete,
			contact1NameEdit
	);

	@FindBy(id = "iceContactNumber1")
	private WebElement contact1NumberTextbox;

	@FindBy(id = "delete_setting_iceContactNumber1")
	private WebElement contact1NumberDelete;

	@FindBy(id = "edit_setting_iceContactNumber1")
	private WebElement contact1NumberEdit;

	public ConfigPageField contact1NumberField = new ConfigPageField(
			CONTACT_NUMBER_1,
			contact1NumberTextbox,
			contact1NumberDelete,
			contact1NumberEdit
	);

	@FindBy(id = "iceContactName2")
	private WebElement contact2NameTextbox;

	@FindBy(id = "delete_setting_iceContactName2")
	private WebElement contact2NameDelete;

	@FindBy(id = "edit_setting_iceContactName2")
	private WebElement contact2NameEdit;

	public ConfigPageField contact2NameField = new ConfigPageField(
			CONTACT_NAME_2,
			contact2NameTextbox,
			contact2NameDelete,
			contact2NameEdit
	);

	@FindBy(id = "iceContactNumber2")
	private WebElement contact2NumberTextbox;

	@FindBy(id = "delete_setting_iceContactNumber2")
	private WebElement contact2NumberDelete;

	@FindBy(id = "edit_setting_iceContactNumber2")
	private WebElement contact2NumberEdit;

	public ConfigPageField contact2NumberField = new ConfigPageField(
			CONTACT_NUMBER_2,
			contact2NumberTextbox,
			contact2NumberDelete,
			contact2NumberEdit
	);

	@FindBy(id = "iceContactName3")
	private WebElement contact3NameTextbox;

	@FindBy(id = "delete_setting_iceContactName3")
	private WebElement contact3NameDelete;

	@FindBy(id = "edit_setting_iceContactName3")
	private WebElement contact3NameEdit;

	public ConfigPageField contact3NameField = new ConfigPageField(
			CONTACT_NAME_3,
			contact3NameTextbox,
			contact3NameDelete,
			contact3NameEdit
	);

	@FindBy(id = "iceContactNumber3")
	private WebElement contact3NumberTextbox;

	@FindBy(id = "delete_setting_iceContactNumber3")
	private WebElement contact3NumberDelete;

	@FindBy(id = "edit_setting_iceContactNumber3")
	private WebElement contact3NumberEdit;

	public ConfigPageField contact3NumberField = new ConfigPageField(
			CONTACT_NUMBER_3,
			contact3NumberTextbox,
			contact3NumberDelete,
			contact3NumberEdit
	);

	@FindBy(id = "iceContactName4")
	private WebElement contact4NameTextbox;

	@FindBy(id = "delete_setting_iceContactName4")
	private WebElement contact4NameDelete;

	@FindBy(id = "edit_setting_iceContactName4")
	private WebElement contact4NameEdit;

	public ConfigPageField contact4NameField = new ConfigPageField(
			CONTACT_NAME_4,
			contact4NameTextbox,
			contact4NameDelete,
			contact4NameEdit
	);

	@FindBy(id = "iceContactNumber4")
	private WebElement contact4NumberTextbox;

	@FindBy(id = "delete_setting_iceContactNumber4")
	private WebElement contact4NumberDelete;

	@FindBy(id = "edit_setting_iceContactNumber4")
	private WebElement contact4NumberEdit;

	public ConfigPageField contact4NumberField = new ConfigPageField(
			CONTACT_NUMBER_4,
			contact4NumberTextbox,
			contact4NumberDelete,
			contact4NumberEdit
	);

	@FindBy(id = "iceContactName5")
	private WebElement contact5NameTextbox;

	@FindBy(id = "delete_setting_iceContactName5")
	private WebElement contact5NameDelete;

	@FindBy(id = "edit_setting_iceContactName5")
	private WebElement contact5NameEdit;

	public ConfigPageField contact5NameField = new ConfigPageField(
			CONTACT_NAME_5,
			contact5NameTextbox,
			contact5NameDelete,
			contact5NameEdit
	);

	@FindBy(id = "iceContactNumber5")
	private WebElement contact5NumberTextbox;

	@FindBy(id = "delete_setting_iceContactNumber5")
	private WebElement contact5NumberDelete;

	@FindBy(id = "edit_setting_iceContactNumber5")
	private WebElement contact5NumberEdit;

	public ConfigPageField contact5NumberField = new ConfigPageField(
			CONTACT_NUMBER_5,
			contact5NumberTextbox,
			contact5NumberDelete,
			contact5NumberEdit
	);

	public SamBizPhonePage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(enableSipField.getTitle(), enableSipField);
				put(sip1ServerAddressField.getTitle(), sip1ServerAddressField);
				put(sip1ServerPortField.getTitle(), sip1ServerPortField);
				put(sip1TransportField.getTitle(), sip1TransportField);
				put(sip1ExtensionField.getTitle(), sip1ExtensionField);
				put(sip1UsernameField.getTitle(), sip1UsernameField);
				put(sip1PasswordField.getTitle(), sip1PasswordField);
				put(sip1ShowPasswordField.getTitle(), sip1ShowPasswordField);
				put(sip1VmAddressField.getTitle(), sip1VmAddressField);
				put(sip1HoldSignallingField.getTitle(), sip1HoldSignallingField);
				put(sip1MessageWaitingNotificationField.getTitle(), sip1MessageWaitingNotificationField);
				put(sip1ContactHeaderUpdatesField.getTitle(), sip1ContactHeaderUpdatesField);
				put(sip1HeaderPortChangeField.getTitle(), sip1HeaderPortChangeField);
				put(sip1VendorProtocolField.getTitle(), sip1VendorProtocolField);
				put(sip1CallForwardingField.getTitle(), sip1CallForwardingField);
				put(sip1DisableCallWaitingField.getTitle(), sip1DisableCallWaitingField);
				put(sip2ServerAddressField.getTitle(), sip2ServerAddressField);
				put(sip2ServerPortField.getTitle(), sip2ServerPortField);
				put(sip2TransportField.getTitle(), sip2TransportField);
				put(sip2ExtensionField.getTitle(), sip2ExtensionField);
				put(sip2UsernameField.getTitle(), sip2UsernameField);
				put(sip2PasswordField.getTitle(), sip2PasswordField);
				put(sip2ShowPasswordField.getTitle(), sip2ShowPasswordField);
				put(sip2VmAddressField.getTitle(), sip2VmAddressField);
				put(sip2HoldSignallingField.getTitle(), sip2HoldSignallingField);
				put(sip2MessageWaitingNotificationField.getTitle(), sip2MessageWaitingNotificationField);
				put(sip2ContactHeaderUpdatesField.getTitle(), sip2ContactHeaderUpdatesField);
				put(sip2HeaderPortChangeField.getTitle(), sip2HeaderPortChangeField);
				put(sip2VendorProtocolField.getTitle(), sip2VendorProtocolField);
				put(sip2DisableCallWaitingField.getTitle(), sip2DisableCallWaitingField);
				put(sip1IDivertField.getTitle(), sip1IDivertField);
				put(sip1CallParkField.getTitle(), sip1CallParkField);
				put(sip1HuntGroupLogonField.getTitle(), sip1HuntGroupLogonField);
				put(ciscoVoicemailField.getTitle(), ciscoVoicemailField);
				put(ciscoServerAddressField.getTitle(), ciscoServerAddressField);
				put(ciscoServerUsernameField.getTitle(), ciscoServerUsernameField);
				put(ciscoServerPasswordField.getTitle(), ciscoServerPasswordField);
				put(ciscoShowPasswordField.getTitle(), ciscoShowPasswordField);
				put(ciscoContactSearchField.getTitle(), ciscoContactSearchField);
				put(ciscoAdvancedSearchField.getTitle(), ciscoAdvancedSearchField);
				put(ciscoDirectoryServerAddressField.getTitle(), ciscoDirectoryServerAddressField);
				put(ciscoDirectoryServerAccountField.getTitle(), ciscoDirectoryServerAccountField);
				put(ciscoDirectoryServerPasswordField.getTitle(), ciscoDirectoryServerPasswordField);
				put(ciscoDirectoryServerShowPasswordField.getTitle(), ciscoDirectoryServerShowPasswordField);
				put(ciscoDirectoryServerSearchFieldField.getTitle(), ciscoDirectoryServerSearchFieldField);
				put(ciscoDirectoryServerSearchValueField.getTitle(), ciscoDirectoryServerSearchValueField);
				put(sipAudioDscpField.getTitle(), sipAudioDscpField);
				put(sipCallControlDscpField.getTitle(), sipCallControlDscpField);
				put(overrideSwitchToTcpField.getTitle(), overrideSwitchToTcpField);
				put(sipDtmfRelayPayloadField.getTitle(), sipDtmfRelayPayloadField);
				put(sipForceInbandDtmfTonesField.getTitle(), sipForceInbandDtmfTonesField);
				put(ldapServerAddressField.getTitle(), ldapServerAddressField);
				put(ldapServerPortField.getTitle(), ldapServerPortField);
				put(ldapSecurityTypeField.getTitle(), ldapSecurityTypeField);
				put(ldapBindDnField.getTitle(), ldapBindDnField);
				put(ldapBindPasswordField.getTitle(), ldapBindPasswordField);
				put(ldapBaseDnField.getTitle(), ldapBaseDnField);
				put(ldapPrimaryEmailField.getTitle(), ldapPrimaryEmailField);
				put(ldapAlternateEmailField.getTitle(), ldapAlternateEmailField);
				put(contact1NameField.getTitle(), contact1NameField);
				put(contact1NumberField.getTitle(), contact1NumberField);
				put(contact2NameField.getTitle(), contact2NameField);
				put(contact2NumberField.getTitle(), contact2NumberField);
				put(contact3NameField.getTitle(), contact3NameField);
				put(contact3NumberField.getTitle(), contact3NumberField);
				put(contact4NameField.getTitle(), contact4NameField);
				put(contact4NumberField.getTitle(), contact4NumberField);
				put(contact5NameField.getTitle(), contact5NameField);
				put(contact5NumberField.getTitle(), contact5NumberField);
			}
		};

		updateCodecFields();
	}

	public ConfigPageField getField(String title) {
		return pageFields.get(title);
	}

	public void updateCarets() {
		firstCodecDownCaretField.setTargetElement(downCarets.get(0));
		secondCodecDownCaretField.setTargetElement(downCarets.get(1));
		thirdCodecDownCaretField.setTargetElement(downCarets.get(2));
		fourthCodecDownCaretField.setTargetElement(downCarets.get(3));

		firstCodecUpCaretField.setTargetElement(upCarets.get(0));
		secondCodecUpCaretField.setTargetElement(upCarets.get(1));
		thirdCodecUpCaretField.setTargetElement(upCarets.get(2));
		fourthCodecUpCaretField.setTargetElement(upCarets.get(3));
	}

	public void moveCodecDown(String codecName) {
		ConfigPageField[] codecs = new ConfigPageField[]{firstCodecDownCaretField, secondCodecDownCaretField, thirdCodecDownCaretField};
		for (int codecIndex = 0; codecIndex < 3; codecIndex++) {
			if (codecLabels.get(codecIndex).getAttribute("innerText").contains(codecName)) {
				clickOnPageEntity(codecs[codecIndex].getTargetElement());
				break;
			}
		}
		sleepSeconds(1);
		updateCodecFields();
		updateCarets();
	}

	public void moveCodecUp(String codecName) {
		ConfigPageField[] codecs = new ConfigPageField[]{secondCodecUpCaretField, thirdCodecUpCaretField, fourthCodecUpCaretField};
		for (int codecIndex = 1; codecIndex < 4; codecIndex++) {
			if (codecLabels.get(codecIndex).getAttribute("innerText").contains(codecName)) {
				clickOnPageEntity(codecs[codecIndex - 1].getTargetElement());
				break;
			}
		}
		sleepSeconds(1);
		updateCodecFields();
		updateCarets();
	}

	public void updateCodecFields() {
		ConfigPageField[] codecs = new ConfigPageField[]{sipFirstAudioCodecField, sipSecondAudioCodecField, sipThirdAudioCodecField, sipFourthAudioCodecField};
		for (int codecIndex = 0; codecIndex < 4; codecIndex++) {
			String newTitle = codecLabels.get(codecIndex).getAttribute("innerText").trim();
			FieldData matchingString = SamFields.getStrings(AndroidPhone.Application.BIZ_PHONE, newTitle);
			if (matchingString != null) {
				codecs[codecIndex].setLabel(codecLabels.get(codecIndex));
				codecs[codecIndex].setTargetElement(codecCheckboxes.get(codecIndex));
				codecs[codecIndex].setTitle(matchingString.title());
				codecs[codecIndex].setKey(matchingString.attribute());
				pageFields.put(matchingString.title(), codecs[codecIndex]);
			}
		}
	}

	public void clickSipTab() {
		clickOnPageEntity(tabs.get(0));
		sleepSeconds(2);
	}

	public void clickLdapTab() {
		clickOnPageEntity(tabs.get(1));
		sleepSeconds(2);
	}

	public void clickEmergencyContactsTab() {
		clickOnPageEntity(tabs.get(2));
		sleepSeconds(2);
	}

	public void openSipRegistration1() {
		if (!registration1Accordian.getAttribute("class").contains("panel-open")) {
			clickOnPageEntity(sipRegistration1Link);
			sleepSeconds(2);
		}
	}

	public void openSipRegistration2() {
		if (!registration2Accordian.getAttribute("class").contains("panel-open")) {
			clickOnPageEntity(sipRegistration2Link);
			sleepSeconds(2);
		}
	}

	public void openCiscoProgram() {
		if (!ciscoAccordian.getAttribute("class").contains("panel-open")) {
			clickOnPageEntity(ciscoPartnerProgram);
			sleepSeconds(2);
		}
	}

	public void openCommonSettings() {
		if (!commonSettingsAccordian.getAttribute("class").contains("panel-open")) {
			clickOnPageEntity(sipCommonSettingsLink);
			sleepSeconds(2);
		}
	}

	public void openCustomAttributes() {
		if (!customAttributesAccordian.getAttribute("class").contains("panel-open")) {
			clickOnPageEntity(customAttributesLink);
			sleepSeconds(2);
		}
	}

	public void clickPlusButton() {
		setTemporaryWait(1);
		if (isEntityClickable(sipAddContactButton)) {
			clickOnPageEntity(sipAddContactButton);
			sleepSeconds(1);
		}
		removeTemporaryWait();
	}

	public void clickMinusButton() {
		setTemporaryWait(1);
		if (isEntityClickable(sipRemoveContactButton)) {
			clickOnPageEntity(sipRemoveContactButton);
			sleepSeconds(1);
		}
		removeTemporaryWait();
	}
}
