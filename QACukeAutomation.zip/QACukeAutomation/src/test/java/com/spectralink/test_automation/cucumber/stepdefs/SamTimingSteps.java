package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleep;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamTimingSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I wait for \"([^\"]*)\" seconds$")
    public void waitSeconds(String arg1) {
        sleepSeconds(Integer.valueOf(arg1));
    }

    @When("^I wait for \"([^\"]*)\" milliseconds$")
    public void waitMilliseconds(String arg1) {
        sleep(Integer.valueOf(arg1));
    }

    @When("^I wait \"([^\"]*)\" seconds for device\\(s\\) \"([^\"]*)\" to update$")
    public void waitSecondsForMultipleUpdates(String arg1, String arg2) {
        sleepSeconds(Integer.valueOf(arg1.trim()));
        for (String eachPhone : arg2.trim().split("\\s*,\\s*")) {
            VersityPhone phone = Environment.getPhone(eachPhone);
            phone.clearAppSettings();
        }
    }

}