package com.spectralink.test_automation.cucumber.framework.sam.common;

import com.jcraft.jsch.JSchException;
import com.spectralink.test_automation.cucumber.framework.common.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.*;

public class Sam {
    private Logger log = LogManager.getLogger(this.getClass().getName());
    private ImDatabase imDatabase;
    private AccountDatabase keyDatabase;
    private Map<String, DatabaseDevice> deviceList = new HashMap<>();
    private String samAddress;
    private Integer databasePort = RunDefaults.getNumericSetting("dbPort");
    private String databaseAccount = RunDefaults.getStringSetting("dbAccount");
    private String databasePassword;
    private String adminAccount;
    private String adminPassword;
    private String samAccountKey;
    private String samOsAccount;
    private String samOsPassword;
    private HeartbeatInspector logInspector;

    public Sam(String address, String dbPassword, String account, String password) {
        samAddress = address != null ? address : RunDefaults.getStringSetting("samAddress");
        databasePassword = dbPassword != null ? dbPassword : RunDefaults.getStringSetting("dbPassword");
        adminAccount = account != null ? account : RunDefaults.getStringSetting("samAccount");
        adminPassword = password != null ? password : RunDefaults.getStringSetting("samPassword");
        samOsAccount = RunDefaults.getStringSetting("samOsAccount");
        samOsPassword = RunDefaults.getStringSetting("samOsPassword");

        log.info("Accessing SAM on remote machine {}", RunDefaults.getStringSetting("samAddress"));

        imDatabase = new ImDatabase(samAddress, databasePort, databaseAccount, databasePassword, adminAccount);
        samAccountKey = imDatabase.getAccountKey().toLowerCase();
        keyDatabase = new AccountDatabase(samAddress, databasePort, samAccountKey, databaseAccount, databasePassword);

        logInspector = new HeartbeatInspector(samAddress, samOsAccount, samOsPassword);

        Iterator<HashMap<String, Object>> devices = keyDatabase.getAllDevices();
        while (devices.hasNext()) {
            HashMap<String, Object> deviceInfo = devices.next();
            String serialNumber = (String) deviceInfo.get("device_serial");
            deviceList.put(serialNumber, new DatabaseDevice(serialNumber, keyDatabase));
        }
    }

    public String getAddress() {
        return samAddress;
    }

    public String getAdminAccount() {
        return adminAccount;
    }

    public String getAdminPassword() {
        return adminPassword;
    }

    public String getOsAccount() {
        return RunDefaults.getStringSetting("samOsAccount");
    }

    public String getOsPassword() {
        return RunDefaults.getStringSetting("samOsPassword");
    }

    public String getJarvisLogPath() {
        return RunDefaults.getStringSetting("samJarvisLog");
    }

    public Integer getDbPort() {
        return RunDefaults.getNumericSetting("dbPort");
    }

    public String getDbAccount() {
        return databaseAccount;
    }

    public String getDbPassword() {
        return databasePassword;
    }

    public String getVmwareServer() {
        return RunDefaults.getStringSetting("esxServer");
    }

    public String getVmwareAccount() {
        return RunDefaults.getStringSetting("esxAccount");
    }

    public String getVmwarePassword() {
        return RunDefaults.getStringSetting("esxPassword");
    }

    public String getVmwareNetwork() {
        return RunDefaults.getStringSetting("vmNetwork");
    }

    public String getVmwareDatastore() {
        return RunDefaults.getStringSetting("vmDatastore");
    }

    public ImDatabase imDatabase() {
        return imDatabase;
    }

    public AccountDatabase keyDatabase() {
        return keyDatabase;
    }

    public HeartbeatInspector jarvisLog() {
        return logInspector;
    }

    public void refreshDevices() {
        deviceList.clear();
        Iterator<HashMap<String, Object>> devices = keyDatabase.getAllDevices();
        while (devices.hasNext()) {
            HashMap<String, Object> deviceInfo = devices.next();
            String serialNumber = (String) deviceInfo.get("device_serial");
            deviceList.put(serialNumber, new DatabaseDevice(serialNumber, keyDatabase));
        }
    }

    public DatabaseDevice getDevice(String serial) {
        refreshDevices();
        if (deviceList.containsKey(serial)) {
            return deviceList.get(serial);
        } else {
            log.error("Device with serial {} does not currently exist", serial);
            return null;
        }
    }

    public Map<String, DatabaseDevice> getDevices() {
        refreshDevices();
        if (deviceList.size() > 0) {
            return deviceList;
        } else {
            log.warn("No devices are currently present");
            return null;
        }
    }

    public List<String> getDeviceSerials() {
        List<String> serials = new ArrayList<String>();
        Map<String, DatabaseDevice> devices = getDevices();
        for (String serial : devices.keySet()) {
            serials.add(serial);
        }
        return serials;
    }

    public DatabaseDevice getRandomDevice() {
        List<String> deviceSerials = getDeviceSerials();
        if (deviceSerials.size() == 0) {
            log.warn("No devices were connected to the SAM");
            return null;
        } else if (deviceList.size() == 1) {
            DatabaseDevice phone = getDevice(deviceSerials.get(0));
            log.debug(phone.getIdentity());
            return phone;
        } else {
            Random random = new Random();
            int randomIndex = random.nextInt(deviceSerials.size());
            DatabaseDevice phone = getDevice(deviceSerials.get(randomIndex));
            log.debug(phone.getIdentity());
            return phone;
        }
    }

    public String getBaseUrl() {
        return "http://" + getAddress() + "/sam/";
    }

    public String getBaseSslUrl() {
        return "https://" + getAddress() + "/sam/";
    }

    public CliResult executeCommand(ArrayList<String> command) throws JSchException, IOException {
        RemoteShell shell = new RemoteShell(getAddress(), getOsAccount(), getOsPassword());
        log.debug("Sending command: {}", command);
        return shell.executeCommand(command);
    }

}
