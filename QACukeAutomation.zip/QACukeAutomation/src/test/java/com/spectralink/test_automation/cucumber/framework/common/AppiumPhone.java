package com.spectralink.test_automation.cucumber.framework.common;

import com.google.common.collect.ImmutableMap;
import com.spectralink.test_automation.cucumber.framework.device.common.AppiumService;
import com.spectralink.test_automation.cucumber.framework.device.pages.*;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidStartScreenRecordingOptions;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import org.apache.commons.codec.binary.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.spectralink.test_automation.cucumber.framework.common.Util.getRandomHex;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofSeconds;

public class AppiumPhone extends AndroidPhone {
	protected AndroidDriver androidDriver;
	private Application appiumStartupApp = Application.BIZ_PHONE;
	private Activity appiumStartupActivity = Activity.BIZ_PHONE_DIALER;
	private Integer appiumTimeout = 10000;
	private AppiumService service;
	private Integer appiumPortNumber;
	private boolean appiumRunning = false;
	private AppiumUi currentAppUi;
	private final Logger log = LogManager.getLogger(this.getClass().getName());
	private BattLifeUi battLifeUi;
	private AmieAgentUi agentUi;
	private BizPhoneUi bizPhoneUi;
	private CiscoPhoneUi ciscoPhoneUi;
	private PttUi pttUi;
	private DeviceAppUi deviceAppUi;
	private SafeUi safeUi;
	private DeviceTranslationUi deviceTranslationUi;
	private WebApiUi webApiUi;
	private ButtonsUi buttonsUi;
	private SysUpdaterUi updaterUi;
	private BarcodeUi barcodeUi;
	private AboutScreenUi aboutScreenUi;

	public AppiumPhone(UsbHost host, String serialNumber, String status, String path) {
		super(host, serialNumber, status, path);
	}

	public BattLifeUi getBattLifeUi() {
		if (battLifeUi == null) {
			battLifeUi = new BattLifeUi(appium());
		}
		return battLifeUi;
	}

	public AmieAgentUi getAmieAgentUi() {
		if (agentUi == null) {
			agentUi = new AmieAgentUi(appium());
		}
		return agentUi;
	}

	public BizPhoneUi getBizPhoneUi() {
		if (bizPhoneUi == null) {
			bizPhoneUi = new BizPhoneUi(appium());
		}
		return bizPhoneUi;
	}

	public CiscoPhoneUi getCiscoPhoneUi() {
		if (ciscoPhoneUi == null) {
			ciscoPhoneUi = new CiscoPhoneUi(appium());
		}
		return ciscoPhoneUi;
	}

	public PttUi getPttUi() {
		if (pttUi == null) {
			pttUi = new PttUi(appium());
		}
		return pttUi;
	}

	public DeviceAppUi getDeviceAppUi() {
		if (deviceAppUi == null) {
			deviceAppUi = new DeviceAppUi(appium());
		}
		return deviceAppUi;
	}

	public SafeUi getSafeUi() {
		if (safeUi == null) {
			safeUi = new SafeUi(appium());
		}
		return safeUi;
	}

	public WebApiUi getWebApiUi() {
		if (webApiUi == null) {
			webApiUi = new WebApiUi(appium());
		}
		return webApiUi;
	}

	public DeviceTranslationUi getDeviceTranslationUi() {
		if (deviceTranslationUi == null) {
			deviceTranslationUi = new DeviceTranslationUi(appium());
		}
		return deviceTranslationUi;
	}

	public AboutScreenUi getAboutScreenUi() {
		if (aboutScreenUi == null) {
			aboutScreenUi = new AboutScreenUi(appium());
		}
		return aboutScreenUi;
	}

	public ButtonsUi getButtonsUi() {
		if (buttonsUi == null) {
			buttonsUi = new ButtonsUi(appium());
		}
		return buttonsUi;
	}

	public SysUpdaterUi getSysUpdaterUi() {
		if (updaterUi == null) {
			updaterUi = new SysUpdaterUi(appium());
		}
		return updaterUi;
	}

	public BarcodeUi getBarcodeUi() {
		if (barcodeUi == null) {
			barcodeUi = new BarcodeUi(appium());
		}
		return barcodeUi;
	}

	public Application getAppiumStartupApp() {
		return appiumStartupApp;
	}

	public void setAppiumStartupApp(Application appiumStartupApp) {
		this.appiumStartupApp = appiumStartupApp;
	}

	public Activity getAppiumStartupActivity() {
		return appiumStartupActivity;
	}

	public void setAppiumStartupActivity(Activity appiumStartupActivity) {
		this.appiumStartupActivity = appiumStartupActivity;
	}

	public boolean isAppiumRunning() {
		return appiumRunning;
	}

	public void setAppiumRunning(boolean appiumRunning) {
		this.appiumRunning = appiumRunning;
	}

	public AppiumUi getCurrentAppUi() {
		return currentAppUi;
	}

	public void setCurrentAppUi(AppiumUi currentAppUi) {
		this.currentAppUi = currentAppUi;
	}

	public Integer getAppiumTimeout() {
		return appiumTimeout;
	}

	public void setAppiumTimeout(Integer appiumTimeout) {
		this.appiumTimeout = appiumTimeout;
	}

	public void clearAppData() {
		androidDriver.resetApp();
	}

	public AndroidDriver appium() {
		if (androidDriver == null) {
			appiumPortNumber = Environment.getNextAppiumPort();
			service = new AppiumService(getSerialNumber(), appiumPortNumber);
			if (service.start()) {
				setAppiumRunning(true);
				DesiredCapabilities capabilities = new DesiredCapabilities();
				//capabilities.setCapability("deviceName", "Spectralink Versity");
				capabilities.setCapability("udid", getSerialNumber());
				capabilities.setCapability("platformName", "Android");
				capabilities.setCapability("automationName", "UiAutomator2");
				capabilities.setCapability("autoGrantPermissions", true);
				capabilities.setCapability("avoidProxy", true);
				capabilities.setCapability("fullReset", false);
				capabilities.setCapability("noReset", true);
				capabilities.setCapability("unlockType", "pin");
				capabilities.setCapability("unlockKey", "1111");
				capabilities.setCapability("newCommandTimeout", 10000);
				capabilities.setCapability("disableWindowAnimation", true);
				String rawUrl = "http://127.0.0.1:" + appiumPortNumber + "/wd/hub";
				sleepSeconds(10);
				try {
					URL localHost = new URL(rawUrl);
					androidDriver = new AndroidDriver(localHost, capabilities);
					androidDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
					log.debug("Connected Android driver for {} to server port {}", getSerialNumber(), appiumPortNumber);
					appiumRunning = true;
				} catch (MalformedURLException mue) {
					log.error("Illegal URL '{}'", rawUrl);
					appiumRunning = false;
				}
			} else {
				log.error("Failed to start Appium service");
				appiumRunning = false;
			}
		}
		return androidDriver;
	}

	public void deleteAndroidDriver() {
		if(androidDriver!=null)
			androidDriver = null;
	}

	public void stopAppiumServer() {
		if (isAppiumRunning()) {
			service.stopServer();
			service.stopNode();
		}
	}

	public void bringAppToForeground(Application packageName) {
		io.appium.java_client.android.Activity activity = new io.appium.java_client.android.Activity(packageName.getPackage(), packageName.getMainActivity());
		activity.setStopApp(false);
		appium().startActivity(activity);
		int failCount = 0;
		while (!getForegroundPackage().contentEquals(packageName.getPackage()) && failCount < 10) {
			sleepSeconds(1);
			failCount += 1;
		}
		if (failCount > 9) log.error("Waited too long for app {} to foreground", packageName.getLabel());
	}

	public void bringAppToForeground(Application packageName, Activity activityName) {
		io.appium.java_client.android.Activity activity = new io.appium.java_client.android.Activity(packageName.getPackage(), activityName.getIntent());
		activity.setStopApp(false);
		appium().startActivity(activity);
		int failCount = 0;
		while (!getForegroundPackage().contentEquals(packageName.getPackage()) && failCount < 10) {
			sleepSeconds(1);
			failCount += 1;
		}
		if (failCount > 9) log.error("Waited too long for app {} to foreground", packageName.getLabel());
	}

	public void closeApp(Application app) {
		androidDriver.terminateApp(app.getPackage());
	}

	public void sendKeyEvent(AndroidKey key) {
		androidDriver.pressKey(new KeyEvent(key));
	}

	@Override
	public String getForegroundPackage() {
		String currentScreen = appium().getCurrentPackage();
		return currentScreen.trim();
	}

	@Override
	public String getForegroundActivity() {
		String currentScreen = appium().currentActivity();
		return currentScreen.trim();
	}

	public Boolean isPhoneLocked() {
		Boolean deviceLocked = appium().isDeviceLocked();
		log.trace("Phone Locked: {}", deviceLocked);
		return deviceLocked;
	}

	public void restartApp(Application appName) {
		bringAppToForeground(appName);
	}

	public void startVideoRecording() {
		appium().startRecordingScreen(
				new AndroidStartScreenRecordingOptions()
						.withTimeLimit(Duration.ofSeconds(1800))
		);
	}

	public void stopVideoRecording(String filepath) {
		String payload = appium().stopRecordingScreen();
		byte[] data = Base64.decodeBase64(payload);
		try (OutputStream stream = new FileOutputStream(filepath)) {
			stream.write(data);
		} catch (IOException ioe) {
			log.error("Could not open file {} for storing video recording: {}", filepath, ioe.getMessage());
		}
	}

	public void scrollUp() {
		sleepSeconds(1);
		Dimension size = appium().manage().window ().getSize();
		int startX = size.getWidth () / 2;
		int startY = (int) (size.height * 0.90);
		int endY = (int) (size.height * 0.10);
		new TouchAction(appium()).press(point(startX, startY)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(500))).moveTo(point(startX, endY)).release().perform();
		sleepSeconds(2);
	}

	public void scrollUpForTranslations() {
		sleepSeconds(1);
		Dimension size = appium().manage().window ().getSize();
		int startX = size.getWidth () / 2;
		int startY = (int) (size.height * 0.90);
		int endY = (int) (size.height * 0.10);
		new TouchAction(appium()).press(point(startX, startY)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1500))).moveTo(point(startX, endY)).release().perform();
		sleepSeconds(2);
	}

	public void scrollUpDimensions(double heightFrom, double heightTo) {
		sleepSeconds(1);
		Dimension size = appium().manage().window ().getSize();
		int startX = size.getWidth () / 2;
		int startY = (int) (size.height * heightFrom);
		int endY = (int) (size.height * heightTo);
		new TouchAction(appium()).press(point(startX, startY)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1500))).moveTo(point(startX, endY)).release().perform();
		sleepSeconds(2);
	}

	public void longPressContentDesc(String element) {
		MobileElement mobileElement = (MobileElement)appium().findElementByAccessibilityId(element);
		new TouchAction(appium()).longPress(ElementOption.element(mobileElement)).perform();
		sleepSeconds(1);
	}

	public void openNotificationBar() {
		appium().openNotifications();
	}

	public Map<Application, Map<String, String>> getNotifications() {
		appium().openNotifications();
		Map<Application, Map<String, String>> notifications = new HashMap<>();
		List<WebElement> notices = appium().findElements(By.id("android:id/notification_header"));
		for (WebElement header : notices) {
			Map<String, String> details = new HashMap<>();
			String appName = header.findElement(By.id("android:id/app_name_text")).getText();
			log.debug("appName: {}", appName);
			Application app = AndroidPhone.findApplication(appName);
			List<WebElement> title = header.findElements(By.xpath("following-sibling::android.widget.TextView[(@resource-id ='android:id/title')]"));
			if (!title.isEmpty()) {
				details.put("title", title.get(0).getText());
				log.debug("title {}", title.get(0).getText());
			}
			List<WebElement> text = header.findElements(By.xpath("following-sibling::android.widget.TextView[(@resource-id ='android:id/text')]"));
			if (!text.isEmpty()) {
				for (int textIndex = 0; textIndex < text.size(); textIndex++) {
					details.put("line" + textIndex, title.get(textIndex).getText());
					log.debug("{} {}", "line" + textIndex, title.get(0).getText());
				}
			}
			notifications.put(app, details);
		}
		return notifications;
	}

	public void openNotificationBarAndDragDown() {
		appium().openNotifications();
		sleepSeconds(2);
		WebElement dragDown = appium().findElementById("com.android.systemui:id/qs_drag_handle_view");
		Dimension size = appium().manage().window ().getSize();
		int toPosition = size.getHeight()/2;
		int centerX = dragDown.getLocation().getX() + dragDown.getSize().getWidth() / 2;
		int centerY = dragDown.getLocation().getY() + dragDown.getSize().getHeight() / 2;
		Point position = new Point(centerX, centerY);
		new TouchAction(appium()).press(point(position.getX(), position.getY())).waitAction().moveTo(point(position.getX(), position.getY() + toPosition)).release().perform();
	}

	public void swipeNotificationLeft() {
		Dimension size = appium().manage().window ().getSize();
		int width = size.getWidth();
		int height = size.getHeight();
		new TouchAction(appium()).press(point(width-10, height/2-10)).waitAction().moveTo(point(width/2-100, height/2)).release().perform();
	}

	public void lockScreen() {
		appium().lockDevice();
	}

	public CliResult sendAppiumAdbShellCommand(List<String> adbParameters) {
		CliResult result = new CliResult();
		if (isAppiumRunning()) {
			Map<String, Object> deviceCommand;
			if (adbParameters.size() > 1) {
				deviceCommand = ImmutableMap.of("command", adbParameters.get(0), "args", adbParameters.subList(1, adbParameters.size()));
				String commandOutput = (String) androidDriver.executeScript("mobile: shell", deviceCommand);
				result.setStdout(commandOutput);
				result.setExitCode(0);
			} else if (adbParameters.size() == 1) {
				deviceCommand = ImmutableMap.of("command", adbParameters.get(0));
				String commandOutput = (String) androidDriver.executeScript("mobile: shell", deviceCommand);
				result.setStdout(commandOutput);
				result.setExitCode(0);
			} else {
				log.error("No arguments provided to ADB command");
				result.setStdout("");
				result.setStderr("No arguments provided to ADB command");
				result.setExitCode(2);
			}
		} else {
			log.error("Could not send ADB command since Appium service was not running");
			result.setExitCode(2);
		}
		return result;
	}

	public boolean selectScrollableMenuOptionBatteryOptimization(String option) {
		for (int count = 0; count < 10; count++) {
			List<WebElement> options = appium().findElements(By.id("android:id/title"));
			for (WebElement element : options) {
				if (element.getText().trim().equalsIgnoreCase(option)) {
					if (appium().findElementByXPath("//android.widget.TextView[contains(@resource-id, 'android:id/title') and contains(@text, '" + element.getText() + "')]/parent::*/android.widget.TextView[2]").getText().equals("Battery optimization not available"))
						return true;
				}
			}
			flingForward();
		}
		return false;
	}

	public void tapOnScreenFor10Seconds(int xValue, int yValue) {
		new TouchAction(appium()).press(point(xValue, yValue)).waitAction(waitOptions(ofSeconds(9))).release().perform();
	}

	public void scrollIntoExactViewAttribute(String value) {
		appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text(\"" + value + "\").instance(0))");
	}

	public void flingToEnd() {
		try {
			appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingToEnd(100);");
		} catch (Exception e) {
			// ignore
		}
	}

	public void flingToBeginning() {
		try {
			appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingToBeginning(100);");
		} catch (Exception e) {
			// ignore
		}
	}

	public void flingForward() {
		try {
			appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingForward();");
		} catch (Exception e) {
			// ignore
		}
	}

	public void flingBackward() {
		try {
			appium().findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).setAsVerticalList().flingBackward();");
		} catch (Exception e) {
			// ignore
		}
	}

}




