package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.WebBrowser;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamFeatureLicensePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.sam.pages.SamFeatureLicensePage.LicenseCount.Available;
import static com.spectralink.test_automation.cucumber.framework.sam.pages.SamFeatureLicensePage.LicenseCount.Valid;

public class SamFeatureLicenseSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    private File licenseFile = Paths.get(Environment.getProjectDirectory(), "src/test/resources/test_data/licenses.json").toFile();
    private Map<String, Map<String, String>> licenses = new HashMap<>();

    public SamFeatureLicenseSteps() {
        if (licenseFile != null) {
            if (licenseFile.exists()) {
                JSONParser parser = new JSONParser();
                try {
                    licenses = new HashMap<>();
                    Object parsedJson = parser.parse(new FileReader(licenseFile));
                    JSONObject licenseSet = (JSONObject) parsedJson;
                    for (Iterator setIterator = licenseSet.keySet().iterator(); setIterator.hasNext(); ) {
                        String key = (String) setIterator.next();
                        JSONObject licenseDetails = (JSONObject) licenseSet.get(key);
                        Map<String, String> detail = new HashMap<>();
                        for (Iterator detailIterator = licenseDetails.keySet().iterator(); detailIterator.hasNext(); ) {
                            String detailKey = (String) detailIterator.next();
                            String detailValue = (String) licenseDetails.get(detailKey);
                            detail.put(detailKey, detailValue);
                        }
                        licenses.put(key, detail);
                    }
                } catch (FileNotFoundException fnfe) {
                    log.error("Could not locate data file licenses: {}", fnfe.getMessage());
                } catch (IOException ioe) {
                    log.error("Could not read data file licenses: {}", ioe.getMessage());
                } catch (ParseException pe) {
                    log.error("Could not parse data file licenses: {}", pe.getMessage());
                }
            }
        } else {
            log.error("No data could be loaded");
        }
    }

    @When("^I enter the \"([^\"]*)\" license into the License Key field$")
    public void enterLicense(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        licensePage.enterLicenseKey(licenses.get(arg1.trim()).get("license"));
        log.debug("Entered '{}' with {} licenses effective from {} to {}", arg1,
                licenses.get(arg1.trim()).get("count"),
                licenses.get(arg1.trim()).get("from_date"),
                licenses.get(arg1.trim()).get("to_date")
        );
    }

    @When("^I click the Feature License 'Save' button$")
    public void clickSave() {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        licensePage.clickSaveButton();
    }

    @When("^I click the Feature License clear search button$")
    public void clickClearSearch() {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        licensePage.clickClearSearchButton();
    }

    @When("^I record the current license counts$")
    public void recordCounts() {
        WebBrowser.refreshCurrentPage(false);
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        Map<String, Integer> licenseInfo = licensePage.getLicenseInfo();
        Environment.setTemporaryValue(Valid.text(), licenseInfo.get(Valid.text()));
        Environment.setTemporaryValue(Available.text(), licenseInfo.get(Available.text()));
    }

    @When("^I enter \"([^\"]*)\" into the Feature License search field$")
    public void enterLicenseSearchValue(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        licensePage.enterSearchValue(arg1.trim());
    }

    @When("^I select \"([^\"]*)\" from the Feature License search menu$")
    public void selectSearchType(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        SamFeatureLicensePage.SearchMenu option = licensePage.getSearchType(arg1.trim());
        licensePage.selectSearchType(option);
    }

    @When("^I click the \"([^\"]*)\" Feature License column heading$")
    public void clickColumnHeading(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        if (licensePage.columnIsVisible(arg1.trim())) {
            licensePage.clickColumnHeading(arg1.trim());
        } else {
            log.error("Cannot find heading titled '{}'", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("^the sort direction for Feature License column \"([^\"]*)\" should be \"([^\"]*)\"$")
    public void verifySortDirection(String arg1, String arg2) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        if (licensePage.columnIsVisible(arg1.trim())) {
            String direction = licensePage.getSortDirection(arg1.trim());
            if (direction.contains(arg2.trim())) {
                log.debug("Sort direction '{}' was verified", arg2);
            } else {
                log.fatal("Sort direction '{}' was not expected", arg2);
                Assert.fail("SAM License Sort Failure");
            }
        } else {
            log.error("Cannot find heading titled '{}'", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("the \"([^\"]*)\" count has increased by \"([^\"]*)\"$")
    public void verifyLicenseAddition(String arg1, String arg2) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        SamFeatureLicensePage.LicenseCount countType = licensePage.getCountType(arg1);
        if (countType != null) {
            Map<String, Integer> licenseInfo = licensePage.getLicenseInfo();
            int newCount = licenseInfo.get(countType.text());
            int oldCount = Environment.getIntegerTemporaryValue(countType.text());
            int expectedCount = oldCount + Integer.valueOf(arg2.trim());
            if (newCount == expectedCount) {
                log.debug("{} license count increased by {}", arg1, arg2);
            } else {
                int realDifference = newCount - oldCount;
                log.error("{} count did not increase by {} (actual {})", arg1, arg2, realDifference);
                Assert.fail("License Increment Failure");
            }
        } else {
            log.error("No matching license count with title '{}'", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("the \"([^\"]*)\" count has decreased by \"([^\"]*)\"$")
    public void verifyLicenseSubtraction(String arg1, String arg2) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        SamFeatureLicensePage.LicenseCount countType = licensePage.getCountType(arg1);
        if (countType != null) {
            Map<String, Integer> licenseInfo = licensePage.getLicenseInfo();
            int newCount = licenseInfo.get(countType.text());
            int oldCount = Environment.getIntegerTemporaryValue(countType.text());
            int expectedCount = oldCount - Integer.valueOf(arg2.trim());
            if (newCount == expectedCount) {
                log.debug("{} license count increased by {}", arg1, arg2);
            } else {
                int realDifference = newCount + oldCount;
                log.error("{} count did not decrease by {} (actual {})", arg1, arg2, realDifference);
                Assert.fail("License Decrement Failure");
            }
        } else {
            log.error("No matching license count with title '{}'", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @Then("I delete the \"([^\"]*)\" license$")
    public void deleteLicense(String arg1) {
        int licensesDeleted = Environment.getSam().keyDatabase().deleteSamLicense(arg1.trim());
        WebBrowser.refreshCurrentPage(false);
        Util.sleepSeconds(2);
        if (licensesDeleted > 0) {
            log.debug("Deleted license with identifier '{}'", arg1);
        } else {
            log.error("Could not delete license '{}'", arg1);
            Assert.fail("License Deletion Failure");
        }
    }

    @Then("I delete all test licenses$")
    public void deleteAllLicenses() {
        int licensesDeleted = Environment.getSam().keyDatabase().deleteSamTestLicenses("do_not_remove");
        WebBrowser.refreshCurrentPage(false);
        Util.sleepSeconds(2);
    }

    @Then("the \"([^\"]*)\" license is visible$")
    public void licenseVisible(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        if (licensePage.licenseIsVisible(arg1.trim())) {
            log.debug("License '{}' was visible", arg1);
        } else {
            log.error("License '{}' was not visible", arg1);
            Assert.fail("License Visibility Failure");
        }
    }

    @Then("the \"([^\"]*)\" license is not visible$")
    public void licenseNotVisible(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        if (!licensePage.licenseIsVisible(arg1.trim())) {
            log.debug("License '{}' was not visible", arg1);
        } else {
            log.error("License '{}' was still visible", arg1);
            Assert.fail("License Visibility Failure");
        }
    }

    @Then("the page displays the Feature License error message \"([^\"]*)\"$")
    public void errorMessageVisible(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        String visibleErrorMessage = licensePage.getErrorMessage();
        if (visibleErrorMessage.contains(arg1.trim())) {
            log.debug("Error message '{}' was visible", arg1);
        } else {
            log.error("Error message '{}' was not visible", arg1);
            Assert.fail("Error Message Failure");
        }
    }

    @Then("^at least one license match is found$")
    public void verifyLicenseMatch() {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        int matches = licensePage.getLicenseRowCount();
        if (matches >= 1) {
            log.debug("Found {} license matches", matches);
        } else {
            log.error("No matches were found");
            Assert.fail("License Search Failed");
        }
    }

    @Then("^exactly \"([^\"]*)\" license matches are found$")
    public void verifyExactLicenseMatch(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        int matches = licensePage.getLicenseRowCount();
        int expectedMatches = Integer.parseInt(arg1.trim());
        if (matches == expectedMatches) {
            log.debug("Found {} license matches", matches);
        } else {
            log.error("{} matches were not found", arg1);
            Assert.fail("License Search Failed");
        }
    }

    @Then("^license \"([^\"]*)\" is visible$")
    public void verifyColumnVisible(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        if (licensePage.licenseIsVisible(arg1.trim())) {
            log.debug("License '{}' was displayed", arg1);
        } else {
            log.error("License '{}' was not displayed", arg1);
            Assert.fail("License Search Failed");
        }
    }

    @Then("^license \"([^\"]*)\" is not visible$")
    public void verifyColumnInvisible(String arg1) {
        SamFeatureLicensePage licensePage = (SamFeatureLicensePage) Environment.getCurrentPage();
        if (licensePage.licenseIsVisible(arg1.trim())) {
            log.debug("License {} was not visible", arg1);
        } else {
            log.error("License {} was still visible", arg1);
            Assert.fail("License Search Failed");
        }
    }
}