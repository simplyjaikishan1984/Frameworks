package com.spectralink.test_automation.cucumber.framework;

import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Set;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class WebBrowser {
	private static Logger log = LogManager.getLogger(WebBrowser.class.getName());
	private static final String projectDirectory = System.getProperty("user.dir");
	private static int implicitWait = 0;
	private static String browserName = RunDefaults.getStringSetting("program");
	private static Dimension dimensions = new Dimension(1400,6000);
	private static WebDriver driver;
	private static Path driverLocation;

	public static boolean isDriverSet() {
		return driver != null;
	}

	public static void loadUrl(URL url) {
		driver = getDriver();
		driver.get(url.toString());
	}

	public static int getImplicitWait() {
		return implicitWait;
	}

	public static void setImplicitWait(int implicitWait) { // needs to be called before call to getDriver()
		WebBrowser.implicitWait = implicitWait;
	}

	public static String getBrowserName() {
		return browserName;
	}

	public static void setBrowserName(String browserName) { // needs to be called before call to getDriver()
		WebBrowser.browserName = browserName;
	}

	public static Path getDriverLocation() {
		return driverLocation;
	}

	public static void setDriverLocation(Path driverLocation) { // needs to be called before call to getDriver()
		WebBrowser.driverLocation = driverLocation;
	}

	public static Dimension getWindowDimensions() {
		return dimensions;
	}

	public static void refreshCurrentPage(Boolean hardRefresh) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("location.reload("+ hardRefresh.toString() + ");");
	}

	public static void setWindowDimensions(int windowWidth, int windowHeight) {
		dimensions = new Dimension(windowWidth, windowHeight);
		driver.manage().window().setSize(dimensions);
	}

	public static void saveScreenshot(File screenshotFile) {
		try {
			File screenshotFileSource = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileChannel fcSource = new FileInputStream(screenshotFileSource).getChannel();
			FileChannel fcTarget = new FileOutputStream(screenshotFile).getChannel();
			fcTarget.transferFrom(fcSource, 0, fcSource.size());
		} catch (Exception e) {
			log.error("Error saving screenshot: {}", e.getMessage());
		}
	}

	public static void savePageSource(File pageFile) {
		try {
			String pageSource = driver.getPageSource();
			PrintWriter out = new PrintWriter(pageFile);
			out.write(pageSource);
			out.close();
		} catch (Exception e) {
			log.error("Error saving page source: {}", e.getMessage());
		}
	}

	public static WebDriver getDriver() {
		if (driver == null) {
			System.setProperty("java.awt.headless", "false");
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			ChromeOptions options;
			log.info("Starting web driver at {}", System.getProperty("webdriver.chrome.driver"));
			switch (browserName.toLowerCase()) {
				case "remote-chrome":
					options = new ChromeOptions();
					try {
						driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), options);
					} catch (MalformedURLException mue) {
						// no-op
					}
					break;
				case "chrome":
					chromePrefs.put("download.default_directory", projectDirectory + "/src/test/resources");
					options = new ChromeOptions();
					options.setExperimentalOption("prefs", chromePrefs);
					if (driverLocation != null) {
						options.setBinary(getDriverLocation().toString());
						log.debug("changed binary path");
					}
					driver = new ChromeDriver(options);
					Capabilities capabilities = ((RemoteWebDriver) driver).getCapabilities();
					log.info("Opening {} browser with driver version {}", browserName, capabilities.getVersion());
					break;
				case "firefox":
					driver = new FirefoxDriver();
					break;
				default:
					throw new RuntimeException("Browser parameter not recognized:  " + browserName);
			}

			setImplicitWait(implicitWait);
			setWindowDimensions(dimensions.getWidth(), dimensions.getHeight());
		}
		return driver;
	}


	private static boolean verifyPageTitle(String expectedTitle) {
		String currentTitle = getTitle();
		if (!currentTitle.contains(expectedTitle)) {
			log.error("Arrived at incorrect page {}", currentTitle);
			return false;
		}
		return true;
	}

	public static String getBodyText() {
		return driver.findElement(By.tagName("body")).getText();
	}

	public static String getTitle() {
		return driver.getTitle();
	}

	public static void clearCookies() {
		driver.manage().deleteAllCookies();
		sleepSeconds(2);
	}

	public static Set<Cookie> getCookies() {
		return driver.manage().getCookies();
	}

	public static void selectFile(String filePath) {
		driver.switchTo().activeElement();
		fileUpload(filePath);
		sleepSeconds(2);
	}

	public static void uploadFile(String fileName) {
		driver.switchTo().activeElement();
		fileUpload(fileName);
	}

	public static void closeSession() {
		if (driver != null) {
			log.info("Disposing web browser session");
			driver.manage().deleteAllCookies();
			driver.quit();
			driver = null;
		}
	}

	public static void clearCache() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.localStorage.clear();");
	}

	public static void close() {
		if (driver != null) {
			log.info("Shutting down web browser");
			driver.manage().deleteAllCookies();
			driver.quit();
		}
	}

	public static void fileUpload(String filePath ){
		try {
			StringSelection stringSelection = new StringSelection(filePath);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
			Robot robot = new Robot();
			robot.delay(1000);

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.delay(1000);

			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.delay(1000);
			log.debug("Chose file at {}", filePath);
		} catch (Exception exp) {
			exp.printStackTrace();
		}
	}
}
