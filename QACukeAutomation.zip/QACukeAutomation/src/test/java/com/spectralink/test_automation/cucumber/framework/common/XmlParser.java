package com.spectralink.test_automation.cucumber.framework.common;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class XmlParser {

    static List<String> xmlElements = new ArrayList<>();

    public static List<String> parseXml(String filename) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        String text;
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new File(filename));
        document.getDocumentElement().normalize();
        NodeList nList = document.getElementsByTagName("resources");
        Node node = nList.item(0);
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Element eElement = (Element) node;
            for(int i=0; i< eElement.getElementsByTagName("string").getLength(); i++) {
                text = eElement.getElementsByTagName("string").item(i).getTextContent().replace("\\n", " ").replace("\\", "").replace("\"","").trim();
                xmlElements.add(text);
            }
            for(int i=0; i< eElement.getElementsByTagName("item").getLength(); i++) {
                text = eElement.getElementsByTagName("item").item(i).getTextContent().replace("\\", "").trim();
                xmlElements.add(text);
            }

        }
        return xmlElements;
    }
}
