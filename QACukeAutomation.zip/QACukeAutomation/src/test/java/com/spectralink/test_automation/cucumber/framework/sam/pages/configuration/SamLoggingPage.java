package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.LoggingStrings.*;

public class SamLoggingPage extends SamConfigurationPage {

	@FindBy(id = "enable_config_manager_label")
	private WebElement enableLoggingLabel;

	@FindBy(id = "enable_system_log")
	private WebElement enableLoggingCheckbox;

	@FindBy(id = "edit_setting_syslogEnabled")
	private WebElement enableLoggingEdit;

	@FindBy(id = "delete_setting_syslogEnabled")
	private WebElement enableLoggingDelete;

	public ConfigPageField enableLoggingField = new ConfigPageField(
			ENABLE_SYSLOG,
			enableLoggingLabel,
			enableLoggingCheckbox,
			enableLoggingDelete,
			enableLoggingEdit
	);

	@FindBy(id = "syslog-server-address")
	private WebElement serverAddressTextbox;

	@FindBy(id = "delete_setting_syslogServerName")
	private WebElement serverAddressDelete;

	@FindBy(id = "edit_setting_syslogServerName")
	private WebElement serverAddressEdit;

	public ConfigPageField serverAddressField = new ConfigPageField(
			LOG_SERVER_ADDRESS,
			serverAddressTextbox,
			serverAddressDelete,
			serverAddressEdit
	);

	@FindBy(id = "syslog_server_port")
	private WebElement serverPortTextbox;

	@FindBy(id = "delete_setting_syslogServerPort")
	private WebElement serverPortDelete;

	@FindBy(id = "edit_setting_syslogServerPort")
	private WebElement serverPortEdit;

	public ConfigPageField serverPortField = new ConfigPageField(
			LOG_SERVER_PORT,
			serverPortTextbox,
			serverPortDelete,
			serverPortEdit
	);

	@FindBy(id = "syslog-logcat-parameters")
	private WebElement logcatParametersTextbox;

	@FindBy(id = "delete_setting_syslogLogcatParams")
	private WebElement logcatParametersDelete;

	@FindBy(id = "edit_setting_syslogLogcatParams")
	private WebElement logcatParametersEdit;

	public ConfigPageField logcatParametersField = new ConfigPageField(
			LOGCAT_PARAMETERS,
			logcatParametersTextbox,
			logcatParametersDelete,
			logcatParametersEdit
	);


	@FindBy(id = "syslog_advanced_debug_password")
	private WebElement debuggingPasswordTextbox;

	@FindBy(id = "delete_setting_syslog_advanced_debug_password")
	private WebElement debuggingPasswordDelete;

	@FindBy(id = "edit_setting_syslog_advanced_debug_password")
	private WebElement debuggingPasswordEdit;

	public ConfigPageField debuggingPasswordField = new ConfigPageField(
			DEBUGGING_PASSWORD,
			debuggingPasswordTextbox,
			debuggingPasswordDelete,
			debuggingPasswordEdit
	);

	@FindBy(id = "show-password-checkbox-label")
	private WebElement showPasswordLabel;

	@FindBy(id = "show-password-checkbox")
	private WebElement showPasswordCheckbox;

	public ConfigPageField showPasswordField = new ConfigPageField(
			SHOW_PASSWORD,
			showPasswordLabel,
			showPasswordCheckbox,
			null,
			null
	);

	@FindBy(id = "bug_report_label")
	private WebElement captureBugReportLabel;

	@FindBy(id = "bug_report")
	private WebElement captureBugReportCheckbox;

	@FindBy(id = "delete_setting_bug_report")
	private WebElement captureBugReportDelete;

	@FindBy(id = "edit_setting_bug_report")
	private WebElement captureBugReportEdit;

	public ConfigPageField captureBugReportField = new ConfigPageField(
			CAPTURE_BUG_REPORT,
			captureBugReportLabel,
			captureBugReportCheckbox,
			captureBugReportDelete,
			captureBugReportEdit
	);

	@FindBy(id = "halt_on_crash_label")
	private WebElement haltOnCrashLabel;

	@FindBy(id = "halt_on_crash")
	private WebElement haltOnCrashCheckbox;

	@FindBy(id = "delete_setting_halt_on_crash")
	private WebElement haltOnCrashDelete;

	@FindBy(id = "edit_setting_halt_on_crash")
	private WebElement haltOnCrashEdit;

	public ConfigPageField haltOnCrashField = new ConfigPageField(
			CRASH_DUMP_MODE,
			haltOnCrashLabel,
			haltOnCrashCheckbox,
			haltOnCrashDelete,
			haltOnCrashEdit
	);

	@FindBy(id = "snaplen")
	private WebElement netTrafficLengthTextbox;

	@FindBy(id = "delete_setting_snaplen")
	private WebElement netTrafficLengthDelete;

	@FindBy(id = "edit_setting_snaplen")
	private WebElement netTrafficLengthEdit;

	public ConfigPageField netTrafficLengthField = new ConfigPageField(
			NETWORK_TRAFFIC_LENGTH,
			netTrafficLengthTextbox,
			netTrafficLengthDelete,
			netTrafficLengthEdit
	);

	@FindBy(id = "logcat_label")
	private WebElement captureLogcatLabel;

	@FindBy(id = "logcat")
	private WebElement captureLogcatCheckbox;

	@FindBy(id = "delete_setting_logcat")
	private WebElement captureLogcatDelete;

	@FindBy(id = "edit_setting_logcat")
	private WebElement captureLogcatEdit;

	public ConfigPageField captureLogcatField = new ConfigPageField(
			CAPTURE_LOGCAT,
			captureLogcatLabel,
			captureLogcatCheckbox,
			captureLogcatDelete,
			captureLogcatEdit
	);

	@FindBy(id = "logcat_size")
	private WebElement logcatSizeMenu;

	@FindBy(id = "delete_setting_logcat_size")
	private WebElement logcatSizeDelete;

	@FindBy(id = "edit_setting_logcat_size")
	private WebElement logcatSizeEdit;

	public ConfigPageField logcatSizeField = new ConfigPageField(
			LOGCAT_FILE_SIZE,
			logcatSizeMenu,
			logcatSizeDelete,
			logcatSizeEdit
	);

	@FindBy(id = "slnk_dump_label")
	private WebElement captureTrafficLabel;

	@FindBy(id = "slnk_dump")
	private WebElement captureTrafficCheckbox;

	@FindBy(id = "delete_setting_slnk_dump")
	private WebElement captureTrafficDelete;

	@FindBy(id = "edit_setting_slnk_dump")
	private WebElement captureTrafficEdit;

	public ConfigPageField captureTrafficField = new ConfigPageField(
			CAPTURE_NETWORK_TRAFFIC,
			captureTrafficLabel,
			captureTrafficCheckbox,
			captureTrafficDelete,
			captureTrafficEdit
	);

	@FindBy(id = "qxdm_log_label")
	private WebElement captureQxdmLabel;

	@FindBy(id = "qxdm_log")
	private WebElement captureQxdmCheckbox;

	@FindBy(id = "delete_setting_qxdm_log")
	private WebElement captureQxdmDelete;

	@FindBy(id = "edit_setting_qxdm_log")
	private WebElement captureQxdmEdit;

	public ConfigPageField captureQxdmField = new ConfigPageField(
			CAPTURE_QXDM_LOG,
			captureQxdmLabel,
			captureQxdmCheckbox,
			captureQxdmDelete,
			captureQxdmEdit
	);

	@FindBy(id = "qxdm_configuration")
	private WebElement qxdmFilterMenu;

	@FindBy(id = "delete_setting_qxdm_configuration")
	private WebElement qxdmFilterDelete;

	@FindBy(id = "edit_setting_qxdm_configuration")
	private WebElement qxdmFilterEdit;

	public ConfigPageField qxdmFilterField = new ConfigPageField(
			QXDM_CONFIGURATION,
			qxdmFilterMenu,
			qxdmFilterDelete,
			qxdmFilterEdit
	);

	@FindBy(id = "file_upload_server_name")
	private WebElement fileUploadServerTextbox;

	@FindBy(id = "delete_setting_file_upload_server_name")
	private WebElement fileUploadServerDelete;

	@FindBy(id = "edit_setting_file_upload_server_name")
	private WebElement fileUploadServerEdit;

	public ConfigPageField fileUploadServerField = new ConfigPageField(
			UPLOAD_SERVER,
			fileUploadServerTextbox,
			fileUploadServerDelete,
			fileUploadServerEdit
	);

	@FindBy(id = "file_upload_server_port")
	private WebElement fileUploadPortTextbox;

	@FindBy(id = "delete_setting_file_upload_server_port")
	private WebElement fileUploadPortDelete;

	@FindBy(id = "edit_setting_file_upload_server_port")
	private WebElement fileUploadPortEdit;

	public ConfigPageField fileUploadPortField = new ConfigPageField(
			UPLOAD_SERVER_PORT,
			fileUploadPortTextbox,
			fileUploadPortDelete,
			fileUploadPortEdit
	);

	@FindBy(id = "file_upload_transport_protocol")
	private WebElement uploadProtocolMenu;

	@FindBy(id = "delete_setting_file_upload_transport_protocol")
	private WebElement uploadProtocolDelete;

	@FindBy(id = "edit_setting_file_upload_transport_protocol")
	private WebElement uploadProtocolEdit;

	public ConfigPageField uploadProtocolField = new ConfigPageField(
			UPLOAD_PROTOCOL,
			uploadProtocolMenu,
			uploadProtocolDelete,
			uploadProtocolEdit
	);

	@FindBy(id = "password_protect_uploaded_files_label")
	private WebElement passwordProtectLabel;

	@FindBy(id = "password_protect_uploaded_files")
	private WebElement passwordProtectCheckbox;

	@FindBy(id = "delete_setting_password_protect_uploaded_files")
	private WebElement passwordProtectDelete;

	@FindBy(id = "edit_setting_password_protect_uploaded_files")
	private WebElement passwordProtectEdit;

	public ConfigPageField passwordProtectField = new ConfigPageField(
			PASSWORD_PROTECT,
			passwordProtectLabel,
			passwordProtectCheckbox,
			passwordProtectDelete,
			passwordProtectEdit
	);

	@FindBy(id = "allow_on_device_config_label")
	private WebElement allowDeviceConfigurationLabel;

	@FindBy(id = "allow_on_device_config")
	private WebElement allowDeviceConfigurationCheckbox;

	@FindBy(id = "delete_setting_allow_on_device_config")
	private WebElement allowDeviceConfigurationDelete;

	@FindBy(id = "edit_setting_allow_on_device_config")
	private WebElement allowDeviceConfigurationEdit;

	public ConfigPageField allowDeviceConfigurationField = new ConfigPageField(
			ALLOW_OVERRIDE,
			allowDeviceConfigurationLabel,
			allowDeviceConfigurationCheckbox,
			allowDeviceConfigurationDelete,
			allowDeviceConfigurationEdit
	);

	@FindBy(className = "md-tab")
	private List<WebElement> tabs;

	public SamLoggingPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(enableLoggingField.getTitle(), enableLoggingField);
				put(serverAddressField.getTitle(), serverAddressField);
				put(serverPortField.getTitle(), serverPortField);
				put(logcatParametersField.getTitle(), logcatParametersField);
				put(debuggingPasswordField.getTitle(), debuggingPasswordField);
				put(showPasswordField.getTitle(), showPasswordField);
				put(allowDeviceConfigurationField.getTitle(), allowDeviceConfigurationField);
				put(captureBugReportField.getTitle(), captureBugReportField);
				put(haltOnCrashField.getTitle(), haltOnCrashField);
				put(captureTrafficField.getTitle(), captureTrafficField);
				put(netTrafficLengthField.getTitle(), netTrafficLengthField);
				put(captureLogcatField.getTitle(), captureLogcatField);
				put(logcatSizeField.getTitle(), logcatSizeField);
				put(captureQxdmField.getTitle(), captureQxdmField);
				put(qxdmFilterField.getTitle(), qxdmFilterField);
				put(fileUploadServerField.getTitle(), fileUploadServerField);
				put(fileUploadPortField.getTitle(), fileUploadPortField);
				put(uploadProtocolField.getTitle(), uploadProtocolField);
				put(passwordProtectField.getTitle(), passwordProtectField);
			}
		};

	}

	public void clickSyslogTab() {
		clickOnPageEntity(tabs.get(0));
		sleepSeconds(1);
	}

	public void clickAdvancedLoggingTab() {
		clickOnPageEntity(tabs.get(1));
		sleepSeconds(1);
	}

	public void clickShowPassword() {
		showPasswordField.click();
	}
}
