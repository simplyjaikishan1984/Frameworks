package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.BarcodeUi;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.BARCODE_TEST_APP;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class DeviceBarcodeSteps {
    private final Logger log = LogManager.getLogger(this.getClass().getName());
    WebDriver driver;
    @When("^I set the Barcode \"([^\"]*)\" switch to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setBarcodeSwitch(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        BarcodeUi barcodeUi = phone.getBarcodeUi();
        ConfigUiField field = barcodeUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BARCODE_TEST_APP, arg1.trim());
        if (field != null) {
            if (field.hasLabelElement()) field.scrollIntoView(heading);
            switch (arg2.toLowerCase()) {
                case "on":
                    if (field.getControlElement().getAttribute("checked").equals("false"))
                        field.tap();
                    else
                        log.debug("Field '{}' was already set to '{}'", arg1, arg2);
                    break;
                case "off":
                    if (field.getControlElement().getAttribute("checked").equals("true"))
                        field.tap();
                    else
                        log.debug("Field '{}' was already set to '{}'", arg1, arg2);
                    break;
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I tap the Barcode \"([^\"]*)\" on device \"([^\"]*)\"$")
    public void tapBarcodeObject(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        BarcodeUi barcodeUi = phone.getBarcodeUi();
        ConfigUiField field = barcodeUi.getField(arg1.trim().toLowerCase());
        if (field != null) {
            if (field.isLabelPresent()) {
                field.tap();
            } else {
                log.error("Field '{}' has no label", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @Then("^I verify the Barcode \"([^\"]*)\" displays \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyFieldData(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        BarcodeUi barcodeUi = phone.getBarcodeUi();
        ConfigUiField field = barcodeUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BARCODE_TEST_APP, arg1.trim());
        if (field != null) {
            if (field.hasLabelElement()) field.scrollIntoView(heading);

            switch (arg1) {
                case "Keyboard input":
                    if (barcodeUi.keyBoardInput().equals(arg2))
                        log.debug("Match found for Keyboard input");
                    else {
                        log.fatal("Match found for Keyboard input");
                        Environment.softAssert().fail("INCORRECT BARCODE DATA");
                    }
                break;

                case "Scanned barcode data":
                    if (barcodeUi.scannedBarcodeData().equals(arg2))
                        log.debug("Match found for Scanned barcode data");
                    else {
                        log.fatal("Match found for Scanned barcode data");
                        Environment.softAssert().fail("INCORRECT BARCODE DATA");
                    }
                    break;

                case "Barcode scanner state":
                    if (barcodeUi.barcodeScannedState().equals(arg2))
                        log.debug("Match found for Barcode scanner state");
                    else {
                        log.fatal("Match found for Barcode scanner state");
                        Environment.softAssert().fail("INCORRECT BARCODE DATA");
                    }
                    break;

            }

        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I find the first scan \"([^\"]*)\" on \"([^\"]*)\"$")
    public void findStartingPoint(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        BarcodeUi barcodeUi = phone.getBarcodeUi();
        for (int i = 0; i <10; i++) {
            barcodeUi.scanData();
            if (barcodeUi.keyBoardInput().equals(arg1)) {
                log.debug("Match found");
                break;
            }
            barcodeUi.clearKeyboardInput();
            sleepSeconds(4);
        }
    }

    @Then("^I verify \"([^\"]*)\" is displayed as the scanned output on \"([^\"]*)\"$")
    public void verifyScan(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        BarcodeUi barcodeUi = phone.getBarcodeUi();
        barcodeUi.scanData();
        sleepSeconds(4);
        if(barcodeUi.keyBoardInput().equals(arg1))
            log.debug("Match found, '{}'", arg1);
        else {
            log.fatal("Scanned '{}' instead of '{}'", barcodeUi.keyBoardInput(), arg1);
            Environment.softAssert().fail("INCORRECT BARCODE DATA");
        }
        barcodeUi.clearKeyboardInput();
        driver.findElement(By.xpath("/html/body/div[5]/div[1]/div/div[4]/div")).click();
        sleepSeconds(2);
    }

    @When("^I present the barcodes page \"([^\"]*)\" on the screen")
    public void startPresentingBarcodes(String arg1) {
        String projectDirectory = System.getProperty("user.dir");
        HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
        ChromeOptions options;
        chromePrefs.put("download.default_directory", projectDirectory + "/src/test/resources");
        options = new ChromeOptions();
        options.setExperimentalOption("prefs", chromePrefs);
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(arg1);
    }

    @When("^I verify \"([^\"]*)\" page is opened on the phone browser on \"([^\"]*)\"$")
    public void getChromeUrl(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        BarcodeUi barcodeUi = phone.getBarcodeUi();
        barcodeUi.scanData();
        sleepSeconds(4);
        String url = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
        if(arg1.equals(url))
            log.debug("'{}' page was opened on '{}'", arg1, arg2);
        else {
            log.fatal("Incorrect web page");
            Environment.softAssert().fail("INCORRECT BARCODE DATA");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.bringAppToForeground(BARCODE_TEST_APP);
        barcodeUi.clearKeyboardInput();
        driver.findElement(By.xpath("/html/body/div[5]/div[1]/div/div[4]/div")).click();
        sleepSeconds(2);
    }

    @When("I clear out the browser session")
    public void closeSession() {
        if (driver != null) {
            log.info("Disposing web browser session");
            driver.manage().deleteAllCookies();
            driver.quit();
            driver = null;
        }
    }
}
