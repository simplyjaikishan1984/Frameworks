package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.DeviceAppStrings.*;
import static com.spectralink.test_automation.cucumber.stepdefs.DeviceDeviceAppSteps.toggleEnabled;

public class DeviceAppUi extends AppiumUi {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @AndroidFindBy(accessibility = "Navigate up")
    private WebElement backButton;

    private final ConfigUiField backButtonField = new ConfigUiField(
            driver,
            BACK_ARROW,
            null,
            backButton,
            null
    );


    @AndroidFindBy(accessibility = "App logo")
    private WebElement aboutIconButton;

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    private final ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            null,
            overflowButton,
            null
    );

    @AndroidFindBy(accessibility = "Allow Wi-Fi toggle title")
    private WebElement wifiToggleLabel;

    @AndroidFindBy(accessibility = "Allow Wi-Fi toggle switch")
    private WebElement wifiToggleControl;

    private final ConfigUiField wifiToggleField = new ConfigUiField(
            driver,
            ALLOW_WIFI_TOGGLE,
            wifiToggleLabel,
            wifiToggleControl,
            null
    );

    @AndroidFindBy(accessibility = "Allow airplane mode title")
    private WebElement allowAirplaneModeLabel;

    @AndroidFindBy(accessibility = "Allow airplane mode switch")
    private WebElement allowAirplaneModeControl;

    private final ConfigUiField allowAirplaneModeField = new ConfigUiField(
            driver,
            ALLOW_AIRPLANE_MODE,
            allowAirplaneModeLabel,
            allowAirplaneModeControl,
            null
    );

    @AndroidFindBy(accessibility = "Allow quick settings tiles title")
    private WebElement allowQuickSettingsTilesLabel;

    @AndroidFindBy(accessibility = "Allow quick settings tiles switch")
    private WebElement allowQuickSettingsTilesControl;

    private final ConfigUiField allowQuickSettingsTilesField = new ConfigUiField(
            driver,
            ALLOW_QUICK_SETTINGS_TILES,
            allowQuickSettingsTilesLabel,
            allowQuickSettingsTilesControl,
            null
    );

    @AndroidFindBy(accessibility = "Quick settings tiles title")
    private WebElement quickSettingsTilesLabel;

    @AndroidFindBy(accessibility = "Quick settings tiles summary")
    private WebElement quickSettingsTilesValue;

    private final ConfigUiField quickSettingsTilesField = new ConfigUiField(
            driver,
            QUICK_SETTINGS_TILE,
            quickSettingsTilesLabel,
            quickSettingsTilesLabel,
            quickSettingsTilesValue
    );

    @AndroidFindBy(accessibility = "Allow notification shade settings gear title")
    private WebElement notificationShadeGearLabel;

    @AndroidFindBy(accessibility = "Allow notification shade settings gear switch")
    private WebElement notificationShadeGearControl;

    private final ConfigUiField notificationShadeGearField = new ConfigUiField(
            driver,
            ALLOW_NOTIFICATION_SHADE_GEAR,
            notificationShadeGearLabel,
            notificationShadeGearControl,
            null
    );

    @AndroidFindBy(accessibility = "Allow time zone configuration title")
    private WebElement timeZoneConfigurationLabel;

    @AndroidFindBy(accessibility = "Allow time zone configuration switch")
    private WebElement timeZoneConfigurationControl;

    private final ConfigUiField timeZoneConfigurationField = new ConfigUiField(
            driver,
            ALLOW_TIME_ZONE_CONFIGURATION,
            timeZoneConfigurationLabel,
            timeZoneConfigurationControl,
            null
    );

    @AndroidFindBy(accessibility = "Allow time format configuration title")
    private WebElement timeFormatConfigurationLabel;

    @AndroidFindBy(accessibility = "Allow time format configuration switch")
    private WebElement timeFormatConfigurationControl;

    private final ConfigUiField timeFormatConfigurationField = new ConfigUiField(
            driver,
            ALLOW_TIME_FORMAT_CONFIGURATION,
            timeFormatConfigurationLabel,
            timeFormatConfigurationControl,
            null
    );

    @AndroidFindBy(accessibility = "Allow automatic time zone toggle title")
    private WebElement automaticTimeZoneToggleLabel;

    @AndroidFindBy(accessibility = "Allow automatic time zone toggle switch")
    private WebElement automaticTimeZoneToggleControl;

    private final ConfigUiField automaticTimeZoneToggleField = new ConfigUiField(
            driver,
            ALLOW_AUTO_TIME_ZONE_TOGGLE,
            automaticTimeZoneToggleLabel,
            automaticTimeZoneToggleControl,
            null
    );

    @AndroidFindBy(accessibility = "Allow emergency call button on lockscreen title")
    private WebElement emergencyCallButtonLabel;

    @AndroidFindBy(accessibility = "Allow emergency call button on lockscreen switch")
    private WebElement emergencyCallButtonControl;

    private final ConfigUiField emergencyCallButtonField = new ConfigUiField(
            driver,
            ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN,
            emergencyCallButtonLabel,
            emergencyCallButtonControl,
            null
    );

    @AndroidFindBy(accessibility = "Automatic time zone title")
    private WebElement automaticTimeZoneLabel;

    @AndroidFindBy(accessibility = "Automatic time zone switch")
    private WebElement automaticTimeZoneControl;

    private final ConfigUiField automaticTimeZoneField = new ConfigUiField(
            driver,
            AUTOMATIC_TIME_ZONE,
            automaticTimeZoneLabel,
            automaticTimeZoneControl,
            null
    );

    @AndroidFindBy(accessibility = "Display device info title")
    private WebElement displayDeviceInfoLabel;

    @AndroidFindBy(accessibility = "Display device info switch")
    private WebElement displayDeviceInfoControl;

    private final ConfigUiField displayDeviceInfoField = new ConfigUiField(
            driver,
            DISPLAY_DEVICE_INFO,
            displayDeviceInfoLabel,
            displayDeviceInfoControl,
            null
    );

    @AndroidFindBy(accessibility = "NTP server address title")
    private WebElement ntpServerAddressLabel;

    @AndroidFindBy(accessibility = "NTP server address summary")
    private WebElement ntpServerAddressValue;

    private final ConfigUiField ntpServerAddressField = new ConfigUiField(
            driver,
            NTP_SERVER_ADDRESS,
            ntpServerAddressLabel,
            ntpServerAddressLabel,
            ntpServerAddressValue
    );

    @AndroidFindBy(accessibility = "Time zone title")
    private WebElement timeZoneLabel;

    @AndroidFindBy(accessibility = "Time zone summary")
    private WebElement timeZoneValue;

    private final ConfigUiField timeZoneField = new ConfigUiField(
            driver,
            TIME_ZONE,
            timeZoneLabel,
            timeZoneLabel,
            timeZoneValue
    );

    @AndroidFindBy(accessibility = "Time format title")
    private WebElement timeFormatLabel;

    @AndroidFindBy(accessibility = "Time format summary")
    private WebElement timeFormatValue;

    private final ConfigUiField timeFormatField = new ConfigUiField(
            driver,
            TIME_FORMAT,
            timeFormatLabel,
            timeFormatLabel,
            timeFormatValue
    );

    @AndroidFindBy(accessibility = "Device info 1 title")
    private WebElement deviceInfo1Label;

    @AndroidFindBy(accessibility = "Device info 1 summary")
    private WebElement deviceInfo1Value;

    private final ConfigUiField deviceInfo1Field = new ConfigUiField(
            driver,
            DEVICE_INFO_1,
            deviceInfo1Label,
            deviceInfo1Label,
            deviceInfo1Value
    );

    @AndroidFindBy(accessibility = "Device info 2 title")
    private WebElement deviceInfo2Label;

    @AndroidFindBy(accessibility = "Device info 2 summary")
    private WebElement deviceInfo2Value;

    private final ConfigUiField deviceInfo2Field = new ConfigUiField(
            driver,
            DEVICE_INFO_2,
            deviceInfo2Label,
            deviceInfo2Label,
            deviceInfo2Value
    );

    @AndroidFindBy(accessibility = "Device info 3 title")
    private WebElement deviceInfo3Label;

    @AndroidFindBy(accessibility = "Device info 3 summary")
    private WebElement deviceInfo3Value;

    private final ConfigUiField deviceInfo3Field = new ConfigUiField(
            driver,
            DEVICE_INFO_3,
            deviceInfo3Label,
            deviceInfo3Label,
            deviceInfo3Value
    );

    @AndroidFindBy(accessibility = "Device info 4 title")
    private WebElement deviceInfo4Label;

    @AndroidFindBy(accessibility = "Device info 4 summary")
    private WebElement deviceInfo4Value;

    private final ConfigUiField deviceInfo4Field = new ConfigUiField(
            driver,
            DEVICE_INFO_4,
            deviceInfo4Label,
            deviceInfo4Label,
            deviceInfo4Value
    );

    @AndroidFindBy(accessibility = "Device name title")
    private WebElement deviceNameLabel;

    @AndroidFindBy(accessibility = "Device name summary")
    private WebElement deviceNameValue;

    private final ConfigUiField deviceNameField = new ConfigUiField(
            driver,
            DEVICE_NAME,
            deviceNameLabel,
            deviceNameLabel,
            deviceNameValue
    );

    @AndroidFindBy(accessibility = "Battery optimization whitelist title")
    private WebElement batteryOptimizationWhitelistLabel;

    @AndroidFindBy(accessibility = "Battery optimization whitelist summary")
    private WebElement batteryOptimizationWhitelistValue;

    private final ConfigUiField batteryOptimizationWhitelistField = new ConfigUiField(
            driver,
            BATTERY_OPTIMIZATION_WHITELIST,
            batteryOptimizationWhitelistLabel,
            batteryOptimizationWhitelistLabel,
            batteryOptimizationWhitelistValue
    );

    @AndroidFindBy(accessibility = "Allow battery saver title")
    private WebElement allowBatterySaverLabel;

    @AndroidFindBy(accessibility = "Allow battery saver switch")
    private WebElement allowBatterySaverControl;

    private final ConfigUiField allowBatterySaverField = new ConfigUiField(
            driver,
            ALLOW_BATTERY_SAVER,
            allowBatterySaverLabel,
            allowBatterySaverControl,
            null
    );

    @AndroidFindBy(accessibility = "SKeyboard title")
    private WebElement sKeyboardLabel;

    @AndroidFindBy(accessibility = "SKeyboard switch")
    private WebElement sKeyboardControl;

    private final ConfigUiField sKeyboardField = new ConfigUiField(
            driver,
            SKEYBOARD,
            sKeyboardLabel,
            sKeyboardControl,
            null
    );

    @AndroidFindBy(accessibility = "Google voice typing title")
    private WebElement googleVoiceTypingLabel;

    @AndroidFindBy(accessibility = "Google voice typing switch")
    private WebElement googleVoiceTypingControl;

    private final ConfigUiField googleVoiceTypingField = new ConfigUiField(
            driver,
            GOOGLE_VOICE_TYPING,
            googleVoiceTypingLabel,
            googleVoiceTypingControl,
            null
    );

    @AndroidFindBy(accessibility = "Time to sleep after inactivity title")
    private WebElement timeToSleepAfterInactivityLabel;

    @AndroidFindBy(accessibility = "Time to sleep after inactivity summary")
    private WebElement timeToSleepAfterInactivityValue;

    private final ConfigUiField timeToSleepAfterInactivityField = new ConfigUiField(
            driver,
            TIME_TO_SLEEP_AFTER_INACTIVITY,
            timeToSleepAfterInactivityLabel,
            timeToSleepAfterInactivityLabel,
            timeToSleepAfterInactivityValue
    );

    @AndroidFindBy(accessibility = "Dialpad tones title")
    private WebElement dialpadTonesLabel;

    @AndroidFindBy(accessibility = "Dialpad tones summary")
    private WebElement dialpadTonesValue;

    private final ConfigUiField dialpadTonesField = new ConfigUiField(
            driver,
            DIALPAD_TONES,
            dialpadTonesLabel,
            dialpadTonesLabel,
            dialpadTonesValue
    );

    @AndroidFindBy(accessibility = "Touch sounds title")
    private WebElement touchSoundsLabel;

    @AndroidFindBy(accessibility = "Touch sounds summary")
    private WebElement touchSoundsValue;

    private final ConfigUiField touchSoundsField = new ConfigUiField(
            driver,
            TOUCH_SOUNDS,
            touchSoundsLabel,
            touchSoundsLabel,
            touchSoundsValue
    );

    @AndroidFindBy(accessibility = "Vibrate on tap title")
    private WebElement vibrateOnTapLabel;

    @AndroidFindBy(accessibility = "Vibrate on tap summary")
    private WebElement vibrateOnTapValue;

    private final ConfigUiField vibrateOnTapField = new ConfigUiField(
            driver,
            VIBRATE_ON_TAP,
            vibrateOnTapLabel,
            vibrateOnTapLabel,
            vibrateOnTapValue
    );

    @AndroidFindBy(accessibility = "AMBER alerts title")
    private WebElement amberAlertsLabel;

    @AndroidFindBy(accessibility = "AMBER alerts summary")
    private WebElement amberAlertsValue;

    private final ConfigUiField amberAlertsField = new ConfigUiField(
            driver,
            AMBER_ALERTS,
            amberAlertsLabel,
            amberAlertsLabel,
            amberAlertsValue
    );

    @AndroidFindBy(accessibility = "Extreme threats title")
    private WebElement extremeThreatsLabel;

    @AndroidFindBy(accessibility = "Extreme threats summary")
    private WebElement extremeThreatsValue;

    private final ConfigUiField extremeThreatsField = new ConfigUiField(
            driver,
            EXTREME_THREATS,
            extremeThreatsLabel,
            extremeThreatsLabel,
            extremeThreatsValue
    );

    @AndroidFindBy(accessibility = "Severe threats title")
    private WebElement severeThreatsLabel;

    @AndroidFindBy(accessibility = "Severe threats summary")
    private WebElement severeThreatsValue;

    private final ConfigUiField severeThreatsField = new ConfigUiField(
            driver,
            SEVERE_THREATS,
            severeThreatsLabel,
            severeThreatsLabel,
            severeThreatsValue
    );

    @AndroidFindBy(accessibility = "Jump to camera title")
    private WebElement jumpToCameraLabel;

    @AndroidFindBy(accessibility = "Jump to camera summary")
    private WebElement jumpToCameraValue;

    private final ConfigUiField jumpToCameraField = new ConfigUiField(
            driver,
            JUMP_TO_CAMERA,
            jumpToCameraLabel,
            jumpToCameraLabel,
            jumpToCameraValue
    );

    @AndroidFindBy(accessibility = "Enable Wi-Fi calling/VoLTE title")
    private WebElement enableWifiCallingLabel;

    @AndroidFindBy(accessibility = "Enable Wi-Fi calling/VoLTE switch")
    private WebElement enableWifiCallingControl;

    private final ConfigUiField enableWifiCallingField = new ConfigUiField(
            driver,
            ENABLE_WIFI_CALLING,
            enableWifiCallingLabel,
            enableWifiCallingControl,
            null
    );

    @AndroidFindBy(accessibility = "Lock screen wallpaper title")
    private WebElement lockScreenWallpaperLabel;

    @AndroidFindBy(accessibility = "Lock screen wallpaper summary")
    private WebElement lockScreenWallpaperValue;

    private final ConfigUiField lockScreenWallpaperField = new ConfigUiField(
            driver,
            LOCK_SCREEN_WALLPAPER,
            lockScreenWallpaperLabel,
            lockScreenWallpaperLabel,
            lockScreenWallpaperValue
    );

    @AndroidFindBy(accessibility = "Home screen wallpaper title")
    private WebElement homeScreenWallpaperLabel;

    @AndroidFindBy(accessibility = "Home screen wallpaper summary")
    private WebElement homeScreenWallpaperValue;

    private final ConfigUiField homeScreenWallpaperField = new ConfigUiField(
            driver,
            HOME_SCREEN_WALLPAPER,
            homeScreenWallpaperLabel,
            homeScreenWallpaperLabel,
            homeScreenWallpaperValue
    );

    @AndroidFindBy(id = "android:id/button2")
    private WebElement doneButton;

    private final ConfigUiField doneButtonField = new ConfigUiField(
            driver,
            DONE,
            null,
            doneButton,
            null
    );

    @AndroidFindBy(accessibility = "Wi-Fi checkbox")
    private WebElement wifiControl;

    private final ConfigUiField wifiField = new ConfigUiField(
            driver,
            WIFI,
            null,
            wifiControl,
            null
    );

    @AndroidFindBy(accessibility = "Bluetooth checkbox")
    private WebElement bluetoothControl;

    private final ConfigUiField bluetoothField = new ConfigUiField(
            driver,
            BLUETOOTH,
            null,
            bluetoothControl,
            null
    );

    @AndroidFindBy(accessibility = "Do not disturb checkbox")
    private WebElement dndControl;

    private final ConfigUiField dndField = new ConfigUiField(
            driver,
            DO_NOT_DISTURB,
            null,
            dndControl,
            null
    );

    @AndroidFindBy(accessibility = "Flashlight checkbox")
    private WebElement flashlightControl;

    private final ConfigUiField flashlightField = new ConfigUiField(
            driver,
            FLASHLIGHT,
            null,
            flashlightControl,
            null
    );

    @AndroidFindBy(accessibility = "Rotation lock checkbox")
    private WebElement rotationLockControl;

    private final ConfigUiField rotationLockField = new ConfigUiField(
            driver,
            ROTATION_LOCK,
            null,
            rotationLockControl,
            null
    );

    @AndroidFindBy(accessibility = "Battery saver checkbox")
    private WebElement batterySaverControl;

    private final ConfigUiField batterySaverField = new ConfigUiField(
            driver,
            BATTERY_SAVER,
            null,
            batterySaverControl,
            null
    );

    @AndroidFindBy(accessibility = "Mobile data checkbox")
    private WebElement mobileDataControl;

    private final ConfigUiField mobileDataField = new ConfigUiField(
            driver,
            MOBILE_DATA,
            null,
            mobileDataControl,
            null
    );

    @AndroidFindBy(accessibility = "Airplane mode checkbox")
    private WebElement airplaneModeControl;

    private final ConfigUiField airplaneModeField = new ConfigUiField(
            driver,
            AIRPLANE_MODE,
            null,
            airplaneModeControl,
            null
    );

    @AndroidFindBy(accessibility = "Cast checkbox")
    private WebElement castControl;

    private final ConfigUiField castField = new ConfigUiField(
            driver,
            CAST,
            null,
            castControl,
            null
    );

    @AndroidFindBy(accessibility = "High touch checkbox")
    private WebElement highTouchControl;

    private final ConfigUiField highTouchField = new ConfigUiField(
            driver,
            HIGH_TOUCH,
            null,
            highTouchControl,
            null
    );

    @AndroidFindBy(accessibility = "Hotspot checkbox")
    private WebElement hotspotControl;

    private final ConfigUiField hotspotField = new ConfigUiField(
            driver,
            HOTSPOT,
            null,
            hotspotControl,
            null
    );

    @AndroidFindBy(accessibility = "Night light checkbox")
    private WebElement nightLightControl;

    private final ConfigUiField nightLightField = new ConfigUiField(
            driver,
            NIGHT_LIGHT,
            null,
            nightLightControl,
            null
    );

    @AndroidFindBy(accessibility = "Location checkbox")
    private WebElement locationControl;

    private final ConfigUiField locationField = new ConfigUiField(
            driver,
            LOCATION,
            null,
            locationControl,
            null
    );

    @AndroidFindBy(accessibility = "Invert colors checkbox")
    private WebElement invertColorsControl;

    private final ConfigUiField invertColorsField = new ConfigUiField(
            driver,
            INVERT_COLORS,
            null,
            invertColorsControl,
            null
    );

    @AndroidFindBy(accessibility = "Data saver checkbox")
    private WebElement dataSaverControl;

    private final ConfigUiField dataSaverField = new ConfigUiField(
            driver,
            DATA_SAVER,
            null,
            dataSaverControl,
            null
    );

    @AndroidFindBy(id = "android:id/edit")
    private WebElement editText;

    private final ConfigUiField editTextField = new ConfigUiField(
            driver,
            EDIT_TEXT,
            null,
            editText,
            null
    );

    @AndroidFindBy(id = "android:id/button1")
    private WebElement okButton;

    private final ConfigUiField okButtonField = new ConfigUiField(
            driver,
            OK_BUTTON,
            null,
            okButton,
            null
    );

    @AndroidFindBy(id = "android:id/button2")
    private WebElement cancelButton;

    private final ConfigUiField cancelButtonField = new ConfigUiField(
            driver,
            CANCEL_BUTTON,
            null,
            cancelButton,
            null
    );

    @AndroidFindBy(xpath = "//android.widget.CheckedTextView[(@resource-id ='android:id/text1') and contains(@text, 'US/Alaska')]")
    private WebElement usAlaskaTimeZone;

    private final ConfigUiField usAlaskaTimeZoneField = new ConfigUiField(
            driver,
            US_ALASKA,
            usAlaskaTimeZone,
            null,
            null
    );

    @AndroidFindBy(xpath = "//android.widget.CheckedTextView[(@resource-id ='android:id/text1') and contains(@text, 'US/Central')]")
    private WebElement usCentralTimeZone;

    private final ConfigUiField usCentralTimeZoneField = new ConfigUiField(
            driver,
            US_CENTRAL,
            usCentralTimeZone,
            null,
            null
    );

    @AndroidFindBy(accessibility = "Wi‑Fi")
    private WebElement androidSettingsWifiState;

    @AndroidFindBy(accessibility = "Edit order of settings.")
    private WebElement editNotificationSettings;

    @AndroidFindBy(accessibility = "Open settings.")
    private WebElement notificationSettingsGear;

    @AndroidFindBy(xpath = "//android.widget.Switch[contains(@content-desc, 'Wi-Fi')]/android.widget.Button/android.widget.LinearLayout/android.widget.TextView")
    private WebElement ssid;

    @AndroidFindBy(xpath = "//android.widget.Switch[@content-desc=\"Airplane mode\"]")
    private WebElement airplaneModeNotificationBar;

    @AndroidFindBy(id = "com.android.systemui:id/emergency_call_button")
    private WebElement emergencyCallButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Time zone')]")
    private WebElement timeZoneLabelAndroidSettings;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Time zone')].//android.widget.TextView[2]")
    private WebElement timeZoneValueAndroidSettings;

    @AndroidFindBy(accessibility = "Developer options title")
    private WebElement developerOptionsLabel;

    private final ConfigUiField developerOptionsField = new ConfigUiField(
            driver,
            DEVELOPER_OPTIONS,
            developerOptionsLabel,
            null,
            null
    );

    @AndroidFindBy(accessibility = "Restore defaults title")
    private WebElement restoreDefaultSettingsLabel;

    private final ConfigUiField restoreDefaultSettingsField = new ConfigUiField(
            driver,
            RESTORE_DEFAULT_SETTINGS,
            restoreDefaultSettingsLabel,
            null,
            null
    );

    @AndroidFindBy(xpath = "//android.widget.Switch[contains(@content-desc, 'Wi-Fi')]")
    private WebElement wifiStateNotificationBar;

    @AndroidFindBy(accessibility = "Device info text")
    private WebElement deviceInfoLockScreen;

    @AndroidFindBy(accessibility = "Device info text")
    private WebElement deviceInfoNotificationBar;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'About phone')].//android.widget.TextView[2]")
    private WebElement deviceNameAndroidSettingsPage;

    private final ConfigUiField deviceNameAndroidSettingsPageField = new ConfigUiField(
            driver,
            ABOUT_PHONE,
            deviceNameAndroidSettingsPage,
            null,
            null
    );

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'System')]")
    private WebElement systemAndroidSettingsPage;

    private final ConfigUiField systemAndroidSettingsPageField = new ConfigUiField(
            driver,
            SYSTEM,
            systemAndroidSettingsPage,
            systemAndroidSettingsPage,
            null
    );

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Wi‑Fi preferences')]")
    private WebElement wifiPreferencesText;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Wi‑Fi Direct')]")
    private WebElement wifiDirectText;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Visible as')]")
    private WebElement deviceNameConnectedDevicesScreen;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Connection preferences')]")
    private WebElement androidSettingsConnectionPreferencesText;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Bluetooth')]")
    private WebElement androidSettingsBluetoothText;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Connection devices')]")
    private WebElement androidSettingsConnectedDevicesText;

    private final ConfigUiField androidSettingsConnectedDevicesTextField = new ConfigUiField(
            driver,
            CONNECTED_DEVICES,
            androidSettingsConnectedDevicesText,
            null,
            null
    );

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/text1') and contains(@text, 'NOT OPTIMIZED')]")
    private WebElement androidSettingsBatteryOptimizationNotOptimizedSpinner;

    @AndroidFindBy(xpath = "//android.widget.CheckedTextView[(@resource-id ='android:id/text1') and contains(@text, 'Not optimized')]")
    private WebElement androidSettingsBatteryOptimizationNotOptimized;

    @AndroidFindBy(id = "com.android.settings:id/state_on_button")
    private WebElement androidSettingsBatterySaverTurnOnButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Languages & input')]")
    private WebElement androidSettingsLanguagesInput;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Virtual keyboard')]")
    private WebElement androidSettingsVirtualKeyboard;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Manage keyboards')]")
    private WebElement androidSettingsManageKeyboards;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Advanced')]")
    private WebElement androidSettingsAdvanced;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Gestures')]")
    private WebElement androidSettingsGestures;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Jump to camera')]")
    private WebElement androidSettingsJumpToCamera;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Emergency alerts')]")
    private WebElement androidSettingsEmergencyAlerts;

    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.RelativeLayout")
    private WebElement wifiText;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Apps & notifications')]")
    private WebElement androidSettingsAppsNotifications;

    private final ConfigUiField androidSettingsAppsNotificationsField = new ConfigUiField(
            driver,
            APPS_NOTIFICATIONS_ANDROID_SETTINGS,
            androidSettingsAppsNotifications,
            androidSettingsAppsNotifications,
            null
    );

    @AndroidFindBy(id = "com.android.systemui:id/qs_drag_handle_view")
    private WebElement expandNotificationIcon;

    public DeviceAppUi (AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(OVERFLOW_MENU.title().toLowerCase(), overflowButtonField);
                put(DONE.title().toLowerCase(), doneButtonField);
                put(EDIT_TEXT.title().toLowerCase(), editTextField);
                put(ALLOW_WIFI_TOGGLE.title().toLowerCase(), wifiToggleField);
                put(ALLOW_AIRPLANE_MODE.title().toLowerCase(), allowAirplaneModeField);
                put(ALLOW_QUICK_SETTINGS_TILES.title().toLowerCase(), allowQuickSettingsTilesField);
                put(QUICK_SETTINGS_TILE.title().toLowerCase(), quickSettingsTilesField);
                put(WIFI.title().toLowerCase(), wifiField);
                put(BLUETOOTH.title().toLowerCase(), bluetoothField);
                put(DO_NOT_DISTURB.title().toLowerCase(), dndField);
                put(FLASHLIGHT.title().toLowerCase(), flashlightField);
                put(ROTATION_LOCK.title().toLowerCase(), rotationLockField);
                put(BATTERY_SAVER.title().toLowerCase(), batterySaverField);
                put(MOBILE_DATA.title().toLowerCase(), mobileDataField);
                put(AIRPLANE_MODE.title().toLowerCase(), airplaneModeField);
                put(CAST.title().toLowerCase(), castField);
                put(HIGH_TOUCH.title().toLowerCase(), highTouchField);
                put(HOTSPOT.title().toLowerCase(), hotspotField);
                put(NIGHT_LIGHT.title().toLowerCase(), nightLightField);
                put(LOCATION.title().toLowerCase(), locationField);
                put(INVERT_COLORS.title().toLowerCase(), invertColorsField);
                put(DATA_SAVER.title().toLowerCase(), dataSaverField);
                put(ALLOW_NOTIFICATION_SHADE_GEAR.title().toLowerCase(), notificationShadeGearField);
                put(ALLOW_TIME_ZONE_CONFIGURATION.title().toLowerCase(), timeZoneConfigurationField);
                put(ALLOW_TIME_FORMAT_CONFIGURATION.title().toLowerCase(), timeFormatConfigurationField);
                put(ALLOW_AUTO_TIME_ZONE_TOGGLE.title().toLowerCase(), automaticTimeZoneToggleField);
                put(ALLOW_EMERGENCY_CALL_BUTTON_ON_LOCK_SCREEN.title().toLowerCase(), emergencyCallButtonField);
                put(NTP_SERVER_ADDRESS.title().toLowerCase(), ntpServerAddressField);
                put(TIME_ZONE.title().toLowerCase(), timeZoneField);
                put(TIME_FORMAT.title().toLowerCase(), timeFormatField);
                put(AUTOMATIC_TIME_ZONE.title().toLowerCase(), automaticTimeZoneField);
                put(DISPLAY_DEVICE_INFO.title().toLowerCase(), displayDeviceInfoField);
                put(DEVICE_INFO_1.title().toLowerCase(), deviceInfo1Field);
                put(DEVICE_INFO_2.title().toLowerCase(), deviceInfo2Field);
                put(DEVICE_INFO_3.title().toLowerCase(), deviceInfo3Field);
                put(DEVICE_INFO_4.title().toLowerCase(), deviceInfo4Field);
                put(DEVICE_NAME.title().toLowerCase(), deviceNameField);
                put(BATTERY_OPTIMIZATION_WHITELIST.title().toLowerCase(), batteryOptimizationWhitelistField);
                put(ALLOW_BATTERY_SAVER.title().toLowerCase(), allowBatterySaverField);
                put(SKEYBOARD.title().toLowerCase(), sKeyboardField);
                put(GOOGLE_VOICE_TYPING.title().toLowerCase(), googleVoiceTypingField);
                put(TIME_TO_SLEEP_AFTER_INACTIVITY.title().toLowerCase(), timeToSleepAfterInactivityField);
                put(DIALPAD_TONES.title().toLowerCase(), dialpadTonesField);
                put(TOUCH_SOUNDS.title().toLowerCase(), touchSoundsField);
                put(VIBRATE_ON_TAP.title().toLowerCase(), vibrateOnTapField);
                put(AMBER_ALERTS.title().toLowerCase(), amberAlertsField);
                put(EXTREME_THREATS.title().toLowerCase(), extremeThreatsField);
                put(SEVERE_THREATS.title().toLowerCase(), severeThreatsField);
                put(JUMP_TO_CAMERA.title().toLowerCase(), jumpToCameraField);
                put(ENABLE_WIFI_CALLING.title().toLowerCase(), enableWifiCallingField);
                put(LOCK_SCREEN_WALLPAPER.title().toLowerCase(), lockScreenWallpaperField);
                put(HOME_SCREEN_WALLPAPER.title().toLowerCase(), homeScreenWallpaperField);
                put(OK_BUTTON.title().toLowerCase(), okButtonField);
                put(CANCEL_BUTTON.title().toLowerCase(), cancelButtonField);
                put(US_CENTRAL.title().toLowerCase(), usCentralTimeZoneField);
                put(US_ALASKA.title().toLowerCase(), usAlaskaTimeZoneField);
                put(BACK_ARROW.title().toLowerCase(), backButtonField);
                put(DEVELOPER_OPTIONS.title().toLowerCase(), developerOptionsField);
                put(RESTORE_DEFAULT_SETTINGS.title().toLowerCase(), restoreDefaultSettingsField);
                put(ABOUT_PHONE.title().toLowerCase(), deviceNameAndroidSettingsPageField);
                put(CONNECTED_DEVICES.title().toLowerCase(), androidSettingsConnectedDevicesTextField);
                put(SYSTEM.title().toLowerCase(), systemAndroidSettingsPageField);
                put(APPS_NOTIFICATIONS_ANDROID_SETTINGS.title().toLowerCase(), androidSettingsAppsNotificationsField);
            }
        };
    }

    public void clickOverflowMenu() {
        clickOnPageEntity(overflowButton);
        Util.sleepSeconds(1);
    }

    public void clearEditText() {
        log.debug("Clearing edit text");
        editText.clear();
    }

    public void editButtonNotifications() {
        log.debug("Clicking edit settings button from the notification drawer");
        editNotificationSettings.click();
    }

    public Boolean isSettingsButtonNotificationsVisible() {
        return notificationSettingsGear.isDisplayed();
    }

    public String timeZoneLabelEnabled() {
        return timeZoneLabel.getAttribute("enabled");
    }

    public String timeZoneLabelEnabledAndroidSettings() {
        return timeZoneLabelAndroidSettings.getAttribute("enabled");
    }

    public String timeZoneValueEnabled() {
        return timeZoneValue.getAttribute("enabled");
    }

    public String timeFormatLabelEnabled() {
        return timeFormatLabel.getAttribute("enabled");
    }

    public String timeFormatValueEnabled() {
        return timeFormatValue.getAttribute("enabled");
    }

    public String getDeviceInfoLockScreen() {
        return deviceInfoLockScreen.getText();
    }

    public String getDeviceInfoNotificationBar() {
        return deviceInfoNotificationBar.getText();
    }

    public void toggleWifiNotificationBar(String value) {
        WebElement element;
        if(toggleEnabled)
            element = driver.findElement(By.xpath("//android.widget.Switch[contains(@content-desc, 'Wi-Fi')]"));
        else
            element = driver.findElement(By.xpath("//android.widget.LinearLayout[contains(@content-desc, 'Wi-Fi')]"));
        log.debug("Wifi State: " + element.getText());
        switch (value) {
            case "on":
                if (element.getText().toLowerCase().equals("on"))
                    log.debug("Wifi already enabled");
                else {
                    element.click();
                    log.debug("Turning on Wi-Fi");
                }
                break;
            case "off":
                if (element.getText().toLowerCase().equals("on")) {
                    element.click();
                    log.debug("Turning off Wi-Fi");
                }
                else
                    log.debug("Wifi already disabled");
                break;
        }
    }

    public void toggleWifiAndroidSettings(String value) {
        switch (value) {
            case "on":
                if (androidSettingsWifiState.getAttribute("checked").equals("true"))
                    log.debug("Wifi already enabled");
                else {
                    androidSettingsWifiState.click();
                    log.debug("Turning on Wi-Fi");
                }
                break;
            case "off":
                if (androidSettingsWifiState.getAttribute("checked").equals("true")) {
                    androidSettingsWifiState.click();
                    log.debug("Turning off Wi-Fi");
                }
                else
                    log.debug("Wifi already disabled");
                break;
        }
    }

    public String getWifiStateNotificationBar() {
        WebElement element;
        if(toggleEnabled)
            element = driver.findElement(By.xpath("//android.widget.Switch[contains(@content-desc, 'Wi-Fi')]"));
        else
            element = driver.findElement(By.xpath("//android.widget.LinearLayout[contains(@content-desc, 'Wi-Fi')]"));

        return element.getText();
    }

    public String getWifiToggleStateAndroidSettings() {
        String wifiState = androidSettingsWifiState.getAttribute("checked");
        log.debug("WIFI State Android Settings: " + wifiState);
        return wifiState;
    }

    public String getTimeFormatStateAndroidSettings() {
        String timeFormat = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Use 24-hour format')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("enabled");
        return timeFormat;
    }

    public String getAutomaticTimeZoneStateAndroidSettings() {
        String automaticTimeZone = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Use network-provided time zone')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("enabled");
        return automaticTimeZone;
    }

    public String getAutomaticTimeZoneSwitchAndroidSettings() {
        String automaticTimeZone = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Use network-provided time zone')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return automaticTimeZone;
    }

    public String getTimeFormatSwitchAndroidSettings() {
        String timeFormat = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Use 24-hour format')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return timeFormat;
    }

    public String getTimeZoneValueAndroidSettings() {
        return timeZoneValueAndroidSettings.getText();
    }

    public void toggleAirplaneModeAndroidSettingsWifi(String value) {
        WebElement airplaneModeWifi = driver.findElementById("android:id/switch_widget");
        switch (value) {
            case "on":
                if (airplaneModeWifi.getText().equals("ON"))
                    log.debug("Airplane Mode already enabled");
                else {
                    airplaneModeWifi.click();
                    log.debug("Turning on Airplane Mode");
                }
                break;
            case "off":
                if (airplaneModeWifi.getText().equals("ON")) {
                    airplaneModeWifi.click();
                    log.debug("Turning off Airplane Mode");
                }
                else
                    log.debug("Airplane Mode already disabled");
                break;
        }
    }

    public void toggleAirplaneModeAndroidSettingsLte(String value) {
        tapOnAdvanced();
        WebElement airplaneModeLte = driver.findElementById("android:id/switch_widget");
        switch (value) {
            case "on":
                if (airplaneModeLte.getText().toLowerCase().equals("on"))
                    log.debug("Airplane Mode already enabled");
                else {
                    airplaneModeLte.click();
                    log.debug("Turning on Airplane Mode");
                }
                break;
            case "off":
                if (airplaneModeLte.getText().toLowerCase().equals("on")) {
                    airplaneModeLte.click();
                    log.debug("Turning off Airplane Mode");
                }
                else
                    log.debug("Airplane Mode already disabled");
                break;
        }
    }

    public void toggleAirplaneModeNotificationBar(String value, WebElement element) {

        switch (value) {
            case "on":
                if (element.getText().toLowerCase().equals("on"))
                    log.debug("Airplane Mode already enabled");
                else {
                    element.click();
                    log.debug("Turning on Airplane Mode");
                }
                break;
            case "off":
                if (element.getText().toLowerCase().equals("on")) {
                    element.click();
                    log.debug("Turning off Airplane Mode");
                }
                else
                    log.debug("Airplane Mode already disabled");
                break;
        }
    }

    public String getAirplaneModeStateNotificationBar() {
        WebElement element;
        if(toggleEnabled)
            element = driver.findElement(By.xpath("//android.widget.Switch[@content-desc=\"Airplane mode\"]"));
        else
            element = driver.findElement(By.xpath("//android.widget.LinearLayout[@content-desc=\"Airplane mode\"]"));

        log.debug("Airplane Mode State notification bar: " + element.getText());
        return element.getText();
    }

    public String getAirplaneModeToggleStateAndroidSettings() {
        tapOnAdvanced();
        String airplaneMode = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Airplane mode')]/parent::*/parent::*/android.widget.LinearLayout[2]/android.widget.Switch").getAttribute("checked");
        return airplaneMode;
    }

    public String getAutomaticTimeZoneControl() {
        return automaticTimeZoneControl.getAttribute("enabled");
    }

    public Boolean isWifiIconNotificationBarVisible() {
        return wifiStateNotificationBar.isDisplayed();
    }

    public Boolean isDeviceInfoVisibleOnLockScreen() {
        return deviceInfoLockScreen.isDisplayed();
    }

    public Boolean isDeviceInfoVisibleInNotificationBar() {
        return deviceInfoNotificationBar.isDisplayed();
    }

    public Boolean isBluetoothIconNotificationBarVisible() {
        WebElement bluetoothIcon = driver.findElement(By.xpath("//android.widget.Switch[contains(@content-desc, 'Bluetooth')]"));
        return bluetoothIcon.isDisplayed();
    }
    public Boolean isDoNotDisturbIconNotificationBarVisible() {
        WebElement dndIcon = driver.findElement(By.xpath("//android.widget.Switch[contains(@content-desc, 'Do Not Disturb')]"));
        return dndIcon.isDisplayed();
    }

    public Boolean isFlashlightIconNotificationBarVisible() {
        WebElement flashlightIcon = driver.findElement(By.xpath("//android.widget.Switch[contains(@content-desc, 'Flashlight')]"));
        return flashlightIcon.isDisplayed();
    }

    public Boolean isAutoRotateIconNotificationBarVisible() {
        WebElement autoRotateScreenIcon = driver.findElement(By.xpath("//android.widget.Switch[contains(@content-desc, 'Auto-rotate screen')]"));
        return autoRotateScreenIcon.isDisplayed();
    }

    public Boolean isBatterySaverIconNotificationBarVisible() {
        WebElement batterySaverIcon = driver.findElement(By.xpath("//android.widget.LinearLayout[contains(@content-desc, 'Battery Saver')]"));
        return batterySaverIcon.isDisplayed();
    }

    public Boolean isMobileDataIconNotificationBarVisible() {
        WebElement mobileDataIcon = driver.findElement(By.xpath("//android.widget.LinearLayout[contains(@content-desc, 'Mobile data')]"));
        return mobileDataIcon.isDisplayed();
    }

    public Boolean isAirplaneModeIconNotificationBarVisible() {
        WebElement airplaneModeIcon = driver.findElement(By.xpath("//android.widget.Switch[contains(@content-desc, 'Airplane mode')]"));
        return airplaneModeIcon.isDisplayed();
    }

    public Boolean isCastIconNotificationBarVisible() {
        WebElement castIcon = driver.findElement(By.xpath("//android.widget.Button[contains(@content-desc, 'Screen Cast')]"));
        return castIcon.isDisplayed();
    }

    public Boolean isHighTouchIconNotificationBarVisible() {
        WebElement highTouchIcon = driver.findElement(By.xpath("//android.widget.TextView[(@resource-id ='com.android.systemui:id/tile_label') and contains(@text, 'High touch')]"));
        return highTouchIcon.isDisplayed();
    }

    public Boolean isLocationIconNotificationBarVisible() {
        WebElement locationIcon = driver.findElement(By.xpath("//android.widget.Button[contains(@content-desc, 'Location')]"));
        return locationIcon.isDisplayed();
    }

    public Boolean isHotspotIconNotificationBarVisible() {
        WebElement hotspotIcon = driver.findElement(By.xpath("//android.widget.Button[contains(@content-desc, 'Hotspot')]"));
        return hotspotIcon.isDisplayed();
    }

    public Boolean isInvertColorsIconNotificationBarVisible() {
        WebElement invertColorsIcon = driver.findElement(By.xpath("//android.widget.Button[contains(@content-desc, 'Invert colors')]"));
        return invertColorsIcon.isDisplayed();
    }

    public Boolean isDataSaverNotificationBarVisible() {
        WebElement dataSaverIcon = driver.findElement(By.xpath("//android.widget.Button[contains(@content-desc, 'Data Saver')]"));
        return dataSaverIcon.isDisplayed();
    }

    public Boolean isNightLightIconNotificationBarVisible() {
        WebElement nightLightIcon = driver.findElement(By.xpath("//android.widget.Button[contains(@content-desc, 'Night Light')]"));
        return nightLightIcon.isDisplayed();
    }

    public Boolean isEmergencyCallButtonVisibleOnLockScreen() {
        return emergencyCallButton.isDisplayed();
    }

    public Point getDeviceAppIconPosition() {
        int centerX = aboutIconButton.getLocation().getX() + aboutIconButton.getSize().getWidth() / 2;
        int centerY = aboutIconButton.getLocation().getY() + aboutIconButton.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }

    public void goBack() {
        backButton.click();
    }

    public void clickExposeButton(VersityPhone phone) {
        WebElement exposeButton;
        if(phone.getModel().toLowerCase().contains("saturn")) {
            try {
                exposeButton = driver.findElementById("com.cisco.customsettings:id/snackbar_action");
                if (exposeButton.isDisplayed())
                    exposeButton.click();
            } catch (Exception exception) {
                log.debug("Hidden settings already exposed");
            }
        }
        else {
            try {
                exposeButton = driver.findElementById("com.spectralink.slnkdevicesettings:id/snackbar_action");
                if (exposeButton.isDisplayed())
                    exposeButton.click();
            } catch (Exception exception) {
                log.debug("Hidden settings already exposed");
            }
        }
    }

    public String getDeviceNameBluetoothAboutPhonePage() {
        String aboutPhonePage = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Device name')]/parent::*/android.widget.TextView[2]").getText();
        return aboutPhonePage;
    }

    public String getDeviceNameBluetoothScreen() {
        return deviceNameConnectedDevicesScreen.getText();
    }

    public void tapOnConnectionPreferences() {
        androidSettingsConnectionPreferencesText.click();
    }

    public void tapOnConnectedDevices() {
        androidSettingsConnectedDevicesText.click();
    }

    public void tapOnBluetooth() {
        androidSettingsBluetoothText.click();
    }

    public void tapOnWiFiPreferences() {
        wifiPreferencesText.click();
    }

    public void tapOnWiFiDirect() {
        wifiDirectText.click();
    }

    public void selectNotOptimized() {
        androidSettingsBatteryOptimizationNotOptimized.click();
    }

    public void selectBatteryOptimizationSpinner() {
        androidSettingsBatteryOptimizationNotOptimizedSpinner.click();
    }

    public String getBatterySaverButtonAndroidSettingsState() {
        String batterySaverButton = androidSettingsBatterySaverTurnOnButton.getAttribute("enabled");
        log.debug("Battery Saver Turn On Button State Android Settings: " + batterySaverButton);
        return batterySaverButton;
    }

    public String getSKeyboardStateAndroidSettings() {
        String sKeyboard = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'SKeyboard')]/parent::*/parent::*/android.widget.LinearLayout[2]/android.widget.Switch").getAttribute("checked");
        return sKeyboard;
    }

    public String getGoogleVoiceTypingStateAndroidSettings() {
        String googleVoiceTyping = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Google voice typing')]/parent::*/parent::*/android.widget.LinearLayout[2]/android.widget.Switch").getAttribute("checked");
        return googleVoiceTyping;
    }

    public String getDialpadTonesStateAndroidSettings() {
        String dialpadTones = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Dial pad tones')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return dialpadTones;
    }

    public String getTouchSoundsStateAndroidSettings() {
        String touchSounds = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Touch sounds')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return touchSounds;
    }

    public String getVibrateOnTapStateAndroidSettings() {
        String vibrateOnTap = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Touch vibration')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return vibrateOnTap;
    }

    public String getAmberAlertsStateAndroidSettings() {
        String amberAlerts = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'AMBER alerts')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return amberAlerts;
    }

    public String getSevereThreatsValueAndroidSettings() {
        String severeThreats = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Severe threats')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return severeThreats;
    }

    public String getSevereThreatsStateAndroidSettings() {
        String severeThreats = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Severe threats')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("enabled");
        return severeThreats;
    }

    public String getExtremeThreatsStateAndroidSettings() {
        String extremeThreats = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Extreme threats')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return extremeThreats;
    }

    public String getJumpToCameraStateAndroidSettings() {
        String jumpToCamera = driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Jump to camera')]/parent::*/parent::*/android.widget.LinearLayout/android.widget.Switch").getAttribute("checked");
        return jumpToCamera;
    }

    public void tapOnLanguagesInput() {
        androidSettingsLanguagesInput.click();
    }
    public void tapOnVirtualKeyboard() {
        androidSettingsVirtualKeyboard.click();
    }
    public void tapOnManageKeyboards() {
        androidSettingsManageKeyboards.click();
    }
    public void tapOnAdvanced() {
        try {
            androidSettingsAdvanced.click();
        }
        catch (Exception exception) {
            log.debug("Advanced options not found");
        }
    }

    public void tapOnGestures() {
        androidSettingsGestures.click();
    }

    public void tapOnJumpToCamera() {
        androidSettingsJumpToCamera.click();
    }

    public void tapOnEmergencyAlerts() {
        androidSettingsEmergencyAlerts.click();
    }

    public String getAndroidSettingsTimeToSleepValue() {
        return driver.findElementByXPath("//android.widget.TextView[(@resource-id ='android:id/title') and contains(@text, 'Screen timeout')]/parent::*/android.widget.TextView[2]").getText();
    }

    public String getSevereThreatsValueText() {
        return severeThreatsValue.getText();
    }

    public String isSevereThreatsLabelEnabled() {
        return severeThreatsLabel.getAttribute("enabled");
    }

    public String isSevereThreatsValueEnabled() {
        return severeThreatsValue.getAttribute("enabled");
    }

    public void tapOnWifiText() {
        wifiText.click();
    }
}
