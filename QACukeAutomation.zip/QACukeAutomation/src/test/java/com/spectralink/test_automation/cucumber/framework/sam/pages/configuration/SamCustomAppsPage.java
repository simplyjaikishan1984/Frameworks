package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.sam.common.CustomAttribute;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamCustomAppsPage extends SamConfigurationPage {

	@FindBy(id = "add_more_custom_app")
	private WebElement plusAppButton;

	@FindBy(xpath = "//input[@ng-model=\"customAttributeURI.appName\"]")
	private List<WebElement> customPackages;

	@FindBy(xpath = "//input[@ng-model=\"customAttributeURI.name\"]")
	private List<WebElement> customPackageKeys;

	@FindBy(xpath = "//select[@ng-model=\"customAttributeURI.dataType\"]")
	private List<WebElement> customPackageTypes;

	@FindBy(xpath = "//input[@ng-model=\"customAttributeURI.value\"]")
	private List<WebElement> customPackageValues;

	@FindBy(xpath = "//*[@ng-click=\"removeCurrentCustomElement(configOptions.customAppConfig,$index)\"]")
	private List<WebElement> customPackageTrashButtons;

	@FindBy(xpath = "//i[@ng-click=\"enableEditFlagForAppURI($index)\"]")
	private List<WebElement> customPackageEditButtons;

	@FindBy(xpath = "//tr[@ng-repeat=\"customAttributeURI in configOptions.customAppConfig track by $index\"]")
	private List<WebElement> customPackageRows;

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	public SamCustomAppsPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public void clickAddPackageAttribute() {
		clickOnPageEntity(plusAppButton);
		sleepSeconds(1);
	}

	public boolean packageRowHasFields(WebElement row) {
		if (getChildEntity(row, By.xpath(".//input[@ng-model=\"customAttributeURI.appName\"]")) != null) {
			return true;
		}
		return false;
	}

	private void reloadCustomAttributes() {
		sleepSeconds(1);
		attributeFields.clear();
		CustomAttribute fieldSet;
		for (WebElement row : customPackageRows) {
			if (packageRowHasFields(row)) {
				fieldSet = new CustomAttribute();
				fieldSet.setPackageElementFromRow(row);
				fieldSet.setPackageKeyElementFromRow(row);
				fieldSet.setPackageDataTypeElementFromRow(row);
				fieldSet.setPackageValueElementFromRow(row);
				fieldSet.setPackageEditButtonFromRow(row);
				fieldSet.setPackageDeleteButtonFromRow(row);
				attributeFields.add(fieldSet);
			}
		}
	}

	public boolean attributeExists(String packageName, String key) {
		for (CustomAttribute attribute : attributeFields) {
			if (attribute.getKeyName() != null && attribute.getKeyName().contentEquals(key)) {
				return true;
			}
		}
		return false;
	}

	public CustomAttribute getPackageCustomAttribute(String key) {
		reloadCustomAttributes();
		for (CustomAttribute attribute : attributeFields) {
			if (attribute != null && attribute.getKeyName().contentEquals(key)) {
				return attribute;
			}
		}
		return null;
	}

	public void setPackageAttribute(String packageName, String key, String type, String value) {
		reloadCustomAttributes();
		if (attributeExists(packageName, key)) {
			CustomAttribute attribute = getPackageCustomAttribute(key);
			attribute.edit();
			attribute.updateValue(type, value);
		} else {
			if (!attributeFields.get(0).getKeyName().isEmpty()) {
				clickAddPackageAttribute();
				reloadCustomAttributes();
			}
			int lastElement = attributeFields.size() - 1;
			attributeFields.get(lastElement).enterPackage(packageName);
			attributeFields.get(lastElement).enterKey(key);
			attributeFields.get(lastElement).selectType(type);
			reloadCustomAttributes();
			attributeFields.get(lastElement).updateValue(type, value);
		}
	}

	public void deleteCustomAttribute(String packageName, String key) {
		reloadCustomAttributes();
		if (attributeExists(packageName, key)) {
			getCustomAttribute(key).delete();
		} else {
			log.error("Could not locate custom attribute {}", key);
		}
	}
}
