package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.WebBrowser;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.sam.common.Sam;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamBasePage;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamLoginPage;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamAmieAgentPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import java.net.MalformedURLException;
import java.net.URL;

import static com.spectralink.test_automation.cucumber.framework.common.Environment.SamPage.*;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamNavigationSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I log into the SAM instance at \"([^\"]*)\" with DB password \"([^\"]*)\" and account \"([^\"]*)\" and password \"([^\"]*)\"")
    public void loginWithSpecificCredentials(String samAddress, String dbPassword, String samAccount, String samPassword) throws Exception {
        Environment.setSam(new Sam(samAddress, dbPassword, samAccount, samPassword));
        WebBrowser.clearCookies();
        WebBrowser.loadUrl(new URL("https://" + samAddress + "/sam/"));
        SamLoginPage loginPage = new SamLoginPage();
        Environment.setCurrentPage(loginPage.accessSam(samAccount, samPassword));
        Environment.setCurrentPageName(DEVICE_LIST);
        sleepSeconds(2);
    }

    @When("^I log into the SAM instance at \"([^\"]*)\" with default DB password and credentials$")
    public void loginWithStandardCredentials(String samAddress) throws MalformedURLException {
        String dbPassword = RunDefaults.getStringSetting("dbPassword");
        String samAccount = RunDefaults.getStringSetting("samAccount");
        String samPassword = RunDefaults.getStringSetting("samPassword");
        Environment.setSam(new Sam(samAddress, dbPassword, samAccount, samPassword));
        WebBrowser.clearCookies();
        WebBrowser.loadUrl(new URL("https://" + samAddress + "/sam/"));
        SamLoginPage loginPage = new SamLoginPage();
        Environment.setCurrentPage(loginPage.accessSam(samAccount, samPassword));
        Environment.setCurrentPageName(DEVICE_LIST);
        sleepSeconds(2);
    }

    @When("^I log into the default SAM test instance$")
    public void loginToDefaultInstance() throws MalformedURLException {
        String samAddress = RunDefaults.getStringSetting("samAddress");
        String dbPassword = RunDefaults.getStringSetting("dbPassword");
        String samAccount = RunDefaults.getStringSetting("samAccount");
        String samPassword = RunDefaults.getStringSetting("samPassword");
        Environment.setSam(new Sam(samAddress, dbPassword, samAccount, samPassword));
        WebBrowser.loadUrl(new URL("https://" + samAddress + "/sam/"));
        SamLoginPage loginPage = new SamLoginPage();
        Environment.setCurrentPage(loginPage.accessSam(samAccount, samPassword));
        Environment.setCurrentPageName(DEVICE_LIST);
        sleepSeconds(2);
    }

    @Then("^I'm logged into SAM$")
    public void verifyLogin() {
        if (!Environment.getCurrentPageName().equals(LOGIN)) {
            SamBasePage currentPage = Environment.getCurrentPage();
            if (currentPage.getAccountName().contains(Environment.getSam().getAdminAccount())) {
                log.debug("Verified successful login to SAM instance at {}", Environment.getSam().getAddress());
            } else {
                log.error("Failed to log into SAM instance at {}", Environment.getSam().getAddress());
                Assert.fail("SAM Login Error");
            }
        } else {
            log.error("Expected not to be at the {} page", LOGIN.name());
            Assert.fail("SAM Login Error");
        }
    }

    @Then("^I'm logged out of SAM$")
    public void verifyLogout() {
        if (Environment.getCurrentPageName().equals(LOGIN)) {
            SamLoginPage currentPage = (SamLoginPage) Environment.getCurrentPage();
            if (!currentPage.onLoginPage()) {
                log.error("Failed to return to {} page after logging out", LOGIN.name());
                Assert.fail("SAM Logout Error");
            }
            log.debug("Verified log out of SAM instance");
        } else {
            log.error("Expected to be at {} page but was at the {} page instead", LOGIN.name(), Environment.getCurrentPageName().name());
            Assert.fail("SAM Logout Error");
        }
    }

    @When("^I click the Devices icon and select Device Holding Area$")
    public void selectDeviceHoldingArea() {
        Environment.setCurrentPage(Environment.getCurrentPage().goToDeviceHoldingAreaPage());
        Environment.setCurrentPageName(DEVICE_HOLDING_AREA);
    }

    @When("^I click the Devices icon and select Device List$")
    public void selectDeviceList() {
        Environment.setCurrentPage(Environment.getCurrentPage().goToDeviceListPage());
        Environment.setCurrentPageName(DEVICE_LIST);
    }

    @When("^I click the Applications icon$")
    public void clickApplicationsIcon() {
        Environment.getCurrentPage().goToApplications();
        Environment.setCurrentPage(new SamAmieAgentPage());
        Environment.setCurrentPageName(AMIE_AGENT);
    }

    @When("^I click the Groups icon$")
    public void clickGroupsIcon() {
        Environment.setCurrentPage(Environment.getCurrentPage().goToManageGroups());
        Environment.setCurrentPageName(GROUPS);
    }

    @When("^I click the Batch Configuration icon$")
    public void clickBatchConfigurationIcon() {
        Environment.setCurrentPage(Environment.getCurrentPage().goToBatchConfig());
        Environment.setCurrentPageName(BATCH_CONFIGURATION);
    }

    @When("^I click the Licenses icon$")
    public void clickLicensesIcon() {
        Environment.setCurrentPage(Environment.getCurrentPage().goToFeatureLicense());
        Environment.setCurrentPageName(LICENSES);
    }

    @When("^I click the Copy Configuration icon$")
    public void clickCopyConfigurationIcon() {
        Environment.setCurrentPage(Environment.getCurrentPage().goToCopyConfig());
        Environment.setCurrentPageName(COPY_CONFIGURATION);
    }

    @When("^I click the About Sam icon$")
    public void clickAboutSamIcon() {
        Environment.setCurrentPage(Environment.getCurrentPage().goToAboutUsPage());
        Environment.setCurrentPageName(ABOUT_SAM);
    }

    @When("^I click the Logout icon$")
    public void clickLogoutIcon() {
        Environment.setCurrentPage(Environment.getCurrentPage().clickLogOut());
        Environment.setCurrentPageName(LOGIN);
    }

    @When("^I close the browser session$")
    public void closeWindow() {
        WebBrowser.closeSession();
        Environment.setCurrentPageName(NONE);
    }

    @When("I hard refresh the default SAM instance page$")
    public void hardRefreshPage() {
        WebBrowser.refreshCurrentPage(true);
    }

    @When("I refresh the default SAM instance page$")
    public void softRefreshPage() {
        WebBrowser.refreshCurrentPage(false);
    }
}