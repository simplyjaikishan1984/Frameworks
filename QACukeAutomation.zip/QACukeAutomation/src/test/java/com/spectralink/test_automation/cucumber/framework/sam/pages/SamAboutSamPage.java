package com.spectralink.test_automation.cucumber.framework.sam.pages;

import com.spectralink.test_automation.cucumber.framework.WebBrowser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.nio.file.Path;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamAboutSamPage extends SamBasePage {

	@FindBy(xpath = "//*[@id=\"item_temSentViaCaller\"]/div[1]/h4/a/span/i")
	private WebElement softwareLicenseExpander;

	@FindBy(xpath = "//*[@id=\"item_temSentViaCaller\"]/div[2]/div/md-content")
	private WebElement softwareLicenseAgreement;

	@FindBy(id = "appVersionAboutUs")
	private WebElement appVersion;

	@FindBy(xpath = "//b[@class=\"ng-binding\"]")
	List<WebElement> dataValues;

	@FindBy(xpath = "//button[@text=\"sslCert\"]")
	private WebElement copyCertToClipboardButton;

	@FindBy(xpath = "//button[@text=\"csrFile\"]")
	private WebElement copyCsrToClipboardButton;

	@FindBy(xpath = "//button[@text=\"currentUser.accountKey\"]")
	private WebElement copyKeyToClipboardButton;

	@FindBy(id = "browse_button")
	private WebElement upgradeBrowseFileButton;

	@FindBy(id = "ad_hoc_backup_button")
	private WebElement backupNowButton;


	public SamAboutSamPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public String getBodyText() {
		return locateElement(By.tagName("body")).getText();
	}

	public void clickCopyAccountKeyToClipboard() {
		clickOnPageEntity(copyKeyToClipboardButton);
		sleepSeconds(1);
	}

	public void clickCopyCertToClipboard() {
		clickOnPageEntity(copyCertToClipboardButton);
		sleepSeconds(1);
	}

	public void clickCopyCsrToClipboard() {
		clickOnPageEntity(copyCsrToClipboardButton);
		sleepSeconds(1);
	}

	public void clickAgreementExpander() {
		clickOnPageEntity(softwareLicenseExpander);
	}

	public String getAgreement() {
		return softwareLicenseAgreement.getText();
	}

	public void uploadUpgradeFile(Path uploadFilePath) {
		clickOnPageEntity(upgradeBrowseFileButton);
		WebBrowser.selectFile(uploadFilePath.toString());
	}

	public void clickBrowseFile() {
		clickOnPageEntity(upgradeBrowseFileButton);
	}

	public void clickBackupNow() {
		clickOnPageEntity(backupNowButton);
		sleepSeconds(60);
	}

	public void chooseFile(Path uploadFilePath) {
		WebBrowser.selectFile(uploadFilePath.toString());
		sleepSeconds(14);
	}

	public String getAppVersion() {
		return appVersion.getText();
	}

	public String getAccountKey() {
		return dataValues.get(0).getText();
	}

	public String getAccountNumber() {
		return dataValues.get(1).getText();
	}

	public String getUploadMessage() {
		setTemporaryWait(10);
		waitForElementPresence(By.xpath("//*[@id=\"upload_files\"]/uib-accordion/div/div/div[1]/h4/a/span/span"));
		removeTemporaryWait();
		return driver.findElement(By.xpath("//*[@id=\"upload_files\"]/uib-accordion/div/div/div[1]/h4/a/span/span")).getText();
	}

	public String getErrorMessage() {
		waitForElementPresence(By.xpath("//*[@id=\"upload_files\"]/uib-accordion/div/div/div[1]/h4/a/span/span"));
		return driver.findElement(By.xpath("//*[@id=\"upload_files\"]/uib-accordion/div/div/div[1]/h4/a/span/span")).getText();
	}
}
