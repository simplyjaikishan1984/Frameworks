package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.RunDefaults;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamDeviceSettingsPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.DEVICE;

public class SamDeviceSettingsSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I check the \"([^\"]*)\" Device Settings field$")
	public void checkDeviceSettingsCheckbox(String arg1) {
		SamDeviceSettingsPage settingsPage = (SamDeviceSettingsPage) Environment.getCurrentPage();
		if (settingsPage.getField(arg1.trim()) != null) {
			settingsPage.getField(arg1.trim()).updateCheckbox(true);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I uncheck the \"([^\"]*)\" Device Settings field$")
	public void uncheckDeviceSettingsCheckbox(String arg1) {
		SamDeviceSettingsPage settingsPage = (SamDeviceSettingsPage) Environment.getCurrentPage();
		if (settingsPage.getField(arg1.trim()) != null) {
			settingsPage.getField(arg1.trim()).updateCheckbox(false);
		} else {
			log.error("No matching field with title '{}'", arg1);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I click the \"([^\"]*)\" radio button of the \"([^\"]*)\" Device Settings field$")
	public void activateDeviceSettingsRadio(String arg1, String arg2) {
		SamDeviceSettingsPage settingsPage = (SamDeviceSettingsPage) Environment.getCurrentPage();
		if (settingsPage.getField(arg2.trim()) != null) {
			String appendedKey = arg1.trim().toLowerCase() + arg2.trim();
			if (settingsPage.getField(appendedKey) != null) {
				settingsPage.getField(appendedKey).updateRadioButton();
			} else {
				log.error("No matching radio button value with title '{}'", arg1);
				Assert.fail("SAM Radio Button Not Found");
			}
		} else {
			log.error("No matching field with title '{}'", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@When("^I select menu option \"([^\"]*)\" from the \"([^\"]*)\" Device Settings field$")
	public void selectDeviceSettingsMenuOption(String arg1, String arg2) {
		SamDeviceSettingsPage settingsPage = (SamDeviceSettingsPage) Environment.getCurrentPage();
		if (settingsPage.getField(arg2) != null) {
			settingsPage.getField(arg2).updateMenuByLabel(arg1);
		} else {
			log.error("Field with label '{}' does not exist", arg2);
			Assert.fail("SAM Field Not Found");
		}
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the Device Settings field \"([^\"]*)\"$")
	public void verifyValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		if (phone != null) {
			String fieldKey = SamFields.getStrings(DEVICE, arg3.trim()).attribute();
			if (fieldKey != null) {
				if (!phone.getCurrentAppSettings().equals(DEVICE)) phone.loadAppPreferences(DEVICE);
				Environment.addScenarioFailure(phone.compare(fieldKey, arg2));
			} else {
				log.error("Field with label '{}' does not exist", arg3);
				Assert.fail("SAM Field Not Found");
			}
		} else {
			log.error("Phone with label '{}' does not exist", arg1);
			Assert.fail("Specified Phone Not Available");
		}
	}

	@When("^I enter \"([^\"]*)\" into the \"([^\"]*)\" Device Settings field$")
	public void enterFieldValue(String arg1, String arg2) {
		SamDeviceSettingsPage settingsPage = (SamDeviceSettingsPage) Environment.getCurrentPage();
		settingsPage.getField(arg2).updateTextbox(arg1);
	}

	@Then("^\"([^\"]*)\" should have the value \"([^\"]*)\" in the Device Settings custom attribute \"([^\"]*)\" setting$")
	public void checkDeviceSettingsCustomAttributeSetting(String arg1, String arg2, String arg3) {
		if (RunDefaults.getBooleanSetting("includeCustomAttributes")) {
			VersityPhone phone = Environment.getPhone(arg1.trim());
			if (phone != null) {
				if (!phone.getCurrentAppSettings().equals(DEVICE)) phone.loadAppPreferences(DEVICE);
				Environment.addScenarioFailure(phone.compare(arg3.trim(), arg2));
			} else {
				log.error("Phone with label '{}' does not exist", arg1);
				Assert.fail("Specified Phone Not Available");
			}
		} else {
			log.debug("Skipped checking attribute '{}' since custom attribute testing is turned off", arg3);
		}
	}

	@Then("^the Device Settings custom attribute page value for \"([^\"]*)\" should be \"([^\"]*)\"$")
	public void verifyCustomAttributeValue(String arg1, String arg2) {
		SamDeviceSettingsPage settingsPage = (SamDeviceSettingsPage) Environment.getCurrentPage();
		Environment.addScenarioFailure(settingsPage.getCustomAttribute(arg1.trim()).compareState(arg2.trim()));
	}

	@When("^I delete the \"([^\"]*)\" Device Settings field$")
	public void deleteDeviceSettings(String arg1) {
		SamDeviceSettingsPage settingsPage = (SamDeviceSettingsPage) Environment.getCurrentPage();
		settingsPage.getField(arg1).delete();
	}

	@Then("^the Device Settings page value for \"([^\"]*)\" should be \"([^\"]*)\"")
	public void verifyDeviceSettingsPageValue(String arg1, String arg2) {
		SamDeviceSettingsPage settingsPage = (SamDeviceSettingsPage) Environment.getCurrentPage();
		if (settingsPage.getField(arg1.trim()) != null) {
			if (arg2.trim().contentEquals("true") || arg2.trim().contentEquals("false")) {
				Environment.addScenarioFailure(settingsPage.getField(arg1.trim()).compareState(Boolean.valueOf(arg2.trim())));
			} else {
				Environment.addScenarioFailure(settingsPage.getField(arg1.trim()).compareState(arg2.trim()));
			}
		} else {
			log.error("Field with label '{}' does not exist", arg2);
		}
	}
}