package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BattLifeStrings.*;

public class BattLifeUi extends AppiumUi {

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    public ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            overflowButton,
            overflowButton,
            null
    );

    @AndroidFindBy(accessibility = "Hour label title")
    private WebElement hourChargeLeftLabel;

    @AndroidFindBy(accessibility = "Hour value title")
    private WebElement hourChargeLeftValue;

    public ConfigUiField hourChargeLeftField = new ConfigUiField(
            driver,
            CHARGE_HOURS_LEFT,
            hourChargeLeftLabel,
            null,
            hourChargeLeftValue
    );

    @AndroidFindBy(accessibility = "Minute label title")
    private WebElement minuteChargeLeftLabel;

    @AndroidFindBy(accessibility = "Minute value title")
    private WebElement minuteChargeLeftValue;

    public ConfigUiField minuteChargeLeftField = new ConfigUiField(
            driver,
            CHARGE_MINUTES_LEFT,
            minuteChargeLeftLabel,
            null,
            minuteChargeLeftValue
    );

    @AndroidFindBy(accessibility = "Time left to charge title")
    private WebElement chargeTimeLeftLabel;

    public ConfigUiField chargeTimeLeftField = new ConfigUiField(
            driver,
            CHARGE_TIME_LEFT,
            chargeTimeLeftLabel,
            null,
            null
    );

    @AndroidFindBy(accessibility = "Battery connector")
    private WebElement connectorImage;

    public ConfigUiField connectorImageField = new ConfigUiField(
            driver,
            USB_CONNECTOR,
            connectorImage,
            null,
            connectorImage
    );

    @AndroidFindBy(accessibility = "Primary battery title")
    private WebElement batteryChargeValue;

    public ConfigUiField batteryChargeField = new ConfigUiField(
            driver,
            BATTERY_CHARGE,
            null,
            null,
            batteryChargeValue
    );

    @AndroidFindBy(accessibility = "Battery serial title")
    private WebElement batterySerialLabel;

    @AndroidFindBy(accessibility = "Battery serial summary")
    private WebElement batterySerialValue;

    public ConfigUiField batterySerialField = new ConfigUiField(
            driver,
            BATTERY_SERIAL,
            batterySerialLabel,
            null,
            batterySerialValue
    );

    @AndroidFindBy(accessibility = "Battery capacity title")
    private WebElement batteryCapacityLabel;

    @AndroidFindBy(accessibility = "Battery capacity summary")
    private WebElement batteryCapacityValue;

    public ConfigUiField batteryCapacityField = new ConfigUiField(
            driver,
            BATTERY_CAPACITY,
            batteryCapacityLabel,
            null,
            batteryCapacityValue
    );

    @AndroidFindBy(accessibility = "Secondary battery title")
    private WebElement secondaryBatteryLabel;

    @AndroidFindBy(accessibility = "Secondary battery summary")
    private WebElement secondaryBatteryValue;

    public ConfigUiField secondaryBatteryField = new ConfigUiField(
            driver,
            SECONDARY_BATTERY_CHARGE,
            secondaryBatteryLabel,
            null,
            secondaryBatteryValue
    );

    @AndroidFindBy(accessibility = "Battery temperature title")
    private WebElement temperatureLabel;

    @AndroidFindBy(accessibility = "Battery temperature summary")
    private WebElement temperatureValue;

    public ConfigUiField temperatureField = new ConfigUiField(
            driver,
            BATTERY_TEMPERATURE,
            temperatureLabel,
            null,
            temperatureValue
    );

    @AndroidFindBy(accessibility = "Battery health title")
    private WebElement healthLabel;

    @AndroidFindBy(accessibility = "Battery health summary")
    private WebElement healthValue;

    public ConfigUiField healthField = new ConfigUiField(
            driver,
            BATTERY_HEALTH,
            healthLabel,
            null,
            healthValue
    );

    @AndroidFindBy(accessibility = "Battery status title")
    private WebElement statusLabel;

    @AndroidFindBy(accessibility = "Battery status summary")
    private WebElement statusValue;

    public ConfigUiField statusField = new ConfigUiField(
            driver,
            BATTERY_STATUS,
            statusLabel,
            null,
            statusValue
    );

    @AndroidFindBy(accessibility = "Battery voltage title")
    private WebElement voltageLabel;

    @AndroidFindBy(accessibility = "Battery voltage summary")
    private WebElement voltageValue;

    public ConfigUiField voltageField = new ConfigUiField(
            driver,
            BATTERY_VOLTAGE,
            voltageLabel,
            null,
            voltageValue
    );

    @AndroidFindBy(accessibility = "Battery technology title")
    private WebElement batteryTypeLabel;

    @AndroidFindBy(accessibility = "Battery technology summary")
    private WebElement batteryTypeValue;

    public ConfigUiField batteryTypeField = new ConfigUiField(
            driver,
            BATTERY_TYPE,
            batteryTypeLabel,
            null,
            batteryTypeValue
    );

    @AndroidFindBy(accessibility = "Battery charge cycle title")
    private WebElement chargeCycleLabel;

    @AndroidFindBy(accessibility = "Battery charge cycle summary")
    private WebElement chargeCycleValue;

    public ConfigUiField chargeCycleField = new ConfigUiField(
            driver,
            BATTERY_CHARGE_CYCLE,
            chargeCycleLabel,
            null,
            chargeCycleValue
    );

    @AndroidFindBy(accessibility = "Open additional metrics and options title")
    private WebElement additionalMetricsButton;

    public ConfigUiField additionalMetricsField = new ConfigUiField(
            driver,
            ADDITIONAL_OPTIONS,
            additionalMetricsButton,
            additionalMetricsButton,
            null
    );

    @AndroidFindBy(accessibility = "Navigate up")
    private WebElement backButton;

    public ConfigUiField backButtonField = new ConfigUiField(
            driver,
            BACK_ARROW,
            null,
            backButton,
            null
    );

    @AndroidFindBy(accessibility = "Alarm volume title")
    private WebElement alarmVolumeLabel;

    @AndroidFindBy(accessibility = "Alarm volume seekbar")
    private WebElement alarmVolumeControl;

    public ConfigUiField alarmVolumeField = new ConfigUiField(
            driver,
            ALARM_VOLUME,
            alarmVolumeLabel,
            alarmVolumeControl,
            alarmVolumeControl
    );

    @AndroidFindBy(accessibility = "Enable battery monitoring title")
    private WebElement enableBatteryMonitoringLabel;

    @AndroidFindBy(accessibility = "Enable battery monitoring switch")
    private WebElement enableBatteryMonitoringControl;

    @AndroidFindBy(accessibility = "Enable battery monitoring summary")
    private WebElement enableBatteryMonitoringValue;

    public ConfigUiField enableBatteryMonitoringField = new ConfigUiField(
            driver,
            ENABLE_BATTERY_MONITORING,
            enableBatteryMonitoringLabel,
            enableBatteryMonitoringControl,
            enableBatteryMonitoringValue
    );

    @AndroidFindBy(accessibility = "Vibrate title")
    private WebElement vibrateLabel;

    @AndroidFindBy(accessibility = "Vibrate switch")
    private WebElement vibrateControl;

    @AndroidFindBy(accessibility = "Vibrate summary")
    private WebElement vibrateValue;

    public ConfigUiField vibrateField = new ConfigUiField(
            driver,
            VIBRATE_WARNING,
            vibrateLabel,
            vibrateControl,
            vibrateValue
    );

    @AndroidFindBy(accessibility = "Sound title")
    private WebElement soundLabel;

    @AndroidFindBy(accessibility = "Sound switch")
    private WebElement soundControl;

    @AndroidFindBy(accessibility = "Sound summary")
    private WebElement soundValue;

    public ConfigUiField soundField = new ConfigUiField(
            driver,
            SOUND_WARNING,
            soundLabel,
            soundControl,
            soundValue
    );

    @AndroidFindBy(accessibility = "Alarm tone title")
    private WebElement alarmToneLabel;

    @AndroidFindBy(accessibility = "Alarm tone title")
    private WebElement alarmToneControl;

    @AndroidFindBy(accessibility = "Alarm tone summary")
    private WebElement alarmToneValue;

    public ConfigUiField alarmToneField = new ConfigUiField(
            driver,
            LOW_ALARM_TONE,
            alarmToneLabel,
            alarmToneControl,
            alarmToneValue
    );

    @AndroidFindBy(accessibility = "Low battery threshold title")
    private WebElement lowBatteryThresholdLabel;

    @AndroidFindBy(accessibility = "Low battery threshold title")
    private WebElement lowBatteryThresholdControl;

    @AndroidFindBy(accessibility = "Low battery threshold summary")
    private WebElement lowBatteryThresholdValue;

    public ConfigUiField lowBatteryThresholdField = new ConfigUiField(
            driver,
            LOW_THRESHOLD_LEVEL,
            lowBatteryThresholdLabel,
            lowBatteryThresholdControl,
            lowBatteryThresholdValue
    );

    @AndroidFindBy(accessibility = "Snooze time title")
    private WebElement snoozeTimeLabel;

    @AndroidFindBy(accessibility = "Snooze time title")
    private WebElement snoozeTimeControl;

    @AndroidFindBy(accessibility = "Snooze time summary")
    private WebElement snoozeTimeValue;

    public ConfigUiField snoozeTimeField = new ConfigUiField(
            driver,
            LOW_WARNING_SNOOZE_TIME,
            snoozeTimeLabel,
            snoozeTimeControl,
            snoozeTimeValue
    );

    @AndroidFindBy(accessibility = "Swipe to snooze message")
    private WebElement alarmSnoozeLabel;

    @AndroidFindBy(accessibility = "Snooze arrow image")
    private WebElement alarmSnoozeIcon;

    @AndroidFindBy(accessibility = "Primary battery title")
    private WebElement alarmSnoozeValue;

    public ConfigUiField alarmSnoozeField = new ConfigUiField(
            driver,
            WARNING_SNOOZE_MESSAGE,
            alarmSnoozeLabel,
            alarmSnoozeIcon,
            alarmSnoozeValue
    );

    public BattLifeUi (AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(OVERFLOW_MENU.title().toLowerCase(), overflowButtonField);
                put(CHARGE_HOURS_LEFT.title().toLowerCase(), hourChargeLeftField);
                put(CHARGE_MINUTES_LEFT.title().toLowerCase(), minuteChargeLeftField);
                put(CHARGE_TIME_LEFT.title().toLowerCase(), chargeTimeLeftField);
                put(USB_CONNECTOR.title().toLowerCase(), connectorImageField);
                put(BATTERY_CHARGE.title().toLowerCase(), batteryChargeField);
                put(BATTERY_SERIAL.title().toLowerCase(), batterySerialField);
                put(BATTERY_CAPACITY.title().toLowerCase(), batteryCapacityField);
                put(SECONDARY_BATTERY_CHARGE.title().toLowerCase(), secondaryBatteryField);
                put(BATTERY_TEMPERATURE.title().toLowerCase(), temperatureField);
                put(BATTERY_HEALTH.title().toLowerCase(), healthField);
                put(BATTERY_STATUS.title().toLowerCase(), statusField);
                put(BATTERY_VOLTAGE.title().toLowerCase(), voltageField);
                put(BATTERY_TYPE.title().toLowerCase(), batteryTypeField);
                put(BATTERY_CHARGE_CYCLE.title().toLowerCase(), chargeCycleField);
                put(ADDITIONAL_OPTIONS.title().toLowerCase(), additionalMetricsField);
                put(BACK_ARROW.title().toLowerCase(), backButtonField);
                put(ALARM_VOLUME.title().toLowerCase(), alarmVolumeField);
                put(ENABLE_BATTERY_MONITORING.title().toLowerCase(), enableBatteryMonitoringField);
                put(VIBRATE_WARNING.title().toLowerCase(), vibrateField);
                put(SOUND_WARNING.title().toLowerCase(), soundField);
                put(LOW_ALARM_TONE.title().toLowerCase(), alarmToneField);
                put(LOW_THRESHOLD_LEVEL.title().toLowerCase(), lowBatteryThresholdField);
                put(LOW_WARNING_SNOOZE_TIME.title().toLowerCase(), snoozeTimeField);
                put(WARNING_SNOOZE_MESSAGE.title().toLowerCase(), alarmSnoozeField);
            }
        };
    }

    public void clickOverflowMenu() {
        clickOnPageEntity(overflowButton);
        Util.sleepSeconds(1);
    }

    public void navigateToMainScreen() {
        backButton.click();
    }

    public void dismissApp() {
        backButton.click();
    }

    public void enableBatteryMonitoring(boolean isMonitoringEnabled) {

        String enableVibrate = enableBatteryMonitoringControl.getAttribute("checked");
        if (enableVibrate.equals("false") && (isMonitoringEnabled))
            enableBatteryMonitoringControl.click();
        else if (enableVibrate.equals("true") && (!isMonitoringEnabled))
            enableBatteryMonitoringControl.click();
    }

}
