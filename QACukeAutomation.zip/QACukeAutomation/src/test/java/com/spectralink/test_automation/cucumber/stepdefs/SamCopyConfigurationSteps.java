package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamCopyConfigPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;

public class SamCopyConfigurationSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I click the Copy Configuration Source Device 'Select Device' button$")
    public void clickSourceDeviceButton() {
        SamCopyConfigPage copyPage = (SamCopyConfigPage) Environment.getCurrentPage();
        copyPage.clickSourceDeviceButton();
    }

    @When("^I click the Copy Configuration Target Device 'Select Device' button$")
    public void clickTargetDeviceButton() {
        SamCopyConfigPage copyPage = (SamCopyConfigPage) Environment.getCurrentPage();
        copyPage.clickTargetDeviceButton();
    }

    @When("^from the Copy Configuration Select Device dialog box I select \"([^\"]*)\"$")
    public void selectSourceDevice(String arg1) {
        SamCopyConfigPage copyPage = (SamCopyConfigPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        copyPage.selectSourceDevice(phone.getSerialNumber());
    }

    @When("^from the Copy Configuration Select Device dialog box I click the 'SELECT DEVICE' button$")
    public void clickSelectDeviceButton() {
        SamCopyConfigPage copyPage = (SamCopyConfigPage) Environment.getCurrentPage();
        copyPage.clickSelectDeviceDialogButton();
    }

    @When("^I click the 'COPY CONFIG' button$")
    public void clickCopyConfigButton() {
        SamCopyConfigPage copyPage = (SamCopyConfigPage) Environment.getCurrentPage();
        copyPage.clickCopyConfigButton();
    }

    @When("^I enter the MAC address of device \"([^\"]*)\" into the Target Device MAC address field$")
    public void enterFieldValue(String arg1) {
        SamCopyConfigPage copyPage = (SamCopyConfigPage) Environment.getCurrentPage();
        VersityPhone phone = Environment.getPhone(arg1.trim());
        copyPage.enterTargetMacAddress(phone.getMacAddress());
    }

    @When("^from the Category menu I select \"([^\"]*)\"$")
    public void selectCategory(String arg1) {
        SamCopyConfigPage copyPage = (SamCopyConfigPage) Environment.getCurrentPage();
        SamCopyConfigPage.CategoryMenu selection = copyPage.getCategoryOption(arg1);
        if (selection != null) {
            copyPage.selectCategory(selection);
        } else {
            log.error("Cannot select '{}' from Category menu", arg1);
            Assert.fail("SAM UI Interaction Error");
        }
    }

    @When("^I enter \"([^\"]*)\" into the Reason field$")
    public void enterReason(String arg1) {
        SamCopyConfigPage copyPage = (SamCopyConfigPage) Environment.getCurrentPage();
        copyPage.enterReason(arg1.trim());
    }

    @Then("^the last SAM database entry for the Category field should be \"([^\"]*)\"$")
    public void verifyCategory(String arg1) {
        String category = Environment.getSam().keyDatabase().getLastCopyConfigCategory();
        if (category.contentEquals(arg1.trim())) {
            log.debug("Recorded category matched selected category");
        } else {
            log.fatal("Recorded category '{}' did not match selected category '{}'", category, arg1);
            Environment.addScenarioFailure(1);
        }
    }

    @Then("^the last SAM database entry for the Reason field should be \"([^\"]*)\"$")
    public void verifyReason(String arg1) {
        String reason = Environment.getSam().keyDatabase().getLastCopyConfigReason();
        if (reason.contentEquals(arg1.trim())) {
            log.debug("Recorded reason matched entered reason");
        } else {
            log.fatal("Recorded reason '{}' did not match selected reason '{}'", reason, arg1);
            Environment.addScenarioFailure(1);
        }
    }
}