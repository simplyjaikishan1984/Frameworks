package com.spectralink.test_automation.cucumber.framework.device.common;

import com.spectralink.test_automation.cucumber.framework.common.CliResult;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

public class PttContentProvider {

    private final VersityPhone phone;
    private Map<String, Object> details;
    private String uri;
    private List<Map<String, Object>> pttState;
    private final Logger log = LogManager.getLogger(this.getClass().getName());

    public PttContentProvider(VersityPhone phone) {
        this.phone = phone;
        this.uri = "content://com.spectralink.slnkptt.provider/session";
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public void loadContent(String uri) {
        setUri(uri);
        parseContent();
    }

    public void reloadContent() {
        parseContent();
    }

    private String runCommand() {
        List<String> command = new ArrayList<>(Arrays.asList("shell", "content", "query", "--uri", uri));
        CliResult results = phone.sendAdbCommand(command);
        if (results.commandSucceeded()) {
            return results.getStdout();
        } else {
            log.error("Abd command failed with error code {}: {}", results.getExitCode(), results.getStdout());
            return null;
        }
    }

    private void parseContent() {
        details = new HashMap<>();
        String output = runCommand();
        if (output != null) {
            log.trace(output);
            Scanner scanner = new Scanner(output);
            String blankCheck = scanner.findInLine("audiostats=,");
            if (blankCheck == null) blankCheck = scanner.findInLine("audiostats=NULL");
            if (blankCheck == null) {
                scanner.findInLine("AP (\\S+)\\s+\\(\\-(\\d+)\\s+dBm\\)");
                details.put("ap", scanner.match().group(1));
                details.put("dBm", -Integer.valueOf(scanner.match().group(2)));
                scanner.findInLine("Pld size (\\d+)ms");
                details.put("pld", Integer.valueOf(scanner.match().group(1)));
                scanner.findInLine("Tx (\\d+) Rx (\\d+)");
                details.put("tx", Integer.valueOf(scanner.match().group(1)));
                details.put("rx", Integer.valueOf(scanner.match().group(2)));
                scanner.findInLine("Missed (\\d+) \\(([0-9\\.]+)%\\)");
                details.put("missed", Integer.valueOf(scanner.match().group(1)));
                details.put("missedPercent", Float.valueOf(scanner.match().group(2)));
                scanner.findInLine("Dropped (\\d+) \\(([0-9\\.]+)%\\)");
                details.put("dropped", Integer.valueOf(scanner.match().group(1)));
                details.put("droppedPercent", Float.valueOf(scanner.match().group(2)));
                scanner.findInLine("Channel (\\d+)");
                details.put("channel", Integer.valueOf(scanner.match().group(1)));
            } else {
                details.put("ap", null);
                details.put("dBm", 0);
                details.put("pld", 0);
                details.put("tx", 0);
                details.put("rx", 0);
                details.put("missed", 0);
                details.put("missedPercent", Float.valueOf(0));
                details.put("dropped", 0);
                details.put("droppedPercent", Float.valueOf(0));
                details.put("channel", 0);
            }
            scanner.findInLine("localId=([^,]+)");
            details.put("localId", scanner.match().group(1));
            scanner.findInLine("serialno=([^,]+)");
            details.put("serialno", scanner.match().group(1));
            scanner.findInLine("focusChannel=([^,]+)");
            details.put("focusChannel", Integer.valueOf(scanner.match().group(1)));
            scanner.findInLine("channelState=([^,]+)");
            details.put("channelState", scanner.match().group(1));
            scanner.findInLine("farId=([^,]*)");
            details.put("farId", scanner.match().group(1));
            scanner.findInLine("farSerialno=(\\S+)");
            details.put("farSerialno", scanner.match().group(1));
        }
    }

    public Map<String, Object> getContent(String uri) {
        setUri(uri);
        return getContent();
    }

    public Map<String, Object> getContent() {
        parseContent();
        return details;
    }

    public Map<String, Object> getLoadedContent() {
        return details;
    }

    private void guaranteeContent() {
        if (details == null) parseContent();
    }

    public String getAccessPoint() {
        guaranteeContent();
        return (String) details.get("ap");
    }

    public Integer getAccessPointDbm() {
        guaranteeContent();
        return (Integer) details.get("dBm");
    }

    public Integer getAccessPointDbm(Map<String, Object> content) {
        return (Integer) content.get("dBm");
    }

    public Integer getPayloadSize() {
        guaranteeContent();
        return (Integer) details.get("pld");
    }

    public Integer getPayloadSize(Map<String, Object> content) {
        return (Integer) content.get("pld");
    }

    public Integer getTransmittedPacketCount() {
        guaranteeContent();
        return (Integer) details.get("tx");
    }

    public Integer getTransmittedPacketCount(Map<String, Object> content) {
        return (Integer) content.get("tx");
    }

    public Integer getReceivedPacketCount() {
        guaranteeContent();
        return (Integer) details.get("rx");
    }

    public Integer getReceivedPacketCount(Map<String, Object> content) {
        return (Integer) content.get("rx");
    }

    public Integer getMissedPacketCount() {
        guaranteeContent();
        return (Integer) details.get("missed");
    }

    public Integer getMissedPacketCount(Map<String, Object> content) {
        return (Integer) content.get("missed");
    }

    public Float getMissedPacketPercent() {
        guaranteeContent();
        return (Float) details.get("missedPercent");
    }

    public Float getMissedPacketPercent(Map<String, Object> content) {
        return (Float) content.get("missedPercent");
    }

    public Integer getDroppedPacketCount() {
        guaranteeContent();
        return (Integer) details.get("dropped");
    }

    public Integer getDroppedPacketCount(Map<String, Object> content) {
        return (Integer) content.get("dropped");
    }

    public Float getDroppedPacketPercent() {
        guaranteeContent();
        return (Float) details.get("droppedPercent");
    }

    public Float getDroppedPacketPercent(Map<String, Object> content) {
        return (Float) content.get("droppedPercent");
    }

    public Integer getTransmitChannel() {
        guaranteeContent();
        return (Integer) details.get("channel");
    }

    public Integer getTransmitChannel(Map<String, Object> content) {
        return (Integer) content.get("channel");
    }

    public String getLocalUserName() {
        guaranteeContent();
        return (String) details.get("localId");
    }

    public String getLocalUserName(Map<String, Object> content) {
        return (String) content.get("localId");
    }

    public String getLocalSerialNumber() {
        guaranteeContent();
        return (String) details.get("serialno");
    }

    public String getLocalSerialNumber(Map<String, Object> content) {
        return (String) content.get("serialno");
    }

    public Integer getFocusChannel() {
        guaranteeContent();
        return (Integer) details.get("focusChannel");
    }

    public Integer getFocusChannel(Map<String, Object> content) {
        return (Integer) content.get("focusChannel");
    }

    public String getChannelState() {
        guaranteeContent();
        return (String) details.get("channelState");
    }

    public String getChannelState(Map<String, Object> content) {
        return (String) content.get("channelState");
    }

    public String getRemoteUserName() {
        guaranteeContent();
        return (String) details.get("farId");
    }

    public String getRemoteUserName(Map<String, Object> content) {
        return (String) content.get("farId");
    }

    public String getRemoteSerialNumber() {
        guaranteeContent();
        return (String) details.get("farSerialno");
    }

    public String getRemoteSerialNumber(Map<String, Object> content) {
        return (String) content.get("farSerialno");
    }

    public boolean isTransmitting() {
        guaranteeContent();
        String channelState = details.get("channelState").toString();
        return channelState.contentEquals("PTT_CHAN_STATE_ALERT") ||
                channelState.contentEquals("PTT_CHAN_STATE_TRANSMIT") ||
                channelState.contentEquals("PTT_CHAN_STATE_EOT");
    }

    public boolean isReceiving() {
        guaranteeContent();
        String channelState = details.get("channelState").toString();
        return channelState.contentEquals("PTT_CHAN_STATE_RECEIVE") ||
                channelState.contentEquals("PTT_CHAN_STATE_RXPLAYOUT");
    }

    public boolean isIdle() {
        guaranteeContent();
        String channelState = details.get("channelState").toString();
        return channelState.contentEquals("PTT_CHAN_STATE_IDLE");
    }

    public boolean isWaiting() {
        guaranteeContent();
        String channelState = details.get("channelState").toString();
        return channelState.contentEquals("PTT_CHAN_STATE_WAITING");
    }

    public boolean areStatesRecorded() {
        return pttState != null && pttState.size() > 0;
    }

    public List<Map<String, Object>> recordStates(Thread thread) {
        pttState = new ArrayList<>();
        while(thread.isAlive()) {
            pttState.add(getContent());
        }
        return pttState;
    }

    public List<String> getStatChanges(String column) {
        List<String> statEntries = new ArrayList<>();
        for (Map<String, Object> attributes : pttState) {
            if (attributes.containsKey(column)) {
                statEntries.add(attributes.get(column).toString());
            }
        }
        return statEntries;
    }

    public Map<String, Object> getLastActivity() {
        Map<String, Object> lastActivity = new HashMap<>();
        for (Map<String, Object> attributes : pttState) {
            String activity = attributes.get("channelState").toString();
            if (activity.contentEquals("PTT_CHAN_STATE_TRANSMIT") || activity.contentEquals("PTT_CHAN_STATE_RECEIVE")) {
                lastActivity = attributes;
                break;
            }
        }
        return lastActivity;
    }
}
