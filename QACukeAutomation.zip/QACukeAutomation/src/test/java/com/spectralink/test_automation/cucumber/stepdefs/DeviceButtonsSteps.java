package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.*;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.ButtonsUi;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Activity.LAUNCHER;
import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.*;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class DeviceButtonsSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I select \"([^\"]*)\" from the Buttons menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectThresholdButtonsMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        ConfigUiField field = buttonsUi.getField(arg2.trim());
        FieldData heading = DeviceFields.getStrings(AndroidPhone.Application.BUTTONS, arg2.trim());
        if(arg1.trim().equals("Scanner/No action") || arg1.trim().equals("No action/Scanner")) {
            if(phone.hasBarcodeScanner())
                arg1 = "Scanner";
            else
                arg1 = "No action";
        }
        if (field != null) {
            field.scrollIntoView(heading);
            boolean found;
            if (field.isValueAccessible()) {
                if (!field.getValueElement().getText().equals(arg1.trim())) {
                    field.tap();
                    if(arg1.equals(arg2))
                        found = field.selectSameCheckedMenuOptionAsButtonItself(arg1.trim());
                    else
                        found = field.selectCheckedMenuOptionForButtons(arg1.trim());
                    if (found) {
                        log.debug("Selected menu option '{}'", arg1);
                        sleepSeconds(1);
                    } else {
                        log.error("Could not find menu option '{}'", arg1);
                    }
                } else {
                    log.debug("Field '{}' was already set to '{}'", arg2, arg1);
                }
            } else {
                log.error("No matching field with title '{}'", arg2.trim());
            }
        }
        else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I select \"([^\"]*)\" app from the Buttons menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectRunApp(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        ConfigUiField field = buttonsUi.getField(arg2.trim());
        FieldData heading = DeviceFields.getStrings(AndroidPhone.Application.BUTTONS, arg2.trim());
        if (field != null) {
            field.scrollIntoView(heading);
            boolean found;
            if (field.isValueAccessible()) {
                if (!field.getValueElement().getText().equals(arg1.trim())) {
                    field.tap();
                    field.selectCheckedMenuOptionForButtons("Run application");
                    sleepSeconds(1);
                    found = field.selectApplication(arg1);
                    if (found) {
                        log.debug("Selected app '{}'", arg1);
                        sleepSeconds(1);
                    } else {
                        log.error("Could not find app '{}'", arg1);
                    }
                } else {
                    log.debug("Field '{}' was already set to '{}'", arg2, arg1);
                }
            } else {
                log.error("No matching field with title '{}'", arg2.trim());
            }
        }
        else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Buttons \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyButtonsValue(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        ConfigUiField field = buttonsUi.getField(arg1.trim());
        FieldData heading = DeviceFields.getStrings(AndroidPhone.Application.BUTTONS, arg1.trim());

        if(arg2.trim().equals("Scanner/No action") || arg2.trim().equals("No action/Scanner")) {
            if(phone.hasBarcodeScanner())
                arg2 = "Scanner";
            else
                arg2 = "No action";
        }

        if (field.hasLabelElement()) field.scrollIntoView(heading);
        if (field.isValueAccessible()) {
            String fieldValue = field.getValueElement().getText();
            if (fieldValue.equals(arg2.trim())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on device {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT Buttons FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I tap \"([^\"]*)\" button once on \"([^\"]*)\"$")
    public void tapButtonOnce(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        switch (arg1.trim()) {
            case "Left button":
                phone.tapButton("900");
                break;
            case "Right button":
                phone.tapButton("901");
                break;
            case "Top":
                phone.tapButton("902");
                break;
            case "Fingerprint":
                phone.tapButton("903");
                break;
            case "Volume up":
                phone.tapButton("24");
                break;
            case "Volume down":
                phone.tapButton("25");
                break;
        }
        log.debug("'{}' button pressed once", arg1);
    }

    @When("^I tap \"([^\"]*)\" button twice on \"([^\"]*)\"$")
    public void tapButtonTwice(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        switch (arg1.trim()) {
            case "Left button":
                phone.tapButton("900");
                phone.tapButton("900");
                break;
            case "Right button":
                phone.tapButton("901");
                phone.tapButton("901");
                break;
            case "Top":
                phone.tapButton("902");
                phone.tapButton("902");
                break;
            case "Fingerprint":
                phone.tapButton("903");
                phone.tapButton("903");
                break;
            case "Volume up":
                phone.tapButton("24");
                phone.tapButton("24");
                break;
            case "Volume down":
                phone.tapButton("25");
                phone.tapButton("25");
                break;
        }
        log.debug("'{}' button pressed twice", arg1);
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as a home key on \"([^\"]*)\"$")
    public void homeKey(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        tapButtonOnce(arg1, arg2);
        if (phone.getForegroundActivity().equals(LAUNCHER.getIntent())) {
            log.debug("'{}' works as a Home key", arg1);
        } else {
            log.error("'{}' does not work as a Home key", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as a back key on \"([^\"]*)\"$")
    public void backKey(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.bringAppToForeground(SETTINGS);
        sleepSeconds(2);
        if(phone.getModel().toLowerCase().contains("saturn"))
            phone.bringAppToForeground(SATURN_BUTTONS);
        else
            phone.bringAppToForeground(BUTTONS);
        sleepSeconds(2);
        tapButtonOnce(arg1, arg2);
        if (phone.getForegroundActivity().equals(".Settings")) {
            log.debug("'{}' works as a Back key", arg1);
        } else {
            log.error("'{}' does not work as a Back key", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as a menu key on \"([^\"]*)\"$")
    public void menuKey(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        tapButtonOnce(arg1, arg2);
        if (isAboutMenuItemAvailable(arg2)) {
            log.debug("'{}' works as a Menu key", arg1);
        } else {
            log.error("'{}' does not work as a Menu key", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as ptt button on \"([^\"]*)\"$")
    public void ptt(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        tapButtonOnce(arg1, arg2);
        if (phone.getForegroundActivity().endsWith(".activities.PTTActivity")) {
            log.debug("'{}' works as a Ptt button", arg1);
        } else {
            log.error("'{}' does not work as a Ptt button", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to open Url \"([^\"]*)\" on \"([^\"]*)\"$")
    public void openUrl(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        tapButtonOnce(arg1, arg3);

        try {
            phone.appium().findElementById("com.android.chrome:id/terms_accept").click();
            log.debug("Accept & continue button pressed");
        }
        catch (Exception exception) {
            log.debug("Accept & continue button not present");
        }

        try {
            phone.appium().findElementById("com.android.chrome:id/negative_button").click();
            log.debug("No thanks button pressed");
        }
        catch (Exception exception) {
            log.debug("No thanks button not present");
        }

        String urlInBrowser = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
        if (arg2.trim().contains(urlInBrowser.trim()))
            log.debug("'{}' page was opened on '{}'", arg2, arg3);
        else {
            log.error("Could not route to '{}' on '{}'", arg2, arg3);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @When("^I select to open the Url \"([^\"]*)\" from the Buttons menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectUrl(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        ConfigUiField field = buttonsUi.getField(arg2.trim());
        FieldData heading = DeviceFields.getStrings(AndroidPhone.Application.BUTTONS, arg2.trim());
        if (field != null) {
            field.scrollIntoView(heading);
            if (field.isValueAccessible()) {
                if (!field.getValueElement().getText().equals(arg1.trim())) {
                    field.tap();
                    field.selectCheckedMenuOptionForButtons("Open URL");
                    sleepSeconds(1);
                    WebElement editText = phone.appium().findElementByClassName("android.widget.EditText");
                    field.typeIntoPageEntity(editText, arg1);
                    phone.appium().findElementById("android:id/button1").click();
                } else {
                    log.debug("Field '{}' was already set to '{}'", arg2, arg1);
                }
            } else {
                log.error("No matching field with title '{}'", arg2.trim());
            }
        }
        else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as panic button on \"([^\"]*)\"$")
    public void panic(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        tapButtonOnce(arg1, arg2);
        if (buttonsUi.getToastText().equalsIgnoreCase("Long press to trigger panic alarm")) {
            log.debug("'{}' works as a Panic button", arg1);
        } else {
            log.error("'{}' does not work as a Panic button", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as volume up button on \"([^\"]*)\"$")
    public void volUp(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        int ringCurrentVolumeLevel = Integer.parseInt(phone.getMediaVolume());
        tapButtonTwice(arg1, arg2);
        sleepSeconds(5);
        if(ringCurrentVolumeLevel!= 10) {
            int ringModifiedVolumeLevel = Integer.parseInt(phone.getMediaVolume());
            if (ringModifiedVolumeLevel - ringCurrentVolumeLevel == 1) {
                log.debug("'{}' works as a Volume up button", arg1);
            } else {
                log.error("'{}' does not work as a Volume up button", arg1);
                Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
            }
        }
        else
            log.debug("Volume already Maximum");
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as volume down button on \"([^\"]*)\"$")
    public void volDown(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        int ringCurrentVolumeLevel = Integer.parseInt(phone.getMediaVolume());
        tapButtonTwice(arg1, arg2);
        sleepSeconds(5);
        if(ringCurrentVolumeLevel!= 0) {
            int ringModifiedVolumeLevel = Integer.parseInt(phone.getMediaVolume());
            if (ringCurrentVolumeLevel - ringModifiedVolumeLevel == 1) {
                log.debug("'{}' works as a Volume down button", arg1);
            } else {
                log.error("'{}' does not work as a Volume down button", arg1);
                Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
            }
        }
        else
            log.debug("Volume already Minimum");
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as Scanner on \"([^\"]*)\"$")
    public void scanner(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if (phone.hasBarcodeScanner()) {
            ButtonsUi buttonsUi = phone.getButtonsUi();
            phone.bringAppToForeground(AUTOMATION_HELPER);
            tapButtonOnce(arg1, arg2);
            if (buttonsUi.getAutomationHelperAppButtonPressText().equals("Barcode Key Event:keypress\n" +
                    "Barcode Key Event:shortpress\n" +
                    "Barcode Key Event:keyrelease\n")) {
                log.debug("'{}' works as a Scanner", arg1);
            } else {
                log.error("'{}' does not work as a Scanner", arg1);
                Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
            }
            phone.sendKeyEvent(AndroidKey.BACK);
        }
        else
            log.debug("Phone does not have a Barcode Scanner");
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as Custom 1 on \"([^\"]*)\"$")
    public void custom1(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        phone.bringAppToForeground(AUTOMATION_HELPER);
        tapButtonOnce(arg1, arg2);
        if (buttonsUi.getAutomationHelperAppButtonPressText().equals("CUSTOM1_BUTTON Key Event keypress\n" +
                "CUSTOM1_BUTTON Key Event shortpress\n" +
                "CUSTOM1_BUTTON Key Event keyrelease\n")) {
            log.debug("'{}' works as Custom 1", arg1);
        } else {
            log.error("'{}' does not work as Custom 1", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as Custom 2 on \"([^\"]*)\"$")
    public void custom2(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        phone.bringAppToForeground(AUTOMATION_HELPER);
        tapButtonOnce(arg1, arg2);
        if (buttonsUi.getAutomationHelperAppButtonPressText().equals("CUSTOM2_BUTTON Key Event keypress\n" +
                "CUSTOM2_BUTTON Key Event shortpress\n" +
                "CUSTOM2_BUTTON Key Event keyrelease\n")) {
            log.debug("'{}' works as Custom 2", arg1);
        } else {
            log.error("'{}' does not work as Custom 2", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as Custom 3 on \"([^\"]*)\"$")
    public void custom3(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        phone.bringAppToForeground(AUTOMATION_HELPER);
        tapButtonOnce(arg1, arg2);
        if (buttonsUi.getAutomationHelperAppButtonPressText().equals("CUSTOM3_BUTTON Key Event keypress\n" +
                "CUSTOM3_BUTTON Key Event shortpress\n" +
                "CUSTOM3_BUTTON Key Event keyrelease\n")) {
            log.debug("'{}' works as Custom 3", arg1);
        } else {
            log.error("'{}' does not work as Custom 3", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as Custom 4 on \"([^\"]*)\"$")
    public void custom4(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        phone.bringAppToForeground(AUTOMATION_HELPER);
        tapButtonOnce(arg1, arg2);
        if (buttonsUi.getAutomationHelperAppButtonPressText().equals("CUSTOM4_BUTTON Key Event keypress\n" +
                "CUSTOM4_BUTTON Key Event shortpress\n" +
                "CUSTOM4_BUTTON Key Event keyrelease\n")) {
            log.debug("'{}' works as Custom 4", arg1);
        } else {
            log.error("'{}' does not work as Custom 4", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify the \"([^\"]*)\" is programmed to open \"([^\"]*)\" app on \"([^\"]*)\"$")
    public void runApplication(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        tapButtonOnce(arg1, arg3);
        AndroidPhone.Application app = phone.findApplication(arg2.trim());
        if (phone.getForegroundPackage().contentEquals(app.getPackage())) {
            log.debug("Started application '{}'", arg2);
            log.debug("'{}' has been programmed to open '{}'", arg1, arg2);
            sleepSeconds(1);
        } else {
            log.error("'{}' does not open '{}'", arg1, arg2);
            Assert.fail(Util.glue("COULD NOT START '" + arg2 + "' APPLICATION"));
        }

    }

    @Then("^I verify the \"([^\"]*)\" is programmed to work as Fingerprint on \"([^\"]*)\"$")
    public void fingerprint(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        phone.bringAppToForeground(AUTOMATION_HELPER);
        tapButtonOnce(arg1, arg2);

        if (buttonsUi.getAutomationHelperAppButtonPressText().equals("Fingerprint Key Event:keypress\n" +
                "Fingerprint Key Event:shortpress\n" +
                "Fingerprint Key Event:keyrelease\n")) {
            log.debug("'{}' works as Fingerprint", arg1);
        } else {
            log.error("'{}' does not work as Fingerprint", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    public boolean isAboutMenuItemAvailable(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        List<WebElement> options = phone.appium().findElements(By.className("android.widget.TextView"));
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals("About")) {
                log.debug("Found About Menu item");
                return true;
            }
        }
        return false;
    }

    @When("^I long press \"([^\"]*)\" button on \"([^\"]*)\"$")
    public void longPressButton(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if (!phone.isRooted()) phone.rootPhone();
        switch (arg1.trim().toUpperCase()) {
            case "PTT":
                phone.longPress("PTT_BUTTON");
                break;
            case "SAFE":
                phone.longPress("PANIC_BUTTON");
                break;
            case "SCANNER":
            case "BARCODE":
                phone.longPress( "BARCODE_BUTTON");
                break;
            case "FINGERPRINT":
                phone.longPress("FINGERPRINT_BUTTON");
                break;
            case "CUSTOM1":
                phone.longPress( "CUSTOM1_BUTTON");
                break;
            case "CUSTOM2":
                phone.longPress("CUSTOM2_BUTTON");
                break;
            case "CUSTOM3":
                phone.longPress("CUSTOM3_BUTTON");
                break;
            case "CUSTOM4":
                phone.longPress("CUSTOM4_BUTTON");
                break;
        }
        log.debug("'{}' button pressed", arg1);
    }

    @Then("^I verify the \"([^\"]*)\" was long pressed on \"([^\"]*)\"$")
    public void longPressVerification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        ButtonsUi buttonsUi = phone.getButtonsUi();
        phone.bringAppToForeground(AUTOMATION_HELPER);
        longPressButton(arg1, arg2);

        switch (arg1.trim()) {
            case "Scanner":
            case "Barcode":
            case "Barcode Scanner":
                arg1 = "Barcode";
                break;
            case "Custom 1":
                arg1 = "CUSTOM1_BUTTON";
                break;
            case "Custom 2":
                arg1 = "CUSTOM2_BUTTON";
                break;
            case "Custom 3":
                arg1 = "CUSTOM3_BUTTON";
                break;
            case "Custom 4":
                arg1 = "CUSTOM4_BUTTON";
                break;
        }

        if (buttonsUi.getAutomationHelperAppButtonPressText().equals(""+ arg1 +" Key Event:keypress\n" +
                ""+ arg1 +" Key Event:longpress\n" +
                ""+ arg1 +" Key Event:keyrelease\n")) {
            log.debug("'{}' was long pressed", arg1);
        } else {
            log.error("'{}' was not long pressed", arg1);
            Environment.softAssert().fail("INCORRECT BUTTON MAPPING");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }
}
