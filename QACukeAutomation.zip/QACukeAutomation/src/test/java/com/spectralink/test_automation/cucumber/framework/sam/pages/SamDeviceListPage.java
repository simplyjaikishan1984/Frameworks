package com.spectralink.test_automation.cucumber.framework.sam.pages;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.SamConfigurationPage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.text.SimpleDateFormat;
import java.util.*;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.sam.pages.SamDeviceListPage.DeviceListColumns.*;

public class SamDeviceListPage extends SamBasePage {

	private static final int grid = 1;

	public enum DeviceListColumns implements FieldData {
		MAC("Device MAC Address", ""),
		SERIAL_NUMBER("Device Serial", ""),
		FIRMWARE_VERSION("Spectralink Firmware Version", ""),
		MODEL("Device Model", ""),
		NETWORK_RSSI("Network RSSI", ""),
		NETWORK_IP("Network IP", ""),
		DEVICE_INFO_1("Device Info 1", ""),
		DEVICE_INFO_2("Device Info 2", ""),
		DEVICE_INFO_3("Device Info 3", ""),
		DEVICE_INFO_4("Device Info 4", ""),
		GROUP("Group", ""),
		CREATE_DATE("Device Created", ""),
		SIP_1_EXTENSION("SIP Extension", ""),
		SIP_2_EXTENSION("Secondary SIP Extension", ""),
		ANDROID_VERSION("Android Version", ""),
		UPDATER_ID("Device Updater Id", ""),
		LAST_HEARTBEAT("Last Heartbeat", "");

		private final String title;
		private final String attribute;

		public String attribute() {
			return attribute;
		}

		public String title() {
			return title;
		}

		DeviceListColumns(String title, String attribute) {
			this.title = title;
			this.attribute = attribute;
		}
	}

	@FindBy(xpath = "//div[@ng-click=\"headerButtonClick($event)\"]")
	private WebElement selectAll;

	@FindBy(id = "device-drop-down")
	private WebElement actionMenu;

	@FindBy(id = "devicelist-actions-changeConfig")
	private WebElement changeConfig;

	@FindBy(id = "devicelist-actions-reApplyConfig")
	private WebElement reapplyConfig;

	@FindBy(id = "devicelist-actions-trigger-heartbeat")
	private WebElement triggerHeartbeat;

	@FindBy(id = "devicelist-actions-export")
	private WebElement exportDevicesOption;

	@FindBy(id = "global-search-column-select")
	private WebElement searchByDropDown;

	@FindBy(xpath = "//button[@ng-click=\"submitQuery(selectedSearchOption,searchTextValue)\"]")
	private WebElement searchButton;

	@FindBy(xpath = "//button[@ng-click=\"customize()\"]")
	private WebElement changeColumnButton;

	@FindBy(id = "searchinput")
	private List<WebElement> searchTextBoxes;

	@FindBy(id = "searchclear")
	private List<WebElement> clearButtons;

	@FindBy(xpath = "//a[@ng-click=\"toggleFilterType()\"]")
	private WebElement searchTypeButton;

	@FindBy(id = "advanceSearch")
	private WebElement advancedSearchTextbox;

	@FindBy(xpath = "//button[@ng-click=\"validateDateQuery()\"]")
	private WebElement advancedSearchButton;

	@FindBy(xpath = "//a[@ng-click=\"resetFilter()\"]")
	private WebElement advancedSearchClearButton;

	@FindBy(id = "device-columns-list-label-Android Version")
	private WebElement androidVersionLabel;

	@FindBy(id = "Android Version")
	private WebElement androidVersionCheckbox;

	public ConfigPageField androidBox = new ConfigPageField(
			ANDROID_VERSION,
			androidVersionLabel,
			androidVersionCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device Created")
	private WebElement createdLabel;

	@FindBy(id = "Device Created")
	private WebElement createdCheckbox;

	public ConfigPageField createdBox = new ConfigPageField(
			CREATE_DATE,
			createdLabel,
			createdCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device Info 1")
	private WebElement deviceInfo1Label;

	@FindBy(id = "Device Info 1")
	private WebElement deviceInfo1Checkbox;

	public ConfigPageField deviceInfo1Box = new ConfigPageField(
			DEVICE_INFO_1,
			deviceInfo1Label,
			deviceInfo1Checkbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device Info 2")
	private WebElement deviceInfo2Label;

	@FindBy(id = "Device Info 2")
	private WebElement deviceInfo2Checkbox;

	public ConfigPageField deviceInfo2Box = new ConfigPageField(
			DEVICE_INFO_2,
			deviceInfo2Label,
			deviceInfo2Checkbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device Info 3")
	private WebElement deviceInfo3Label;

	@FindBy(id = "Device Info 3")
	private WebElement deviceInfo3Checkbox;

	public ConfigPageField deviceInfo3Box = new ConfigPageField(
			DEVICE_INFO_3,
			deviceInfo3Label,
			deviceInfo3Checkbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device Info 4")
	private WebElement deviceInfo4Label;

	@FindBy(id = "Device Info 4")
	private WebElement deviceInfo4Checkbox;

	public ConfigPageField deviceInfo4Box = new ConfigPageField(
			DEVICE_INFO_4,
			deviceInfo4Label,
			deviceInfo4Checkbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device MAC Address")
	private WebElement macAddressLabel;

	@FindBy(id = "Device MAC Address")
	private WebElement macAddressCheckbox;

	public ConfigPageField macAddressBox = new ConfigPageField(
			MAC,
			macAddressLabel,
			macAddressCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device Model")
	private WebElement modelLabel;

	@FindBy(id = "Device Model")
	private WebElement modelCheckbox;

	public ConfigPageField modelBox = new ConfigPageField(
			MODEL,
			modelLabel,
			modelCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device Serial")
	private WebElement serialLabel;

	@FindBy(id = "Device Serial")
	private WebElement serialCheckbox;

	public ConfigPageField serialBox = new ConfigPageField(
			SERIAL_NUMBER,
			serialLabel,
			serialCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Device Updater Id")
	private WebElement updaterLabel;

	@FindBy(id = "Device Updater Id")
	private WebElement updaterCheckbox;

	public ConfigPageField updaterBox = new ConfigPageField(
			UPDATER_ID,
			updaterLabel,
			updaterCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Group")
	private WebElement groupLabel;

	@FindBy(id = "Group")
	private WebElement groupCheckbox;

	public ConfigPageField groupBox = new ConfigPageField(
			GROUP,
			groupLabel,
			groupCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Last Heartbeat")
	private WebElement lastBeatLabel;

	@FindBy(id = "Last Heartbeat")
	private WebElement lastBeatCheckbox;

	public ConfigPageField lastBeatBox = new ConfigPageField(
			LAST_HEARTBEAT,
			lastBeatLabel,
			lastBeatCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Network IP")
	private WebElement ipLabel;

	@FindBy(id = "Network IP")
	private WebElement ipCheckbox;

	public ConfigPageField ipBox = new ConfigPageField(
			NETWORK_IP,
			ipLabel,
			ipCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Network RSSI")
	private WebElement rssiLabel;

	@FindBy(id = "Network RSSI")
	private WebElement rssiCheckbox;

	public ConfigPageField rssiBox = new ConfigPageField(
			NETWORK_RSSI,
			rssiLabel,
			rssiCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Secondary SIP Extension")
	private WebElement secondSipLabel;

	@FindBy(id = "Secondary SIP Extension")
	private WebElement secondSipCheckbox;

	public ConfigPageField secondSipBox = new ConfigPageField(
			SIP_2_EXTENSION,
			secondSipLabel,
			secondSipCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-SIP Extension")
	private WebElement sipLabel;

	@FindBy(id = "SIP Extension")
	private WebElement sipCheckbox;

	public ConfigPageField sipBox = new ConfigPageField(
			SIP_1_EXTENSION,
			sipLabel,
			sipCheckbox, null, null
	);

	@FindBy(id = "device-columns-list-label-Spectralink Firmware Version")
	private WebElement firmwareLabel;

	@FindBy(id = "Spectralink Firmware Version")
	private WebElement firmwareCheckbox;

	public ConfigPageField firmwareBox = new ConfigPageField(
			FIRMWARE_VERSION,
			firmwareLabel,
			firmwareCheckbox, null, null
	);

	@FindBy(xpath = "//button[@ng-click=\"ok()\"]")
	private WebElement okButton;

	@FindBy(xpath = "//div[@ng-click=\"selectButtonClick(row, $event)\"]")
	private List<WebElement> deviceListCheckboxes;

	//@FindBy(className = "ui-grid-header-cell-label")
	//private List<WebElement> headings;

	@FindBy(xpath = "//div[@role=\"columnheader\"]")
	private List<WebElement> headings;

	public Map<String, ConfigPageField> columnFields;

	public SamDeviceListPage() {
		super();
		PageFactory.initElements(driver, this);

		columnFields = new HashMap<String, ConfigPageField>() {
			{
				put(androidBox.getTitle(), androidBox);
				put(createdBox.getTitle(), createdBox);
				put(deviceInfo1Box.getTitle(), deviceInfo1Box);
				put(deviceInfo2Box.getTitle(), deviceInfo2Box);
				put(deviceInfo3Box.getTitle(), deviceInfo3Box);
				put(deviceInfo4Box.getTitle(), deviceInfo4Box);
				put(macAddressBox.getTitle(), macAddressBox);
				put(modelBox.getTitle(), modelBox);
				put(serialBox.getTitle(), serialBox);
				put(updaterBox.getTitle(), updaterBox);
				put(groupBox.getTitle(), groupBox);
				put(lastBeatBox.getTitle(), lastBeatBox);
				put(ipBox.getTitle(), ipBox);
				put(rssiBox.getTitle(), rssiBox);
				put(secondSipBox.getTitle(), secondSipBox);
				put(sipBox.getTitle(), sipBox);
				put(firmwareBox.getTitle(), firmwareBox);
			}
		};
	}

	public DeviceListColumns getDeviceListColumn(String title) {
		for (DeviceListColumns columnTitle : DeviceListColumns.values()) {
			if (columnTitle.title().toLowerCase().contentEquals(title.trim().toLowerCase())) {
				return columnTitle;
			}
		}
		return null;
	}

	public WebElement getCheckBox(int index) {
		return deviceListCheckboxes.get(index);
	}

	public void selectReapplyConfig() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(reapplyConfig);
	}

	public void selectTriggerHeartbeat() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(triggerHeartbeat);
	}

	public void selectExportAllDevices() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(exportDevicesOption);
	}

	public SamConfigurationPage selectChangeConfig() {
		clickOnPageEntity(actionMenu);
		clickOnPageEntity(changeConfig);
		return new SamConfigurationPage();
	}

	public void enableSelectAll() {
		if (!selectAll.getAttribute("class").contains("ui-grid-all-selected")) {
			clickOnPageEntity(selectAll);
		}
	}

	public void disableSelectAll() {
		if (selectAll.getAttribute("class").contains("ui-grid-all-selected")) {
			clickOnPageEntity(selectAll);
		}
	}

	public void clickOkButton() {
		clickOnPageEntity(okButton);
		sleepSeconds(2);
	}

	public void clickChangeColumns() {
		clickOnPageEntity(changeColumnButton);
	}

	public void selectSearchType(String menuOption) {
		selectMenuByText(searchByDropDown, menuOption);
	}

	public void clickSearchButton() {
		clickOnPageEntity(searchButton);
		sleepSeconds(1);
	}

	public void enterSearchValue(String value) {
		for (WebElement textBox : searchTextBoxes) {
			if (textBox.isDisplayed()) {
				typeIntoPageEntity(textBox, value);
				break;
			}
		}
	}

	public void clickSearchClearButton() {
		for (WebElement button : clearButtons) {
			if (button.isDisplayed()) {
				clickOnPageEntity(button);
				sleepSeconds(1);
				break;
			}
		}
	}

	public Integer getDeviceListSize() {
		return deviceListCheckboxes.size();
	}

	public void enableCheckbox(WebElement checkbox) {
		if (!checkbox.getAttribute("class").contains("ui-grid-row-selected")) {
			clickOnPageEntity(checkbox);
		}
	}

	public void disableCheckbox(WebElement checkbox) {
		if (checkbox.getAttribute("class").contains("ui-grid-row-selected")) {
			clickOnPageEntity(checkbox);
		}
	}

	public void enableCheckboxWithAddress(String macAddress) {
		int rowIndex = getRowIndexOfColumnValue(macAddress, getHeadingIndex(MAC.title()), grid);
		if (rowIndex != -1 && !getCheckBox(rowIndex).getAttribute("class").contains("ui-grid-row-selected")) {
			clickOnPageEntity(getCheckBox(rowIndex));
		}
	}

	public void enableOnlyCheckboxWithAddress(String macAddress) {
		int rowIndex = getRowIndexOfColumnValue(macAddress, getHeadingIndex(MAC.title()), grid);
		if (rowIndex != -1) {
			for (WebElement checkBox : deviceListCheckboxes) {
				if (checkBox.equals(getCheckBox(rowIndex))) {
					if (!checkBox.getAttribute("class").contains("ui-grid-row-selected")) {
						clickOnPageEntity(checkBox);
					}
				} else {
					if (checkBox.getAttribute("class").contains("ui-grid-row-selected")) {
						clickOnPageEntity(checkBox);
					}
				}
			}
		}
	}

	public void clickCheckboxWithAddress(String macAddress) {
		int rowIndex = getRowIndexOfColumnValue(macAddress, getHeadingIndex(MAC.title()), grid);
		clickOnPageEntity(getCheckBox(rowIndex));
	}

	public void clickCheckboxWithSerial(String serial) {
		int rowIndex = getRowIndexOfColumnValue(serial, getHeadingIndex(SERIAL_NUMBER.title()), grid);
		clickOnPageEntity(getCheckBox(rowIndex));
	}

	public boolean deviceIsVisible(String cellValue, String title) {
		setTemporaryWait(1);
		int rowIndex = waitForColumnValue(cellValue, getHeadingIndex(title), grid);
		removeTemporaryWait();
		return rowIndex != -1;
	}

	public boolean deviceIsChecked(String serial) {
		int rowIndex = getRowIndexOfColumnValue(serial, getHeadingIndex(SERIAL_NUMBER.title()), grid);
		return rowIndex != -1 && getCheckBox(rowIndex).getAttribute("class").contains("ui-grid-row-selected");
	}

	public int getDeviceRowCount() {
		return getRowCount(grid);
	}

	public List<WebElement> getHeadings() {
		return headings;
	}

	public int getHeadingIndex(String targetHeading) {
		for (int columnIndex = 0; columnIndex < headings.size(); columnIndex++) {
			if (headings.get(columnIndex).getAttribute("innerText").contains(targetHeading)) {
				return columnIndex + 1;
			}
		}
		return -1;
	}

	public void clickBasicSearchLink() {
		if (!searchTypeButton.getAttribute("innerText").contentEquals("Advanced")) {
			clickOnPageEntity(searchTypeButton);
		}
	}

	public void clickAdvancedSearchLink() {
		if (searchTypeButton.getAttribute("innerText").contentEquals("Advanced")) {
			clickOnPageEntity(searchTypeButton);
		}
	}

	public void enterAdvancedSearchValue(String value) {
		typeIntoPageEntity(advancedSearchTextbox, value);
	}

	public void clickAdvancedSearchButton() {
		clickOnPageEntity(advancedSearchButton);
		sleepSeconds(1);
	}

	public void clickAdvancedSearchClear() {
		clickOnPageEntity(advancedSearchClearButton);
	}

	public void clearDeviceSelections() {
		for (WebElement checkbox : deviceListCheckboxes) {
			disableCheckbox(checkbox);
		}
	}

	public void sendHeartbeatRequest(String macAddress) {
		clearDeviceSelections();
		enableCheckboxWithAddress(macAddress);
		selectTriggerHeartbeat();
		sleepSeconds(4);
	}

	public String sendSingleHeartbeatRequest(Integer snoozeTime, String macAddress) {
		clearDeviceSelections();
		enableCheckboxWithAddress(macAddress);
		selectTriggerHeartbeat();
		SimpleDateFormat logcatFormat = new SimpleDateFormat("MM-dd HH:mm");
		logcatFormat.setTimeZone(TimeZone.getTimeZone("America/Denver"));
		String logcatMarker = logcatFormat.format(new Date());
		sleepSeconds(snoozeTime);
		return logcatMarker;
	}

	public void sendMultiHeartbeatRequest(Integer snoozeTime, String ... macAddresses) {
		for (String address : macAddresses) {
			clickCheckboxWithAddress(address);
		}
		selectTriggerHeartbeat();
		sleepSeconds(snoozeTime);
	}

	public void sendAllDevicesHeartbeatRequest(Integer snoozeTime) {
		enableSelectAll();
		selectTriggerHeartbeat();
		enableSelectAll();
		sleepSeconds(snoozeTime);
	}

	public void reapplyConfigOnDevice(String macAddress) {
		clearDeviceSelections();
		clickCheckboxWithAddress(macAddress);
		selectReapplyConfig();
	}

	public boolean deviceListColumnModalDisplayed() {
		return isPresent(By.id("device-columns-body"));
	}

	public ConfigPageField getField(String title) {
		return columnFields.get(title);
	}

	public boolean columnIsVisible(String title) {
		for (WebElement heading : getHeadings()) {
			if (heading.getAttribute("innerText").contains(title)) return true;
		}
		return false;
	}

	public boolean columnIsNotVisible(String title) {
		for (WebElement heading : getHeadings()) {
			if (heading.getAttribute("innerText").contains(title)) return false;
		}
		return true;
	}

	public void clickColumnHeading(String title) {
		for (WebElement heading : getHeadings()) {
			if (heading.getAttribute("innerText").contains(title)) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView(true)", heading);
				clickOnPageEntity(heading);
				sleepSeconds(1);
				break;
			}
		}
	}
	public List<String> getSearchTypes() {
		List<String> optionList = new ArrayList<>();
		List<WebElement> options = searchByDropDown.findElements(By.tagName("option"));
		for (WebElement label : options) {
			optionList.add(label.getText());
		}
		return optionList;
	}

	public String getSortDirection(String title) {
		for (WebElement heading : getHeadings()) {
			if (heading.getAttribute("innerText").contains(title)) {
				return heading.getAttribute("aria-sort");
			}
		}
		return "unknown";
	}
}
