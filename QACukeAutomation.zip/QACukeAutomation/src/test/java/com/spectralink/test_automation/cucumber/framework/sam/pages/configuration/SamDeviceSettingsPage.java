package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.DeviceSettingsStrings.*;

public class SamDeviceSettingsPage extends SamConfigurationPage {

	@FindBy(id = "enable_config_manager_label")
	private WebElement enableDeviceSettingsLabel;

	@FindBy(id = "enable_device_settings")
	private WebElement enableDeviceSettingsCheckbox;

	@FindBy(id = "edit_setting_enableDeviceSettings")
	private WebElement enableDeviceSettingsEdit;

	@FindBy(id = "delete_setting_enableDeviceSettings")
	private WebElement enableDeviceSettingsDelete;

	@FindBy(id = "undo_setting_enableDeviceSettings")
	private WebElement enableDeviceSettingsUndo;

	public ConfigPageField enableDeviceSettingsField = new ConfigPageField(
			ENABLE_DEVICE_SETTINGS,
			enableDeviceSettingsLabel,
			enableDeviceSettingsCheckbox,
			enableDeviceSettingsDelete,
			enableDeviceSettingsEdit,
			enableDeviceSettingsUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-wifi\"]")
	private WebElement allowWifiToggleLabel;

	@FindBy(id = "allow-wifi")
	private WebElement allowWifiToggleRadio;

	@FindBy(id = "delete_setting_deviceSettingsAllowWifi")
	private WebElement allowWifiToggleDelete;

	@FindBy(id = "edit_setting_deviceSettingsAllowWifi")
	private WebElement allowWifiToggleEdit;

	@FindBy(id = "undo_setting_deviceSettingsAllowWifi")
	private WebElement allowWifiToggleUndo;

	public ConfigPageField allowWifiToggleField = new ConfigPageField(
			WIFI,
			allowWifiToggleLabel,
			allowWifiToggleRadio,
			allowWifiToggleDelete,
			allowWifiToggleEdit,
			allowWifiToggleUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-wifi\"]")
	private WebElement disallowWifiToggleLabel;

	@FindBy(id = "disable-wifi")
	private WebElement disallowWifiToggleRadio;

	public ConfigPageField disallowWifiToggleField = new ConfigPageField(
			WIFI,
			disallowWifiToggleLabel,
			disallowWifiToggleRadio,
			allowWifiToggleDelete,
			allowWifiToggleEdit,
			allowWifiToggleUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-airplane-mode\"]")
	private WebElement allowAirplaneModeToggleLabel;

	@FindBy(id = "allow-airplane-mode")
	private WebElement allowAirplaneModeToggleRadio;

	@FindBy(id = "delete_setting_deviceSettingsAllowAirplaneMode")
	private WebElement airplaneModeToggleDelete;

	@FindBy(id = "edit_setting_deviceSettingsAllowAirplaneMode")
	private WebElement airplaneModeToggleEdit;

	@FindBy(id = "undo_setting_deviceSettingsAllowAirplaneMode")
	private WebElement airplaneModeToggleUndo;

	public ConfigPageField allowAirplaneModeToggleField = new ConfigPageField(
			AIRPLANE_MODE,
			allowAirplaneModeToggleLabel,
			allowAirplaneModeToggleRadio,
			airplaneModeToggleDelete,
			airplaneModeToggleEdit,
			airplaneModeToggleUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-airplane-mode\"]")
	private WebElement disallowAirplaneModeToggleLabel;

	@FindBy(id = "disable-airplane-mode")
	private WebElement disallowAirplaneModeToggleRadio;

	public ConfigPageField disallowAirplaneModeToggleField = new ConfigPageField(
			AIRPLANE_MODE,
			disallowAirplaneModeToggleLabel,
			disallowAirplaneModeToggleRadio,
			airplaneModeToggleDelete,
			airplaneModeToggleEdit,
			airplaneModeToggleUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-all-quick-settings-tiles\"]")
	private WebElement allowSettingsTilesLabel;

	@FindBy(id = "allow-all-quick-settings-tiles")
	private WebElement allowSettingsTilesRadio;

	@FindBy(id = "delete_setting_slnkDeviceSettingsQuickSettingsTiles")
	private WebElement settingsTilesDelete;

	@FindBy(id = "edit_setting_slnkDeviceSettingsQuickSettingsTiles")
	private WebElement settingsTilesEdit;

	@FindBy(id = "undo_setting_slnkDeviceSettingsQuickSettingsTiles")
	private WebElement settingsTilesUndo;

	public ConfigPageField allowSettingsTilesField = new ConfigPageField(
			QUICK_SETTINGS_TILES,
			allowSettingsTilesLabel,
			allowSettingsTilesRadio,
			settingsTilesDelete,
			settingsTilesEdit,
			settingsTilesUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-allow-all-quick-settings-tiles\"]")
	private WebElement disallowSettingsTilesLabel;

	@FindBy(id = "disable-allow-all-quick-settings-tiles")
	private WebElement disallowSettingsTilesRadio;

	public ConfigPageField disallowSettingsTilesField = new ConfigPageField(
			QUICK_SETTINGS_TILES,
			disallowSettingsTilesLabel,
			disallowSettingsTilesRadio,
			settingsTilesDelete,
			settingsTilesEdit,
			settingsTilesUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-dnd-quick-setting\"]")
	private WebElement allowDndModeToggleLabel;

	@FindBy(id = "allow-dnd-quick-setting")
	private WebElement allowDndModeToggleRadio;

	@FindBy(id = "delete_setting_allowDNDQSTile")
	private WebElement dndModeToggleDelete;

	@FindBy(id = "edit_setting_allowDNDQSTile")
	private WebElement dndModeToggleEdit;

	@FindBy(id = "undo_setting_allowDNDQSTile")
	private WebElement dndModeToggleUndo;

	public ConfigPageField allowDndModeToggleField = new ConfigPageField(
			DND_CONFIG,
			allowDndModeToggleLabel,
			allowDndModeToggleRadio,
			dndModeToggleDelete,
			dndModeToggleEdit,
			dndModeToggleUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-dnd-quick-setting\"]")
	private WebElement disallowDndModeToggleLabel;

	@FindBy(id = "disable-dnd-quick-setting")
	private WebElement disallowDndModeToggleRadio;

	public ConfigPageField disallowDndModeToggleField = new ConfigPageField(
			DND_CONFIG,
			disallowDndModeToggleLabel,
			disallowDndModeToggleRadio,
			dndModeToggleDelete,
			dndModeToggleEdit,
			dndModeToggleUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-notif-shade-settings-gear\"]")
	private WebElement allowNotificationShadeLabel;

	@FindBy(id = "allow-notif-shade-settings-gear")
	private WebElement allowNotificationShadeRadio;

	@FindBy(id = "delete_setting_slnkDeviceSettingsNotificationShade")
	private WebElement notificationShadeDelete;

	@FindBy(id = "edit_setting_slnkDeviceSettingsNotificationShade")
	private WebElement notificationShadeEdit;

	@FindBy(id = "undo_setting_slnkDeviceSettingsNotificationShade")
	private WebElement notificationShadeUndo;

	public ConfigPageField allowNotificationShadeField = new ConfigPageField(
			NOTIFICATION_SHADE,
			allowNotificationShadeLabel,
			allowNotificationShadeRadio,
			notificationShadeDelete,
			notificationShadeEdit,
			notificationShadeUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-allow-notif-shade-settings-gear\"]")
	private WebElement disallowNotificationShadeLabel;

	@FindBy(id = "disable-allow-notif-shade-settings-gear")
	private WebElement disallowNotificationShadeRadio;

	public ConfigPageField disallowNotificationShadeField = new ConfigPageField(
			NOTIFICATION_SHADE,
			disallowNotificationShadeLabel,
			disallowNotificationShadeRadio,
			notificationShadeDelete,
			notificationShadeEdit,
			notificationShadeUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-timezone-config\"]")
	private WebElement allowTimezoneConfigLabel;

	@FindBy(id = "allow-timezone-config")
	private WebElement allowTimezoneConfigRadio;

	@FindBy(id = "delete_setting_allowConfigTimezone")
	private WebElement timezoneConfigDelete;

	@FindBy(id = "edit_setting_allowConfigTimezone")
	private WebElement timezoneConfigEdit;

	@FindBy(id = "undo_setting_allowConfigTimezone")
	private WebElement timezoneConfigUndo;

	public ConfigPageField allowTimezoneConfigField = new ConfigPageField(
			TIMEZONE_CONFIG,
			allowTimezoneConfigLabel,
			allowTimezoneConfigRadio,
			timezoneConfigDelete,
			timezoneConfigEdit,
			timezoneConfigUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-timezone-config\"]")
	private WebElement disallowTimezoneConfigLabel;

	@FindBy(id = "disable-timezone-config")
	private WebElement disallowTimezoneConfigRadio;

	public ConfigPageField disallowTimezoneConfigField = new ConfigPageField(
			TIMEZONE_CONFIG,
			disallowTimezoneConfigLabel,
			disallowTimezoneConfigRadio,
			timezoneConfigDelete,
			timezoneConfigEdit,
			timezoneConfigUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-timeformat-config\"]")
	private WebElement allowTimeFormatConfigLabel;

	@FindBy(id = "allow-timeformat-config")
	private WebElement allowTimeFormatConfigRadio;

	@FindBy(id = "delete_setting_allowConfigTimeformat")
	private WebElement timeFormatConfigDelete;

	@FindBy(id = "edit_setting_allowConfigTimeformat")
	private WebElement timeFormatConfigEdit;

	@FindBy(id = "undo_setting_allowConfigTimeformat")
	private WebElement timeFormatConfigUndo;

	public ConfigPageField allowTimeFormatConfigField = new ConfigPageField(
			TIME_FORMAT_CONFIG,
			allowTimeFormatConfigLabel,
			allowTimeFormatConfigRadio,
			timeFormatConfigDelete,
			timeFormatConfigEdit,
			timeFormatConfigUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-timeformat-config\"]")
	private WebElement disallowTimeFormatConfigLabel;

	@FindBy(id = "disable-timeformat-config")
	private WebElement disallowTimeFormatConfigRadio;

	public ConfigPageField disallowTimeFormatConfigField = new ConfigPageField(
			TIME_FORMAT_CONFIG,
			disallowTimeFormatConfigLabel,
			disallowTimeFormatConfigRadio,
			timeFormatConfigDelete,
			timeFormatConfigEdit,
			timeFormatConfigUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-auto-timezone-config\"]")
	private WebElement allowAutoTimezoneConfigLabel;

	@FindBy(id = "allow-auto-timezone-config")
	private WebElement allowAutoTimezoneConfigRadio;

	@FindBy(id = "delete_setting_allowConfigAutoTimezone")
	private WebElement autoTimezoneConfigDelete;

	@FindBy(id = "edit_setting_allowConfigAutoTimezone")
	private WebElement autoTimezoneConfigEdit;

	@FindBy(id = "undo_setting_allowConfigAutoTimezone")
	private WebElement autoTimezoneConfigUndo;

	public ConfigPageField allowAutoTimezoneConfigField = new ConfigPageField(
			AUTO_TIMEZONE_CONFIG,
			allowAutoTimezoneConfigLabel,
			allowAutoTimezoneConfigRadio,
			autoTimezoneConfigDelete,
			autoTimezoneConfigEdit,
			autoTimezoneConfigUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-auto-timezone-config\"]")
	private WebElement disallowAutoTimezoneConfigLabel;

	@FindBy(id = "disable-auto-timezone-config")
	private WebElement disallowAutoTimezoneConfigRadio;

	public ConfigPageField disallowAutoTimezoneConfigField = new ConfigPageField(
			AUTO_TIMEZONE_CONFIG,
			disallowAutoTimezoneConfigLabel,
			disallowAutoTimezoneConfigRadio,
			autoTimezoneConfigDelete,
			autoTimezoneConfigEdit,
			autoTimezoneConfigUndo
	);

	@FindBy(id = "deviceSettings-ntp-server")
	private WebElement ntpServerAddressTextbox;

	@FindBy(id = "delete_setting_deviceSettingsNtpServer")
	private WebElement ntpServerAddressDelete;

	@FindBy(id = "edit_setting_deviceSettingsNtpServer")
	private WebElement ntpServerAddressEdit;

	@FindBy(id = "undo_setting_deviceSettingsNtpServer")
	private WebElement ntpServerAddressUndo;

	public ConfigPageField ntpServerAddressField = new ConfigPageField(
			NTP_SERVER,
			null,
			ntpServerAddressTextbox,
			ntpServerAddressDelete,
			ntpServerAddressEdit,
			ntpServerAddressUndo
	);

	@FindBy(id = "timezone")
	private WebElement timezoneMenu;

	@FindBy(id = "delete_setting_timezone")
	private WebElement timezoneDelete;

	@FindBy(id = "edit_setting_timezone")
	private WebElement timezoneEdit;

	@FindBy(id = "undo_setting_timezone")
	private WebElement timezoneUndo;

	public ConfigPageField timezoneField = new ConfigPageField(
			TIMEZONE,
			null,
			timezoneMenu,
			timezoneDelete,
			timezoneEdit,
			timezoneUndo
	);

	@FindBy(id = "time_format")
	private WebElement timeFormatMenu;

	@FindBy(id = "delete_setting_time_format")
	private WebElement timeFormatDelete;

	@FindBy(id = "edit_setting_time_format")
	private WebElement timeFormatEdit;

	@FindBy(id = "undo_setting_time_format")
	private WebElement timeFormatUndo;

	public ConfigPageField timeFormatField = new ConfigPageField(
			TIME_DISPLAY_FORMAT,
			null,
			timeFormatMenu,
			timeFormatDelete,
			timeFormatEdit,
			timeFormatUndo
	);

	@FindBy(xpath = "//label[@for=\"allow-auto-timezone\"]")
	private WebElement allowAutoTimezoneLabel;

	@FindBy(id = "allow-auto-timezone")
	private WebElement allowAutoTimezoneRadio;

	@FindBy(id = "delete_setting_autoTimezone")
	private WebElement autoTimezoneDelete;

	@FindBy(id = "edit_setting_autoTimezone")
	private WebElement autoTimezoneEdit;

	@FindBy(id = "undo_setting_autoTimezone")
	private WebElement autoTimezoneUndo;

	public ConfigPageField allowAutoTimezoneField = new ConfigPageField(
			AUTO_TIMEZONE,
			allowAutoTimezoneLabel,
			allowAutoTimezoneRadio,
			autoTimezoneDelete,
			autoTimezoneEdit,
			autoTimezoneUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-auto-timezone\"]")
	private WebElement disallowAutoTimezoneLabel;

	@FindBy(id = "disable-auto-timezone")
	private WebElement disallowAutoTimezoneRadio;

	public ConfigPageField disallowAutoTimezoneField = new ConfigPageField(
			AUTO_TIMEZONE,
			disallowAutoTimezoneLabel,
			disallowAutoTimezoneRadio,
			autoTimezoneDelete,
			autoTimezoneEdit,
			autoTimezoneUndo
	);

	@FindBy(xpath = "//label[@for=\"display-device-info-yes\"]")
	private WebElement displayDeviceInfoEnableLabel;

	@FindBy(id = "display-device-info-yes")
	private WebElement displayDeviceInfoEnableRadio;

	@FindBy(id = "delete_setting_displayDeviceInfo")
	private WebElement displayDeviceInfoDelete;

	@FindBy(id = "edit_setting_displayDeviceInfo")
	private WebElement displayDeviceInfoEdit;

	@FindBy(id = "undo_setting_displayDeviceInfo")
	private WebElement displayDeviceInfoUndo;

	public ConfigPageField displayDeviceInfoEnableField = new ConfigPageField(
			INFO_DISPLAY,
			displayDeviceInfoEnableLabel,
			displayDeviceInfoEnableRadio,
			displayDeviceInfoDelete,
			displayDeviceInfoEdit,
			displayDeviceInfoUndo
	);

	@FindBy(xpath = "//label[@for=\"display-device-info-no\"]")
	private WebElement displayDeviceInfoDisableLabel;

	@FindBy(id = "display-device-info-no")
	private WebElement displayDeviceInfoDisableRadio;

	public ConfigPageField displayDeviceInfoDisableField = new ConfigPageField(
			INFO_DISPLAY,
			displayDeviceInfoDisableLabel,
			displayDeviceInfoDisableRadio,
			displayDeviceInfoDelete,
			displayDeviceInfoEdit,
			displayDeviceInfoUndo
	);

	@FindBy(id = "device-info-1")
	private WebElement deviceInfo1Textbox;

	@FindBy(id = "delete_setting_deviceInfo1")
	private WebElement deviceInfo1Delete;

	@FindBy(id = "edit_setting_deviceInfo1")
	private WebElement deviceInfo1Edit;

	@FindBy(id = "undo_setting_deviceInfo1")
	private WebElement deviceInfo1Undo;

	public ConfigPageField deviceInfo1Field = new ConfigPageField(
			DEVICE_INFO_1,
			null,
			deviceInfo1Textbox,
			deviceInfo1Delete,
			deviceInfo1Edit,
			deviceInfo1Undo
	);

	@FindBy(id = "device-info-2")
	private WebElement deviceInfo2Textbox;

	@FindBy(id = "delete_setting_deviceInfo2")
	private WebElement deviceInfo2Delete;

	@FindBy(id = "edit_setting_deviceInfo2")
	private WebElement deviceInfo2Edit;

	@FindBy(id = "undo_setting_deviceInfo2")
	private WebElement deviceInfo2Undo;

	public ConfigPageField deviceInfo2Field = new ConfigPageField(
			DEVICE_INFO_2,
			null,
			deviceInfo2Textbox,
			deviceInfo2Delete,
			deviceInfo2Edit,
			deviceInfo2Undo
	);

	@FindBy(id = "device-info-3")
	private WebElement deviceInfo3Textbox;

	@FindBy(id = "delete_setting_deviceInfo3")
	private WebElement deviceInfo3Delete;

	@FindBy(id = "edit_setting_deviceInfo3")
	private WebElement deviceInfo3Edit;

	@FindBy(id = "undo_setting_deviceInfo3")
	private WebElement deviceInfo3Undo;

	public ConfigPageField deviceInfo3Field = new ConfigPageField(
			DEVICE_INFO_3,
			null,
			deviceInfo3Textbox,
			deviceInfo3Delete,
			deviceInfo3Edit,
			deviceInfo3Undo
	);

	@FindBy(id = "device-info-4")
	private WebElement deviceInfo4Textbox;

	@FindBy(id = "delete_setting_deviceInfo4")
	private WebElement deviceInfo4Delete;

	@FindBy(id = "edit_setting_deviceInfo4")
	private WebElement deviceInfo4Edit;

	@FindBy(id = "undo_setting_deviceInfo4")
	private WebElement deviceInfo4Undo;

	public ConfigPageField deviceInfo4Field = new ConfigPageField(
			DEVICE_INFO_4,
			null,
			deviceInfo4Textbox,
			deviceInfo4Delete,
			deviceInfo4Edit,
			deviceInfo4Undo
	);

	@FindBy(id = "device-name")
	private WebElement deviceNameTextbox;

	@FindBy(id = "delete_setting_deviceName")
	private WebElement deviceNameDelete;

	@FindBy(id = "edit_setting_deviceName")
	private WebElement deviceNameEdit;

	@FindBy(id = "undo_setting_deviceName")
	private WebElement deviceNameUndo;

	public ConfigPageField deviceNameField = new ConfigPageField(
			DEVICE_NAME,
			null,
			deviceNameTextbox,
			deviceNameDelete,
			deviceNameEdit,
			deviceNameUndo
	);

	@FindBy(id = "application_Battery_Optimization_Whitelist")
	private WebElement whitelistTextbox;

	@FindBy(id = "delete_setting_applicationBatteryOptimizationWhitelist")
	private WebElement whitelistDelete;

	@FindBy(id = "edit_setting_applicationBatteryOptimizationWhitelist")
	private WebElement whitelistEdit;

	@FindBy(id = "undo_setting_applicationBatteryOptimizationWhitelist")
	private WebElement whitelistUndo;

	public ConfigPageField whitelistField = new ConfigPageField(
			APPLICATION_WHITELIST,
			null,
			whitelistTextbox,
			whitelistDelete,
			whitelistEdit,
			whitelistUndo
	);

	@FindBy(xpath = "//label[@for=\"enable-battery-saver\"]")
	private WebElement allowBatterySaverLabel;

	@FindBy(id = "enable-battery-saver")
	private WebElement allowBatterySaverRadio;

	@FindBy(id = "delete_setting_slnkDeviceSettingsBatterySaver")
	private WebElement batterySaverDelete;

	@FindBy(id = "edit_setting_slnkDeviceSettingsBatterySaver")
	private WebElement batterySaverEdit;

	@FindBy(id = "undo_setting_slnkDeviceSettingsBatterySaver")
	private WebElement batterySaverUndo;

	public ConfigPageField allowBatterySaverField = new ConfigPageField(
			BATTERY_SAVER,
			allowBatterySaverLabel,
			allowBatterySaverRadio,
			batterySaverDelete,
			batterySaverEdit,
			batterySaverUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-enable-battery-saver\"]")
	private WebElement disallowBatterySaverLabel;

	@FindBy(id = "disable-enable-battery-saver")
	private WebElement disallowBatterySaverRadio;

	public ConfigPageField disallowBatterySaverField = new ConfigPageField(
			BATTERY_SAVER,
			disallowBatterySaverLabel,
			disallowBatterySaverRadio,
			batterySaverDelete,
			batterySaverEdit,
			batterySaverUndo
	);

	@FindBy(xpath = "//label[@for=\"secure-keyboard\"]")
	private WebElement allowSecureKeyboardLabel;

	@FindBy(id = "secure-keyboard")
	private WebElement allowSecureKeyboardRadio;

	@FindBy(id = "delete_setting_slnkDeviceSettingsSecureKeyboard")
	private WebElement secureKeyboardDelete;

	@FindBy(id = "edit_setting_slnkDeviceSettingsSecureKeyboard")
	private WebElement secureKeyboardEdit;

	@FindBy(id = "undo_setting_slnkDeviceSettingsSecureKeyboard")
	private WebElement secureKeyboardUndo;

	public ConfigPageField allowSecureKeyboardField = new ConfigPageField(
			SECURE_KEYBOARD,
			allowSecureKeyboardLabel,
			allowSecureKeyboardRadio,
			secureKeyboardDelete,
			secureKeyboardEdit,
			secureKeyboardUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-secure-keyboard\"]")
	private WebElement disallowSecureKeyboardLabel;

	@FindBy(id = "disable-secure-keyboard")
	private WebElement disallowSecureKeyboardRadio;

	public ConfigPageField disallowSecureKeyboardField = new ConfigPageField(
			SECURE_KEYBOARD,
			disallowSecureKeyboardLabel,
			disallowSecureKeyboardRadio,
			secureKeyboardDelete,
			secureKeyboardEdit,
			secureKeyboardUndo
	);

	@FindBy(xpath = "//label[@for=\"google-voice-typing\"]")
	private WebElement allowGoogleVoiceTypingLabel;

	@FindBy(id = "google-voice-typing")
	private WebElement allowGoogleVoiceTypingRadio;

	@FindBy(id = "delete_setting_slnkDeviceSettingsGoogleVoiceTyping")
	private WebElement googleVoiceTypingDelete;

	@FindBy(id = "edit_setting_slnkDeviceSettingsGoogleVoiceTyping")
	private WebElement googleVoiceTypingEdit;

	@FindBy(id = "undo_setting_slnkDeviceSettingsGoogleVoiceTyping")
	private WebElement googleVoiceTypingUndo;

	public ConfigPageField allowGoogleVoiceTypingField = new ConfigPageField(
			VOICE_TYPING,
			allowGoogleVoiceTypingLabel,
			allowGoogleVoiceTypingRadio,
			googleVoiceTypingDelete,
			googleVoiceTypingEdit,
			googleVoiceTypingUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-google-voice-typing\"]")
	private WebElement disallowGoogleVoiceTypingLabel;

	@FindBy(id = "disable-google-voice-typing")
	private WebElement disallowGoogleVoiceTypingRadio;

	public ConfigPageField disallowGoogleVoiceTypingField = new ConfigPageField(
			VOICE_TYPING,
			disallowGoogleVoiceTypingLabel,
			disallowGoogleVoiceTypingRadio,
			googleVoiceTypingDelete,
			googleVoiceTypingEdit,
			googleVoiceTypingUndo
	);

	@FindBy(id = "time-to-sleep")
	private WebElement timeToSleepMenu;

	@FindBy(id = "delete_setting-time-to-sleep")
	private WebElement timeToSleepDelete;

	@FindBy(id = "edit_setting-time-to-sleep")
	private WebElement timeToSleepEdit;

	@FindBy(id = "undo_setting-time-to-sleep")
	private WebElement timeToSleepUndo;

	public ConfigPageField timeToSleepField = new ConfigPageField(
			INACTIVITY_SLEEP,
			null,
			timeToSleepMenu,
			timeToSleepDelete,
			timeToSleepEdit,
			timeToSleepUndo
	);

	@FindBy(id = "enable-dialpad-tones")
	private WebElement enableDialPadTonesMenu;

	@FindBy(id = "delete_setting-enable-dialpad-tones")
	private WebElement dialPadTonesDelete;

	@FindBy(id = "edit_setting-enable-dialpad-tones")
	private WebElement dialPadTonesEdit;

	@FindBy(id = "undo_setting-enable-dialpad-tones")
	private WebElement dialPadTonesUndo;

	public ConfigPageField enableDialPadTonesField = new ConfigPageField(
			DIALPAD_TONES,
			null,
			enableDialPadTonesMenu,
			dialPadTonesDelete,
			dialPadTonesEdit,
			dialPadTonesUndo
	);

	@FindBy(id = "enable-touch-sounds")
	private WebElement enableTouchSoundsMenu;

	@FindBy(id = "delete_setting-enable-touch-sounds")
	private WebElement touchSoundsDelete;

	@FindBy(id = "edit_setting-enable-touch-sounds")
	private WebElement touchSoundsEdit;

	@FindBy(id = "undo_setting-enable-touch-sounds")
	private WebElement touchSoundsUndo;

	public ConfigPageField enableTouchSoundsField = new ConfigPageField(
			TOUCH_SOUNDS,
			null,
			enableTouchSoundsMenu,
			touchSoundsDelete,
			touchSoundsEdit,
			touchSoundsUndo
	);

	@FindBy(id = "enable-vibrate-on-tap")
	private WebElement enableVibrateOnTapMenu;

	@FindBy(id = "delete_setting-enable-vibrate-on-tap")
	private WebElement vibrateOnTapDelete;

	@FindBy(id = "edit_setting-enable-vibrate-on-tap")
	private WebElement vibrateOnTapEdit;

	@FindBy(id = "undo_setting-enable-vibrate-on-tap")
	private WebElement vibrateOnTapUndo;

	public ConfigPageField enableVibrateOnTapField = new ConfigPageField(
			VIBRATE_TAP,
			null,
			enableVibrateOnTapMenu,
			vibrateOnTapDelete,
			vibrateOnTapEdit,
			vibrateOnTapUndo
	);

	@FindBy(id = "enable_amber_alerts")
	private WebElement enableAmberAlertsMenu;

	@FindBy(id = "delete_setting-enable_amber_alerts")
	private WebElement amberAlertsDelete;

	@FindBy(id = "edit_setting-enable_amber_alerts")
	private WebElement amberAlertsEdit;

	@FindBy(id = "undo_setting-enable_amber_alerts")
	private WebElement amberAlertsUndo;

	public ConfigPageField enableAmberAlertsField = new ConfigPageField(
			AMBER_ALERTS,
			null,
			enableAmberAlertsMenu,
			amberAlertsDelete,
			amberAlertsEdit,
			amberAlertsUndo
	);

	@FindBy(id = "enable_extreme_threats")
	private WebElement enableExtremeThreatsMenu;

	@FindBy(id = "delete_setting-enable_extreme_threats")
	private WebElement extremeThreatsDelete;

	@FindBy(id = "edit_setting-enable_extreme_threats")
	private WebElement extremeThreatsEdit;

	@FindBy(id = "undo_setting-enable_extreme_threats")
	private WebElement extremeThreatsUndo;

	public ConfigPageField enableExtremeThreatsField = new ConfigPageField(
			EXTREME_THREATS,
			null,
			enableExtremeThreatsMenu,
			extremeThreatsDelete,
			extremeThreatsEdit,
			extremeThreatsUndo
	);

	@FindBy(id = "enable_severe_threats")
	private WebElement enableSevereThreatsMenu;

	@FindBy(id = "delete_setting-enable_severe_threats")
	private WebElement severeThreatsDelete;

	@FindBy(id = "edit_setting-enable_severe_threats")
	private WebElement severeThreatsEdit;

	@FindBy(id = "undo_setting-enable_severe_threats")
	private WebElement severeThreatsUndo;

	public ConfigPageField enableSevereThreatsField = new ConfigPageField(
			SEVERE_THREATS,
			null,
			enableSevereThreatsMenu,
			severeThreatsDelete,
			severeThreatsEdit,
			severeThreatsUndo
	);

	@FindBy(id = "enable_jump_to_camera")
	private WebElement enableJumpToCameraMenu;

	@FindBy(id = "delete_setting-enable_jump_to_camera")
	private WebElement jumpToCameraDelete;

	@FindBy(id = "edit_setting-enable_jump_to_camera")
	private WebElement jumpToCameraEdit;

	@FindBy(id = "undo_setting-enable_jump_to_camera")
	private WebElement jumpToCameraUndo;

	public ConfigPageField enableJumpToCameraField = new ConfigPageField(
			JUMP_TO_CAMERA,
			null,
			enableJumpToCameraMenu,
			jumpToCameraDelete,
			jumpToCameraEdit,
			jumpToCameraUndo
	);

	@FindBy(xpath = "//label[@for=\"enable_wifi_calling\"]")
	private WebElement allowWifiVolteCallingLabel;

	@FindBy(id = "enable_wifi_calling")
	private WebElement allowWifiVolteCallingRadio;

	@FindBy(id = "delete_setting_slnkDeviceSettingsWifiCalling")
	private WebElement wifiVolteCallingDelete;

	@FindBy(id = "edit_setting_slnkDeviceSettingsWifiCalling")
	private WebElement wifiVolteCallingEdit;

	@FindBy(id = "undo_setting_slnkDeviceSettingsWifiCalling")
	private WebElement wifiVolteCallingUndo;

	public ConfigPageField allowWifiVolteCallingField = new ConfigPageField(
			ENABLE_WIFI_VOLTE_CALLING,
			allowWifiVolteCallingLabel,
			allowWifiVolteCallingRadio,
			wifiVolteCallingDelete,
			wifiVolteCallingEdit,
			wifiVolteCallingUndo
	);

	@FindBy(xpath = "//label[@for=\"disable-enable_wifi_calling\"]")
	private WebElement disallowWifiVolteCallingLabel;

	@FindBy(id = "disable-enable_wifi_calling")
	private WebElement disallowWifiVolteCallingRadio;

	public ConfigPageField disallowWifiVolteCallingField = new ConfigPageField(
			ENABLE_WIFI_VOLTE_CALLING,
			disallowWifiVolteCallingLabel,
			disallowWifiVolteCallingRadio,
			wifiVolteCallingDelete,
			wifiVolteCallingEdit,
			wifiVolteCallingUndo
	);

	public SamDeviceSettingsPage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(enableDeviceSettingsField.getTitle(), enableDeviceSettingsField);
				put(allowWifiToggleField.getTitle(), allowWifiToggleField);
				put("allow" + allowWifiToggleField.getTitle(), allowWifiToggleField);
				put("disallow" + disallowWifiToggleField.getTitle(), disallowWifiToggleField);
				put(allowAirplaneModeToggleField.getTitle(), allowAirplaneModeToggleField);
				put("allow" + allowAirplaneModeToggleField.getTitle(), allowAirplaneModeToggleField);
				put("disallow" + disallowAirplaneModeToggleField.getTitle(), disallowAirplaneModeToggleField);
				put(allowSettingsTilesField.getTitle(), allowSettingsTilesField);
				put("allow" + allowSettingsTilesField.getTitle(), allowSettingsTilesField);
				put("disallow" + disallowSettingsTilesField.getTitle(), disallowSettingsTilesField);
				put(allowDndModeToggleField.getTitle(), allowDndModeToggleField);
				put("allow" + allowDndModeToggleField.getTitle(), allowDndModeToggleField);
				put("disallow" + disallowDndModeToggleField.getTitle(), disallowDndModeToggleField);
				put(allowNotificationShadeField.getTitle(), allowNotificationShadeField);
				put("allow" + allowNotificationShadeField.getTitle(), allowNotificationShadeField);
				put("disallow" + disallowNotificationShadeField.getTitle(), disallowNotificationShadeField);
				put(allowTimezoneConfigField.getTitle(), allowTimezoneConfigField);
				put("allow" + allowTimezoneConfigField.getTitle(), allowTimezoneConfigField);
				put("disallow" + disallowTimezoneConfigField.getTitle(), disallowTimezoneConfigField);
				put(allowTimeFormatConfigField.getTitle(), allowTimeFormatConfigField);
				put("allow" + allowTimeFormatConfigField.getTitle(), allowTimeFormatConfigField);
				put("disallow" + disallowTimeFormatConfigField.getTitle(), disallowTimeFormatConfigField);
				put(allowAutoTimezoneConfigField.getTitle(), allowAutoTimezoneConfigField);
				put("allow" + allowAutoTimezoneConfigField.getTitle(), allowAutoTimezoneConfigField);
				put("disallow" + disallowAutoTimezoneConfigField.getTitle(), disallowAutoTimezoneConfigField);
				put(ntpServerAddressField.getTitle(), ntpServerAddressField);
				put(timezoneField.getTitle(), timezoneField);
				put(timeFormatField.getTitle(), timeFormatField);
				put(allowAutoTimezoneField.getTitle(), allowAutoTimezoneField);
				put("yes" + allowAutoTimezoneField.getTitle(), allowAutoTimezoneField);
				put("no" + disallowAutoTimezoneField.getTitle(), disallowAutoTimezoneField);
				put(displayDeviceInfoEnableField.getTitle(), displayDeviceInfoEnableField);
				put("yes" + displayDeviceInfoEnableField.getTitle(), displayDeviceInfoEnableField);
				put("no" + displayDeviceInfoDisableField.getTitle(), displayDeviceInfoDisableField);
				put(deviceInfo1Field.getTitle(), deviceInfo1Field);
				put(deviceInfo2Field.getTitle(), deviceInfo2Field);
				put(deviceInfo3Field.getTitle(), deviceInfo3Field);
				put(deviceInfo4Field.getTitle(), deviceInfo4Field);
				put(deviceInfo4Field.getTitle(), deviceInfo4Field);
				put(deviceNameField.getTitle(), deviceNameField);
				put(whitelistField.getTitle(), whitelistField);
				put(allowBatterySaverField.getTitle(), allowBatterySaverField);
				put("allow" + allowBatterySaverField.getTitle(), allowBatterySaverField);
				put("disallow" + disallowBatterySaverField.getTitle(), disallowBatterySaverField);
				put(allowSecureKeyboardField.getTitle(), allowSecureKeyboardField);
				put("allow" + allowSecureKeyboardField.getTitle(), allowSecureKeyboardField);
				put("disallow" + disallowSecureKeyboardField.getTitle(), disallowSecureKeyboardField);
				put(allowGoogleVoiceTypingField.getTitle(), allowGoogleVoiceTypingField);
				put("allow" + allowGoogleVoiceTypingField.getTitle(), allowGoogleVoiceTypingField);
				put("disallow" + disallowGoogleVoiceTypingField.getTitle(), disallowGoogleVoiceTypingField);
				put(timeToSleepField.getTitle(), timeToSleepField);
				put(enableDialPadTonesField.getTitle(), enableDialPadTonesField);
				put(enableTouchSoundsField.getTitle(), enableTouchSoundsField);
				put(enableVibrateOnTapField.getTitle(), enableVibrateOnTapField);
				put(enableAmberAlertsField.getTitle(), enableAmberAlertsField);
				put(enableExtremeThreatsField.getTitle(), enableExtremeThreatsField);
				put(enableSevereThreatsField.getTitle(), enableSevereThreatsField);
				put(enableJumpToCameraField.getTitle(), enableJumpToCameraField);
				put(allowWifiVolteCallingField.getTitle(), allowWifiVolteCallingField);
				put("allow" + allowWifiVolteCallingField.getTitle(), allowWifiVolteCallingField);
				put("disallow" + disallowWifiVolteCallingField.getTitle(), disallowWifiVolteCallingField);
			}
		};
	}
}
