package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BarcodeStrings.*;

public class BarcodeUi extends AppiumUi{

    @AndroidFindBy(id = "com.spectralink.example.barcode:id/barcodeScannerSwitch")
    private WebElement enableBarcodeScanner;

    public ConfigUiField enableBarcodeScannerField = new ConfigUiField(
            driver,
            ENABLE_BARCODE_SCANNER,
            enableBarcodeScanner,
            enableBarcodeScanner,
            null
    );

    @AndroidFindBy(id = "com.spectralink.example.barcode:id/keyboardInputSwitch")
    private WebElement enableScannerKeyboardInput;

    public ConfigUiField enableScannerKeyboardInputField = new ConfigUiField(
            driver,
            ENABLE_SCANNER_KEYBOARD_INPUT,
            enableScannerKeyboardInput,
            enableScannerKeyboardInput,
            null
    );

    @AndroidFindBy(id = "com.spectralink.example.barcode:id/keyboardInputTextView")
    public WebElement keyboardInput;

    public ConfigUiField keyboardInputField = new ConfigUiField(
            driver,
            KEYBOARD_INPUT,
            keyboardInput,
            keyboardInput,
            null
    );

    @AndroidFindBy(id = "com.spectralink.example.barcode:id/barcodeDataTextView")
    private WebElement scannedBarcodeData;

    public ConfigUiField scannedBarcodeDataField = new ConfigUiField(
            driver,
            SCANNED_BARCODE_DATA,
            scannedBarcodeData,
            scannedBarcodeData,
            null
    );

    @AndroidFindBy(id = "com.spectralink.example.barcode:id/barcodeStateTextView")
    private WebElement barcodeScannerState;

    public ConfigUiField barcodeScannerStateField = new ConfigUiField(
            driver,
            BARCODE_SCANNER_STATE,
            barcodeScannerState,
            barcodeScannerState,
            null
    );

    @AndroidFindBy(id = "com.spectralink.example.barcode:id/clearButton")
    private WebElement clearButton;

    public ConfigUiField clearButtonField = new ConfigUiField(
            driver,
            CLEAR_BUTTON,
            clearButton,
            clearButton,
            null
    );

    @AndroidFindBy(id = "com.spectralink.example.barcode:id/fab")
    private WebElement barcodeButton;

    public ConfigUiField barcodeButtonField = new ConfigUiField(
            driver,
            BARCODE_BUTTON,
            barcodeButton,
            barcodeButton,
            null
    );

    public BarcodeUi (AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(BARCODE_BUTTON.title().toLowerCase(), barcodeButtonField);
                put(CLEAR_BUTTON.title().toLowerCase(), clearButtonField);
                put(BARCODE_SCANNER_STATE.title().toLowerCase(), barcodeScannerStateField);
                put(SCANNED_BARCODE_DATA.title().toLowerCase(), scannedBarcodeDataField);
                put(KEYBOARD_INPUT.title().toLowerCase(), keyboardInputField);
                put(ENABLE_BARCODE_SCANNER.title().toLowerCase(), enableBarcodeScannerField);
                put(ENABLE_SCANNER_KEYBOARD_INPUT.title().toLowerCase(), enableScannerKeyboardInputField);
            }
        };
    }

    public String keyBoardInput() {
        return keyboardInput.getText();
    }

    public String scannedBarcodeData() {
        return scannedBarcodeData.getText();
    }

    public String barcodeScannedState() {
        return barcodeScannerState.getText();
    }

    public void scanData() {
        barcodeButton.click();
    }

    public void clearKeyboardInput() {
        clearButton.click();
    }

}
