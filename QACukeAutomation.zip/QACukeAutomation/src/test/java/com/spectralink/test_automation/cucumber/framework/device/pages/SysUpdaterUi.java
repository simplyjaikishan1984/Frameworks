package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.SysUpdaterStrings.*;

public class SysUpdaterUi extends AppiumUi {

    @AndroidFindBy(xpath = "//android.view.ViewGroup[(@resource-id ='com.spectralink.slnkota:id/toolbar')]/android.widget.TextView")
    private WebElement appNameLabel;

    public ConfigUiField appNameField = new ConfigUiField(
            driver,
            APP_NAME,
            appNameLabel,
            null,
            appNameLabel
    );

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    public ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            overflowButton,
            overflowButton,
            null
    );

    @AndroidFindBy(id = "com.spectralink.slnkota:id/imageView")
    private WebElement logoImage;

    public ConfigUiField logoField = new ConfigUiField(
            driver,
            SYS_UPDATER_LOGO,
            logoImage,
            null,
            null
    );

    @AndroidFindBy(id = "com.spectralink.slnkota:id/currentVersionText")
    private WebElement currentVersionLabel;

    @AndroidFindBy(id = "com.spectralink.slnkota:id/currentVersionNumber")
    private WebElement currentVersionValue;

    public ConfigUiField currentVersionField = new ConfigUiField(
            driver,
            CURRENT_VERSION,
            currentVersionLabel,
            null,
            currentVersionValue
    );

    @AndroidFindBy(id = "com.spectralink.slnkota:id/updateAvailableText")
    private WebElement updateAvailableLabel;

    @AndroidFindBy(id = "com.spectralink.slnkota:id/updateVersionNumber")
    private WebElement updateAvailableValue;

    public ConfigUiField updateAvailableField = new ConfigUiField(
            driver,
            AVAILABLE_VERSION,
            updateAvailableLabel,
            null,
            updateAvailableValue
    );

    @AndroidFindBy(id = "com.spectralink.slnkota:id/errorMessage")
    private WebElement errorMessageValue;

    public ConfigUiField errorMessageField = new ConfigUiField(
            driver,
            SYSTEM_UPDATE,
            errorMessageValue,
            null,
            errorMessageValue
    );

    @AndroidFindBy(id = "com.spectralink.slnkota:id/button_check_update")
    private WebElement checkUpdateButton;

    public ConfigUiField checkUpdateField = new ConfigUiField(
            driver,
            CHECK_BUTTON,
            null,
            checkUpdateButton,
            checkUpdateButton
    );

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[1]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/title')]")
    private WebElement serverAddressLabel;

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[1]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/summary')]")
    private WebElement serverAddressValue;

    public ConfigUiField serverAddressField = new ConfigUiField(
            driver,
            SERVER_ADDRESS,
            serverAddressLabel,
            null,
            serverAddressValue
    );

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/title')]")
    private WebElement serverPortLabel;

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/summary')]")
    private WebElement serverPortValue;

    public ConfigUiField serverPortField = new ConfigUiField(
            driver,
            SERVER_PORT,
            serverPortLabel,
            null,
            serverPortValue
    );

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[3]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/title')]")
    private WebElement relativePathLabel;

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[3]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/summary')]")
    private WebElement relativePathValue;

    public ConfigUiField relativePathField = new ConfigUiField(
            driver,
            OTA_PATH,
            relativePathLabel,
            null,
            relativePathValue
    );

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[4]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/title')]")
    private WebElement protocolLabel;

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[4]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/summary')]")
    private WebElement protocolValue;

    public ConfigUiField protocolField = new ConfigUiField(
            driver,
            PROTOCOL,
            protocolLabel,
            null,
            protocolValue
    );

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[5]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/title')]")
    private WebElement pollingLabel;

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[5]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/summary')]")
    private WebElement pollingValue;

    public ConfigUiField pollingField = new ConfigUiField(
            driver,
            POLLING_INTERVAL,
            pollingLabel,
            null,
            pollingValue
    );

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[5]/android.widget.RelativeLayout/android.widget.TextView[(@resource-id ='android:id/title')]")
    private WebElement meteredNetworkLabel;

    @AndroidFindBy(xpath = "//android.widget.ListView/android.widget.LinearLayout[5]/android.widget.LinearLayout/android.widget.Switch[(@resource-id ='android:id/switch_widget')]")
    private WebElement meteredNetworkControl;

    public ConfigUiField meteredNetworkField = new ConfigUiField(
            driver,
            METERED_NETWORK,
            meteredNetworkLabel,
            meteredNetworkControl,
            null
    );

    @AndroidFindBy(accessibility = "Navigate up")
    private WebElement backButton;

    public ConfigUiField backButtonField = new ConfigUiField(
            driver,
            BACK_ARROW,
            backButton,
            backButton,
            null
    );

    @AndroidFindBy(id = "android:id/alertTitle")
    private WebElement editBoxLabel;

    @AndroidFindBy(id = "android:id/edit")
    private WebElement editBoxValue;

    public ConfigUiField editBoxField = new ConfigUiField(
            driver,
            EDIT_BOX,
            editBoxLabel,
            editBoxValue,
            editBoxValue
    );
    
    public SysUpdaterUi(AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(appNameField.getKey().toLowerCase(), appNameField);
                put(overflowButtonField.getKey().toLowerCase(), overflowButtonField);
                put(logoField.getKey().toLowerCase(), logoField);
                put(currentVersionField.getKey().toLowerCase(), currentVersionField);
                put(updateAvailableField.getKey().toLowerCase(), updateAvailableField);
                put(errorMessageField.getKey().toLowerCase(), errorMessageField);
                put(checkUpdateField.getKey().toLowerCase(), checkUpdateField);
                put(serverAddressField.getKey().toLowerCase(), serverAddressField);
                put(serverPortField.getKey().toLowerCase(), serverPortField);
                put(relativePathField.getKey().toLowerCase(), relativePathField);
                put(protocolField.getKey().toLowerCase(), protocolField);
                put(pollingField.getKey().toLowerCase(), pollingField);
                put(meteredNetworkField.getKey().toLowerCase(), meteredNetworkField);
                put(backButtonField.getKey().toLowerCase(), backButtonField);
                put(editBoxField.getKey().toLowerCase(), editBoxField);
            }
        };
    }

    public void tapOverflowMenu() {
        overflowButtonField.tap();
        Util.sleepSeconds(2);
    }

    public void getNotifications() {
        overflowButtonField.tap();
        Util.sleepSeconds(2);
    }

    public void navigateBackOneScreen() {
        backButton.click();
    }

    public void dismissApp() {
        backButton.click();
    }

}
