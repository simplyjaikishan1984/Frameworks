package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.SafeUi;
import io.appium.java_client.TouchAction;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.SAFE;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BizPhoneStrings.EDIT_TEXT;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.SafeStrings.*;
import static io.appium.java_client.touch.offset.PointOption.point;

public class DeviceSafeSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @When("^I tap the Safe \"([^\"]*)\" on \"([^\"]*)\"$")
    public void tapSafeObject(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        ConfigUiField field = safeUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(SAFE, arg1.trim());

        if (field != null) {
            if (field.hasLabelElement()) {
                assert heading != null;
                field.scrollIntoView(heading);
                if (field.isLabelPresent()) {
                    field.tap();
                } else {
                    log.error("Field '{}' has no label", arg1);
                }
            } else if (field.hasControlElement())
                field.tap();
            else {
                log.error("Field '{}' has no control", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I set the Safe \"([^\"]*)\" switch to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setSafeSwitch(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        ConfigUiField field = safeUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(SAFE, arg1.trim());
        if (field != null) {
            if (field.hasLabelElement()) {
                assert heading != null;
                field.scrollIntoView(heading);
            }
            if (!field.getControlElement().getText().toLowerCase().contentEquals(arg2.trim().toLowerCase())) {
                field.tap();
            } else {
                log.debug("Field '{}' was already set to '{}'", arg1, arg2);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I select \"([^\"]*)\" from the Safe tone menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectToneSafeMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        ConfigUiField field = null;
        switch (arg2.trim().toLowerCase()) {
            case "alarm tone":
                field = safeUi.getField(ALARM_TONE);
                break;
            case "warning tone":
                field = safeUi.getField(WARNING_TONE);
                break;
        }
        boolean warning = arg2.trim().toLowerCase().contains("warning");
        if (field != null) {
            if(warning)
                field.scrollIntoView(WARNING_TONE);
            else
                field.scrollIntoView(ALARM_TONE);
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectScrollableMenuOption(arg1.trim());
                if (found) {
                    safeUi.tapOkButton();
                    log.debug("Selected menu option '{}'", arg1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                    safeUi.tapCancelButton();
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg2, arg1);
            }
        } else {
            if(warning)
                log.error("No matching field with title '{}'", WARNING_TONE.title());
            else
                log.error("No matching field with title '{}'", ALARM_TONE.title());
        }
    }

    @When("^I select \"([^\"]*)\" from the Safe menu \"([^\"]*)\" sensitivity on \"([^\"]*)\"$")
    public void selectThresholdSafeMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        ConfigUiField field = null;
        switch (arg2.trim().toLowerCase()) {
            case "no movement":
                field = safeUi.getField(NO_MOVEMENT_SENSITIVITY);
                break;
            case "tilt":
                field = safeUi.getField(TILT_SENSITIVITY);
                break;
            case "running":
                field = safeUi.getField(RUNNING_SENSITIVITY);
                break;
        }
        if (field != null) {
            switch (arg2.trim().toLowerCase()) {
                case "no movement":
                    field.scrollIntoView(NO_MOVEMENT_SENSITIVITY);
                    break;
                case "tilt":
                    field.scrollIntoView(TILT_SENSITIVITY);
                    break;
                case "running":
                    field.scrollIntoView(RUNNING_SENSITIVITY);
                    break;
            }
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
                if (found) {
                    log.debug("Selected menu option '{}'", arg1);
                    sleepSeconds(1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg2, arg1);
            }
        } else {
            switch (arg2.trim().toLowerCase()) {
                case "no movement":
                    log.error("No matching field with title '{}'", NO_MOVEMENT_SENSITIVITY.title());
                    break;
                case "tilt":
                    log.error("No matching field with title '{}'", TILT_SENSITIVITY.title());
                    break;
                case "running":
                    log.error("No matching field with title '{}'", RUNNING_SENSITIVITY.title());
                    break;
            }
        }
    }

    @When("^I select \"([^\"]*)\" from the Safe menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectSafeMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        ConfigUiField field = safeUi.getField(arg2);
        if (field != null) {
            field.scrollIntoViewAttribute(arg2);
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
                if (found) {
                    log.debug("Selected menu option '{}'", arg1);
                    sleepSeconds(1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg2, arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg2);
        }

    }

    @When("^I enter \"([^\"]*)\" into the Safe edit box on \"([^\"]*)\"$")
    public void enterInEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        ConfigUiField field = safeUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = safeUi.getField(EDIT_TEXT);
            field.enter(arg1.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg2);
        }
    }

    @When("^I select \"([^\"]*)\" from the Safe overflow menu on \"([^\"]*)\"$")
    public void selectOverflowOption(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        ConfigUiField field = safeUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isLabelPresent()) {
            field.tap();
            found = field.selectTextMenuOption(arg1.trim());
            if (found) {
                log.debug("Selected menu option '{}'", arg1);
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @Then("^the Safe \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifySafeValue(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        ConfigUiField field = safeUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(SAFE, arg1.trim());
        if (field.hasLabelElement()) {
            assert heading != null;
            field.scrollIntoView(heading);
        }
        if (field.isValuePresent()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT Safe FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^I verify \"([^\"]*)\" Alarm screen on \"([^\"]*)\"$")
    public void  verifyAlarmScreenElements(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        SafeUi safeUi = phone.getSafeUi();
        switch (arg1.trim()) {
            case "NO MOVEMENT":
                Assert.assertEquals(safeUi.getAlarmType(),"NO MOVEMENT");
                break;
            case "PANIC":
                Assert.assertEquals(safeUi.getAlarmType(),"PANIC");
                break;
            default:
                Assert.assertEquals(safeUi.getAlarmType(),"TILT");
                break;
        }
        if (!safeUi.getEventType().equals("ALARM"))
            Assert.fail("Did not find 'ALARM' Text");
        safeUi.getAlarmTimer();
        if (!safeUi.getCancelText().equals("SWIPE TO CANCEL ALARM"))
            Assert.fail("Did not find Cancel Text");

    }

    @Then("^I verify \"([^\"]*)\" Warning screen on \"([^\"]*)\"$")
    public void verifyWarningScreenElements(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        SafeUi safeUi = phone.getSafeUi();

        switch (arg1.trim()) {
            case "NO MOVEMENT":
                Assert.assertEquals(safeUi.getAlarmType(),"NO MOVEMENT");
                break;
            case "TILT":
                Assert.assertEquals(safeUi.getAlarmType(),"TILT");
                break;
        }
        if (!safeUi.getEventType().equals("WARNING"))
            Assert.fail("Did not find 'WARNING' Text");
        safeUi.getAlarmTimer();
        if (!safeUi.getCancelText().equals("SWIPE TO CANCEL ALARM ACTIVATION"))
            Assert.fail("Did not find Cancel Text");

    }

    @When("^I terminate alarm on \"([^\"]*)\"$")
    public void terminateAlarm(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        SafeUi safeUi = phone.getSafeUi();
        Point position = safeUi.getTerminateAlarmIconPosition();
        log.info("Terminating Alarm");
        new TouchAction(phone.appium()).press(point(position.getX()-100, position.getY())).waitAction().moveTo(point(position.getX()+100, position.getY())).release().perform();
    }

    @When("^I trigger panic button on \"([^\"]*)\"$")
    public void clickPanicButton(String arg1){
        VersityPhone phone = Environment.getPhone(arg1.trim());
        sleepSeconds(2);
        SafeUi safeUi = phone.getSafeUi();
        Point position = safeUi.getPanicButtonIconPosition();
        new TouchAction(phone.appium()).longPress(point(position.getX(), position.getY())).perform();
    }

    @When("^I start snoozing on \"([^\"]*)\"$")
    public void startSnooze(String arg1){
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        WebElement snooze = phone.appium().findElementByAccessibilityId("Notification summary");
        if(snooze.getText().contains("Start snoozing"))
            snooze.click();
    }

    @When("^I stop snoozing on \"([^\"]*)\"$")
    public void stopSnooze(String arg1){
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        WebElement snooze = phone.appium().findElementByAccessibilityId("Notification summary");
        if(snooze.getText().contains("Stop snoozing"))
            snooze.click();
    }

    @When("^I enter \"([^\"]*)\"'s extension number into the Safe edit box on \"([^\"]*)\"$")
    public void enterIntoEditText(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg2.trim());
        VersityPhone phone2 = Environment.getPhone(arg1.trim());
        SafeUi safeUi = phone1.getSafeUi();
        ConfigUiField field = safeUi.getField(EDIT_TEXT);
        log.debug("Entering: "+ phone2.callServerDetails().extensionReg1 + " into edit text box");
        field.enter(phone2.callServerDetails().extensionReg1);
    }

    @Then("^I verify Emergency call should trigger after alarm timeout time \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyEmergencyCall(String arg1, String arg2){
        VersityPhone phone = Environment.getPhone(arg2.trim());
        int alarmTimeout = Integer.parseInt(arg1);
        assert phone != null;
        sleepSeconds(alarmTimeout-2);
        log.debug("Current screen on " + arg2 + " is: " + phone.getForegroundActivity());
        if(!phone.getForegroundActivity().equals("com.spectralink.SlnkSafe.SlnkSafeAlertActivity"))
            Environment.softAssert().fail("Alarm screen not found");
        if(phone.ciscoPhoneContentProvider().getCallIdIncomingOutgoingCall() != null) {
            Environment.softAssert().fail("Emergency call has triggered before alarm timeout");
        }
        sleepSeconds(2);
    }

}
