package com.spectralink.test_automation.cucumber.framework.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;

public class CSVStructuredFile<E extends Enum<E> & CSVHeading> {

    private Logger log = LogManager.getLogger(this.getClass().getName());
    private final String DELIMITER = ",";
    private final String NEW_LINE_SEPARATOR = "\n";
    private File inputCsvFile;
    private File outputCsvFile;
    private boolean includeHeadings = false;
    private Class<E> enumType;
    private List<E> headings = new ArrayList<>();
    private List<EnumMap<E, String>> lines = new ArrayList<>();

    public CSVStructuredFile(Class<E> enumType, File inputFile) {
        this.enumType = enumType;
        this.inputCsvFile = inputFile;
    }

    public CSVStructuredFile(Class<E> enumType) {
        this.enumType = enumType;
    }

    public void includeOutputHeadings(boolean includeHeadings) {
        this.includeHeadings = includeHeadings;
    }

    public void setHeadings(E ... eachHeading) {
        headings.clear();
        lines.clear();
        for (E heading : eachHeading) {
            headings.add(heading);
        }
    }

    public List<E> getHeadings() {
        return headings;
    }

    public boolean headingExists(E heading) {
        for (E thisHeading : getHeadings()) {
            if (thisHeading.equals(heading)) {
                return true;
            }
        }
        return false;
    }

    public List<String> getHeadingTitles() {
        List<String> titles = new ArrayList<>();
        for (int headingIndex = 0; headingIndex < headings.size(); headingIndex++) {
            titles.add(headings.get(headingIndex).getTitle());
        }
        return titles;
    }

    public E getHeading(String text) {
        for (E heading : headings) {
            if (heading.getTitle().contains(text)) {
                return heading;
            }
        }
        return null;
    }

    public CSVStructuredFile addColumn(E heading) {
        headings.add(heading);
        return this;
    }

    public void deleteColumn(E heading) {
        for (E existingHeading : headings) {
            if (existingHeading.equals(heading)) {
                headings.remove(heading);

                for (EnumMap<E, String> cells : lines) {
                    if (cells.containsKey(heading)) {
                        cells.remove(heading);
                    }
                }
                break;
            }
        }
    }

    public int addRow() {
        lines.add(new EnumMap<>(enumType));
        return lines.size() - 1;
    }

    public void deleteRow(int rowIndex) {
        if (lines.size() > rowIndex) {
            lines.remove(rowIndex);
        }
    }

    public int getRowCount() {
        return lines.size();
    }

    public void setCellInRow(int rowIndex, E heading, String value) {
        if (lines.size() > rowIndex) {
            lines.get(rowIndex).put(heading, value);
        }
    }

    public String getCellValueInRow(int rowIndex, E heading) {
        if (rowIndex < lines.size() && lines.get(rowIndex).containsKey(heading)) {
            return lines.get(rowIndex).get(heading);
        } else {
            return "";
        }
    }

    public int findRowWithValue(E heading, String searchValue) {
        for (int rowIndex = 0; rowIndex < lines.size(); rowIndex++) {
            if (lines.get(rowIndex).get(heading).contains(searchValue)) {
                return rowIndex;
            }
        }
        return -1;
    }

    public EnumMap<E, String> getRow(int lineIndex) {
        return lines.get(lineIndex);
    }

    public List<String> getRowValues(int lineIndex) {
        if (lines.size() > lineIndex) {
            List<String> values = new ArrayList<>();
            EnumMap<E, String> targetLine = getRow(lineIndex);
            for (int headingIndex = 0; headingIndex < headings.size(); headingIndex++) {
                values.add(targetLine.get(headings.get(headingIndex)));
            }
            return values;
        } else {
            return null;
        }
    }

    public E getKeyFromHeading(String text) {
        for (E heading : enumType.getEnumConstants()) {
            if (heading.getTitle().contains(text)) {
                return heading;
            }
        }
        return null;
    }

    private boolean columnIsDefined(String text) {
        for (E heading : enumType.getEnumConstants()) {
            if (heading.getTitle().contains(text)) {
                return true;
            }
        }
        return false;
    }

    private void parseHeading(int lineNumber, String[] cells) {
        for (int cellIndex = 0; cellIndex < cells.length; cellIndex++) {
            E header = getKeyFromHeading(cells[cellIndex]);
            if (header != null) {
                addColumn(header);
            } else {
                log.error("Error parsing CSV file in line {}", (lineNumber + 1));
                log.error("'{}' is not a recognized heading", cells[cellIndex]);
            }
        }
    }

    private void parseData(int lineNumber, String[] cells) {
        if (cells.length <= headings.size()) {
            int newLine = addRow();
            for (int cellIndex = 0; cellIndex < cells.length; cellIndex++) {
                E heading = headings.get(cellIndex);
                if (heading != null) {
                    setCellInRow(newLine, heading, cells[cellIndex]);
                } else {
                    log.error("Error parsing CSV file in line {}", (lineNumber + 1));
                    log.error("Heading not defined for value {}", cells[cellIndex]);
                }
            }
        } else {
            log.error("Error parsing CSV file in line {}", (lineNumber + 1));
            log.error("Cells with no headings exist");
        }
    }

    public void parseFile() {
        if (inputCsvFile != null) {
            parseFile(inputCsvFile);
        } else {
            log.error( "Input CSV file was not set before calling parseFile()");
        }
    }

    public void parseFile(File inputFile) {
        BufferedReader reader;
        String eachLine;
        inputCsvFile = inputFile;
        try {
            reader = new BufferedReader(new FileReader(inputFile));
            int lineNumber = 0;
            headings.clear();
            lines.clear();
            while ((eachLine = reader.readLine()) != null) {
                if (!eachLine.trim().isEmpty() && !eachLine.matches("^\\s*#.*")) {
                    String[] cells = eachLine.trim().split("\\s*,\\s*");
                    if (lineNumber == 0 && columnIsDefined(cells[0])) {
                        parseHeading(lineNumber, cells);
                    } else {
                        parseData(lineNumber, cells);
                    }
                    lineNumber += 1;
                }
            }
            reader.close();
        } catch (IOException ioe) {
            log.error("Error opening file {}: {}", inputCsvFile.getPath(), ioe.getMessage());
        }
    }

    public Path getInputPath() {
        return inputCsvFile.toPath();
    }

    public void setOutputPath(Path outputPath) {
        this.outputCsvFile = outputPath.toFile();
    }

    public void setOutputFile(File outputFile) {
        this.outputCsvFile = outputFile;
    }

    public File getOutputCsvFile() {
        return outputCsvFile;
    }

    private String buildHeading() {
        StringBuilder builder = new StringBuilder();
        for (int headingIndex = 0; headingIndex < headings.size(); headingIndex++) {
            if (headingIndex != 0) builder.append(DELIMITER);
            builder.append(headings.get(headingIndex).getTitle());
        }
        builder.append(NEW_LINE_SEPARATOR);
        return builder.toString();
    }

    private String buildLine(int lineIndex) {
        if (lines.size() > lineIndex) {
            StringBuilder builder = new StringBuilder();
            for (int headingIndex = 0; headingIndex < headings.size(); headingIndex++) {
                if (headingIndex != 0) builder.append(DELIMITER);
                builder.append(getCellValueInRow(lineIndex, headings.get(headingIndex)));
            }
            builder.append(NEW_LINE_SEPARATOR);
            return builder.toString();
        } else {
            return null;
        }
    }

    public void writeFile(Path outputPath) {
        setOutputPath(outputPath);
        writeFile();
    }

    public void writeFile() {
        FileWriter fileWriter = null;
        String operation = outputCsvFile.exists() ? "Updated" : "Created";
        try {
            fileWriter = new FileWriter(outputCsvFile);
            if (includeHeadings) fileWriter.append(buildHeading());

            for (int lineIndex = 0; lineIndex < lines.size(); lineIndex++) {
                fileWriter.append(buildLine(lineIndex));
            }
        } catch (IOException ioe) {
            log.error("Error in writing file: {}", ioe.getMessage());
        } finally {
            if (fileWriter != null) {
                try {
                    fileWriter.flush();
                    fileWriter.close();
                    log.debug("{} CSV file {}", operation, outputCsvFile);
                } catch (IOException ioe) {
                    log.error("Error while flushing/closing fileWriter: {}", ioe.getMessage());
                }
            }
        }
    }

    public void deleteInputFile() {
        try {
            log.debug("Deleting file {}", inputCsvFile.getName());
            inputCsvFile.delete();
        } catch (Exception ioe) {
            log.error("Error while trying to delete file: " + ioe.toString());
        }
    }

    public void deleteOutputFile() {
        try {
            log.debug("Deleting file {}", outputCsvFile.getName());
            outputCsvFile.delete();
        } catch (Exception ioe) {
            log.error("Error while trying to delete file: " + ioe.toString());
        }
    }

    public void dumpFile() {
        StringBuilder builder = new StringBuilder();
        List<String> titles = getHeadingTitles();
        for (String title : titles) {
            builder.append(String.format("%20s", title));
        }
        log.debug(builder.toString());
        for (int lineIndex = 0; lineIndex < lines.size(); lineIndex++) {
            builder = new StringBuilder();
            List<String> values = getRowValues(lineIndex);
            for (String value : values) {
                builder.append(String.format("%20s", value));
            }
            log.debug(builder.toString());
        }
    }
}
