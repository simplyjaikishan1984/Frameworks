package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.BattLifeStrings.*;

public class SamBattLifePage extends SamConfigurationPage {

	@FindBy(id = "battLifeEnabled")
	private WebElement battlifeEnabledLabel;

	@FindBy(id = "batt_life_enabled")
	private WebElement battlifeEnabledCheckbox;

	@FindBy(id = "delete_setting_battLifeEnabled")
	private WebElement battlifeEnabledDelete;

	@FindBy(id = "edit_setting_battLifeEnabled")
	private WebElement battlifeEnabledEdit;

	public ConfigPageField battlifeEnabledField = new ConfigPageField(
			ENABLE_BATTERY_MONITORING,
			battlifeEnabledLabel,
			battlifeEnabledCheckbox,
			battlifeEnabledDelete,
			battlifeEnabledEdit
	);

	@FindBy(id = "vibrateEnabled")
	private WebElement vibrateLabel;

	@FindBy(id = "batt_life_vibrate")
	private WebElement vibrateCheckbox;

	@FindBy(id = "delete_setting_vibrateEnabled")
	private WebElement vibrateDelete;

	@FindBy(id = "edit_setting_vibrateEnabled")
	private WebElement vibrateEdit;

	public ConfigPageField vibrateField = new ConfigPageField(
			VIBRATE_WARNING,
			vibrateLabel,
			vibrateCheckbox,
			vibrateDelete,
			vibrateEdit
	);

	@FindBy(id = "soundEnabled")
	private WebElement audibleAlarmLabel;

	@FindBy(id = "audible_alarm")
	private WebElement audibleAlarmCheckbox;

	@FindBy(id = "delete_setting_soundEnabled")
	private WebElement audibleAlarmDelete;

	@FindBy(id = "edit_setting_soundEnabled")
	private WebElement audibleAlarmEdit;

	public ConfigPageField audibleAlarmField = new ConfigPageField(
			SOUND_WARNING,
			audibleAlarmLabel,
			audibleAlarmCheckbox,
			audibleAlarmDelete,
			audibleAlarmEdit
	);

	@FindBy(id = "alertLevel")
	private WebElement alertThresholdMenu;

	@FindBy(id = "delete_setting_alertLevel")
	private WebElement alertThresholdDelete;

	@FindBy(id = "edit_setting_alertLevel")
	private WebElement alertThresholdEdit;

	public ConfigPageField alertThresholdField = new ConfigPageField(
			LOW_THRESHOLD_LEVEL,
			alertThresholdMenu,
			alertThresholdDelete,
			alertThresholdEdit
	);

	@FindBy(id = "battAlarmSnoozeTime")
	private WebElement alarmSnoozeTimeMenu;

	@FindBy(id = "delete_setting_battAlarmSnoozeTime")
	private WebElement alarmSnoozeTimeDelete;

	@FindBy(id = "edit_setting_battAlarmSnoozeTime")
	private WebElement alarmSnoozeTimeEdit;

	public ConfigPageField alarmSnoozeTimeField = new ConfigPageField(
			LOW_WARNING_SNOOZE_TIME,
			alarmSnoozeTimeMenu,
			alarmSnoozeTimeDelete,
			alarmSnoozeTimeEdit
	);

	@FindBy(id = "battAlarmTone")
	private WebElement alarmToneMenu;

	@FindBy(id = "delete_setting_battAlarmTone")
	private WebElement alarmToneDelete;

	@FindBy(id = "edit_setting_battAlarmTone")
	private WebElement alarmToneEdit;

	public ConfigPageField alarmToneField = new ConfigPageField(
			LOW_ALARM_TONE,
			alarmToneMenu,
			alarmToneDelete,
			alarmToneEdit
	);

	public SamBattLifePage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(battlifeEnabledField.getTitle(), battlifeEnabledField);
				put(vibrateField.getTitle(), vibrateField);
				put(audibleAlarmField.getTitle(), audibleAlarmField);
				put(alertThresholdField.getTitle(), alertThresholdField);
				put(alarmSnoozeTimeField.getTitle(), alarmSnoozeTimeField);
				put(alarmToneField.getTitle(), alarmToneField);
			}
		};
	}
}
