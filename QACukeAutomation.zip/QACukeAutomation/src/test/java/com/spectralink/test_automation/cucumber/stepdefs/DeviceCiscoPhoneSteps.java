package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.CiscoPhoneUi;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;

import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.BIZ_PHONE;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.BizPhoneStrings.*;
import static com.spectralink.test_automation.cucumber.stepdefs.DeviceNavigationSteps.inCall;
import static com.spectralink.test_automation.cucumber.stepdefs.DeviceNavigationSteps.phoneOnHomeScreen;

public class DeviceCiscoPhoneSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());
    private static final String REG_CODE_OK = "200";
    private static final String CALL_STATE_INCOMING_CALL = "CALL_STATE_EARLY";
    private static final String MEDIA_STATE_DURING_CALL = "MEDIA_STATE_ACTIVE";
    private static final String CALL_STATE_CALL_ANSWERED = "CALL_STATE_CONFIRMED";
    private static final String CALL_STATE_CALL_ENDED = "CALL_STATE_DISCONNECTED";
    private static final String MEDIA_STATE_NOT_IN_ACTIVE_CALL = "MEDIA_STATE_NULL";
    private static final String MEDIA_STATE_DURING_HOLD = "MEDIA_STATE_LOCAL_HOLD";
    private static final String MEDIA_STATE_DURING_HOLD_FAR_END = "MEDIA_STATE_REMOTE_HOLD";
    private static final String CALL_MUTED = "1";
    private static final String CALL_UNMUTED = "0";
    private static Boolean enableAutodial = false;
    private Long callStartTime;
    private String callerNamePhoneA;
    private String callerNamePhoneB;
    private String callerNamePhoneC;

    @When("^I tap the Cisco Phone \"([^\"]*)\" on \"([^\"]*)\"$")
    public void tapCiscoPhoneObject(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;

        if(arg1.equalsIgnoreCase("call logs tab")) {
            try {
                phone.appium().findElementByXPath("//android.widget.FrameLayout[contains(@content-desc, 'Recent')]").click();
            }
            catch (Exception exception) {
                log.error("Couldn't find the 'Call logs tab'");
            }
        }
        else {
            CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
            ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
            FieldData heading = DeviceFields.getStrings(BIZ_PHONE, arg1.trim());
            if (field != null) {
                if (field.hasLabelElement()) {
                    assert heading != null;
                    field.scrollIntoView(heading);
                    if (field.isLabelPresent()) {
                        field.tap();
                    } else {
                        log.error("Field '{}' has no label", arg1);
                    }
                } else if (field.hasControlElement())
                    field.tap();
                else {
                    log.error("Field '{}' has no control", arg1);
                }
            } else {
                log.error("No matching field with title '{}'", arg1);
            }
        }
    }

    @Then("^I verify \"([^\"]*)\" is not present on Cisco Phone \"([^\"]*)\"$")
    public void elementNotPresent(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim());
        WebElement targetElement = null;
        if (field.hasLabelElement())
            targetElement = field.getLabelElement();
        else if (field.hasControlElement())
            targetElement = field.getControlElement();
        if (ciscoPhoneUi.isEntityDisplayed(targetElement)) {
            log.error("'{}' is present on '{}' when it shouldn't have been", arg1, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        } else
            log.debug("Verified '{}' is not present on '{}'", arg1, arg2);
    }

    @Then("^I verify \"([^\"]*)\" is present on Cisco Phone \"([^\"]*)\"$")
    public void elementPresent(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim());
        WebElement targetElement = null;
        if (field.hasLabelElement())
            targetElement = field.getLabelElement();
        else if (field.hasControlElement())
            targetElement = field.getControlElement();
        if (ciscoPhoneUi.isEntityDisplayed(targetElement))
            log.debug("Verified '{}' is present on '{}'", arg1, arg2);
        else {
            log.error("'{}' is not present on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @When("^I tap the Cisco Phone Emergency Contact \"([^\"]*)\" on \"([^\"]*)\"$")
    public void tapCiscoPhoneEmergencyContacts(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        if (field != null) {
            if (field.hasControlElement())
                field.tap();
            else {
                log.error("Field '{}' has no control", arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg1);
        }
    }

    @When("^I set the Cisco Phone \"([^\"]*)\" switch to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void setCiscoPhoneSwitch(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        if (field.isValueAccessible()) {
            if (!field.getControlElement().getText().toLowerCase().contentEquals(arg2.trim().toLowerCase())) {
                field.tap();
                if (arg1.equals("Enable autodial")) {
                    enableAutodial = arg2.equals("ON");
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg1, arg2);
            }
        } else {
            log.error("Field '{}' was not accessible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I select \"([^\"]*)\" from the Cisco Phone Ringtone menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectToneCiscoPhoneMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field;
        if (arg2.equals("Reg 1 ringtone"))
            field = ciscoPhoneUi.getField(RINGTONE_REG_1);
        else
            field = ciscoPhoneUi.getField(RINGTONE_REG_2);
        if (field != null) {
            if (arg2.equals("Reg 1 ringtone"))
                field.scrollIntoView(RINGTONE_REG_1);
            else
                field.scrollIntoView(RINGTONE_REG_2);
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectScrollableMenuOption(arg1.trim());
                if (found) {
                    ciscoPhoneUi.tapOkButton();
                    log.debug("Selected menu option '{}'", arg1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                    ciscoPhoneUi.tapCancelButton();
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg3, arg1);
            }
        } else {
            if (arg2.equals("Reg 1 ringtone"))
                log.error("No matching field with title '{}'", RINGTONE_REG_1.title());
            else
                log.error("No matching field with title '{}'", RINGTONE_REG_2.title());
        }
    }

    @When("^I select \"([^\"]*)\" from the Cisco Phone overflow menu on \"([^\"]*)\"$")
    public void selectOverflowOption(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isControlPresent()) {
            tapCiscoPhoneObject("More options", arg2);
            found = field.selectTextMenuOption(arg1.trim().toLowerCase());
            if (found) {
                log.debug("Selected menu option '{}'", arg1);
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @When("^I select \"([^\"]*)\" feature from the Cisco Phone overflow menu on \"([^\"]*)\"$")
    public void selectFeaturesOverflowMenu(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isControlPresent()) {
            tapCiscoPhoneObject("More options", arg2);
            field.selectTextMenuOption("Features");
            found = field.selectTextMenuOption(arg1.trim().toLowerCase());
            if (found) {
                log.debug("Selected menu option '{}'", arg1);
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @Then("^I verify \"([^\"]*)\" feature is present in the Cisco Phone Features menu on \"([^\"]*)\"$")
    public void verifyFeaturesMenu(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.cisco.phone:id/title"));
        for (WebElement element : options) {
            if (element.getText().trim().equalsIgnoreCase(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("'{}' menu option present", arg1);
        else {
            log.error("'{}' menu option not present", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\" feature is not present in the Cisco Phone Features menu on \"([^\"]*)\"$")
    public void verifyFeaturesMenuItemNotPresent(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.cisco.phone:id/title"));
        for (WebElement element : options) {
            if (element.getText().trim().equalsIgnoreCase(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found) {
            log.error("'{}' menu option found but shouldn't have been there", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        } else
            log.debug("Verified '{}' menu option not present", arg1);
    }

    @Then("^I verify \"([^\"]*)\" is present in the Cisco Phone Overflow menu on \"([^\"]*)\"$")
    public void verifyOverflowMenuItems(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        boolean found = false;
        List<WebElement> options = phone.appium().findElements(By.id("com.cisco.phone:id/title"));
        for (WebElement element : options) {
            if (element.getText().trim().equalsIgnoreCase(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found) {
            log.debug("Verified '{}' Overflow menu item is present on '{}'", arg1, arg2);
        } else {
            log.error("'{}' Overflow menu item is not present on '{}' ", arg1, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\" is not present in the Cisco Phone Overflow menu on \"([^\"]*)\"$")
    public void verifyOverflowMenuItemNotPresent(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.cisco.phone:id/title"));
        for (WebElement element : options) {
            if (element.getText().trim().equalsIgnoreCase(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found) {
            log.error("'{}' Overflow menu item present when it shouldn't have on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        } else
            log.debug("Verified '{}' Overflow menu item is not present on '{}'", arg1, arg2);
    }

    @Then("^I verify Cisco Features is not present in the overflow menu on Cisco Phone \"([^\"]*)\"$")
    public void verifyFeaturesMenuNotPresent(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(OVERFLOW_MENU);
        boolean found = false;
        if (field.isControlPresent()) {
            tapCiscoPhoneObject("More options", arg1);
            List<WebElement> options = phone.appium().findElements(By.id("com.cisco.phone:id/title"));
            for (WebElement element : options) {
                if (element.getText().equals("Features")) {
                    found = true;
                    break;
                }
            }
            if (found) {
                log.error("Features menu present when it shouldn't have ");
                Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
            } else
                log.debug("Verified Features menu option not present on '{}'", arg1);
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @When("^I select \"([^\"]*)\" from the Cisco Phone menu \"([^\"]*)\" on \"([^\"]*)\"$")
    public void selectMenuOption(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg2);
        if (field != null) {
            field.scrollIntoViewAttribute(arg2);
            boolean found;
            if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
                field.tap();
                found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
                if (found) {
                    log.debug("Selected menu option '{}'", arg1);
                    sleepSeconds(1);
                } else {
                    log.error("Could not find menu option '{}'", arg1);
                }
            } else {
                log.debug("Field '{}' was already set to '{}'", arg2, arg1);
            }
        } else {
            log.error("No matching field with title '{}'", arg2);
        }
    }

    @Then("^I verify there are \"([^\"]*)\" menu items present on Cisco Phone \"([^\"]*)\"$")
    public void verifyMenuItems(String arg1, String arg2) {
        int noOfItems = Integer.parseInt(arg1);
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.cisco.phone:id/title"));
        if (options.size() == noOfItems) {
            log.debug("'{}' menu options found on '{}'", arg1, arg2);
        } else {
            log.error("'{}' menu options found instead of '{}' on '{}'", options.size(), arg1, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^the Cisco Phone \"([^\"]*)\" value is set to the pbx \"([^\"]*)\" value on \"([^\"]*)\"$")
    public void verifyCiscoPhonePbxValue(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());

        switch (arg2.toLowerCase()) {
            case "server":
                if (field.isValueAccessible()) {
                    String fieldValue = field.getValueElement().getText().toLowerCase();
                    if (fieldValue.contentEquals(phone.callServerDetails().sipServerAddress)) {
                        log.debug("Verified field '{}' was set to '{}'", fieldValue, arg3);
                    } else {
                        log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, phone.callServerDetails().sipServerAddress, arg3);
                        Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
                    }
                } else {
                    log.error("Field '{}' was not visible", arg1);
                    Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
                }
                break;
            case "voicemail retrieval address":
                if (field.isValueAccessible()) {
                    String fieldValue = field.getValueElement().getText().toLowerCase();
                    if (fieldValue.contentEquals(phone.callServerDetails().voicemailRetrievalAddress)) {
                        log.debug("Verified field '{}' was set to '{}'", fieldValue, arg3);
                    } else {
                        log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, phone.callServerDetails().voicemailRetrievalAddress, arg3);
                        Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
                    }
                } else {
                    log.error("Field '{}' was not visible", arg1);
                    Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
                }
                break;
            case "extension":
                if (field.isValueAccessible()) {
                    String fieldValue = field.getValueElement().getText().toLowerCase();
                    if (fieldValue.contentEquals(phone.callServerDetails().extensionReg1)) {
                        log.debug("Verified field '{}' was set to '{}'", fieldValue, arg3);
                    } else {
                        log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, phone.callServerDetails().extensionReg1, arg3);
                        Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
                    }
                } else {
                    log.error("Field '{}' was not visible", arg1);
                    Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
                }
                break;
            case "primary server address":
                if (field.isValueAccessible()) {
                    String fieldValue = field.getValueElement().getText().toLowerCase();
                    if (fieldValue.contentEquals(phone.callServerDetails().voicemailPrimaryServerAddress)) {
                        log.debug("Verified field '{}' was set to '{}'", fieldValue, arg3);
                    } else {
                        log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, phone.callServerDetails().voicemailPrimaryServerAddress, arg3);
                        Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
                    }
                } else {
                    log.error("Field '{}' was not visible", arg1);
                    Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
                }
                break;
        }


    }

    @Then("^the Cisco Phone \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyCiscoPhoneValue(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());

        if (field.isValueAccessible()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Cisco Phone \"([^\"]*)\" value is not set on \"([^\"]*)\"$")
    public void verifyValueNotSet(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, arg1.trim());

        if (field.hasLabelElement()) {
            assert heading != null;
            field.scrollIntoView(heading);
        }
        if (field.isValuePresent()) {
            log.error("Field '{}' is set on '{}'", arg1, arg2);
            Environment.softAssert().fail("FIELD VALUE PRESENT");
        } else {
            log.debug("Verified Field '{}'s value is not set on '{}'", arg1, arg2);
        }
    }

    @Then("^the Cisco Phone Cisco feature \"([^\"]*)\" Username value is not set on \"([^\"]*)\"$")
    public void verifyUsername(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, USERNAME.title().trim());

        if (field.hasLabelElement()) {
            if (arg1.contains("contact search"))
                field.scrollIntoView(heading);
            else
                field.scrollToEnd();
        }
        if (field.isValuePresent()) {
            log.error("Field '{}' is set on '{}'", arg1, arg2);
            Environment.softAssert().fail("FIELD VALUE PRESENT");
        } else {
            log.debug("Verified Field '{}'s value is not set on '{}'", arg1, arg2);
        }
    }

    @Then("^the Cisco Phone Cisco feature \"([^\"]*)\" Username value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyUsernameValueSet(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, USERNAME.title().trim());

        if (field.hasLabelElement()) {
            if (arg1.contains("contact search"))
                field.scrollIntoView(heading);
            else
                field.scrollToEnd();
        }
        String fieldValue = field.getValueElement().getText().toLowerCase();
        if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
            log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
        } else {
            log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
            Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
        }
    }

    @Then("^the Cisco Phone Cisco feature Voicemail Username value is set to pbx username on \"([^\"]*)\"$")
    public void verifyUsernameValuePbxSet(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(CISCO_VOICEMAIL_USERNAME.title().toLowerCase());
        field.scrollToEnd();
        String fieldValue = field.getValueElement().getText().toLowerCase();
        if (fieldValue.equalsIgnoreCase(phone.callServerDetails().voicemailUsername)) {
            log.debug("Verified field Voicemail Username was set to '{}'", fieldValue);
        } else {
            log.error("Field Voicemail Username was set to '{}' rather than '{}' on {}", fieldValue, phone.callServerDetails().voicemailUsername, arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
        }
    }

    @Then("^the Cisco Phone Cisco feature \"([^\"]*)\" Password value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyPasswordValueSet(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, PASSWORD.title().trim());

        if (field.hasLabelElement()) {
            if (arg1.contains("contact search"))
                field.scrollIntoView(heading);
            else
                field.scrollToEnd();
        }
        String fieldValue = field.getValueElement().getText().toLowerCase();
        if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
            log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
        } else {
            log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
            Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
        }
    }

    @Then("^the Cisco Phone Cisco feature \"([^\"]*)\" Password value is not set on \"([^\"]*)\"$")
    public void verifyPassword(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, PASSWORD.title().trim());

        if (field.hasLabelElement()) {
            if (arg1.contains("contact search"))
                field.scrollIntoView(heading);
            else
                field.scrollToEnd();
        }
        if (field.isValuePresent()) {
            log.error("Field '{}' is set on '{}'", arg1, arg2);
            Environment.softAssert().fail("FIELD VALUE PRESENT");
        } else {
            log.debug("Verified Field '{}'s value is not set on '{}'", arg1, arg2);
        }
    }

    @Then("^the Cisco Phone Cisco feature \"([^\"]*)\" Username field is non-interactive on \"([^\"]*)\"$")
    public void verifyUsernameValue(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, USERNAME.title().trim());

        if (field.hasLabelElement()) {
            if (arg1.contains("contact search"))
                field.scrollIntoView(heading);
            else
                field.scrollToEnd();
        }
        if (field.hasControlElement())
            if (field.getControlElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s control is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s control is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        if (field.hasLabelElement())
            if (field.getLabelElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s label is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s label is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        if (field.hasValueElement()) {
            if (field.isValuePresent()) {
                if (field.getValueElement().getAttribute("enabled").equals("false"))
                    log.debug("Verified field '{}'s value is non-interactive '{}'", arg1, arg2);
                else {
                    log.error("Field '{}'s value is interactive on {}", arg1, arg2);
                    Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
                }
            } else {
                log.debug("Field '{}'s value is not set on '{}'", arg1, arg2);
            }
        }
    }

    @Then("^the Cisco Phone Cisco feature \"([^\"]*)\" Password field is non-interactive on \"([^\"]*)\"$")
    public void verifyPasswordValue(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, PASSWORD.title().trim());

        if (field.hasLabelElement()) {
            if (arg1.contains("contact search"))
                field.scrollIntoView(heading);
            else
                field.scrollToEnd();
        }
        if (field.hasControlElement())
            if (field.getControlElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s control is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s control is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        if (field.hasLabelElement())
            if (field.getLabelElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s label is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s label is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        if (field.hasValueElement()) {
            if (field.isValuePresent()) {
                if (field.getValueElement().getAttribute("enabled").equals("false"))
                    log.debug("Verified field '{}'s value is non-interactive '{}'", arg1, arg2);
                else {
                    log.error("Field '{}'s value is interactive on {}", arg1, arg2);
                    Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
                }
            } else {
                log.debug("Field '{}'s value is not set on '{}'", arg1, arg2);
            }
        }
    }

    @Then("^the Cisco Phone \"([^\"]*)\" field is non-interactive on \"([^\"]*)\"$")
    public void verifyOptionBlocked(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, arg1.trim());
        if (field.hasLabelElement())
            field.scrollIntoView(heading);
        if (field.hasControlElement())
            if (field.getControlElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s control is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s control is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        if (field.hasLabelElement())
            if (field.getLabelElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}'s label is non-interactive '{}'", arg1, arg2);
            else {
                log.error("Field '{}'s label is interactive on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        if (field.hasValueElement()) {
            if (field.isValuePresent()) {
                if (field.getValueElement().getAttribute("enabled").equals("false"))
                    log.debug("Verified field '{}'s value is non-interactive '{}'", arg1, arg2);
                else {
                    log.error("Field '{}'s value is interactive on {}", arg1, arg2);
                    Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
                }
            } else {
                log.debug("Field '{}'s value is not set on '{}'", arg1, arg2);
            }
        }
    }

    @Then("^I verify there are no favorites on Cisco Phone \"([^\"]*)\"$")
    public void noFavoritesText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        if (ciscoPhoneUi.noResultText().equals("No favorites")) {
            log.debug("Verified the \"No favorites text\" is visible on '{}'", arg1);
        } else {
            log.error("the \"No favorites text\" not visible on '{}'", arg1);
            Environment.softAssert().fail("Favorites still present after clearing call logs");
        }
    }

    @When("^I enter \"([^\"]*)\" into the Cisco Phone edit box on \"([^\"]*)\"$")
    public void enterInEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            field = ciscoPhoneUi.getField(EDIT_TEXT);
            field.enter(arg1.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg2);
        }
    }
    @When("I enter \"([^\"]*)\" into the Cisco Phone password edit box on \"([^\"]*)\"$")
    public void enterInPasswordEditText(String arg1,String arg2){
        VersityPhone phone = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(LOGGING_PASSWORD_EDIT_TEXT);
        if (field.isControlPresent()) {
            field = ciscoPhoneUi.getField(LOGGING_PASSWORD_EDIT_TEXT);
            field.enter(arg1.trim());
        } else {
            log.debug("The Logging password Edit text box was not visible on '{}'", arg2);
        }
    }

    @When("^I enter \"([^\"]*)\" into the Cisco Phone search edit box on \"([^\"]*)\"$")
    public void enterInSearchEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(SEARCH_EDIT_TEXT);
        if (field.isControlPresent()) {
            field = ciscoPhoneUi.getField(SEARCH_EDIT_TEXT);
            field.enter(arg1.trim());
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg2);
        }
    }

    @When("^I enter pbx \"([^\"]*)\" into the Cisco Phone edit box on \"([^\"]*)\"$")
    public void enterIntoEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(EDIT_TEXT);
        switch (arg1.toLowerCase()) {
            case "server":
                log.debug("Entering: " + phone.callServerDetails().sipServerAddress + " into edit text box");
                field.enter(phone.callServerDetails().sipServerAddress);
                break;
            case "password":
                log.debug("Entering: " + phone.callServerDetails().passReg1 + " into edit text box");
                field.enter(phone.callServerDetails().passReg1);
                break;
            case "extension":
                log.debug("Entering: " + phone.callServerDetails().extensionReg1 + " into edit text box");
                field.enter(phone.callServerDetails().extensionReg1);
                break;
        }
    }

    @When("^I clear the Cisco Phone edit box on \"([^\"]*)\"$")
    public void enterEndpointText(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(EDIT_TEXT);
        if (field.isControlPresent()) {
            ciscoPhoneUi.clearEditText();
        } else {
            log.debug("The Edit text box was not visible on '{}'", arg1);
        }
    }

    @Then("^the Cisco Phone verifies Registration is successful on \"([^\"]*)\"$")
    public void registerSipExtension(String arg1) {
        sleepSeconds(8);
        VersityPhone phone = Environment.getPhone(arg1.trim());

        /* REG_CODE */
        assert phone != null;
        String actualRegCode = phone.ciscoPhoneContentProvider().getRegistrationCode();
        log.debug("Registration Code should be: " + REG_CODE_OK);
        if (REG_CODE_OK.equals(actualRegCode)) {
            log.debug("Registration Code is: " + actualRegCode);
        } else {
            log.error("Registration Code is: " + actualRegCode);
            Environment.softAssert().fail("Incorrect Registration Code");
        }

        /* LAST_REG */
        Long actualLastRegTime = Long.valueOf(phone.ciscoPhoneContentProvider().getRegistrationUpdate());
        log.debug("Last Registration Time: " + actualLastRegTime);

        /* REG_EXPIRE */
        Long actualRegExpireTime = Long.parseLong(phone.ciscoPhoneContentProvider().getRegistrationExpiration()) * 1000;
        log.debug("Registration Expire Time: " + actualRegExpireTime);

        Long currentTime = getCurrentTime();
        log.debug("Current Timestamp: " + currentTime);

        if (currentTime < actualLastRegTime + actualRegExpireTime) {
            log.debug("Registration Expiration time condition is met");
        } else {
            log.error("Registration Expiration time condition is not met");
            Environment.softAssert().fail("Current time exceeds last registration time plus the expiration time");
        }
    }

    @Then("^the Cisco Phone verifies Registration fails on \"([^\"]*)\"$")
    public void registrationFailure(String arg1) {
        sleepSeconds(35);
        VersityPhone phone = Environment.getPhone(arg1.trim());

        /* REG_CODE */
        assert phone != null;
        String actualRegCode = phone.ciscoPhoneContentProvider().getRegistrationCode();
        log.debug("Registration Code should not be: " + REG_CODE_OK);
        if (!REG_CODE_OK.equals(actualRegCode)) {
            log.debug("Registration Code is: " + actualRegCode);
        } else {
            log.error("Registration Code is: " + actualRegCode);
            Environment.softAssert().fail("Incorrect Registration Code");
        }
    }

    @When("^I make a Cisco Phone call from \"([^\"]*)\" to \"([^\"]*)\"$")
    public void makeACall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        log.debug("Current package on " + arg2 + " is: " + phone2.getForegroundPackage());
        log.debug("Current activity on " + arg2 + " is: " + phone2.getForegroundActivity());
        if (phone2.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone2.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg1 + " to " + arg2);
        assert phone1 != null;
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg1);
        log.debug("Dialing extension number: " + phone2.callServerDetails().extensionReg1);
        for (char c : phone2.callServerDetails().extensionReg1.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg1);
        sleepSeconds(4);
        String callIdCallingPhone = getIncomingOutgoingCiscoPhoneCallId(arg1);
        log.debug("Call Id of the calling phone: " + arg1 + " is: " + callIdCallingPhone);
        String callIdReceivingPhone = getIncomingOutgoingCiscoPhoneCallId(arg2);
        log.debug("Call Id of the phone receiving the call: " + arg2 + " is: " + callIdReceivingPhone);
    }

    @When("^I answer the Cisco Phone call from \"([^\"]*)\" on \"([^\"]*)\"$")
    public void answerCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        CiscoPhoneUi ciscoPhoneUi = phone2.getCiscoPhoneUi();
        sleepSeconds(2);
        log.debug("Phone locked? :" + phone2.isLocked());
        log.debug("Phone in Call? :" + inCall);
        log.debug("Phone on home screen? :" + phoneOnHomeScreen);
        if (phone2.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            ciscoPhoneUi.answerCall();
        } else {
            log.debug("Phone is either in the CiscoPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone2.openNotificationBar();
            ciscoPhoneUi.headsUpAnswer();
        }
        log.debug("Call answered");
        phoneOnHomeScreen = false;
        inCall = false;
        callStartTime = getCurrentTime();

        sleepSeconds(2);

        assert phone1 != null;
        String callIdCallingPhone = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdReceivingPhone = getActiveCiscoPhoneCall(arg2, arg1);

        log.debug("callIdCallingPhone: " + callIdCallingPhone);
        log.debug("callIdReceivingPhone: " + callIdReceivingPhone);


        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else {
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        }
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I decline Cisco Phone call from \"([^\"]*)\" on \"([^\"]*)\"$")
    public void declineCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone1 = getActiveCiscoPhoneCall(arg1);
        String callIdPhone2 = getActiveCiscoPhoneCall(arg2);
        assert phone2 != null;
        CiscoPhoneUi ciscoPhoneUi2 = phone2.getCiscoPhoneUi();
        sleepSeconds(2);
        log.debug("Phone locked? :" + phone2.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone2.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            ciscoPhoneUi2.declineCall();
            log.debug("Call declined");
        } else {
            log.debug("Phone is either in the CiscoPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone2.openNotificationBar();
            ciscoPhoneUi2.headsUpDecline();
            log.debug("Call declined");
            phone2.sendKeyEvent(AndroidKey.BACK);
        }
        phoneOnHomeScreen = false;

        assert phone1 != null;
        CiscoPhoneUi ciscoPhoneUi1 = phone1.getCiscoPhoneUi();
        if (ciscoPhoneUi1.isEndCallButtonVisible())
            ciscoPhoneUi1.endCall();

        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone1);
        log.debug("Actual Call State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdPhone2);
        log.debug("Actual Call State for call id: " + callIdPhone2 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone1);
        log.debug("Actual Media State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdPhone2);
        log.debug("Actual Media State for call id: " + callIdPhone2 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I end the Cisco Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone12 = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdPhone21 = getActiveCiscoPhoneCall(arg2, arg1);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);
        assert phone2 != null;
        CiscoPhoneUi ciscoPhoneUi = phone2.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I remove the Cisco Phone call with \"([^\"]*)\" from Conference on \"([^\"]*)\"$")
    public void endConference(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());

        String callIdPhone1 = getActiveCiscoPhoneCall(arg1);

        if (phone2.ciscoPhoneContentProvider().isHost().equals("1"))
            log.debug(arg2 + " is the Conference Host");
        else {
            log.error(arg2 + " is not the Conference Host");
            Environment.softAssert().fail("INCORRECT CISCO PHONE CONTENT PROVIDER STATUS");
        }

        if (phone2.ciscoPhoneContentProvider().isCapableToRemoveParticipants().equals("1"))
            log.debug(arg2 + " is capable to remove participants");
        else {
            log.error(arg2 + " is not capable to remove participants");
            Environment.softAssert().fail("INCORRECT CISCO PHONE CONTENT PROVIDER STATUS");
        }

        tapCiscoPhoneObject("More button", arg2);
        tapCiscoPhoneObject("Participants button", arg2);

        phone2.appium().findElementByAccessibilityId("Remove icon " + phone1.callServerDetails().extensionReg1).click();

        log.debug("Call ended");
        sleepSeconds(5);

        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone1);
        log.debug("Actual Call State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + callStatePhone1);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone1);
        log.debug("Actual Media State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
    }

    @When("^I end the unanswered Cisco Phone call with \"([^\"]*)\" on \"([^\"]*)\"")
    public void endCallWithoutAnswer(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone12 = getIncomingOutgoingCiscoPhoneCallId(arg1);
        String callIdPhone21 = getIncomingOutgoingCiscoPhoneCallId(arg2);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);
        assert phone2 != null;
        CiscoPhoneUi ciscoPhoneUi = phone2.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);

        phoneOnHomeScreen = false;
    }

    @When("^I keep \"([^\"]*)\" and \"([^\"]*)\" in Cisco Phone call for \"([^\"]*)\" seconds")
    public void verifyAudioStats(String arg1, String arg2, Integer arg3) {

        sleepSeconds(arg3);
        Long callTime = getCurrentTime();
        long actualCallTime = callTime - callStartTime;

        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdCallingPhone = getActiveCiscoPhoneCall(arg1);
        String callIdReceivingPhone = getActiveCiscoPhoneCall(arg2);
        assert phone1 != null;
        int txPacketsPhone1 = Integer.parseInt(phone1.ciscoPhoneContentProvider().getTxPackets(callIdCallingPhone));
        log.debug("Actual Tx packets for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + txPacketsPhone1);
        assert phone2 != null;
        int txPacketsPhone2 = Integer.parseInt(phone2.ciscoPhoneContentProvider().getTxPackets(callIdReceivingPhone));

        log.debug("Actual Tx packets for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + txPacketsPhone2);
        int rxPacketsPhone1 = Integer.parseInt(phone1.ciscoPhoneContentProvider().getRxPackets(callIdCallingPhone));
        log.debug("Actual Rx packets for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + rxPacketsPhone1);
        int rxPacketsPhone2 = Integer.parseInt(phone2.ciscoPhoneContentProvider().getRxPackets(callIdReceivingPhone));
        log.debug("Actual Rx packets for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + rxPacketsPhone2);
        Double missedPacketsPhone1 = Double.valueOf(phone1.ciscoPhoneContentProvider().getMissedPackets(callIdCallingPhone));
        log.debug("Actual Missed packets for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + missedPacketsPhone1);
        Double missedPacketsPhone2 = Double.valueOf(phone2.ciscoPhoneContentProvider().getMissedPackets(callIdReceivingPhone));
        log.debug("Actual Missed packets for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + missedPacketsPhone2);
        Double droppedPacketsPhone1 = Double.valueOf(phone1.ciscoPhoneContentProvider().getDroppedPackets(callIdCallingPhone));
        log.debug("Actual Dropped packets for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + droppedPacketsPhone1);
        Double droppedPacketsPhone2 = Double.valueOf(phone2.ciscoPhoneContentProvider().getDroppedPackets(callIdReceivingPhone));
        log.debug("Actual Dropped packets for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + droppedPacketsPhone2);

        /*Convert milliseconds to seconds */
        int seconds = (int) ((actualCallTime / 1000));
        int packetsInTxPhone1 = txPacketsPhone1 / seconds;
        int packetsInTxPhone2 = txPacketsPhone2 / seconds;
        int packetsInRxPhone1 = rxPacketsPhone1 / seconds;
        int packetsInRxPhone2 = rxPacketsPhone2 / seconds;
        double missedAndDroppedPacketsPhone1 = (missedPacketsPhone1 + droppedPacketsPhone1);
        double missedAndDroppedPacketsPhone2 = (missedPacketsPhone2 + droppedPacketsPhone2);

        log.debug("Duration of the call in seconds: " + seconds);
        log.debug("Tx per second for call id: " + callIdCallingPhone + " on : " + arg1 + " is:" + packetsInTxPhone1);
        log.debug("Tx per second for call id: " + callIdReceivingPhone + " on : " + arg2 + " is:" + packetsInTxPhone2);
        log.debug("Rx per second for call id: " + callIdCallingPhone + " on : " + arg1 + " is:" + packetsInRxPhone1);
        log.debug("Rx per second for call id: " + callIdReceivingPhone + " on : " + arg2 + " is:" + packetsInRxPhone2);

        int idealPacketRate = 50;
        int packetErrorMargin = 5;

        if (packetsInTxPhone1 < (idealPacketRate - packetErrorMargin)) {
            log.debug("TX packets are not within margin: " + packetsInTxPhone1);
            Environment.softAssert().fail("Not enough TX packets on : " + arg1);
        } else
            log.debug("TX packets are within margin : " + packetsInTxPhone1);

        if (packetsInTxPhone2 < (idealPacketRate - packetErrorMargin)) {
            log.debug("TX packets are not within margin: " + packetsInTxPhone2);
            Environment.softAssert().fail("Not enough TX packets on : " + arg2);
        } else
            log.debug("TX packets are within margin : " + packetsInTxPhone2);

        if (packetsInRxPhone1 < (idealPacketRate - packetErrorMargin)) {
            log.debug("RX packets are not within margin: " + packetsInRxPhone1);
            Environment.softAssert().fail("Not enough RX packets on : " + arg1);
        } else
            log.debug("RX packets are within margin : " + packetsInRxPhone1);

        if (packetsInRxPhone2 < (idealPacketRate - packetErrorMargin)) {
            log.debug("RX packets are not within margin: " + packetsInRxPhone2);
            Environment.softAssert().fail("Not enough RX packets on : " + arg2);
        } else
            log.debug("RX packets are within margin : " + packetsInRxPhone2);

        if (missedAndDroppedPacketsPhone1 >= 0.75) {
            log.debug("Missed/Dropped packets are not within margin: " + missedAndDroppedPacketsPhone1);
            Environment.softAssert().fail("Too many Missed/Dropped packets on : " + arg1);
        } else
            log.debug("Missed/Dropped packets are within margin: " + missedAndDroppedPacketsPhone1);
        if (missedAndDroppedPacketsPhone2 >= 0.75) {
            log.debug("Missed/Dropped packets are not within margin: " + missedAndDroppedPacketsPhone2);
            Environment.softAssert().fail("Too many Missed/Dropped packets on : " + arg2);
        } else
            log.debug("Missed/Dropped packets are within margin: " + missedAndDroppedPacketsPhone2);

    }

    private Long getCurrentTime() {
        return System.currentTimeMillis();
    }

    private String getIncomingOutgoingCiscoPhoneCallId(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        return phone.ciscoPhoneContentProvider().getCallIdIncomingOutgoingCall();
    }

    private String getActiveCiscoPhoneCall(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        return phone.ciscoPhoneContentProvider().getCallId();
    }

    private String getCiscoPhoneHoldCall(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        return phone.ciscoPhoneContentProvider().getCallIdOfHoldCall();
    }

    private String getActiveCiscoPhoneCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        return phone1.ciscoPhoneContentProvider().getCallIdFarEndUsername(phone2.callServerDetails().extensionReg1);
    }

    @When("^I enter \"([^\"]*)\" into the Cisco Phone edit box for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void enterInEditTextContactName(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field;
        switch (arg2.toLowerCase()) {
            case "emergency contact name":
                field = ciscoPhoneUi.getField(EMERGENCY_CONTACT_NAME);
                if (field.isControlPresent()) {
                    field = ciscoPhoneUi.getField(EMERGENCY_CONTACT_NAME);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "emergency contact number":
                field = ciscoPhoneUi.getField(EMERGENCY_CONTACT_NUMBER);
                if (field.isControlPresent()) {
                    field = ciscoPhoneUi.getField(EMERGENCY_CONTACT_NUMBER);
                    field.enter(arg1.trim());
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg3);
                }
                break;
            case "first name":
                phone.scrollIntoExactViewAttribute("First name");
                phone.appium().findElementByXPath("//android.widget.EditText[(@text ='First name')]").sendKeys(arg1);
                if(phone.appium().isKeyboardShown())
                    phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "last name":
                phone.scrollIntoExactViewAttribute("Last name");
                phone.appium().findElementByXPath("//android.widget.EditText[(@text ='Last name')]").sendKeys(arg1);
                if(phone.appium().isKeyboardShown())
                    phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "company":
                phone.scrollIntoExactViewAttribute("Company");
                phone.appium().findElementByXPath("//android.widget.EditText[(@text ='Company')]").sendKeys(arg1);
                if(phone.appium().isKeyboardShown())
                    phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "phone":
                phone.scrollIntoExactViewAttribute("Phone");
                phone.appium().findElementByXPath("//android.widget.EditText[(@text ='Phone')]").sendKeys(arg1);
                if(phone.appium().isKeyboardShown())
                    phone.sendKeyEvent(AndroidKey.BACK);
                break;
            case "email":
                phone.scrollIntoExactViewAttribute("Email");
                phone.appium().findElementByXPath("//android.widget.EditText[(@text ='Email')]").sendKeys(arg1);
                if(phone.appium().isKeyboardShown())
                    phone.sendKeyEvent(AndroidKey.BACK);
                break;
        }
    }

    @When("^I clear the Cisco Phone edit box for \"([^\"]*)\" on \"([^\"]*)\"$")
    public void clearEditText(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field;
        switch (arg1.trim().toLowerCase()) {
            case "contact name":
                field = ciscoPhoneUi.getField(EMERGENCY_CONTACT_NAME);
                if (field.isControlPresent()) {
                    field = ciscoPhoneUi.getField(EMERGENCY_CONTACT_NAME);
                    field.clear();
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg2);
                }
                break;
            case "contact number":
                field = ciscoPhoneUi.getField(EMERGENCY_CONTACT_NUMBER);
                if (field.isControlPresent()) {
                    field = ciscoPhoneUi.getField(EMERGENCY_CONTACT_NUMBER);
                    field.clear();
                } else {
                    log.debug("The Edit text box was not visible on '{}'", arg2);
                }
                break;
        }
    }

    @Then("^the Cisco Phone Emergency Contact \"([^\"]*)\" label is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyEmergencyContactName(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        if (field.isLabelPresent()) {
            String fieldValue = field.getLabelElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Cisco Phone Emergency Contact \"([^\"]*)\" field is non-interactive on \"([^\"]*)\"$")
    public void verifyEmergencyContactNameInteraction(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        if (field.isLabelPresent()) {
            if (field.getLabelElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}' is non-interactive on '{}'", arg1, arg2);
            else {
                log.error("Field '{}' is interactive on on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
        if (field.isValuePresent()) {
            if (field.getLabelElement().getAttribute("enabled").equals("false"))
                log.debug("Verified field '{}' is non-interactive on '{}'", arg1, arg2);
            else {
                log.error("Field '{}' is interactive on on {}", arg1, arg2);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @Then("^the Cisco Phone Emergency Contact \"([^\"]*)\" value is set to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void verifyEmergencyContactNumber(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(arg1.trim().toLowerCase());
        if (field.isValuePresent()) {
            String fieldValue = field.getValueElement().getText().toLowerCase();
            if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
                log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
            } else {
                log.error("Field '{}' was set to '{}' rather than '{}' on {}", arg1, fieldValue, arg2, arg3);
                Environment.softAssert().fail("INCORRECT CISCO PHONE FIELD VALUE");
            }
        } else {
            log.error("Field '{}' was not visible", arg1);
            Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
        }
    }

    @When("^I unlock the Cisco Phone Developer Options option on \"([^\"]*)\"$")
    public void selectOverflowOption(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(OVERFLOW_MENU);
        boolean found;
        if (field.isControlPresent()) {
            tapCiscoPhoneObject("More options", arg1);
            found = field.selectTextMenuOption("About");
            if (found) {
                Point position = ciscoPhoneUi.getCiscoPhoneIconPosition();
                phone.tapOnScreenFor10Seconds(position.getX(), position.getY());
                ciscoPhoneUi.clickExposeButton();
                log.debug("Enabled Cisco Phone developer options");
                ciscoPhoneUi.goBack();
            } else {
                log.error("Could not find menu option '{}'", arg1);
            }
        } else {
            log.debug("The overflow menu was not visible on '{}'", arg1);
        }
    }

    @When("^I place the active Cisco Phone call between \"([^\"]*)\" and \"([^\"]*)\" on hold on \"([^\"]*)\"$")
    public void holdCall(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String callIdCallingPhone = getActiveCiscoPhoneCall(arg1);
        String callIdReceivingPhone = getActiveCiscoPhoneCall(arg2);
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();

        log.debug("Placing the call on hold on : " + arg3);
        ciscoPhoneUi.holdResumeButton(true);
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        assert phone2 != null;
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        if (arg3.equals(arg1)) {
            if (MEDIA_STATE_DURING_HOLD.equals(mediaStatePhone1))
                log.debug("Media States matched on : " + arg1);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg1);

            if (MEDIA_STATE_DURING_HOLD_FAR_END.equals(mediaStatePhone2))
                log.debug("Media States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg2);
        } else {

            if (MEDIA_STATE_DURING_HOLD_FAR_END.equals(mediaStatePhone1))
                log.debug("Media States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg2);

            if (MEDIA_STATE_DURING_HOLD.equals(mediaStatePhone2))
                log.debug("Media States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg2);
        }
    }

    @When("^I place the active Cisco Phone call between \"([^\"]*)\" and \"([^\"]*)\" on resume on \"([^\"]*)\"$")
    public void resumeCall(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String callIdCallingPhone = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdReceivingPhone = getActiveCiscoPhoneCall(arg2, arg1);
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();

        log.debug("Resuming the call from hold on : " + arg3);
        try {
            phone.appium().findElementByAccessibilityId("End call enabled");
            ciscoPhoneUi.endCall();
        } catch (Exception ignored) {
        }

        ciscoPhoneUi.holdResumeButton(false);
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        assert phone2 != null;
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I blind transfer the Cisco Phone call on \"([^\"]*)\" to \"([^\"]*)\"$")
    public void blindTransfer(String arg1, String arg2) {
        VersityPhone phoneThatTransferredTheCall = Environment.getPhone(arg1.trim());
        VersityPhone phoneCallWasTransferredTo = Environment.getPhone(arg2.trim());

        String callIdActiveCall = getActiveCiscoPhoneCall(arg1);

        assert phoneThatTransferredTheCall != null;
        CiscoPhoneUi ciscoPhoneUi = phoneThatTransferredTheCall.getCiscoPhoneUi();
        tapCiscoPhoneObject("More button", arg1);
        tapCiscoPhoneObject("Transfer to number", arg1);

        String callState = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdActiveCall);
        log.debug("Actual Call State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + callState);

        String mediaState = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdActiveCall);
        log.debug("Actual Media State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + mediaState);

        if (CALL_STATE_CALL_ANSWERED.equals(callState))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);

        assert phoneCallWasTransferredTo != null;
        log.debug("Dialing extension number: " + phoneCallWasTransferredTo.callServerDetails().extensionReg1);
        for (char c : phoneCallWasTransferredTo.callServerDetails().extensionReg1.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Start new call button", arg1);
        sleepSeconds(2);
    }

    @When("^I \"([^\"]*)\" the transferred Cisco Phone call on \"([^\"]*)\"$")
    public void answerBlindTransferredCall(String arg1, String arg2) {
        VersityPhone phoneCallWasTransferredTo = Environment.getPhone(arg2.trim());
        String activeCall = getActiveCiscoPhoneCall(arg2);

        assert phoneCallWasTransferredTo != null;
        CiscoPhoneUi ciscoPhoneUi = phoneCallWasTransferredTo.getCiscoPhoneUi();
        sleepSeconds(4);
        log.debug("Phone locked? :" + phoneCallWasTransferredTo.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phoneCallWasTransferredTo.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            if (arg1.toLowerCase().equals("answer")) {
                ciscoPhoneUi.answerCall();
                log.debug("Call answered");
            } else {
                ciscoPhoneUi.declineCall();
                log.debug("Call decline");
            }

        } else {
            log.debug("Phone is either in the CiscoPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phoneCallWasTransferredTo.openNotificationBar();
            if (arg1.toLowerCase().equals("answer")) {
                ciscoPhoneUi.headsUpAnswer();
                log.debug("Call answered");
            } else {
                ciscoPhoneUi.headsUpDecline();
                log.debug("Call declined");
                phoneCallWasTransferredTo.sendKeyEvent(AndroidKey.BACK);
            }
        }
        phoneOnHomeScreen = false;

        sleepSeconds(2);

        if (arg1.toLowerCase().equals("answer")) {

            String callState = phoneCallWasTransferredTo.ciscoPhoneContentProvider().getCallState(activeCall);
            log.debug("Actual Call State for call id: " + activeCall + " on : " + arg2 + " is: " + callState);

            if (CALL_STATE_CALL_ANSWERED.equals(callState))
                log.debug("Call States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Call State on : " + arg2);

            String mediaState = phoneCallWasTransferredTo.ciscoPhoneContentProvider().getMediaState(activeCall);
            log.debug("Actual Media State for call id: " + activeCall + " on : " + arg2 + " is: " + mediaState);

            if (MEDIA_STATE_DURING_CALL.equals(mediaState))
                log.debug("Media States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg2);
        } else {
            String callState = phoneCallWasTransferredTo.ciscoPhoneContentProvider().getCallState(activeCall);
            log.debug("Actual Call State for call id: " + activeCall + " on : " + arg2 + " is: " + callState);

            if (CALL_STATE_CALL_ENDED.equals(callState))
                log.debug("Call States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Call State on : " + arg2);

            String mediaState = phoneCallWasTransferredTo.ciscoPhoneContentProvider().getMediaState(activeCall);
            log.debug("Actual Media State for call id: " + activeCall + " on : " + arg2 + " is: " + mediaState);

            if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaState))
                log.debug("Media States matched on : " + arg2);
            else
                Environment.softAssert().fail("Incorrect Media State on : " + arg2);
        }
    }

    @When("^I end the transferred Cisco Phone call between \"([^\"]*)\" and \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endBlindTransferredCall(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone = Environment.getPhone(arg3.trim());

        String activeCallPhone1 = getActiveCiscoPhoneCall(arg1, arg2);
        String activeCallPhone2 = getActiveCiscoPhoneCall(arg2, arg1);

        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        sleepSeconds(2);

        assert phone1 != null;
        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(activeCallPhone1);
        log.debug("Actual Call State for call id: " + activeCallPhone1 + " on : " + arg1 + " is: " + callStatePhone1);
        assert phone2 != null;
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(activeCallPhone2);
        log.debug("Actual Call State for call id: " + activeCallPhone2 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(activeCallPhone1);
        log.debug("Actual Media State for call id: " + activeCallPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(activeCallPhone2);
        log.debug("Actual Media State for call id: " + activeCallPhone2 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("I attempt to blind transfer the Cisco Phone call on \"([^\"]*)\" to \"([^\"]*)\"$")
    public void attemptToBlindTransfer(String arg1, String arg2) {
        VersityPhone phoneThatTransferredTheCall = Environment.getPhone(arg1.trim());
        String callIdActiveCall = getActiveCiscoPhoneCall(arg1);

        assert phoneThatTransferredTheCall != null;
        CiscoPhoneUi ciscoPhoneUi = phoneThatTransferredTheCall.getCiscoPhoneUi();
        tapCiscoPhoneObject("More button", arg1);
        tapCiscoPhoneObject("Transfer to number", arg1);

        String callState = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdActiveCall);
        log.debug("Actual Call State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + callState);

        String mediaState = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdActiveCall);
        log.debug("Actual Media State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + mediaState);

        if (CALL_STATE_CALL_ANSWERED.equals(callState))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
    }

    @When("I cancel the blind transfer of Cisco Phone call on \"([^\"]*)\" to \"([^\"]*)\"$")
    public void cancelBlindTransfer(String arg1, String arg2) {
        VersityPhone phoneThatTransferredTheCall = Environment.getPhone(arg1.trim());
        String callIdActiveCall = getCiscoPhoneHoldCall(arg1);

        tapCiscoPhoneObject("Back arrow", arg1);
        sleepSeconds(2);
        String callState = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdActiveCall);
        log.debug("Actual Call State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + callState);

        String mediaState = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdActiveCall);
        log.debug("Actual Media State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + mediaState);

        if (CALL_STATE_CALL_ANSWERED.equals(callState))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
    }

    @When("^I end the rejected Cisco Phone call on \"([^\"]*)\"$")
    public void endRejectedBlindTransferredCall(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String activeCallPhone1 = getActiveCiscoPhoneCall(arg1);
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        sleepSeconds(2);
        String callStatePhone1 = phone.ciscoPhoneContentProvider().getCallState(activeCallPhone1);
        log.debug("Actual Call State for call id: " + activeCallPhone1 + " on : " + arg1 + " is: " + callStatePhone1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);

        String mediaStatePhone1 = phone.ciscoPhoneContentProvider().getMediaState(activeCallPhone1);
        log.debug("Actual Media State for call id: " + activeCallPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
    }

    @When("^I toggle Wifi \"([^\"]*)\" on \"([^\"]*)\" with \"([^\"]*)\" and verify CiscoPhone registration status")
    public void toggleWifi(String arg1, String arg2, String arg3) {
        VersityPhone phone;
        if (arg2.equals("Lte Phone"))
            phone = Environment.getUsbHost().getVersityLtePhone();
        else
            phone = Environment.getUsbHost().getVersityWifiPhone();
        log.debug("Model Number: " + phone.getModel());

        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ConfigUiField field = ciscoPhoneUi.getField(OVERFLOW_MENU);
        if (field.isControlPresent()) {
            ciscoPhoneUi.tapOverflowMenu();
            field.selectTextMenuOption("Settings");
        }
        field = ciscoPhoneUi.getField(REGISTRATION_1);
        FieldData heading = DeviceFields.getStrings(BIZ_PHONE, REGISTRATION_1.title().trim());
        field.scrollIntoView(heading);
        field.tap();
        field = ciscoPhoneUi.getField(TRANSPORT);
        if (field.isControlPresent()) {
            ciscoPhoneUi.tapTransportLabel();
            field.selectCheckedMenuOption(arg3.trim());
        }
        ciscoPhoneUi.goBack();
        ciscoPhoneUi.goBack();

        if (arg1.equals("Off")) {
            phone.toggleWifiSvc(false);
            if (arg3.equals("TCP"))
                sleepSeconds(35);
            else
                sleepSeconds(300);
            String actualRegCode = phone.ciscoPhoneContentProvider().getRegistrationCode();
            log.debug("Registration Code should not be: " + REG_CODE_OK);
            if (!REG_CODE_OK.equals(actualRegCode)) {
                log.debug("Registration Code is: " + actualRegCode);
            } else {
                log.error("Registration Code is: " + actualRegCode);
                Environment.softAssert().fail("Incorrect Registration Code");
            }
        } else {
            phone.toggleWifiSvc(true);
            sleepSeconds(35);
            String actualRegCode = phone.ciscoPhoneContentProvider().getRegistrationCode();
            log.debug("Registration Code should be: " + REG_CODE_OK);
            if (REG_CODE_OK.equals(actualRegCode)) {
                log.debug("Registration Code is: " + actualRegCode);
            } else {
                log.error("Registration Code is: " + actualRegCode);
                Environment.softAssert().fail("Incorrect Registration Code");
            }
        }
    }

    @When("^I announce transfer the Cisco Phone call with \"([^\"]*)\" on \"([^\"]*)\" to \"([^\"]*)\"$")
    public void announceTransfer(String arg1, String arg2, String arg3) {
        VersityPhone phoneThatTransferredTheCall = Environment.getPhone(arg2.trim());

        String callIdPhoneInCall21 = getActiveCiscoPhoneCall(arg2, arg1);
        String callIdPhoneInCall23 = getActiveCiscoPhoneCall(arg2, arg3);

        assert phoneThatTransferredTheCall != null;
        CiscoPhoneUi ciscoPhoneUi = phoneThatTransferredTheCall.getCiscoPhoneUi();
        tapCiscoPhoneObject("More button", arg2);
        tapCiscoPhoneObject("Transfer to call", arg2);

        String callState23 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdPhoneInCall23);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall23 + " on : " + arg2 + " with " + arg3 + " is: " + callState23);

        String mediaState23 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdPhoneInCall23);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall23 + " on : " + arg2 + " with " + arg3 + " is: " + mediaState23);

        if (CALL_STATE_CALL_ANSWERED.equals(callState23))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState23))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);

        ciscoPhoneUi.clickHeldCallToMerge(callIdPhoneInCall21);
        log.debug("Transferring the call with : " + arg1 + " to : " + arg3);
        tapCiscoPhoneObject("Transfer", arg2);
        sleepSeconds(2);

        callState23 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdPhoneInCall23);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall23 + " on : " + arg2 + " with " + arg3 + " is: " + callState23);

        mediaState23 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdPhoneInCall23);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall23 + " on : " + arg2 + " with " + arg3 + " is: " + mediaState23);

        if (CALL_STATE_CALL_ENDED.equals(callState23))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaState23))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);

        String callState21 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdPhoneInCall21);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall21 + " on : " + arg2 + " with " + arg1 + " is: " + callState21);

        String mediaState21 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdPhoneInCall21);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall21 + " on : " + arg2 + " with " + arg1 + " is: " + mediaState21);

        if (CALL_STATE_CALL_ENDED.equals(callState21))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaState21))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("I attempt to announce transfer the Cisco Phone call with \"([^\"]*)\" to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void attemptToAnnounceTransfer(String arg1, String arg2,String arg3) {
        VersityPhone phoneThatTransferredTheCall = Environment.getPhone(arg3.trim());

        String callIdPhoneInCall31 = getActiveCiscoPhoneCall(arg3, arg1);
        String callIdPhoneInCall32 = getActiveCiscoPhoneCall(arg3, arg2);

        assert phoneThatTransferredTheCall != null;
        CiscoPhoneUi ciscoPhoneUi = phoneThatTransferredTheCall.getCiscoPhoneUi();
        tapCiscoPhoneObject("More button", arg3);
        tapCiscoPhoneObject("Transfer to call", arg3);

        String callState32 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdPhoneInCall32);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall32 + " on : " + arg2 + " with " + arg3 + " is: " + callState32);

        String mediaState32 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdPhoneInCall32);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall32 + " on : " + arg2 + " with " + arg3 + " is: " + mediaState32);

        if (CALL_STATE_CALL_ANSWERED.equals(callState32))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState32))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);
    }

    @When("^I cancel announce transfer the Cisco Phone call with \"([^\"]*)\" to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void cancelAnnounceTransfer(String arg1, String arg2, String arg3) {
        VersityPhone phoneThatTransferredTheCall = Environment.getPhone(arg3.trim());

        String callIdPhoneInCall31 = getActiveCiscoPhoneCall(arg3, arg1);
        String callIdPhoneInCall32 = getActiveCiscoPhoneCall(arg3, arg2);

        tapCiscoPhoneObject("Toolbar cross button", arg3);
        sleepSeconds(2);

        String callState32 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdPhoneInCall32);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall32 + " on : " + arg3 + " with " + arg2 + " is: " + callState32);

        String mediaState32 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdPhoneInCall32);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall32 + " on : " + arg3 + " with " + arg2 + " is: " + mediaState32);

        if (CALL_STATE_CALL_ANSWERED.equals(callState32))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (MEDIA_STATE_DURING_CALL.equals(mediaState32))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);

        String callState31 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getCallState(callIdPhoneInCall31);
        log.debug("Actual Call State for call id: " + callIdPhoneInCall31 + " on : " + arg3 + " with " + arg1 + " is: " + callState31);

        String mediaState31 = phoneThatTransferredTheCall.ciscoPhoneContentProvider().getMediaState(callIdPhoneInCall31);
        log.debug("Actual Media State for call id: " + callIdPhoneInCall31 + " on : " + arg3 + " with " + arg1 + " is: " + mediaState31);

        if (CALL_STATE_CALL_ANSWERED.equals(callState31))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState31))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);
    }

    @When("^I add a Cisco Phone call from \"([^\"]*)\" to \"([^\"]*)\"$")
    public void addCall(String arg1, String arg2) {
        VersityPhone phoneAddingACall = Environment.getPhone(arg1.trim());
        VersityPhone phoneReceivingCall = Environment.getPhone(arg2.trim());

        String callIdActiveCall = getActiveCiscoPhoneCall(arg1);

        assert phoneAddingACall != null;
        CiscoPhoneUi ciscoPhoneUi = phoneAddingACall.getCiscoPhoneUi();
        tapCiscoPhoneObject("More button", arg1);
        tapCiscoPhoneObject("Add call", arg1);

        String callState = phoneAddingACall.ciscoPhoneContentProvider().getCallState(callIdActiveCall);
        log.debug("Actual Call State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + callState);

        String mediaState = phoneAddingACall.ciscoPhoneContentProvider().getMediaState(callIdActiveCall);
        log.debug("Actual Media State for call id: " + callIdActiveCall + " on : " + arg1 + " is: " + mediaState);

        if (CALL_STATE_CALL_ANSWERED.equals(callState))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);

        assert phoneReceivingCall != null;
        log.debug("Dialing extension number: " + phoneReceivingCall.callServerDetails().extensionReg1);
        for (char c : phoneReceivingCall.callServerDetails().extensionReg1.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Start new call button", arg1);
        sleepSeconds(2);
    }

    @When("^I choose to resume Cisco Phone call with \"([^\"]*)\" on \"([^\"]*)\" putting the other call with \"([^\"]*)\" on hold")
    public void holdResume(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        String callIdArg21 = getActiveCiscoPhoneCall(arg2, arg1);
        String callIdArg23 = getActiveCiscoPhoneCall(arg2, arg3);

        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.clickHeldCallToMerge(callIdArg21);
        log.debug("Resuming call with : " + arg1 + " on " + arg2);

        String callState21 = phone.ciscoPhoneContentProvider().getCallState(callIdArg21);
        log.debug("Actual Call State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg1 + " is: " + callState21);

        String mediaState21 = phone.ciscoPhoneContentProvider().getMediaState(callIdArg21);
        log.debug("Actual Media State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg1 + " is: " + mediaState21);

        if (CALL_STATE_CALL_ANSWERED.equals(callState21))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_DURING_CALL.equals(mediaState21))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);

        String callState23 = phone.ciscoPhoneContentProvider().getCallState(callIdArg23);
        log.debug("Actual Call State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg3 + " is: " + callState23);

        String mediaState23 = phone.ciscoPhoneContentProvider().getMediaState(callIdArg23);
        log.debug("Actual Media State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg3 + " is: " + mediaState23);

        if (CALL_STATE_CALL_ANSWERED.equals(callState23))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState23))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I merge Cisco Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void mergeCall(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callIdArg21 = getActiveCiscoPhoneCall(arg2, arg1);

        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        tapCiscoPhoneObject("More button", arg2);
        tapCiscoPhoneObject("Conference call", arg2);
        log.debug("Resuming call with : " + arg1 + " on " + arg2);
        ciscoPhoneUi.clickHeldCallToMerge(callIdArg21);
        tapCiscoPhoneObject("Merge button", arg2);

        sleepSeconds(2);

        String callState21 = phone.ciscoPhoneContentProvider().getCallState(callIdArg21);
        log.debug("Actual Call State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg1 + " is: " + callState21);

        String mediaState21 = phone.ciscoPhoneContentProvider().getMediaState(callIdArg21);
        log.debug("Actual Media State for call id: " + callIdArg21 + " on : " + arg2 + " with " + arg1 + " is: " + mediaState21);

        if (CALL_STATE_CALL_ANSWERED.equals(callState21))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);
        if (MEDIA_STATE_DURING_CALL.equals(mediaState21))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I split Cisco Phone calls with \"([^\"]*)\" and \"([^\"]*)\" on \"([^\"]*)\"$")
    public void splitCalls(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String callIdArg31 = getActiveCiscoPhoneCall(arg3, arg1);
        String callIdArg32 = getActiveCiscoPhoneCall(arg3, arg2);

        sleepSeconds(2);
        assert phone != null;
        tapCiscoPhoneObject("Split call", arg3);
        sleepSeconds(2);

        String callState31 = phone.ciscoPhoneContentProvider().getCallState(callIdArg31);
        log.debug("Actual Call State for call id: " + callIdArg31 + " on : " + arg3 + " with " + arg1 + " is: " + callState31);

        String mediaState31 = phone.ciscoPhoneContentProvider().getMediaState(callIdArg31);
        log.debug("Actual Media State for call id: " + callIdArg31 + " on : " + arg3 + " with " + arg1 + " is: " + mediaState31);

        if (CALL_STATE_CALL_ANSWERED.equals(callState31))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState31))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);

        String callState32 = phone.ciscoPhoneContentProvider().getCallState(callIdArg32);
        log.debug("Actual Call State for call id: " + callIdArg32 + " on : " + arg3 + " with " + arg2 + " is: " + callState32);

        String mediaState32 = phone.ciscoPhoneContentProvider().getMediaState(callIdArg32);
        log.debug("Actual Media State for call id: " + callIdArg32 + " on : " + arg3 + " with " + arg2 + " is: " + mediaState32);

        if (CALL_STATE_CALL_ANSWERED.equals(callState32))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (MEDIA_STATE_DURING_HOLD.equals(mediaState32))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);
    }

    @When("^I end Cisco Phone calls with \"([^\"]*)\" and \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endCalls(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone = Environment.getPhone(arg3.trim());

        String callIdPhone31 = getActiveCiscoPhoneCall(arg3, arg1);
        String callIdPhone32 = getActiveCiscoPhoneCall(arg3, arg2);
        String callIdPhone1 = getActiveCiscoPhoneCall(arg1);
        String callIdPhone2 = getActiveCiscoPhoneCall(arg2);

        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        String callStatePhone31 = phone.ciscoPhoneContentProvider().getCallState(callIdPhone31);
        log.debug("Actual Call State for call id: " + callIdPhone31 + " on : " + arg3 + " with " + arg1 + " is: " + callStatePhone31);
        String callStatePhone32 = phone.ciscoPhoneContentProvider().getCallState(callIdPhone32);
        log.debug("Actual Call State for call id: " + callIdPhone32 + " on : " + arg3 + " with " + arg2 + " is: " + callStatePhone32);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone31))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone32))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);

        String mediaStatePhone31 = phone.ciscoPhoneContentProvider().getMediaState(callIdPhone31);
        log.debug("Actual Media State for call id: " + callIdPhone31 + " on : " + arg3 + " with " + arg1 + " is: " + mediaStatePhone31);
        String mediaStatePhone32 = phone.ciscoPhoneContentProvider().getMediaState(callIdPhone32);
        log.debug("Actual Media State for call id: " + callIdPhone32 + " on : " + arg3 + " with " + arg2 + " is: " + mediaStatePhone32);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone31))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone32))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);

        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone1);
        log.debug("Actual Call State for call id: " + callIdPhone1 + " on : " + arg1 + " with " + arg3 + " is: " + callStatePhone1);
        assert phone2 != null;
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdPhone2);
        log.debug("Actual Call State for call id: " + callIdPhone2 + " on : " + arg2 + " with " + arg3 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone1);
        log.debug("Actual Media State for call id: " + callIdPhone1 + " on : " + arg2 + " with " + arg3 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdPhone2);
        log.debug("Actual Media State for call id: " + callIdPhone2 + " on : " + arg2 + " with " + arg3 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @Then("^I verify \"([^\"]*)\"'s call server name/number \"([^\"]*)\" up on index \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void favoriteIndexVerification(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        String callServerName = targetPhone.callServerDetails().displayName;
        switch (arg2.toLowerCase()) {
            case "shows":
                if (callServerName.equals(ciscoPhoneUi.entryAtIndex(arg3))) {
                    log.debug("Verified " + callServerName + " shows up on index '{}'", arg3);
                } else {
                    log.error(callServerName + " did not show up on index '{}'", arg3);
                    Environment.softAssert().fail("Item did not show up where it should have");
                }
                break;
            case "does not show":
                if (callServerName.equals(ciscoPhoneUi.entryAtIndex(arg3))) {
                    log.error(callServerName + " showed up up on index '{}' when it shouldn't have", arg3);
                    Environment.softAssert().fail("Item showed up where it shouldn't have");
                } else {
                    log.debug("Verified " + callServerName + " did not show up on index '{}'", arg3);
                }
                break;
        }
    }

    @Then("^I verify \"([^\"]*)\" \"([^\"]*)\" up on index \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void favoriteCallLogsContactsVerificationAtIndex(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();

        switch (arg2.toLowerCase()) {
            case "shows":
                if (arg1.equals(ciscoPhoneUi.entryAtIndex(arg3))) {
                    log.debug("Verified " + arg1 + " shows up on index '{}'", arg3);
                } else {
                    log.error(arg1 + " did not show up on index '{}'", arg3);
                    Environment.softAssert().fail("Favorited item did not show up where it should have");
                }
                break;
            case "does not show":
                if (arg1.equals(ciscoPhoneUi.entryAtIndex(arg3))) {
                    log.error(arg1 + " showed up up on index '{}' when it shouldn't have", arg3);
                    Environment.softAssert().fail("Favorited item showed up where it shouldn't have");
                } else {
                    log.debug("Verified " + arg1 + " did not show up on index '{}'", arg3);
                }
                break;
        }
    }

    @Then("^I create a local contact for \"([^\"]*)\" with name as \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void createLocalContact(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.tapCreateNewContact();
        sleepSeconds(2);
        phone.scrollIntoExactViewAttribute("First name");
        phone.appium().findElementByXPath("//android.widget.EditText[(@text ='First name')]").sendKeys(arg2);
        if(phone.appium().isKeyboardShown())
            phone.sendKeyEvent(AndroidKey.BACK);
        phone.scrollIntoExactViewAttribute("Phone");
        phone.appium().findElementByXPath("//android.widget.EditText[(@text ='Phone')]").sendKeys(phone1.callServerDetails().extensionReg1);
        if(phone.appium().isKeyboardShown())
            phone.sendKeyEvent(AndroidKey.BACK);
        ciscoPhoneUi.saveContact();
    }

    @Then("^I create a local contact \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void createContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone != null;
        String[] splitFirstLastNames = arg1.split("\\s+");
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.tapCreateNewContact();
        sleepSeconds(2);
        phone.scrollIntoExactViewAttribute("First name");
        phone.appium().findElementByXPath("//android.widget.EditText[(@text ='First name')]").sendKeys(splitFirstLastNames[0]);
        if(phone.appium().isKeyboardShown())
            phone.sendKeyEvent(AndroidKey.BACK);
        phone.scrollIntoExactViewAttribute("Last name");
        phone.appium().findElementByXPath("//android.widget.EditText[(@text ='Last name')]").sendKeys(splitFirstLastNames[1]);
        if(phone.appium().isKeyboardShown())
            phone.sendKeyEvent(AndroidKey.BACK);
        phone.scrollIntoExactViewAttribute("Phone");
        phone.appium().findElementByXPath("//android.widget.EditText[(@text ='Phone')]").sendKeys(phone1.callServerDetails().extensionReg1);
        if(phone.appium().isKeyboardShown())
            phone.sendKeyEvent(AndroidKey.BACK);
        ciscoPhoneUi.saveContact();
    }

    @When("^I \"([^\"]*)\" the favorites contacts list on Cisco Phone \"([^\"]*)\"$")
    public void expandContractFavoritesList(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        switch (arg1.toLowerCase()) {
            case "expand":
                try {
                    phone.appium().findElementByAccessibilityId("Favorite contacts collapsed title").click();
                } catch (Exception exception) {
                    log.debug("Favorites list already expanded");
                }
                sleepSeconds(1);
                break;
            case "collapse":
                try {
                    phone.appium().findElementByAccessibilityId("Favorite contacts expanded title").click();
                } catch (Exception exception) {
                    log.debug("Favorites list already collapsed");
                }
                sleepSeconds(1);
                break;
        }
    }

    @When("^I \"([^\"]*)\" the local contacts list on Cisco Phone \"([^\"]*)\"$")
    public void expandContractContactsList(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        switch (arg1.toLowerCase()) {
            case "expand":
                try {
                    phone.appium().findElementByAccessibilityId("Local contacts collapsed title").click();
                } catch (Exception exception) {
                    log.debug("Favorites list already expanded");
                }
                sleepSeconds(1);
                break;
            case "collapse":
                try {
                    phone.appium().findElementByAccessibilityId("Local contacts expanded title").click();
                } catch (Exception exception) {
                    log.debug("Favorites list already collapsed");
                }
                sleepSeconds(1);
                break;
        }
    }

    @Then("^I verify contact \"([^\"]*)\" shows up in the favorites contacts list on Cisco Phone \"([^\"]*)\"$")
    public void favoritesList(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1.trim());
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Favorite contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the favorites contacts list", arg1);
        else {
            log.error("Contact '{}' not found in the favorites contacts list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify contact \"([^\"]*)\" shows up in the local contacts list on Cisco Phone \"([^\"]*)\"$")
    public void contactsList(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Local contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the local contacts list", arg1);
        else {
            log.error("Contact '{}' not found in the local contacts list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify contact \"([^\"]*)\" does not show up in the favorites contacts list on Cisco Phone \"([^\"]*)\"$")
    public void favoritesListDoesNotShow(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        try {
            phone.scrollIntoExactViewAttribute(arg1.trim());
            log.error("Contact '{}' showed up in the favorites contacts list when it shouldn't have", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        } catch (Exception exception) {
            log.debug("Contact '{}' did not up in the favorites contacts list", arg1);
        }
    }

    @Then("^I verify contact \"([^\"]*)\" does not show up in the local contacts list on Cisco Phone \"([^\"]*)\"$")
    public void contactsListDoesNotShow(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        try {
            phone.scrollIntoExactViewAttribute(arg1.trim());
            log.error("Contact '{}' showed up in the local contacts list when it shouldn't have", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        } catch (Exception exception) {
            log.debug("Contact '{}' did not up in the local contacts list", arg1);
        }
    }

    @When("^I select the contact at index \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void selectContactAtIndex(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        phone.longPressContentDesc("Contact name index " + arg1 + "title");
    }

    @When("^I add the contact \"([^\"]*)\" to favorites on Cisco Phone \"([^\"]*)\"$")
    public void favoriteContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1.trim());
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Local contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                element.click();
                break;
            }
            log.error("Contact '{}' not found in favorites list", arg1);
        }
        if (!phone.appium().findElementByAccessibilityId("Add remove favorite title").getText().contains("Remove")) {
            phone.appium().findElementByAccessibilityId("Add remove favorite title").click();
            log.debug("Contact '{}' added to favorites", arg1);
        } else {
            log.error("Contact '{}' could not be added to favorites", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        phone.appium().findElementByAccessibilityId("Close icon").click();
    }

    @When("^I remove the contact \"([^\"]*)\" from favorites on Cisco Phone \"([^\"]*)\"$")
    public void removeFromFavorites(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1.trim());
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Favorite contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                element.click();
                break;
            }
            log.error("Contact '{}' not found in favorites list", arg1);
        }
        if (!phone.appium().findElementByAccessibilityId("Add remove favorite title").getText().contains("Add")) {
            phone.appium().findElementByAccessibilityId("Add remove favorite title").click();
            log.debug("Contact '{}' removed from favorites", arg1);
        } else {
            log.error("Contact '{}' could not be removed from favorites", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        phone.appium().findElementByAccessibilityId("Close icon").click();
    }

    @When("^I search for contact \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void searchContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.tapSearchContact();
        phone.appium().findElementByAccessibilityId("Search for contacts").sendKeys(arg1.trim());
        phone.sendKeyEvent(AndroidKey.ENTER);
        sleepSeconds(5);
    }

    @Then("^I verify contact name \"([^\"]*)\" shows up in the favorites contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchContactFavorites(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Favorite contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the search results list", arg1);
        else {
            log.error("Contact '{}' not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify contact name \"([^\"]*)\" shows up in the local contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchContactLocal(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Local contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the search results list", arg1);
        else {
            log.error("Contact '{}' not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify contact name \"([^\"]*)\" shows up in the CUCM contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchContactCucm(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'CUCM search contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the search results list", arg1);
        else {
            log.error("Contact '{}' not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify contact number \"([^\"]*)\" shows up in the favorites contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchContactNumberFavorites(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_number') and contains(@content-desc, 'Favorite contact number')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the search results list", arg1);
        else {
            log.error("Contact '{}' not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify contact number \"([^\"]*)\" shows up in the local contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchContactNumberLocal(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_number') and contains(@content-desc, 'Local contact number')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the search results list", arg1);
        else {
            log.error("Contact '{}' not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify contact number \"([^\"]*)\" shows up in the CUCM contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchContactNumberCucm(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_number') and contains(@content-desc, 'CUCM search contact number')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the search results list", arg1);
        else {
            log.error("Contact '{}' not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify pbx contact number for \"([^\"]*)\" shows up in the favorites contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchPbxContactNumberFavorites(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        phone.scrollIntoExactViewAttribute(targetPhone.callServerDetails().extensionReg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Favorite contact number')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(targetPhone.callServerDetails().extensionReg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the search results list", arg1);
        else {
            log.error("Contact '{}' not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify pbx contact number for \"([^\"]*)\" shows up in the local contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchPbxContactNumberLocal(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        phone.scrollIntoExactViewAttribute(targetPhone.callServerDetails().extensionReg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_number') and contains(@content-desc, 'Local contact number')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(targetPhone.callServerDetails().extensionReg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' number found in the search results list", arg1);
        else {
            log.error("Contact '{}' number not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify pbx contact number for \"([^\"]*)\" shows up in the CUCM contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchPbxContactNumberCucm(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        phone.scrollIntoExactViewAttribute(targetPhone.callServerDetails().extensionReg1);
        boolean found = false;
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'CUCM search contact number')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(targetPhone.callServerDetails().extensionReg1.trim())) {
                found = true;
                break;
            }
        }
        if (found)
            log.debug("Contact '{}' found in the search results list", arg1);
        else {
            log.error("Contact '{}' not found in the search results list", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify contact name \"([^\"]*)\" does not show up in the contacts search list on Cisco Phone \"([^\"]*)\"$")
    public void searchContactCucmDoesNot(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        try {
            phone.scrollIntoExactViewAttribute(arg1.trim());
            log.error("Contact name '{}' showed up in the contacts search list when it shouldn't have", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        } catch (Exception exception) {
            log.debug("Contact name '{}' did not up in the contacts search list", arg1);
        }
    }

    @Then("^I tap the contact \"([^\"]*)\" in the Favorites contacts search results list on Cisco Phone \"([^\"]*)\"$")
    public void tapFavoritesContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1.trim());
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Favorites contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                element.click();
                break;
            }
            log.error("Contact '{}' not found in favorites search results list", arg1);
        }
    }

    @Then("^I tap the contact \"([^\"]*)\" in the Local contacts search results list on Cisco Phone \"([^\"]*)\"$")
    public void tapLocalContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1.trim());
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'Local contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                element.click();
                break;
            }
            log.error("Contact '{}' not found in local contacts search results list", arg1);
        }
    }

    @Then("^I tap the contact \"([^\"]*)\" in the CUCM contacts search results list on Cisco Phone \"([^\"]*)\"$")
    public void tapCucmContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.scrollIntoExactViewAttribute(arg1.trim());
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name') and contains(@content-desc, 'CUCM search contact name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                element.click();
                break;
            }
            log.error("Contact '{}' not found in CUCM search results list", arg1);
        }
    }

    @When("^I delete contact \"([^\"]*)\" from Cisco Phone \"([^\"]*)\"$")
    public void deleteContact(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.tapSearchContact();
        phone.appium().findElementByAccessibilityId("Search for contacts").sendKeys(arg1.trim());
        phone.sendKeyEvent(AndroidKey.ENTER);
        sleepSeconds(5);
        phone.scrollIntoExactViewAttribute(arg1.trim());
        List<WebElement> options = phone.appium().findElementsByXPath("//android.widget.TextView[(@resource-id ='com.cisco.phone:id/contact_name')]");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                element.click();
                break;
            }
            log.error("Contact '{}' not found in favorites list", arg1);
        }
        phone.appium().findElementByAccessibilityId("Edit contact").click();
        selectOverflowOption("Delete", arg2);
        tapCiscoPhoneObject("Ok button", arg2);
        phone.sendKeyEvent(AndroidKey.BACK);
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @When("^I make a Cisco Phone call from \"([^\"]*)\" to an invalid number \"([^\"]*)\"$")
    public void makeAnInvalidCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone1 != null;
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg1);
        log.debug("Dialing extension number: " + arg2);
        for (char c : arg2.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg1);
        sleepSeconds(1);
        ciscoPhoneUi.clearDialpad();
    }

    @When("^I clear dialpad on Cisco Phone \"([^\"]*)\"$")
    public void clearDialpad(String arg1) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        ciscoPhoneUi.clearDialpad();
    }

    @When("^I make a Cisco Phone call from \"([^\"]*)\" to unregistered \"([^\"]*)\"$")
    public void makeACallToUnregisteredNumber(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg1);
        log.debug("Dialing extension number: " + phone2.callServerDetails().extensionReg1);
        for (char c : phone2.callServerDetails().extensionReg1.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg1);
        sleepSeconds(1);
    }

    @When("^I make a Cisco Phone call from \"([^\"]*)\" to unresponsive \"([^\"]*)\"$")
    public void makeACallToUnregisteredInvalidNumber(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg1);
        log.debug("Dialing extension number: " + phone2.callServerDetails().extensionReg1);
        for (char c : phone2.callServerDetails().extensionReg1.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg1);
        sleepSeconds(1);
    }

    @When("^I end the Cisco Phone call dialed to an invalid number on \"([^\"]*)\"")
    public void endCallInvalidNumber(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);
    }

    @When("^I end the Cisco Phone call placed on Voicemail on \"([^\"]*)\"")
    public void endVoicemailCall(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);
    }

    @Then("^I get \"([^\"]*)\"'s caller name on calling Cisco Phone, \"([^\"]*)\"$")
    public void getCallerName(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        switch (arg1) {
            case "PHONE A":
                callerNamePhoneA = ciscoPhoneUi.getCallerNameCalledPhone();
                log.debug("Caller name: PHONE A: " + callerNamePhoneA);
                break;
            case "PHONE B":
                callerNamePhoneB = ciscoPhoneUi.getCallerNameCalledPhone();
                log.debug("Caller name: PHONE B: " + callerNamePhoneB);
                break;
            case "PHONE C":
                callerNamePhoneC = ciscoPhoneUi.getCallerNameCalledPhone();
                log.debug("Caller name: PHONE C: " + callerNamePhoneC);
                break;
        }
    }

    @Then("^I get \"([^\"]*)\"'s caller name on receiving Cisco Phone, \"([^\"]*)\"$")
    public void getCallerNameReceivingPhone(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        String callerName;
        log.debug("Phone locked? :" + phone.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            callerName = ciscoPhoneUi.getCallerNameReceivedCall();
        } else {
            log.debug("Phone is either in the CiscoPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone.openNotificationBar();
            callerName = ciscoPhoneUi.getCallerNameFromHeadsUpNotification();
        }
        phoneOnHomeScreen = false;
        inCall = false;

        switch (arg1) {
            case "PHONE A":
                callerNamePhoneA = callerName;
                log.debug("Caller name: PHONE A: " + callerNamePhoneA);
                break;
            case "PHONE B":
                callerNamePhoneB = callerName;
                log.debug("Caller name: PHONE B: " + callerNamePhoneB);
                break;
            case "PHONE C":
                callerNamePhoneC = callerName;
                log.debug("Caller name: PHONE C: " + callerNamePhoneC);
                break;
        }
    }

    @Then("^I verify \"([^\"]*)\" shows up as the caller name on Cisco Phone \"([^\"]*)\"$")
    public void callerNameVerification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        String callerName = phone.appium().findElementByAccessibilityId("Caller name title").getText();
        if (arg1.equals(callerName)) {
            log.debug("Verified " + arg1 + " shows up as caller name on " + arg2);
        } else {
            log.error(arg1 + " did not show up as caller name on " + arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\" shows up as the caller number on Cisco Phone \"([^\"]*)\"$")
    public void callerNumberVerification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        String callerNumber = phone.appium().findElementByAccessibilityId("Caller number title").getText();
        if (arg1.equals(callerNumber)) {
            log.debug("Verified " + arg1 + " shows up as caller number on " + arg2);
        } else {
            log.error(arg1 + " did not show up as caller number on " + arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify Caller photo shows up on Cisco Phone \"([^\"]*)\"$")
    public void callerPhotoVerification(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        try {
            phone.appium().findElementByAccessibilityId("Contact image");
            log.debug("Caller photo is present on '{}'", arg1);
        }
        catch(Exception exception) {
            log.error("Caller photo is not present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\"'s display name shows up as the caller name on Cisco Phone \"([^\"]*)\"$")
    public void callerNameVal(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone != null;
        String callerName = phone.appium().findElementByAccessibilityId("Caller name title").getText();
        if (callerName.equals(phone1.callServerDetails().displayName)) {
            log.debug("Verified " + phone1.callServerDetails().displayName + " shows up as caller name on " + arg2);
        } else {
            log.error(callerName + " showed up as caller name instead on " + arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\"'s display number shows up as the caller number on Cisco Phone \"([^\"]*)\"$")
    public void callerNumberVal(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone != null;
        String callerNumber = phone.appium().findElementByAccessibilityId("Caller number title").getText();
        if (callerNumber.contains(phone1.callServerDetails().extensionReg1)) {
            log.debug("Verified " + phone1.callServerDetails().extensionReg1 + " shows up as caller number on " + arg2);
        } else {
            log.error(callerNumber + " showed up as caller number instead on " + arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\" shows up as the toolbar title on Cisco Phone \"([^\"]*)\"$")
    public void toolBarVerification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if (phone.appium().findElementByAccessibilityId("Toolbar title").getText().equals(arg1.trim())) {
            log.debug("Verified " + arg1 + " shows up as toolbar title on " + arg2);
        } else {
            log.error(arg1 + " did not show up as toolbar title on " + arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify \"([^\"]*)\"'s number \"([^\"]*)\" up on index \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void listItemVerification(String arg1, String arg2, String arg3, String arg4) {
        VersityPhone phone = Environment.getPhone(arg4.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        assert phone != null;
        assert phone1 != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        switch (arg2.toLowerCase()) {
            case "shows":
                if (phone1.callServerDetails().extensionReg1.equals(ciscoPhoneUi.entryAtIndex(arg3))) {
                    log.debug("Verified " + phone1.callServerDetails().extensionReg1 + " shows up on index '{}'", arg3);
                } else {
                    log.error(phone1.callServerDetails().extensionReg1 + " did not show up on index '{}'", arg3);
                    Environment.softAssert().fail("Item did not show up where it should have");
                }
                break;
            case "does not show":
                if (phone1.callServerDetails().extensionReg1.equals(ciscoPhoneUi.entryAtIndex(arg3))) {
                    log.error(phone1.callServerDetails().extensionReg1 + " showed up up on index '{}' when it shouldn't have", arg3);
                    Environment.softAssert().fail("Item showed up where it shouldn't have");
                } else {
                    log.debug("Verified " + phone1.callServerDetails().extensionReg1 + " did not show up on index '{}'", arg3);
                }
                break;
        }
    }

    @When("^I check Cisco Phone \"([^\"]*)\"'s current screen")
    public void callReceivingPhoneScreen(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        assert phone != null;
        log.debug("Current screen on " + arg1 + " is: " + phone.getForegroundPackage());
        if (phone.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
    }

    @Then("^I verify you cannot have HAC and ANC enabled at the same time on Cisco Phone \"([^\"]*)\"$")
    public void checkAncHacBehavior(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        ciscoPhoneUi.checkAncHacBehavior();
    }

    @When("^I dial the number \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void dialNumber(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg2);
        log.debug("Dialing extension number: " + arg2);
        for (char c : arg1.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg2);
        sleepSeconds(1);
        ciscoPhoneUi.clearDialpad();
    }

    @When("^I dial \"([^\"]*)\"'s number on Cisco Phone \"([^\"]*)\"$")
    public void dialNumberExtension(String arg1, String arg2) {
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        CiscoPhoneUi ciscoPhoneUi = phone2.getCiscoPhoneUi();
        String phoneNumber = phone1.callServerDetails().extensionReg1;
        tapCiscoPhoneObject("Dialpad Tab",arg2);
        log.debug("Dialing extension number: " + phoneNumber);
        for (char c : phoneNumber.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg2);
    }

    @Then("^I verify service unavailable pop up shows up on Cisco Phone \"([^\"]*)\"$")
    public void serviceUnavailablePopup(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        if (ciscoPhoneUi.popUpMessage().equals("Service is not available")) {
            log.debug("Service Unavailable pop up showed up");
        } else {
            log.error("Service Unavailable pop up did not show up");
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify forwarding destination not found pop up shows up on Cisco Phone \"([^\"]*)\"$")
    public void callForwardPopup(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone.appium().findElementById("android:id/message").getText().equals("Forwarding destination not found")) {
            log.debug("Forwarding destination pop up showed up");
        }
        else {
            log.error("Forwarding destination pop up did not show up");
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify forwarding destination not found pop up does not show anymore on Cisco Phone \"([^\"]*)\"$")
    public void callForwardPopupDoesNot(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        try {
            phone.appium().findElementById("android:id/message").getText().equals("Forwarding destination not found");
            log.error("Forwarding destination pop up showed up");
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        catch (Exception exception) {
            log.debug("Forwarding destination pop up did not show up");
        }
    }

    @When("^I set call forwarding to \"([^\"]*)\"'s extension on Cisco Phone \"([^\"]*)\"$")
    public void setCallForwarding(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        String extensionNumberTargetPhone = targetPhone.callServerDetails().extensionReg1;
        selectFeaturesOverflowMenu("Call forwarding", arg2);
        WebElement element1 = phone.appium().findElementByAccessibilityId("Enable call forwarding switch");
        if(element1.getText().equals("OFF"))
            element1.click();
        phone.appium().findElement(By.id("com.cisco.phone:id/forward_edit"));
        WebElement element2 = phone.appium().findElement(By.id("com.cisco.phone:id/forward_edit"));
        ciscoPhoneUi.typeIntoPageEntity(element2, extensionNumberTargetPhone);
        ciscoPhoneUi.goBack();
    }

    @When("^I set call forwarding to \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void setCallForwardingInvalidNumber(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        selectFeaturesOverflowMenu("Call forwarding", arg2);
        WebElement element1 = phone.appium().findElementByAccessibilityId("Enable call forwarding switch");
        if(element1.getText().equals("OFF"))
            element1.click();
        phone.appium().findElement(By.id("com.cisco.phone:id/forward_edit"));
        WebElement element2 = phone.appium().findElement(By.id("com.cisco.phone:id/forward_edit"));
        ciscoPhoneUi.typeIntoPageEntity(element2, arg1);
        ciscoPhoneUi.goBack();
    }

    @When("^I disable call forwarding on Cisco Phone \"([^\"]*)\"$")
    public void disableCallForwarding(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        selectFeaturesOverflowMenu("Call forwarding", arg1);
        WebElement element1 = phone.appium().findElementByAccessibilityId("Enable call forwarding switch");
        if(element1.getText().equals("ON"))
            element1.click();
    }

    @Then("^I verify call forwarding is set to \"([^\"]*)\"'s extension on Cisco Phone \"([^\"]*)\"$")
    public void verifyCallForwarding(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        String extensionNumberTargetPhone = targetPhone.callServerDetails().extensionReg1;
        WebElement element = phone.appium().findElementByAccessibilityId("Toolbar summary");
        if (element.getText().contains("Calls forwarded to " + extensionNumberTargetPhone))
            log.debug("Call forwarding set to '{}' on '{}'", arg1, arg2);
        else {
            log.error("Call forwarding not set to '{}' on '{}'", arg1, arg2);
            Environment.softAssert().fail("Cisco Phone FAILURE");
        }
    }

    @Then("^I verify call forwarding toolbar indication is not present on Cisco Phone \"([^\"]*)\"$")
    public void verifyCallForwardingNotThere(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        try {
            phone.appium().findElementByAccessibilityId("Toolbar summary");
            log.error("call forwarding toolbar indication present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        catch (Exception exception) {
            log.debug("call forwarding toolbar indication is not present on '{}'", arg1);
        }
    }

    @Then("^I verify blue tick not present on Cisco Phone \"([^\"]*)\"$")
    public void noBlueTick(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        try {
            phone.appium().findElementById("com.cisco.phone:id/icon");
            log.error("Blue tick present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        catch (Exception exception) {
            log.debug("Blue tick not present on '{}'", arg1);
        }
    }

    @Then("^I verify call forwarding number view is not present on Cisco Phone \"([^\"]*)\"$")
    public void verifyCallForwardingNumberViewNotThere(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        try {
            phone.appium().findElementByAccessibilityId("Toolbar summary");
            log.error("Call forwarding number view present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        catch (Exception exception) {
            log.debug("Call forwarding number view is not present on '{}'", arg1);
        }
    }

    @When("^I make a Cisco Phone call from \"([^\"]*)\" to \"([^\"]*)\" with call forwarding set to \"([^\"]*)\"$")
    public void makeAForwardedCall(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg3.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        log.debug("Current package on " + arg3 + " is: " + phone2.getForegroundPackage());
        log.debug("Current activity on " + arg3 + " is: " + phone2.getForegroundActivity());
        if (phone2.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone2.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg1 + " to " + arg2);
        assert phone1 != null;
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg1);
        log.debug("Dialing extension number: " + phone.callServerDetails().extensionReg1);
        for (char c : phone.callServerDetails().extensionReg1.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg1);
        sleepSeconds(4);
        String callIdCallingPhone = getIncomingOutgoingCiscoPhoneCallId(arg1);
        log.debug("Call Id of the calling phone: " + arg1 + " is: " + callIdCallingPhone);
        String callIdReceivingPhone = getIncomingOutgoingCiscoPhoneCallId(arg3);
        log.debug("Call Id of the phone receiving the call: " + arg3 + " is: " + callIdReceivingPhone);
    }

    @When("^I make a Cisco Phone call from \"([^\"]*)\" to \"([^\"]*)\" unresponsive with call forwarding set to \"([^\"]*)\"$")
    public void makeAForwardedCallUnresponsive(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg3.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String numberToDial = phone.callServerDetails().extensionReg1;
        log.debug("Deleting Android Driver");
        phone.deleteAndroidDriver();
        log.debug("Rebooting the phone");
        phone.rebootPhone();
        assert phone2 != null;
        log.debug("Current package on " + arg3 + " is: " + phone2.getForegroundPackage());
        log.debug("Current activity on " + arg3 + " is: " + phone2.getForegroundActivity());
        if (phone2.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone2.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg1 + " to " + arg2);
        assert phone1 != null;
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg1);
        log.debug("Dialing extension number: " + numberToDial);
        for (char c : numberToDial.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg1);
        sleepSeconds(4);
        String callIdCallingPhone = getIncomingOutgoingCiscoPhoneCallId(arg1);
        log.debug("Call Id of the calling phone: " + arg1 + " is: " + callIdCallingPhone);
        String callIdReceivingPhone = getIncomingOutgoingCiscoPhoneCallId(arg3);
        log.debug("Call Id of the phone receiving the call: " + arg3 + " is: " + callIdReceivingPhone);
    }

    @Then("^I verify contact number \"([^\"]*)\" shows up at index \"([^\"]*)\" on the Voicemail tab on Cisco Phone \"([^\"]*)\"$")
    public void contactNumberAtIndex(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String textAtIndex = phone.appium().findElementByAccessibilityId("Contact number index " + arg2 + " title").getText();
        if(arg1.equals(textAtIndex))
            log.debug("Contact number '{}' showed up at index '{}' on '{}'", arg1, arg2, arg3);
        else {
            log.error("Contact number '{}' showed up at index '{}' on '{}' instead", textAtIndex, arg2, arg3);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify there are no voicemails on Cisco Phone \"([^\"]*)\"$")
    public void noVoicemail(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String textAtIndex = phone.appium().findElementById("com.cisco.phone:id/tv_no_result").getText();
        if(textAtIndex.equals("No voicemails"))
            log.debug("There are no voicemails on '{}'", arg1);
        else {
            log.error("There still are voicemails on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify contact name \"([^\"]*)\" shows up at index \"([^\"]*)\" on the Voicemail tab on Cisco Phone \"([^\"]*)\"$")
    public void contactNameAtIndex(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String textAtIndex = phone.appium().findElementByAccessibilityId("Contact name index " + arg2 + " title").getText();
        if(arg1.equals(textAtIndex))
            log.debug("Contact name '{}' showed up at index '{}' on '{}'", arg1, arg2, arg3);
        else {
            log.error("Contact name '{}' showed up at index '{}' on '{}' instead", textAtIndex, arg2, arg3);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I verify the voicemail messages count at index \"([^\"]*)\" is \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void noOfVoicemailMessages(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());
        String textAtIndex = phone.appium().findElementByAccessibilityId("voicemail_unread_count_of_index_" + arg1).getText();
        if(arg2.equals(textAtIndex))
            log.debug("'{}' no of messages showed up at index '{}' on '{}'", arg2, arg1, arg3);
        else {
            log.error("'{}' messages showed up at index '{}' on '{}' instead", textAtIndex, arg1, arg3);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @Then("^I tap the contact name \"([^\"]*)\" on the Voicemail tab on Cisco Phone \"([^\"]*)\"$")
    public void tapName(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElementsById("com.cisco.phone:id/contact_name");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                log.debug("Tapping contact name '{}'", arg1);
                element.click();
            }
        }
    }

    @Then("^I tap the contact at index \"([^\"]*)\" on the Voicemail tab on Cisco Phone \"([^\"]*)\"$")
    public void tapNameByIndex(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("Contact name index " + arg1 + " title").click();
    }

    @Then("^I tap the contact number \"([^\"]*)\" on the Voicemail tab on Cisco Phone \"([^\"]*)\"$")
    public void tapNumber(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElementsById("com.cisco.phone:id/contact_number");
        for (WebElement element : options) {
            if (element.getText().trim().contentEquals(arg1.trim())) {
                log.debug("Tapping contact name '{}'", arg1);
                element.click();
            }
        }
    }

    @When("^I delete voicemail at index \"([^\"]*)\" from device on Cisco Phone \"([^\"]*)\"$")
    public void deleteVoicemailMessagesFromDevice(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("voicemail_delete_at_index_" + arg1).click();
        tapCiscoPhoneObject("From device button", arg2);
    }

    @When("^I delete voicemail at index \"([^\"]*)\" from server on Cisco Phone \"([^\"]*)\"$")
    public void deleteVoicemailMessagesFromServer(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("voicemail_delete_at_index_" + arg1).click();
        tapCiscoPhoneObject("From server button", arg2);
    }

    @When("^I decline the Cisco Phone call on \"([^\"]*)\" and let it go to voicemail")
    public void declineCallForVoicemail(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        sleepSeconds(2);
        log.debug("Phone locked? :" + phone.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            ciscoPhoneUi.declineCall();
            log.debug("Call declined");
        } else {
            log.debug("Phone is either in the CiscoPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone.openNotificationBar();
            ciscoPhoneUi.headsUpDecline();
            log.debug("Call declined");
            phone.sendKeyEvent(AndroidKey.BACK);
        }
        phoneOnHomeScreen = false;
    }

    @Then("^I verify voicemail notification exists on Cisco Phone \"([^\"]*)\"$")
    public void voicemailNotification(String arg1) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("android:id/title");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("Voicemail waiting")) {
                found = true;
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            }
        }
        if(found)
            log.debug("Voicemail notification present on '{}'", arg1);
        else {
            log.error("Voicemail notification not present on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify voicemail notification does not exist on Cisco Phone \"([^\"]*)\"$")
    public void voicemailNotificationDoesNotExist(String arg1) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("android:id/title");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("Voicemail waiting")) {
                found = true;
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            }
        }
        if(found) {
            log.error("Voicemail notification present on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        else
            log.debug("Voicemail notification not present on '{}'", arg1);
    }

    @Then("^I verify call park notification does not exist on Cisco Phone \"([^\"]*)\"$")
    public void callParkDoesNotExist(String arg1) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("android:id/header_text");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("Parked call")) {
                found = true;
                phone.sendKeyEvent(AndroidKey.BACK);
                break;
            }
        }
        phone.sendKeyEvent(AndroidKey.BACK);
        if(found) {
            log.error("Voicemail notification present on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        else
            log.debug("Voicemail notification not present on '{}'", arg1);
    }

    @Then("^I verify tapping voicemail notification dials the voicemail number on Cisco Phone \"([^\"]*)\"$")
    public void voicemailNotificationDial(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("android:id/title");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("Voicemail waiting")) {
                element.click();
                sleepSeconds(5);
                if(phone.appium().findElementByAccessibilityId("Caller name title").getText().equals("VoiceMail"))
                    log.debug("VoiceMail called on '{}'", arg1);
                else {
                    log.error("VoiceMail not called on'{}'", arg1);
                    Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
                }
                tapCiscoPhoneObject("End call", arg1);
            }
        }
    }

    @When("^I tap the \"([^\"]*)\" number on the contact details screen on Cisco Phone \"([^\"]*)\"$")
    public void tapNumberContactDetails(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());

        switch (arg1.toLowerCase()) {
            case "work":
                phone.appium().findElementByAccessibilityId("Phone work title").click();
                break;
            case "home":
                phone.appium().findElementByAccessibilityId("Phone home title").click();
                break;
            case "mobile":
                phone.appium().findElementByAccessibilityId("Phone mobile title").click();
                break;
        }
    }

    @Then("^I verify \"([^\"]*)\" number is saved as \"([^\"]*)\" on the contact details screen on Cisco Phone \"([^\"]*)\"$")
    public void verifyNumberContactDetails(String arg1, String arg2, String arg3) {
        VersityPhone phone = Environment.getPhone(arg3.trim());

        switch (arg1.toLowerCase()) {
            case "work":
                if (phone.appium().findElementByAccessibilityId("Phone work title").getText().equals(arg2.trim()))
                    log.debug("'{}' is saved as '{}' on '{}'", arg1, arg2, arg3);
                else {
                    log.error("'{}' is saved as '{}' instead on '{}'", arg1, phone.appium().findElementByAccessibilityId("Phone work title").getText(), arg3);
                    Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
                }
                break;
            case "home":
                if (phone.appium().findElementByAccessibilityId("Phone home title").getText().equals(arg2.trim()))
                    log.debug("'{}' is saved as '{}' on '{}'", arg1, arg2, arg3);
                else {
                    log.error("'{}' is saved as '{}' instead on '{}'", arg1, phone.appium().findElementByAccessibilityId("Phone work title").getText(), arg3);
                    Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
                }
                break;
            case "mobile":
                if (phone.appium().findElementByAccessibilityId("Phone mobile title").getText().equals(arg2.trim()))
                    log.debug("'{}' is saved as '{}' on '{}'", arg1, arg2, arg3);
                else {
                    log.error("'{}' is saved as '{}' instead on '{}'", arg1, phone.appium().findElementByAccessibilityId("Phone work title").getText(), arg3);
                    Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
                }
                break;
        }
    }

    @Then("^I verify the Cisco Phone dialer is populated with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void dialerNumber(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String dialerText = phone.appium().findElementByAccessibilityId("Dialpad entry text").getText();
        if(arg1.equals(dialerText))
            log.debug("Dialer is populated with '{}' on '{}'", arg1, arg2);
        else {
            log.error("Dialer is instead populated with '{}' on '{}'", dialerText, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I play the voicemail message at index \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void playVoicemailAtIndex(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("voicemail_arrival_time_at_index_" + arg1).click();
    }

    @Then("^I verify Message waiting notification is present on lock screen on Cisco Phone \"([^\"]*)\"$")
    public void mwNotificationOnLockScreen(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.appium().findElementByAccessibilityId("voicemail_arrival_time_at_index_" + arg1).click();
    }

    @Then("^I verify \"([^\"]*)\" shows up as caller Name on Cisco Phone \"([^\"]*)\"$")
    public void verifyCallIsSentToVoicemail(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if(phone.appium().findElementByAccessibilityId("Caller name title").getText().equals(arg1))
            log.debug("VoiceMail called on '{}'", arg1);
        else {
            log.error("VoiceMail not called on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify the Cisco Phone call between \"([^\"]*)\" and \"([^\"]*)\" is in two way audio")
    public void twoWayAudio(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        callStartTime = getCurrentTime();
        sleepSeconds(2);
        String callIdCallingPhone = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdReceivingPhone = getActiveCiscoPhoneCall(arg2, arg1);

        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else {
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        }
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I park the Cisco Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void parkCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg2.trim());
        VersityPhone phone2 = Environment.getPhone(arg1.trim());
        String callIdPhone12 = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdPhone21 = getActiveCiscoPhoneCall(arg2, arg1);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);

        selectOverflowOption("Park call", arg2);

        sleepSeconds(5);

        String callStatePhone1 = phone2.ciscoPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone2.ciscoPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_HOLD_FAR_END.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I resume the parked Cisco Phone call with \"([^\"]*)\" by tapping the notification on \"([^\"]*)\"$")
    public void resumeParkedCallFromNotification(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());

        phone2.openNotificationBar();
        phone2.appium().findElementByAccessibilityId("Caller number title").click();
        sleepSeconds(5);

        String callIdPhone12 = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdPhone21 = getActiveCiscoPhoneCall(arg2, arg1);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);

        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I resume the parked Cisco Phone call with \"([^\"]*)\" by \"([^\"]*)\" on another phone \"([^\"]*)\"$")
    public void resumeParkedCallFromAnotherPhone(String arg1, String arg2, String arg3) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        VersityPhone phone3 = Environment.getPhone(arg3.trim());

        phone2.openNotificationBar();
        String callParkNumber = phone2.appium().findElementByAccessibilityId("Caller number title").getText();
        phone2.sendKeyEvent(AndroidKey.BACK);

        log.debug("Current package on " + arg1 + " is: " + phone1.getForegroundPackage());
        log.debug("Current activity on " + arg1 + " is: " + phone1.getForegroundActivity());
        if (phone1.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone1.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg3 + " to " + arg1);

        CiscoPhoneUi ciscoPhoneUi = phone3.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg3);
        log.debug("Dialing call park number: " + callParkNumber);
        for (char c : callParkNumber.toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg3);

        sleepSeconds(5);

        String callIdPhone13 = getActiveCiscoPhoneCall(arg1, arg3);
        String callIdPhone31 = getActiveCiscoPhoneCall(arg3, arg1);
        log.debug("callIdPhone13: " + callIdPhone13);
        log.debug("callIdPhone31: " + callIdPhone31);

        assert phone1 != null;
        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone13);
        log.debug("Actual Call State for call id: " + callIdPhone13 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone3 = phone3.ciscoPhoneContentProvider().getCallState(callIdPhone31);
        log.debug("Actual Call State for call id: " + callIdPhone31 + " on : " + arg3 + " is: " + callStatePhone3);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone3))
            log.debug("Call States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg3);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone13);
        log.debug("Actual Media State for call id: " + callIdPhone13 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone3 = phone3.ciscoPhoneContentProvider().getMediaState(callIdPhone31);
        log.debug("Actual Media State for call id: " + callIdPhone31 + " on : " + arg3 + " is: " + mediaStatePhone3);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone3))
            log.debug("Media States matched on : " + arg3);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg3);
    }

    @When("^I end the parked Cisco Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endParkedCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone1 = getActiveCiscoPhoneCall(arg1);
        String callIdPhone2 = getActiveCiscoPhoneCall(arg2);
        log.debug("callIdPhone1: " + callIdPhone1);
        log.debug("callIdPhone2: " + callIdPhone2);
        assert phone2 != null;
        CiscoPhoneUi ciscoPhoneUi = phone2.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone1);
        log.debug("Actual Call State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdPhone2);
        log.debug("Actual Call State for call id: " + callIdPhone2 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone1);
        log.debug("Actual Media State for call id: " + callIdPhone1 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdPhone2);
        log.debug("Actual Media State for call id: " + callIdPhone2 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I answer the park reversion Cisco Phone call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void answerParkReversionCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg2.trim());
        VersityPhone phone2 = Environment.getPhone(arg1.trim());
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        sleepSeconds(2);
        phone1.openNotificationBar();
        ciscoPhoneUi.headsUpAnswer();
        log.debug("Call answered");
        callStartTime = getCurrentTime();
        sleepSeconds(2);
        assert phone1 != null;
        String callIdCallingPhone = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdReceivingPhone = getActiveCiscoPhoneCall(arg2, arg1);

        log.debug("callIdCallingPhone: " + callIdCallingPhone);
        log.debug("callIdReceivingPhone: " + callIdReceivingPhone);


        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else {
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        }
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I make a Cisco Phone hunt group call from \"([^\"]*)\" to \"([^\"]*)\"$")
    public void makeAHuntGroupCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        log.debug("Current package on " + arg2 + " is: " + phone2.getForegroundPackage());
        log.debug("Current activity on " + arg2 + " is: " + phone2.getForegroundActivity());
        if (phone2.getForegroundPackage().equals("com.android.launcher3"))
            phoneOnHomeScreen = true;
        if (phone2.getForegroundActivity().endsWith(".activities.InCallScreen"))
            inCall = true;
        log.debug("Calling from " + arg1 + " to " + arg2);
        assert phone1 != null;
        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        tapCiscoPhoneObject("Dialpad Tab",arg1);
        log.debug("Dialing extension number: " + phone1.callServerDetails().getHuntGroupNumber());
        for (char c : phone1.callServerDetails().getHuntGroupNumber().toCharArray()) {
            ciscoPhoneUi.clickDialNumber(c);
        }
        tapCiscoPhoneObject("Call button", arg1);
        sleepSeconds(4);
        String callIdCallingPhone = getIncomingOutgoingCiscoPhoneCallId(arg1);
        log.debug("Call Id of the calling phone: " + arg1 + " is: " + callIdCallingPhone);
        String callIdReceivingPhone = getIncomingOutgoingCiscoPhoneCallId(arg2);
        log.debug("Call Id of the phone receiving the call: " + arg2 + " is: " + callIdReceivingPhone);
    }

    @When("^I answer the Cisco Phone hunt group call from \"([^\"]*)\" on \"([^\"]*)\"$")
    public void answerHuntGroupCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        assert phone2 != null;
        CiscoPhoneUi ciscoPhoneUi = phone2.getCiscoPhoneUi();
        sleepSeconds(2);
        log.debug("Phone locked? :" + phone2.isLocked());
        log.debug("Phone in Call? :" + inCall);
        if (phone2.isLocked() || inCall || phoneOnHomeScreen) {
            log.debug("Phone is either on home screen or in another call or locked");
            log.debug("Showing the full screen incoming call notification");
            ciscoPhoneUi.answerCall();
        } else {
            log.debug("Phone is either in the CiscoPhone app or in another other app");
            log.debug("Showing just the heads-up incoming call notification");
            phone2.openNotificationBar();
            ciscoPhoneUi.headsUpAnswer();
        }
        log.debug("Call answered");
        phoneOnHomeScreen = false;
        inCall = false;
        callStartTime = getCurrentTime();

        sleepSeconds(2);

        assert phone1 != null;
        String callIdCallingPhone = getActiveCiscoPhoneCall(arg1);
        String callIdReceivingPhone = getActiveCiscoPhoneCall(arg2);

        log.debug("callIdCallingPhone: " + callIdCallingPhone);
        log.debug("callIdReceivingPhone: " + callIdReceivingPhone);

        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdCallingPhone);
        log.debug("Actual Call State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdReceivingPhone);
        log.debug("Actual Call State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ANSWERED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdCallingPhone);
        log.debug("Actual Media State for call id: " + callIdCallingPhone + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdReceivingPhone);
        log.debug("Actual Media State for call id: " + callIdReceivingPhone + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else {
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        }
        if (MEDIA_STATE_DURING_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @When("^I end the Cisco Phone hunt group call with \"([^\"]*)\" on \"([^\"]*)\"$")
    public void endHuntGroupCall(String arg1, String arg2) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        VersityPhone phone2 = Environment.getPhone(arg2.trim());
        String callIdPhone12 = getActiveCiscoPhoneCall(arg1);
        String callIdPhone21 = getActiveCiscoPhoneCall(arg2);
        log.debug("callIdPhone12: " + callIdPhone12);
        log.debug("callIdPhone21: " + callIdPhone21);
        assert phone2 != null;
        CiscoPhoneUi ciscoPhoneUi = phone2.getCiscoPhoneUi();
        ciscoPhoneUi.endCall();
        log.debug("Call ended");
        sleepSeconds(5);

        assert phone1 != null;
        String callStatePhone1 = phone1.ciscoPhoneContentProvider().getCallState(callIdPhone12);
        log.debug("Actual Call State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + callStatePhone1);
        String callStatePhone2 = phone2.ciscoPhoneContentProvider().getCallState(callIdPhone21);
        log.debug("Actual Call State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + callStatePhone2);

        if (CALL_STATE_CALL_ENDED.equals(callStatePhone1))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (CALL_STATE_CALL_ENDED.equals(callStatePhone2))
            log.debug("Call States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg2);

        String mediaStatePhone1 = phone1.ciscoPhoneContentProvider().getMediaState(callIdPhone12);
        log.debug("Actual Media State for call id: " + callIdPhone12 + " on : " + arg1 + " is: " + mediaStatePhone1);
        String mediaStatePhone2 = phone2.ciscoPhoneContentProvider().getMediaState(callIdPhone21);
        log.debug("Actual Media State for call id: " + callIdPhone21 + " on : " + arg2 + " is: " + mediaStatePhone2);

        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone1))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
        if (MEDIA_STATE_NOT_IN_ACTIVE_CALL.equals(mediaStatePhone2))
            log.debug("Media States matched on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg2);
    }

    @Then("^I verify Cisco Phone call is in active call state on \"([^\"]*)\"$")
    public void verifyCallState(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        String callId = getActiveCiscoPhoneCall(arg1);
        sleepSeconds(2);
        String callState = phone.ciscoPhoneContentProvider().getCallState(callId);
        log.debug("Actual Call State for call id: " + callId + " on : " + arg1 + " is: " + callState);
        String mediaState = phone.ciscoPhoneContentProvider().getMediaState(callId);
        log.debug("Actual Media State for call id: " + callId + " on : " + arg1 + " is: " + mediaState);
        if (CALL_STATE_CALL_ANSWERED.equals(callState))
            log.debug("Call States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Call State on : " + arg1);
        if (MEDIA_STATE_DURING_CALL.equals(mediaState))
            log.debug("Media States matched on : " + arg1);
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1);
    }

    @Then("^I verify no call log entries contain \"([^\"]*)\" on \"([^\"]*)\"$")
    public void callLogEntriesValidation(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg2.trim());
        List<WebElement> options = phone.appium().findElements(By.id("com.cisco.phone:id/caller_text_primary"));
        for (WebElement element : options) {
            if(element.getText().trim().startsWith(arg1)) {
                found = true;
                break;
            }
        }
        if(found) {
            log.error("Call Entries containing '{}' showed up on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        else
            log.debug("Call Entries containing '{}' did not show up on '{}'", arg1, arg2);
    }

    @Then("^I verify notification bar indicates calls being forwarding to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void callForwardNotification(String arg1, String arg2) {
        boolean found = false;
        VersityPhone phoneCallsForwardedTo = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("com.android.systemui:id/notification_title");
        for (WebElement element : options) {
            if(element.getText().trim().equalsIgnoreCase("All calls forwarded: " + phoneCallsForwardedTo.callServerDetails().extensionReg1.trim())) {
                found = true;
                break;
            }
        }
        if(found) {
            log.debug("Call forwarded notification present on '{}'", arg1);
        }
        else {
            log.error("Call forwarded notification not present on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify call forwarded notification is not present on \"([^\"]*)\"$")
    public void callForwardNotification(String arg1) {
        boolean found = false;
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        List<WebElement> options = phone.appium().findElementsById("com.android.systemui:id/notification_title");
        for (WebElement element : options) {
            if(element.getText().trim().contains("All calls forwarded:")) {
                found = true;
                break;
            }
        }
        if(found) {
            log.error("Call forwarded notification is present instead on'{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        else {
            log.debug("Call forwarded notification not present on '{}'", arg1);
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Cisco status indicates calls being forwarding to \"([^\"]*)\" on \"([^\"]*)\"$")
    public void callForwardingCiscoStatus(String arg1, String arg2) {
        VersityPhone phoneCallsForwardedTo = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        selectOverflowOption("Cisco Phone Status", arg2);
        String callForwardingTest = phone.appium().findElementByAccessibilityId("Feature status list for index 0 title").getText();
        if(callForwardingTest.contains("Calls forwarded to " + phoneCallsForwardedTo.callServerDetails().extensionReg1))
            log.debug("Cisco Status contains indication calls being forwarded to '{}' on '{}'", arg1, arg2);
        else {
            log.error("Cisco Status does not contain any indication calls being forwarded to '{}' on '{}'", arg1, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Cisco status does not indicate calls being forwarding on \"([^\"]*)\"$")
    public void callForwardingCiscoStatusNotPresent(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        selectOverflowOption("Cisco Phone Status", arg1);
        if(phone.appium().findElementByAccessibilityId("Feature status list for index 0 title").getText().contains("Calls forwarded to")) {
            log.error("Call forward indication present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        else  {
            log.debug("Call forward indication not present on '{}'", arg1);
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Disable button is visible in Call forward notification on \"([^\"]*)\"$")
    public void callForwardingCiscoStatus(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.appium().findElement(By.xpath("//android.widget.TextView[(@resource-id ='android:id/app_name_text') and contains(@text, 'Cisco Phone')]")).click();
        phone.appium().findElement(By.xpath("//android.widget.Button[@content-desc ='Expand' and @index='3']")).click();

        try {
            phone.appium().findElementByAccessibilityId("DISABLE");
            log.debug("Disable button present on '{}'", arg1);
        }
        catch(Exception exception) {
            log.error("Disable button not present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I disable Call forwarding from notification bar on \"([^\"]*)\"$")
    public void callForwardingDisableNotification(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        phone.appium().findElement(By.xpath("//android.widget.TextView[(@resource-id ='android:id/app_name_text') and contains(@text, 'Cisco Phone')]")).click();
        phone.appium().findElement(By.xpath("//android.widget.Button[@content-desc ='Expand' and @index='3']")).click();
        phone.appium().findElementByAccessibilityId("DISABLE").click();
        phone.sendKeyEvent(AndroidKey.BACK);
    }


    @Then("^I verify Caller name is presented as \"([^\"]*)\"'s display name in the heads up notification on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiver(String arg1, String arg2) {
        VersityPhone callerPhone = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.openNotificationBar();
        tapCiscoPhoneObject("Expand button",arg2);
        String callerName = phone.appium().findElementByAccessibilityId("Caller name title").getText();
        if(callerName.equals(callerPhone.callServerDetails().displayName))
            log.debug("Caller name is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller name is presented as '{}' instead on'{}'", callerName, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Caller number is presented as \"([^\"]*)\"'s display number in the heads up notification on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverNumber(String arg1, String arg2) {
        VersityPhone callerPhone = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.openNotificationBar();
        tapCiscoPhoneObject("Expand button",arg2);
        String callerNumber = phone.appium().findElementByAccessibilityId("Caller number title").getText();
        if(callerNumber.contains(callerPhone.callServerDetails().extensionReg1))
            log.debug("Caller number is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller number is presented as '{}' instead on'{}'", callerNumber, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Caller photo is presented in the heads up notification on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverPhoto(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        tapCiscoPhoneObject("Expand button",arg1);
        try {
            phone.appium().findElementByAccessibilityId("Caller photo");
            log.debug("Caller photo is present on '{}'", arg1);
        }
        catch(Exception exception) {
            log.error("Caller photo is not present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify 'Forwarded from \"([^\"]*)\"' indication is presented in the heads up notification on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverForward(String arg1, String arg2) {
        VersityPhone callForwarderPhone = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.openNotificationBar();
        tapCiscoPhoneObject("Expand button",arg2);
        String callerName = phone.appium().findElementById("com.cisco.phone:id/content_text2").getText();
        if (callerName.equals("- Forwarded from: " + callForwarderPhone.callServerDetails().extensionReg1 + " " + callForwarderPhone.callServerDetails().displayName))
            log.debug("Call forwarder '{}' name and number name is presented on'{}'", arg1, arg2);
        else {
            log.error("'{}' is presented instead on'{}'", callerName, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }
    @Then("^I verify Caller name is presented as \"([^\"]*)\"'s display name in the incoming call full screen on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverFullScreen(String arg1, String arg2) {
        VersityPhone callerPhone = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerName = phone.appium().findElementByAccessibilityId("Caller name title").getText();
        if(callerName.equals(callerPhone.callServerDetails().displayName))
            log.debug("Caller name is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller name is presented as '{}' instead on'{}'", callerName, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify Caller number is presented as \"([^\"]*)\"'s display number in the incoming call full screen on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverNumberFullScreen(String arg1, String arg2) {
        VersityPhone callerPhone = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerNumber = phone.appium().findElementByAccessibilityId("Caller number title").getText();
        if(callerNumber.equals(callerPhone.callServerDetails().extensionReg1))
            log.debug("Caller number is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller number is presented as '{}' instead on'{}'", callerNumber, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify Caller photo is presented in the incoming call full screen on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverPhotoFullScreen(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        try {
            phone.appium().findElementByAccessibilityId("Caller photo");
            log.debug("Caller photo is present on '{}'", arg1);
        }
        catch(Exception exception) {
            log.error("Caller photo is not present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify 'Forwarded from \"([^\"]*)\"' indication is presented in the incoming call full screen on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverForwardFullScreen(String arg1, String arg2){
        VersityPhone callForwarderPhone = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerName = phone.appium().findElementByAccessibilityId("Feature text title").getText();
        if (callerName.equals("- Forwarded from: " + callForwarderPhone.callServerDetails().extensionReg1 + " " + callForwarderPhone.callServerDetails().displayName))
            log.debug("Call forwarder '{}' name and number name is presented on'{}'", arg1, arg2);
        else {
            log.error("'{}' is presented instead on'{}'", callerName, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify Called party name is presented as \"([^\"]*)\"'s display name on the calling Cisco Phone \"([^\"]*)\"$")
    public void callingFullScreen(String arg1, String arg2) {
        VersityPhone callerPhone = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerName = phone.appium().findElementByAccessibilityId("Caller name title").getText();
        if(callerName.equals(callerPhone.callServerDetails().displayName))
            log.debug("Caller name is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller name is presented as '{}' instead on'{}'", callerName, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify Called party number is presented as \"([^\"]*)\"'s display number on the calling Cisco Phone \"([^\"]*)\"$")
    public void callingNumberFullScreen(String arg1, String arg2) {
        VersityPhone callerPhone = Environment.getPhone(arg1.trim());
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerNumber = phone.appium().findElementByAccessibilityId("Caller number title").getText();
        if(callerNumber.contains(callerPhone.callServerDetails().extensionReg1))
            log.debug("Caller number is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller number is presented as '{}' instead on'{}'", callerNumber, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify Called party photo is presented on the calling Cisco Phone \"([^\"]*)\"$")
    public void callingPhotoFullScreen(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        try {
            phone.appium().findElementByAccessibilityId("Contact image");
            log.debug("Caller photo is present on '{}'", arg1);
        }
        catch(Exception exception) {
            log.error("Caller photo is not present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I scroll to Missed call notification section on \"([^\"]*)\"$")
    public void missedCallNotificationItem(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        phone.openNotificationBar();
        for (int count = 0; count < 4; count++) {
            List<WebElement> options = phone.appium().findElements(By.id("android:id/header_text"));
            for (WebElement element : options) {
                if (element.getText().contentEquals("Missed call".trim())) {
                    break;
                }
            }
            phone.scrollUpDimensions(0.70, 0.30);
        }
    }

    @Then("^I verify Missed call notification is present on \"([^\"]*)\"$")
    public void missedCallNotificationPresent(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if(missedCallNotification(phone)) {
            log.debug("Missed call notification present on '{}'", arg1);
        }
        else {
            log.error("Missed call notification not present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Missed call notification is not present on \"([^\"]*)\"$")
    public void missedCallNotificationNotPresent(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if(missedCallNotification(phone)) {
            log.error("Missed call notification present on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
        else {
            log.debug("Missed call notification not present on '{}'", arg1);
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    public boolean missedCallNotification(VersityPhone phone) {
        phone.openNotificationBar();
        for (int count = 0; count < 4; count++) {
            List<WebElement> options = phone.appium().findElements(By.id("android:id/header_text"));
            for (WebElement element : options) {
                if (element.getText().contains("Missed call".trim())) {
                    return true;
                }
            }
            phone.scrollUpDimensions(0.80, 0.20);
        }
        return false;
    }

    @Then("^I verify Caller name is presented as \"([^\"]*)\" in the heads up notification on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverCallerName(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.openNotificationBar();
        tapCiscoPhoneObject("Expand button",arg2);
        String callerName = phone.appium().findElementByAccessibilityId("Caller name title").getText();
        if(callerName.equals(arg1))
            log.debug("Caller name is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller name is presented as '{}' instead on'{}'", callerName, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Caller number is presented as \"([^\"]*)\" in the heads up notification on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverCallerNumber(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        phone.openNotificationBar();
        tapCiscoPhoneObject("Expand button",arg2);
        String callerNumber = phone.appium().findElementByAccessibilityId("Caller number title").getText();
        if(callerNumber.equals(arg1))
            log.debug("Caller number is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller number is presented as '{}' instead on'{}'", callerNumber, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I verify Caller name is presented as \"([^\"]*)\" in the incoming call full screen on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverNameFullScreen(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerName = phone.appium().findElementByAccessibilityId("Caller name title").getText();
        if(callerName.equals(arg1))
            log.debug("Caller name is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller name is presented as '{}' instead on'{}'", callerName, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify Caller number is presented as \"([^\"]*)\" in the incoming call full screen on the receiver Cisco Phone \"([^\"]*)\"$")
    public void callReceiverCallerNumberFullScreen(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerNumber = phone.appium().findElementByAccessibilityId("Caller number title").getText();
        if(callerNumber.equals(arg1))
            log.debug("Caller number is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller number is presented as '{}' instead on'{}'", callerNumber, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify Called party name is presented as \"([^\"]*)\" on the calling Cisco Phone \"([^\"]*)\"$")
    public void calledPartyNameCallingPhone(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerName = phone.appium().findElementByAccessibilityId("Caller name title").getText();
        if(callerName.equals(arg1))
            log.debug("Caller name is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller name is presented as '{}' instead on'{}'", callerName, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @Then("^I verify Called party number is presented as \"([^\"]*)\" on the calling Cisco Phone \"([^\"]*)\"$")
    public void calledPartyNumberCallingPhone(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callerNumber = phone.appium().findElementByAccessibilityId("Caller number title").getText();
        if(callerNumber.equals(arg1))
            log.debug("Caller number is presented as '{}''s display name on'{}'", arg1, arg2);
        else {
            log.error("Caller number is presented as '{}' instead on'{}'", callerNumber, arg2);
            Environment.softAssert().fail("INCORRECT CISCO PHONE APP VALUE");
        }
    }

    @When("^I place the Cisco Phone conference call between \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" on hold on \"([^\"]*)\"$")
    public void holdConferenceCall(String arg1,String arg2,String arg3,String arg4) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        String callIdArg12 = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdArg13 = getActiveCiscoPhoneCall(arg1, arg3);
        assert phone1 != null;

        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        log.debug("Placing the conference call on hold on : " + arg1);
        ciscoPhoneUi.holdResumeButton(true);
        sleepSeconds(8);

        assert phone1 != null;
        String mediaState12 = phone1.ciscoPhoneContentProvider().getMediaState(callIdArg12);
        log.debug("Actual Media State for call id: " + callIdArg12 + " on : " + arg1 + " with " + arg2 + " is: " + mediaState12);
        String mediaState13 = phone1.ciscoPhoneContentProvider().getMediaState(callIdArg13);
        log.debug("Actual Media State for call id: " + callIdArg13 + " on : " + arg1 + " with " + arg3 + " is: " + mediaState13);

        if (MEDIA_STATE_DURING_HOLD.equals(mediaState12))
            log.debug("Media States on : " + arg1 + " with " + arg2 + " is matched ");
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1 + " with " + arg2);

        if (MEDIA_STATE_DURING_HOLD.equals(mediaState13))
            log.debug("Media States on : " + arg1 + " with " + arg3 + " is matched ");
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1 + " with " + arg3);

    }

    @When("^I place the Cisco Phone conference call between \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\" on resume on \"([^\"]*)\"$")
    public void resumeConferenceCall(String arg1,String arg2,String arg3,String arg4) {
        VersityPhone phone1 = Environment.getPhone(arg1.trim());
        String callIdArg12 = getActiveCiscoPhoneCall(arg1, arg2);
        String callIdArg13 = getActiveCiscoPhoneCall(arg1, arg3);
        assert phone1 != null;

        CiscoPhoneUi ciscoPhoneUi = phone1.getCiscoPhoneUi();
        log.debug("Placing the conference call on resume on : " + arg1);
        ciscoPhoneUi.holdResumeButton(false);
        sleepSeconds(8);

        String mediaState12 = phone1.ciscoPhoneContentProvider().getMediaState(callIdArg12);
        log.debug("Actual Media State for call id: " + callIdArg12 + " on : " + arg1 + " with " + arg2 + " is: " + mediaState12);
        String mediaState13 = phone1.ciscoPhoneContentProvider().getMediaState(callIdArg13);
        log.debug("Actual Media State for call id: " + callIdArg13 + " on : " + arg1 + " with " + arg3 + " is: " + mediaState13);

        if (MEDIA_STATE_DURING_CALL.equals(mediaState12))
            log.debug("Media States on : " + arg1 + " with " + arg2 + " is matched ");
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1 + " with " + arg2);

        if (MEDIA_STATE_DURING_CALL.equals(mediaState13))
            log.debug("Media States on : " + arg1 + " with " + arg3 + " is matched ");
        else
            Environment.softAssert().fail("Incorrect Media State on : " + arg1 + " with " + arg3);
    }

    @Then("^I verify Cisco Phone call with \"([^\"]*)\" is muted on \"([^\"]*)\"$")
    public void verifyPhoneIsMuted(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callIdPhone = getActiveCiscoPhoneCall(arg2, arg1);
        log.debug("callIdPhone: " + callIdPhone);

        String mediaStatePhone1 = phone.ciscoPhoneContentProvider().getCallMutedState(callIdPhone);
        log.debug("Actual Mute State for call id: " + callIdPhone + " on : " + arg2 + " is: " + mediaStatePhone1);

        if (CALL_MUTED.equals(mediaStatePhone1))
            log.debug("Call is muted on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Mute State on : " + arg2);
    }

    @Then("^I verify Cisco Phone call with \"([^\"]*)\" is unmuted on \"([^\"]*)\"$")
    public void verifyPhoneIsUnmuted(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        String callIdPhone = getActiveCiscoPhoneCall(arg2, arg1);
        log.debug("callIdPhone: " + callIdPhone);

        String mediaStatePhone1 = phone.ciscoPhoneContentProvider().getCallMutedState(callIdPhone);
        log.debug("Actual Mute State for call id: " + callIdPhone + " on : " + arg2 + " is: " + mediaStatePhone1);

        if (CALL_UNMUTED.equals(mediaStatePhone1))
            log.debug("Call is unmuted on : " + arg2);
        else
            Environment.softAssert().fail("Incorrect Mute State on : " + arg2);
    }

    @When("^I select the call log entry at index \"([^\"]*)\" on Cisco Phone \"([^\"]*)\"$")
    public void selectCallLogEntryAtIndex(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        assert phone != null;
        phone.longPressContentDesc("Caller name index " + arg1 + " title");
    }

    @Then("^I verify \"([^\"]*)\"'s caller name and number on Call details screen on Cisco Phone \"([^\"]*)\"$")
    public void callerNameAndNumberVerification(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        VersityPhone targetPhone = Environment.getPhone(arg1.trim());
        assert phone != null;
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        String nameOnCallLog = ciscoPhoneUi.getCallerNameCalledPhone().toLowerCase();
        String numberOnCallLog = ciscoPhoneUi.getCallerNumber().toLowerCase();
        String name = targetPhone.callServerDetails().displayName;
        String number = targetPhone.callServerDetails().extensionReg1;
        if (nameOnCallLog.equals(name.trim().toLowerCase())) {
            if (numberOnCallLog.equals(number.trim().toLowerCase())) {
                log.info("Call details verified successfully");
            } else {
                Environment.softAssert().fail("Caller number "+number+" is not matching with "+numberOnCallLog+" on callLog screen");
            }
        } else {
            Environment.softAssert().fail("Caller name " +name+" is not matching with "+nameOnCallLog +" on callLog screen");
        }
    }

    @Then("^I verify \"([^\"]*)\" notifications appear on the notification badge on Cisco Phone \"([^\"]*)\"$")
    public void notificationBade(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        if(arg1.equals("1")) {
            try {
                phone.appium().findElementByAccessibilityId("Recent, 1 new notification");
                log.debug("1 notification appeared on the notification badge on '{}'", arg2);
            } catch (Exception exception) {
                log.error("Unexpected number of notifications appeared on the notification badge");
                Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
            }
        }
        else {
            try {
                phone.appium().findElementByAccessibilityId("Recent, " + arg1 + " new notifications");
                log.debug("'{}' notifications appeared on the notification badge on '{}'", arg1, arg2);
            } catch (Exception exception) {
                log.error("Unexpected number of notifications appeared on the notification badge");
                Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
            }
        }
    }

    @Then("^I verify no notifications appear on the notification badge on Cisco Phone \"([^\"]*)\"$")
    public void notificationBadeNoNotifications(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        try {
            phone.appium().findElementByAccessibilityId("Recent");
            log.debug("No notifications appeared on the notification badge");
        }
        catch (Exception exception) {
            log.error("Unexpected number of notifications appeared on the notification badge on '{}'", arg1);
            Environment.softAssert().fail("INCORRECT CISCO PHONE VALUE");
        }
    }

    @When("I enter the Cisco Phone voicemail settings if required on \"([^\"]*)\"$")
    public void enterVoicemailCredentials(String arg1){
        VersityPhone phone = Environment.getPhone(arg1.trim());
        CiscoPhoneUi ciscoPhoneUi = phone.getCiscoPhoneUi();
        if(ciscoPhoneUi.isLoginUserNameDisplayed()){
            ConfigUiField usernameField = ciscoPhoneUi.getField(USERNAME_EDIT_TEXT);
            if (usernameField.isControlPresent()) {
                usernameField = ciscoPhoneUi.getField(USERNAME_EDIT_TEXT);
                usernameField.enter(phone.callServerDetails().voicemailUsername);
            } else {
                log.debug("The voicemail username was not visible on '{}'", arg1);
            }

            ConfigUiField passwordField = ciscoPhoneUi.getField(PASSWORD_EDIT_TEXT);
            if (passwordField.isControlPresent()) {
                passwordField = ciscoPhoneUi.getField(PASSWORD_EDIT_TEXT);
                passwordField.enter(phone.callServerDetails().voicemailPassword);
            } else {
                log.debug("The voicemail password was not visible on '{}'", arg1);
            }
            tapCiscoPhoneObject("Login button",arg1);
        }

    }

}