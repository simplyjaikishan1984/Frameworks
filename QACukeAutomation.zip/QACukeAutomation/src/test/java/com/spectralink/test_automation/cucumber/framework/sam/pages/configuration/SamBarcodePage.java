package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.sam.fields.SamFields.BarcodeStrings.*;

public class SamBarcodePage extends SamConfigurationPage {

	@FindBy(id = "expandsetting_barcodeazteck")
	private WebElement aztecExpand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeazteck\"]/div/div/div[1]/button")
	private WebElement aztecClose;

	@FindBy(id = "expandsetting_barcodeCodaBar")
	private WebElement codaBarExpand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeCodaBar\"]/div/div/div[1]/button")
	private WebElement codaBarClose;

	@FindBy(id = "expandsetting_barcodeCode11")
	private WebElement code11Expand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeCode11\"]/div/div/div[1]/button")
	private WebElement code11Close;

	@FindBy(id = "expandsetting_barcodeCode39")
	private WebElement code39Expand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeCode39\"]/div/div/div[1]/button")
	private WebElement code39Close;

	@FindBy(id = "expandsetting_barcodeDataMatrix")
	private WebElement dataMatrixExpand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeDataMatrix\"]/div/div/div[1]/button")
	private WebElement dataMatrixClose;

	@FindBy(id = "expandsetting_barcodeEAN8")
	private WebElement ean8Expand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeEAN8\"]/div/div/div[1]/button")
	private WebElement ean8Close;

	@FindBy(id = "expandsetting_barcodeGs1Databar14")
	private WebElement gs1Databar14Expand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeGs1Databar14\"]/div/div/div[1]/button")
	private WebElement gs1Databar14Close;

	@FindBy(id = "expandsetting_barcodeInterleaved2Of5")
	private WebElement interleaved2Of5Expand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeInterleaved2Of5\"]/div/div/div[1]/button")
	private WebElement interleaved2Of5Close;

	@FindBy(id = "expandsetting_barcodeMatrix2Of5")
	private WebElement matrix2Of5Expand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeMatrix2Of5\"]/div/div/div[1]/button")
	private WebElement matrix2Of5Close;

	@FindBy(id = "expandsetting_barcodeMSIPlessey")
	private WebElement msiPlesseyExpand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeMSIPlessey\"]/div/div/div[1]/button")
	private WebElement msiPlesseyClose;

	@FindBy(id = "expandsetting_barcodeQR")
	private WebElement qrExpand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeQR\"]/div/div/div[1]/button")
	private WebElement qrClose;

	@FindBy(id = "expandsetting_barcodeUPCA")
	private WebElement upcaExpand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeUPCA\"]/div/div/div[1]/button")
	private WebElement upcaClose;

	@FindBy(id = "expandsetting_barcodeUPCE")
	private WebElement upceExpand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeUPCE\"]/div/div/div[1]/button")
	private WebElement upceClose;

	@FindBy(id = "expandsetting_barcodeEnableISBT128")
	private WebElement isbt128Expand;

	@FindBy(xpath = "//*[@id=\"Model_barcodeEnableISBT128\"]/div/div/div[1]/button")
	private WebElement isbt128Close;


	@FindBy(id = "camera_as_scanner_label")
	private WebElement enableScannerLabel;

	@FindBy(id = "barcode_scanner_state")
	private WebElement enableScannerCheckbox;

	@FindBy(id = "edit_setting_barcodeScannerState")
	private WebElement enableScannerEdit;

	@FindBy(id = "delete_setting_barcodeScannerState")
	private WebElement enableScannerDelete;

	public ConfigPageField enableScannerField = new ConfigPageField(
			ENABLE_BARCODE_SCANNER,
			enableScannerLabel,
			enableScannerCheckbox,
			enableScannerDelete,
			enableScannerEdit
	);

	@FindBy(id = "barcodeIlluminationPower")
	private WebElement illuminationTextbox;

	@FindBy(id = "delete_setting_barcodeIlluminationPower")
	private WebElement illuminationDelete;

	@FindBy(id = "edit_setting_barcodeIlluminationPower")
	private WebElement illuminationEdit;

	public ConfigPageField illuminationField = new ConfigPageField(
			ILLUMINATION_POWER,
			illuminationTextbox,
			illuminationDelete,
			illuminationEdit
	);

	@FindBy(id = "barcodeDecodeSessionTimeout")
	private WebElement decodeTimeoutTextbox;

	@FindBy(id = "delete_setting_barcodeDecodeSessionTimeout")
	private WebElement decodeTimeoutDelete;

	@FindBy(id = "edit_setting_barcodeDecodeSessionTimeout")
	private WebElement decodeTimeoutEdit;

	public ConfigPageField decodeTimeoutField = new ConfigPageField(
			DECODE_TIMEOUT,
			decodeTimeoutTextbox,
			decodeTimeoutDelete,
			decodeTimeoutEdit
	);

	@FindBy(xpath = "//label[@for='enable_barcodeAutoCarriageReturnEnabled']")
	private WebElement carriageReturnEnableLabel;

	@FindBy(id = "enable_barcodeAutoCarriageReturnEnabled")
	private WebElement carriageReturnEnableRadio;

	@FindBy(id = "delete_setting_barcodeAutoCarriageReturnEnabled")
	private WebElement carriageReturnDelete;

	@FindBy(id = "edit_setting_barcodeAutoCarriageReturnEnabled")
	private WebElement carriageReturnEdit;

	public ConfigPageField autoCarriageReturnEnableField = new ConfigPageField(
			CARRIAGE_RETURN,
			carriageReturnEnableLabel,
			carriageReturnEnableRadio,
			carriageReturnDelete,
			carriageReturnEdit
	);

	@FindBy(xpath = "//label[@for='disable_barcodeAutoCarriageReturnEnabled']")
	private WebElement carriageReturnDisableLabel;

	@FindBy(id = "disable_barcodeAutoCarriageReturnEnabled")
	private WebElement carriageReturnDisableRadio;

	public ConfigPageField autoCarriageReturnDisableField = new ConfigPageField(
			CARRIAGE_RETURN,
			carriageReturnDisableLabel,
			carriageReturnDisableRadio,
			carriageReturnDelete,
			carriageReturnEdit
	);

	@FindBy(xpath = "//label[@for='enable_barcodeVibrateEnabled']")
	private WebElement vibrateEnableLabel;

	@FindBy(id = "enable_barcodeVibrateEnabled")
	private WebElement vibrateEnableRadio;

	@FindBy(id = "delete_setting_barcodeVibrateEnabled")
	private WebElement vibrateDelete;

	@FindBy(id = "edit_setting_barcodeVibrateEnabled")
	private WebElement vibrateEdit;

	public ConfigPageField vibrateEnableField = new ConfigPageField(
			VIBRATE_SUCCESS,
			vibrateEnableLabel,
			vibrateEnableRadio,
			vibrateDelete,
			vibrateEdit
	);

	@FindBy(xpath = "//label[@for='disable_barcodeVibrateEnabled']")
	private WebElement vibrateDisableLabel;

	@FindBy(id = "disable_barcodeVibrateEnabled")
	private WebElement vibrateDisableRadio;

	public ConfigPageField vibrateDisableField = new ConfigPageField(
			VIBRATE_SUCCESS,
			vibrateDisableLabel,
			vibrateDisableRadio,
			vibrateDelete,
			vibrateEdit
	);

	@FindBy(xpath = "//label[@for='enable_barcodeSoundEnabled']")
	private WebElement soundEnableLabel;

	@FindBy(id = "enable_barcodeSoundEnabled")
	private WebElement soundEnableRadio;

	@FindBy(id = "delete_setting_barcodeSoundEnabled")
	private WebElement soundDelete;

	@FindBy(id = "edit_setting_barcodeSoundEnabled")
	private WebElement soundEdit;

	public ConfigPageField soundEnableField = new ConfigPageField(
			SOUND_SUCCESS,
			soundEnableLabel,
			soundEnableRadio,
			soundDelete,
			soundEdit
	);

	@FindBy(xpath = "//label[@for='disable_barcodeSoundEnabled']")
	private WebElement soundDisableLabel;

	@FindBy(id = "disable_barcodeSoundEnabled")
	private WebElement soundDisableRadio;

	public ConfigPageField soundDisableField = new ConfigPageField(
			SOUND_SUCCESS,
			soundDisableLabel,
			soundDisableRadio,
			soundDelete,
			soundEdit
	);

	@FindBy(id = "barcodeScanSound")
	private WebElement scanSoundMenu;

	@FindBy(id = "delete_setting_barcodeScanSound")
	private WebElement scanSoundDelete;

	@FindBy(id = "edit_setting_barcodeScanSound")
	private WebElement scanSoundEdit;

	public ConfigPageField scanSoundField = new ConfigPageField(
			SUCCESS_TONE,
			scanSoundMenu,
			scanSoundDelete,
			scanSoundEdit
	);

	@FindBy(id = "label_barcodeCode128")
	private WebElement code128Label;

	@FindBy(id = "Server_barcodeCode128")
	private WebElement code128Checkbox;

	@FindBy(id = "delete_setting_barcodeCode128")
	private WebElement code128Delete;

	@FindBy(id = "edit_setting_barcodeCode128")
	private WebElement code128Edit;

	public ConfigPageField code128Field = new ConfigPageField(
			CODE128_SYMBOLOGY,
			code128Label,
			code128Checkbox,
			code128Delete,
			code128Edit
	);

	@FindBy(id = "label_barcodeCode32")
	private WebElement code32Label;

	@FindBy(id = "Server_barcodeCode32")
	private WebElement code32Checkbox;

	@FindBy(id = "delete_setting_barcodeCode32")
	private WebElement code32Delete;

	@FindBy(id = "edit_setting_barcodeCode32")
	private WebElement code32Edit;

	public ConfigPageField code32Field = new ConfigPageField(
			CODE32_SYMBOLOGY,
			code32Label,
			code32Checkbox,
			code32Delete,
			code32Edit
	);

	@FindBy(id = "label_barcodeCode93")
	private WebElement code93Label;

	@FindBy(id = "Server_barcodeCode93")
	private WebElement code93Checkbox;

	@FindBy(id = "delete_setting_barcodeCode93")
	private WebElement code93Delete;

	@FindBy(id = "edit_setting_barcodeCode93")
	private WebElement code93Edit;

	public ConfigPageField code93Field = new ConfigPageField(
			CODE93_SYMBOLOGY,
			code93Label,
			code93Checkbox,
			code93Delete,
			code93Edit
	);

	@FindBy(id = "label_barcodeEAN13")
	private WebElement ean13Label;

	@FindBy(id = "Server_barcodeEAN13")
	private WebElement ean13Checkbox;

	@FindBy(id = "delete_setting_barcodeEAN13")
	private WebElement ean13Delete;

	@FindBy(id = "edit_setting_barcodeEAN13")
	private WebElement ean13Edit;

	public ConfigPageField ean13Field = new ConfigPageField(
			EAN13_SYMBOLOGY,
			ean13Label,
			ean13Checkbox,
			ean13Delete,
			ean13Edit
	);

	@FindBy(id = "label_barcodeGs1128")
	private WebElement gs1128Label;

	@FindBy(id = "Server_barcodeGs1128")
	private WebElement gs1128Checkbox;

	@FindBy(id = "delete_setting_barcodeGs1128")
	private WebElement gs1128Delete;

	@FindBy(id = "edit_setting_barcodeGs1128")
	private WebElement gs1128Edit;

	public ConfigPageField gs1128Field = new ConfigPageField(
			GS1_128_SYMBOLOGY,
			gs1128Label,
			gs1128Checkbox,
			gs1128Delete,
			gs1128Edit
	);

	@FindBy(id = "label_barcodeHanXinCode")
	private WebElement hanXinCodeLabel;

	@FindBy(id = "Server_barcodeHanXinCode")
	private WebElement hanXinCodeCheckbox;

	@FindBy(id = "delete_setting_barcodeHanXinCode")
	private WebElement hanXinCodeDelete;

	@FindBy(id = "edit_setting_barcodeHanXinCode")
	private WebElement hanXinCodeEdit;

	public ConfigPageField hanXinCodeField = new ConfigPageField(
			HAN_XIN_SYMBOLOGY,
			hanXinCodeLabel,
			hanXinCodeCheckbox,
			hanXinCodeDelete,
			hanXinCodeEdit
	);

	@FindBy(id = "label_barcodeMicroPDF417")
	private WebElement microPdf417Label;

	@FindBy(id = "Server_barcodeMicroPDF417")
	private WebElement microPdf417Checkbox;

	@FindBy(id = "delete_setting_barcodeMicroPDF417")
	private WebElement microPdf417Delete;

	@FindBy(id = "edit_setting_barcodeMicroPDF417")
	private WebElement microPdf417Edit;

	public ConfigPageField microPdf417Field = new ConfigPageField(
			MICRO_PDF417_SYMBOLOGY,
			microPdf417Label,
			microPdf417Checkbox,
			microPdf417Delete,
			microPdf417Edit
	);

	@FindBy(id = "label_barcodeMicroQR")
	private WebElement microQrLabel;

	@FindBy(id = "Server_barcodeMicroQR")
	private WebElement microQrCheckbox;

	@FindBy(id = "delete_setting_barcodeMicroQR")
	private WebElement microQrDelete;

	@FindBy(id = "edit_setting_barcodeMicroQR")
	private WebElement microQrEdit;

	public ConfigPageField microQrField = new ConfigPageField(
			MICRO_QR_SYMBOLOGY,
			microQrLabel,
			microQrCheckbox,
			microQrDelete,
			microQrEdit
	);

	@FindBy(id = "label_barcodePDF417")
	private WebElement pdf417Label;

	@FindBy(id = "Server_barcodePDF417")
	private WebElement pdf417Checkbox;

	@FindBy(id = "delete_setting_barcodePDF417")
	private WebElement pdf417Delete;

	@FindBy(id = "edit_setting_barcodePDF417")
	private WebElement pdf417Edit;

	public ConfigPageField pdf417Field = new ConfigPageField(
			PDF417_SYMBOLOGY,
			pdf417Label,
			pdf417Checkbox,
			pdf417Delete,
			pdf417Edit
	);

	@FindBy(id = "label_barcodeazteck")
	private WebElement aztecLabel;

	@FindBy(id = "Server_barcodeazteck")
	private WebElement aztecCheckbox;

	@FindBy(id = "delete_setting_barcodeazteck")
	private WebElement aztecDelete;

	@FindBy(id = "edit_setting_barcodeazteck")
	private WebElement aztecEdit;

	public ConfigPageField aztecField = new ConfigPageField(
			AZTEC_SYMBOLOGY,
			aztecLabel,
			aztecCheckbox,
			aztecDelete,
			aztecEdit
	);

	@FindBy(id = "Server_barcodeaztecpolarity")
	private WebElement aztecPolarityMenu;

	@FindBy(id = "delete_setting_barcodeaztecpolarity")
	private WebElement aztecPolarityDelete;

	@FindBy(id = "edit_setting_barcodeaztecpolarity")
	private WebElement aztecPolarityEdit;

	public ConfigPageField aztecPolarityField = new ConfigPageField(
			AZTEC_POLARITY,
			aztecPolarityMenu,
			aztecPolarityDelete,
			aztecPolarityEdit
	);

	@FindBy(id = "label_barcodeCodaBar")
	private WebElement codaBarLabel;

	@FindBy(id = "Server_barcodeCodaBar")
	private WebElement codaBarCheckbox;

	@FindBy(id = "delete_setting_barcodeCodaBar")
	private WebElement codaBarDelete;

	@FindBy(id = "edit_setting_barcodeCodaBar")
	private WebElement codaBarEdit;

	public ConfigPageField codaBarField = new ConfigPageField(
			CODABAR_SYMBOLOGY,
			codaBarLabel,
			codaBarCheckbox,
			codaBarDelete,
			codaBarEdit
	);

	@FindBy(id = "Server_barcodeCodaBarMinLength")
	private WebElement codaBarLength;

	@FindBy(id = "delete_setting_barcodeCodaBarMinLength")
	private WebElement codaBarLengthDelete;

	@FindBy(id = "edit_setting_barcodeCodaBarMinLength")
	private WebElement codaBarLengthEdit;

	public ConfigPageField codaBarLengthField = new ConfigPageField(
			CODABAR_LENGTH,
			codaBarLength,
			codaBarLengthDelete,
			codaBarLengthEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeCodaBarStripCharacters']")
	private WebElement codaBarStripCharsLabel;

	@FindBy(id = "Server_barcodeCodaBarStripCharacters")
	private WebElement codaBarStripCharsCheckbox;

	@FindBy(id = "delete_setting_barcodeCodaBarStripCharacters")
	private WebElement codaBarStripCharsDelete;

	@FindBy(id = "edit_setting_barcodeCodaBarStripCharacters")
	private WebElement codaBarStripCharsEdit;

	public ConfigPageField codaBarStripCharsField = new ConfigPageField(
			CODABAR_ENABLE_NOTIS,
			codaBarStripCharsLabel,
			codaBarStripCharsCheckbox,
			codaBarStripCharsDelete,
			codaBarStripCharsEdit
	);

	@FindBy(id = "label_barcodeCode11")
	private WebElement code11Label;

	@FindBy(id = "Server_barcodeCode11")
	private WebElement code11Checkbox;

	@FindBy(id = "delete_setting_barcodeCode11")
	private WebElement code11Delete;

	@FindBy(id = "edit_setting_barcodeCode11")
	private WebElement code11Edit;

	public ConfigPageField code11Field = new ConfigPageField(
			CODE11_SYMBOLOGY,
			code11Label,
			code11Checkbox,
			code11Delete,
			code11Edit
	);

	@FindBy(id = "Server_barcodeCode11Checksum")
	private WebElement code11CheckDigitMenu;

	@FindBy(id = "delete_setting_barcodeCode11Checksum")
	private WebElement code11CheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeCode11Checksum")
	private WebElement code11CheckDigitEdit;

	public ConfigPageField code11CheckDigitField = new ConfigPageField(
			CODE11_CHECKDIGIT,
			code11CheckDigitMenu,
			code11CheckDigitDelete,
			code11CheckDigitEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeCode11TransmitCheckDigit']")
	private WebElement code11TransmitCheckDigitLabel;

	@FindBy(id = "Server_barcodeCode11TransmitCheckDigit")
	private WebElement code11TransmitCheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeCode11TransmitCheckDigit")
	private WebElement code11TransmitCheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeCode11TransmitCheckDigit")
	private WebElement code11TransmitCheckDigitEdit;

	public ConfigPageField code11TransmitCheckDigitField = new ConfigPageField(
			CODE11_TRANSMIT_CHECKDIGIT,
			code11TransmitCheckDigitLabel,
			code11TransmitCheckDigitCheckbox,
			code11TransmitCheckDigitDelete,
			code11TransmitCheckDigitEdit
	);

	@FindBy(id = "label_barcodeCode39")
	private WebElement code39Label;

	@FindBy(id = "Server_barcodeCode39")
	private WebElement code39Checkbox;

	@FindBy(id = "delete_setting_barcodeCode39")
	private WebElement code39Delete;

	@FindBy(id = "edit_setting_barcodeCode39")
	private WebElement code39Edit;

	public ConfigPageField code39Field = new ConfigPageField(
			CODE39_SYMBOLOGY,
			code39Label,
			code39Checkbox,
			code39Delete,
			code39Edit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeCode39ASCIIMode']")
	private WebElement code39AsciiModeLabel;

	@FindBy(id = "Server_barcodeCode39ASCIIMode")
	private WebElement code39AsciiModeCheckbox;

	@FindBy(id = "delete_setting_barcodeCode39ASCIIMode")
	private WebElement code39AsciiModeDelete;

	@FindBy(id = "edit_setting_barcodeCode39ASCIIMode")
	private WebElement code39AsciiModeEdit;

	public ConfigPageField code39AsciiModeField = new ConfigPageField(
			CODE39_ASCII,
			code39AsciiModeLabel,
			code39AsciiModeCheckbox,
			code39AsciiModeDelete,
			code39AsciiModeEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeCode39Checksum']")
	private WebElement code39CheckDigitLabel;

	@FindBy(id = "Server_barcodeCode39Checksum")
	private WebElement code39CheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeCode39Checksum")
	private WebElement code39CheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeCode39Checksum")
	private WebElement code39CheckDigitEdit;

	public ConfigPageField code39CheckDigitField = new ConfigPageField(
			CODE39_CHECKDIGIT,
			code39CheckDigitLabel,
			code39CheckDigitCheckbox,
			code39CheckDigitDelete,
			code39CheckDigitEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeCode39TransmitCheckDigit']")
	private WebElement code39TransmitCheckDigitLabel;

	@FindBy(id = "Server_barcodeCode39TransmitCheckDigit")
	private WebElement code39TransmitCheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeCode39TransmitCheckDigit")
	private WebElement barcodeCode39TransmitCheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeCode39TransmitCheckDigit")
	private WebElement barcodeCode39TransmitCheckDigitEdit;

	public ConfigPageField code39TransmitCheckDigitField = new ConfigPageField(
			CODE39_TRANSMIT_CHECKDIGIT,
			code39TransmitCheckDigitLabel,
			code39TransmitCheckDigitCheckbox,
			barcodeCode39TransmitCheckDigitDelete,
			barcodeCode39TransmitCheckDigitEdit
	);

	@FindBy(id = "label_barcodeDataMatrix")
	private WebElement dataMatrixLabel;

	@FindBy(id = "Server_barcodeDataMatrix")
	private WebElement dataMatrixCheckbox;

	@FindBy(id = "delete_setting_barcodeDataMatrix")
	private WebElement dataMatrixDelete;

	@FindBy(id = "edit_setting_barcodeDataMatrix")
	private WebElement dataMatrixEdit;

	public ConfigPageField dataMatrixField = new ConfigPageField(
			DATA_MATRIX_SYMBOLOGY,
			dataMatrixLabel,
			dataMatrixCheckbox,
			dataMatrixDelete,
			dataMatrixEdit
	);

	@FindBy(id = "Server_barcodeDataMatrixMirror")
	private WebElement dataMatrixMirrorMenu;

	@FindBy(id = "delete_setting_barcodeDataMatrixMirror")
	private WebElement dataMatrixMirrorDelete;

	@FindBy(id = "edit_setting_barcodeDataMatrixMirror")
	private WebElement dataMatrixMirrorEdit;

	public ConfigPageField dataMatrixMirrorField = new ConfigPageField(
			DATA_MATRIX_MIRROR,
			dataMatrixMirrorMenu,
			dataMatrixMirrorDelete,
			dataMatrixMirrorEdit
	);

	@FindBy(id = "Server_barcodeDataMatrixPolarity")
	private WebElement dataMatrixPolarityMenu;

	@FindBy(id = "delete_setting_barcodeDataMatrixPolarity")
	private WebElement dataMatrixPolarityDelete;

	@FindBy(id = "edit_setting_barcodeDataMatrixPolarity")
	private WebElement dataMatrixPolarityEdit;

	public ConfigPageField dataMatrixPolarityField = new ConfigPageField(
			DATA_MATRIX_POLARITY,
			dataMatrixPolarityMenu,
			dataMatrixPolarityDelete,
			dataMatrixPolarityEdit
	);

	@FindBy(id = "label_barcodeEAN8")
	private WebElement ean8Label;

	@FindBy(id = "Server_barcodeEAN8")
	private WebElement ean8Checkbox;

	@FindBy(id = "delete_setting_barcodeEAN8")
	private WebElement ean8Delete;

	@FindBy(id = "edit_setting_barcodeEAN8")
	private WebElement ean8Edit;

	public ConfigPageField ean8Field = new ConfigPageField(
			EAN8_SYMBOLOGY,
			ean8Label,
			ean8Checkbox,
			ean8Delete,
			ean8Edit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeEAN8ConvertToEAN13']")
	private WebElement ean8ConvertEan13Label;

	@FindBy(id = "Server_barcodeEAN8ConvertToEAN13")
	private WebElement ean8ConvertEan13Checkbox;

	@FindBy(id = "delete_setting_barcodeEAN8ConvertToEAN13")
	private WebElement ean8ConvertEan13Delete;

	@FindBy(id = "edit_setting_barcodeEAN8ConvertToEAN13")
	private WebElement ean8ConvertEan13Edit;

	public ConfigPageField ean8ConvertEan13Field = new ConfigPageField(
			EAN8_CONVERT_EAN13,
			ean8ConvertEan13Label,
			ean8ConvertEan13Checkbox,
			ean8ConvertEan13Delete,
			ean8ConvertEan13Edit
	);

	@FindBy(id = "label_barcodeGs1Databar14")
	private WebElement gs1Databar14Label;

	@FindBy(id = "Server_barcodeGs1Databar14")
	private WebElement gs1Databar14Checkbox;

	@FindBy(id = "delete_setting_barcodeGs1Databar14")
	private WebElement gs1Databar14Delete;

	@FindBy(id = "edit_setting_barcodeGs1Databar14")
	private WebElement gs1Databar14Edit;

	public ConfigPageField gs1Databar14Field = new ConfigPageField(
			GS1_DATABAR_14_SYMBOLOGY,
			gs1Databar14Label,
			gs1Databar14Checkbox,
			gs1Databar14Delete,
			gs1Databar14Edit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeGs1Databar14CCAB']")
	private WebElement gs1Databar14CcabLabel;

	@FindBy(id = "Server_barcodeGs1Databar14CCAB")
	private WebElement gs1Databar14CcabCheckbox;

	@FindBy(id = "delete_setting_barcodeGs1Databar14CCAB")
	private WebElement gs1Databar14CcabDelete;

	@FindBy(id = "edit_setting_barcodeGs1Databar14CCAB")
	private WebElement gs1Databar14CcabEdit;

	public ConfigPageField gs1Databar14CcabField = new ConfigPageField(
			GS1_DATABAR_14_CCAB,
			gs1Databar14CcabLabel,
			gs1Databar14CcabCheckbox,
			gs1Databar14CcabDelete,
			gs1Databar14CcabEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeGs1Databar14CCC']")
	private WebElement gs1Databar14CccLabel;

	@FindBy(id = "Server_barcodeGs1Databar14CCC")
	private WebElement gs1Databar14CccCheckbox;

	@FindBy(id = "delete_setting_barcodeGs1Databar14CCC")
	private WebElement gs1Databar14CccDelete;

	@FindBy(id = "edit_setting_barcodeGs1Databar14CCC")
	private WebElement gs1Databar14CccEdit;

	public ConfigPageField gs1Databar14CccField = new ConfigPageField(
			GS1_DATABAR_14_CCC,
			gs1Databar14CccLabel,
			gs1Databar14CccCheckbox,
			gs1Databar14CccDelete,
			gs1Databar14CccEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeGs1Databar14Expanded']")
	private WebElement gs1Databar14ExpandedLabel;

	@FindBy(id = "Server_barcodeGs1Databar14Expanded")
	private WebElement gs1Databar14ExpandedCheckbox;

	@FindBy(id = "delete_setting_barcodeGs1Databar14Expanded")
	private WebElement gs1Databar14ExpandedDelete;

	@FindBy(id = "edit_setting_barcodeGs1Databar14Expanded")
	private WebElement gs1Databar14ExpandedEdit;

	public ConfigPageField gs1Databar14ExpandedField = new ConfigPageField(
			GS1_DATABAR_14_EXPANDED,
			gs1Databar14ExpandedLabel,
			gs1Databar14ExpandedCheckbox,
			gs1Databar14ExpandedDelete,
			gs1Databar14ExpandedEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeGs1Databar14Limited']")
	private WebElement gs1Databar14LimitedLabel;

	@FindBy(id = "Server_barcodeGs1Databar14Limited")
	private WebElement gs1Databar14LimitedCheckbox;

	@FindBy(id = "delete_setting_barcodeGs1Databar14Limited")
	private WebElement gs1Databar14LimitedDelete;

	@FindBy(id = "edit_setting_barcodeGs1Databar14Limited")
	private WebElement gs1Databar14LimitedEdit;

	public ConfigPageField gs1Databar14LimitedField = new ConfigPageField(
			GS1_DATABAR_14_LIMITED,
			gs1Databar14LimitedLabel,
			gs1Databar14LimitedCheckbox,
			gs1Databar14LimitedDelete,
			gs1Databar14LimitedEdit
	);

	@FindBy(id = "label_barcodeInterleaved2Of5")
	private WebElement interleaved2Of5Label;

	@FindBy(id = "Server_barcodeInterleaved2Of5")
	private WebElement interleaved2Of5Checkbox;

	@FindBy(id = "delete_setting_barcodeInterleaved2Of5")
	private WebElement interleaved2Of5Delete;

	@FindBy(id = "edit_setting_barcodeInterleaved2Of5")
	private WebElement interleaved2Of5Edit;

	public ConfigPageField interleaved2Of5Field = new ConfigPageField(
			INTERLEAVED_2OF5_SYMBOLOGY,
			interleaved2Of5Label,
			interleaved2Of5Checkbox,
			interleaved2Of5Delete,
			interleaved2Of5Edit
	);

	@FindBy(id = "Server_barcodeInterleaved2Of5Checksum")
	private WebElement interleaved2Of5CheckDigitMenu;

	@FindBy(id = "delete_setting_barcodeInterleaved2Of5Checksum")
	private WebElement interleaved2Of5CheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeInterleaved2Of5Checksum")
	private WebElement interleaved2Of5CheckDigitEdit;

	public ConfigPageField interleaved2Of5CheckDigitField = new ConfigPageField(
			INTERLEAVED_2OF5_CHECKDIGIT,
			interleaved2Of5CheckDigitMenu,
			interleaved2Of5CheckDigitDelete,
			interleaved2Of5CheckDigitEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeInterleaved2Of5TransmitCheckDigit']")
	private WebElement interleaved2Of5TransmitCheckDigitLabel;

	@FindBy(id = "Server_barcodeInterleaved2Of5TransmitCheckDigit")
	private WebElement interleaved2Of5TransmitCheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeInterleaved2Of5TransmitCheckDigit")
	private WebElement interleaved2Of5TransmitCheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeInterleaved2Of5TransmitCheckDigit")
	private WebElement interleaved2Of5TransmitCheckDigitEdit;

	public ConfigPageField interleaved2Of5TransmitCheckDigitField = new ConfigPageField(
			INTERLEAVED_2OF5_TRANSMIT_CHECKDIGIT,
			interleaved2Of5TransmitCheckDigitLabel,
			interleaved2Of5TransmitCheckDigitCheckbox,
			interleaved2Of5TransmitCheckDigitDelete,
			interleaved2Of5TransmitCheckDigitEdit
	);


	@FindBy(xpath = "//label[@for='Server_barcodeInterleaved2Of5QuiteZone']")
	private WebElement interleaved2Of5QuiteZoneLabel;

	@FindBy(id = "Server_barcodeInterleaved2Of5QuiteZone")
	private WebElement interleaved2Of5QuiteZoneCheckbox;

	@FindBy(id = "delete_setting_barcodeInterleaved2Of5QuiteZone")
	private WebElement interleaved2Of5QuiteZoneDelete;

	@FindBy(id = "edit_setting_barcodeInterleaved2Of5QuiteZone")
	private WebElement interleaved2Of5QuiteZoneEdit;

	public ConfigPageField interleaved2Of5QuiteZoneField = new ConfigPageField(
			INTERLEAVED_2OF5_QUIET_ZONE,
			interleaved2Of5QuiteZoneLabel,
			interleaved2Of5QuiteZoneCheckbox,
			interleaved2Of5QuiteZoneDelete,
			interleaved2Of5QuiteZoneEdit
	);

	@FindBy(id = "Server_barcodeInterleaved2of5LengthType")
	private WebElement interleaved2Of5ScanLengthTypeMenu;

	@FindBy(id = "delete_setting_barcodeInterleaved2of5LengthType")
	private WebElement interleaved2Of5ScanLengthTypeDelete;

	@FindBy(id = "edit_setting_barcodeInterleaved2of5LengthType")
	private WebElement interleaved2Of5ScanLengthTypeEdit;

	public ConfigPageField interleaved2Of5ScanLengthTypeField = new ConfigPageField(
			INTERLEAVED_2OF5_LENGTH_TYPE,
			interleaved2Of5ScanLengthTypeMenu,
			interleaved2Of5ScanLengthTypeDelete,
			interleaved2Of5ScanLengthTypeEdit
	);

	@FindBy(id = "Server_barcodeInterleaved2of5Length1")
	private WebElement interleaved2Of5AllowedLength1Textbox;

	@FindBy(id = "delete_setting_barcodeInterleaved2of5Length1")
	private WebElement interleaved2Of5AllowedLength1Delete;

	@FindBy(id = "edit_setting_barcodeInterleaved2of5Length1")
	private WebElement interleaved2Of5AllowedLength1Edit;

	public ConfigPageField interleaved2Of5AllowedLength1Field = new ConfigPageField(
			INTERLEAVED_2OF5_LENGTH_1,
			interleaved2Of5AllowedLength1Textbox,
			interleaved2Of5AllowedLength1Delete,
			interleaved2Of5AllowedLength1Edit
	);

	@FindBy(id = "Server_barcodeInterleaved2of5Length2")
	private WebElement interleaved2Of5AllowedLength2Textbox;

	@FindBy(id = "delete_setting_barcodeInterleaved2of5Length2")
	private WebElement interleaved2Of5AllowedLength2Delete;

	@FindBy(id = "edit_setting_barcodeInterleaved2of5Length2")
	private WebElement interleaved2Of5AllowedLength2Edit;

	public ConfigPageField interleaved2Of5AllowedLength2Field = new ConfigPageField(
			INTERLEAVED_2OF5_LENGTH_2,
			interleaved2Of5AllowedLength2Textbox,
			interleaved2Of5AllowedLength2Delete,
			interleaved2Of5AllowedLength2Edit
	);

	@FindBy(id = "label_barcodeMatrix2Of5")
	private WebElement matrix2Of5Label;

	@FindBy(id = "Server_barcodeMatrix2Of5")
	private WebElement matrix2Of5Checkbox;

	@FindBy(id = "delete_setting_barcodeMatrix2Of5")
	private WebElement matrix2Of5Delete;

	@FindBy(id = "edit_setting_barcodeMatrix2Of5")
	private WebElement matrix2Of5Edit;

	public ConfigPageField matrix2Of5Field = new ConfigPageField(
			MATRIX_2OF5_SYMBOLOGY,
			matrix2Of5Label,
			matrix2Of5Checkbox,
			matrix2Of5Delete,
			matrix2Of5Edit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeMatrix2Of5Checkdigit']")
	private WebElement matrix2Of5CheckDigitLabel;

	@FindBy(id = "Server_barcodeMatrix2Of5Checkdigit")
	private WebElement matrix2Of5CheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeMatrix2Of5Checkdigit")
	private WebElement matrix2Of5CheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeMatrix2Of5Checkdigit")
	private WebElement matrix2Of5CheckDigitEdit;

	public ConfigPageField matrix2Of5CheckDigitField = new ConfigPageField(
			MATRIX_2OF5_CHECKDIGIT,
			matrix2Of5CheckDigitLabel,
			matrix2Of5CheckDigitCheckbox,
			matrix2Of5CheckDigitDelete,
			matrix2Of5CheckDigitEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeMatrix2Of5TransmitCheckDigit']")
	private WebElement matrix2Of5TransmitCheckDigitLabel;

	@FindBy(id = "Server_barcodeMatrix2Of5TransmitCheckDigit")
	private WebElement matrix2Of5TransmitCheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeMatrix2Of5TransmitCheckDigit")
	private WebElement matrix2Of5TransmitCheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeMatrix2Of5TransmitCheckDigit")
	private WebElement matrix2Of5TransmitCheckDigitEdit;

	public ConfigPageField matrix2Of5TransmitCheckDigitField = new ConfigPageField(
			MATRIX_2OF5_TRANSMIT_CHECKDIGIT,
			matrix2Of5TransmitCheckDigitLabel,
			matrix2Of5TransmitCheckDigitCheckbox,
			matrix2Of5TransmitCheckDigitDelete,
			matrix2Of5TransmitCheckDigitEdit
	);

	@FindBy(id = "label_barcodeMSIPlessey")
	private WebElement msiPlesseyLabel;

	@FindBy(id = "Server_barcodeMSIPlessey")
	private WebElement msiPlesseyCheckbox;

	@FindBy(id = "delete_setting_barcodeMSIPlessey")
	private WebElement msiPlesseyDelete;

	@FindBy(id = "edit_setting_barcodeMSIPlessey")
	private WebElement msiPlesseyEdit;

	public ConfigPageField msiPlesseyField = new ConfigPageField(
			MSI_PLESSEY_SYMBOLOGY,
			msiPlesseyLabel,
			msiPlesseyCheckbox,
			msiPlesseyDelete,
			msiPlesseyEdit
	);

	@FindBy(id = "Server_barcodeMSIPlesseyMod10NumCheckDigits")
	private WebElement msiPlesseyCheckDigitsMenu;

	@FindBy(id = "delete_setting_barcodeMSIPlesseyMod10NumCheckDigits")
	private WebElement msiPlesseyCheckDigitsDelete;

	@FindBy(id = "edit_setting_barcodeMSIPlesseyMod10NumCheckDigits")
	private WebElement msiPlesseyCheckDigitsEdit;

	public ConfigPageField msiPlesseyCheckDigitsField = new ConfigPageField(
			MSI_PLESSEY_CHECKDIGITS,
			msiPlesseyCheckDigitsMenu,
			msiPlesseyCheckDigitsDelete,
			msiPlesseyCheckDigitsEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeMSIPlesseyMod10TransmitCheckDigit']")
	private WebElement msiPlesseyTransmitCheckDigitLabel;

	@FindBy(id = "Server_barcodeMSIPlesseyMod10TransmitCheckDigit")
	private WebElement msiPlesseyTransmitCheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeMSIPlesseyMod10TransmitCheckDigit")
	private WebElement msiPlesseyTransmitCheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeMSIPlesseyMod10TransmitCheckDigit")
	private WebElement msiPlesseyTransmitCheckDigitEdit;

	public ConfigPageField msiPlesseyTransmitCheckDigitField = new ConfigPageField(
			MSI_PLESSEY_TRANSMIT_CHECKDIGIT,
			msiPlesseyTransmitCheckDigitLabel,
			msiPlesseyTransmitCheckDigitCheckbox,
			msiPlesseyTransmitCheckDigitDelete,
			msiPlesseyTransmitCheckDigitEdit
	);

	@FindBy(id = "Server_barcodeMSIPlesseyMod10ChecksumAlgorithm")
	private WebElement msiPlesseyCheckDigitAlgorithmMenu;

	@FindBy(id = "delete_setting_barcodeMSIPlesseyMod10ChecksumAlgorithm")
	private WebElement msiPlesseyCheckDigitAlgorithmDelete;

	@FindBy(id = "edit_setting_barcodeMSIPlesseyMod10ChecksumAlgorithm")
	private WebElement msiPlesseyCheckDigitAlgorithmEdit;

	public ConfigPageField msiPlesseyCheckDigitAlgorithmField = new ConfigPageField(
			MSI_PLESSEY_CHECKDIGIT_ALGORITHM,
			msiPlesseyCheckDigitAlgorithmMenu,
			msiPlesseyCheckDigitAlgorithmDelete,
			msiPlesseyCheckDigitAlgorithmEdit
	);

	@FindBy(id = "label_barcodeQR")
	private WebElement qrLabel;

	@FindBy(id = "Server_barcodeQR")
	private WebElement qrCheckbox;

	@FindBy(id = "delete_setting_barcodeQR")
	private WebElement qrDelete;

	@FindBy(id = "edit_setting_barcodeQR")
	private WebElement qrEdit;

	public ConfigPageField qrField = new ConfigPageField(
			QR_SYMBOLOGY,
			qrLabel,
			qrCheckbox,
			qrDelete,
			qrEdit
	);

	@FindBy(id = "Server_barcodeQRPolarity")
	private WebElement qrPolarityMenu;

	@FindBy(id = "delete_setting_barcodeQRPolarity")
	private WebElement qrPolarityDelete;

	@FindBy(id = "edit_setting_barcodeQRPolarity")
	private WebElement qrPolarityEdit;

	public ConfigPageField qrPolarityField = new ConfigPageField(
			QR_POLARITY,
			qrPolarityMenu,
			qrPolarityDelete,
			qrPolarityEdit
	);

	@FindBy(id = "label_barcodeUPCA")
	private WebElement upcaLabel;

	@FindBy(id = "Server_barcodeUPCA")
	private WebElement upcaCheckbox;

	@FindBy(id = "delete_setting_barcodeUPCA")
	private WebElement upcaDelete;

	@FindBy(id = "edit_setting_barcodeUPCA")
	private WebElement upcaEdit;

	public ConfigPageField upcaField = new ConfigPageField(
			UPCA_SYMBOLOGY,
			upcaLabel,
			upcaCheckbox,
			upcaDelete,
			upcaEdit
	);

	@FindBy(id = "Server_barcodeUPCAPreamble")
	private WebElement upcaTransmitPreambleMenu;

	@FindBy(id = "delete_setting_barcodeUPCAPreamble")
	private WebElement upcaTransmitPreambleDelete;

	@FindBy(id = "edit_setting_barcodeUPCAPreamble")
	private WebElement upcaTransmitPreambleEdit;

	public ConfigPageField upcaTransmitPreambleField = new ConfigPageField(
			UPCA_TRANSMIT_PREAMBLE,
			upcaTransmitPreambleMenu,
			upcaTransmitPreambleDelete,
			upcaTransmitPreambleEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeUPCATransmitCheckDigit']")
	private WebElement upcaTransmitCheckDigitLabel;

	@FindBy(id = "Server_barcodeUPCATransmitCheckDigit")
	private WebElement upcaTransmitCheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeUPCATransmitCheckDigit")
	private WebElement upcaTransmitCheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeUPCATransmitCheckDigit")
	private WebElement upcaTransmitCheckDigitEdit;

	public ConfigPageField upcaTransmitCheckDigitField = new ConfigPageField(
			UPCA_TRANSMIT_CHECKDIGIT,
			upcaTransmitCheckDigitLabel,
			upcaTransmitCheckDigitCheckbox,
			upcaTransmitCheckDigitDelete,
			upcaTransmitCheckDigitEdit
	);

	@FindBy(id = "label_barcodeUPCE")
	private WebElement upceLabel;

	@FindBy(id = "Server_barcodeUPCE")
	private WebElement upceCheckbox;

	@FindBy(id = "delete_setting_barcodeUPCE")
	private WebElement upceDelete;

	@FindBy(id = "edit_setting_barcodeUPCE")
	private WebElement upceEdit;

	public ConfigPageField upceField = new ConfigPageField(
			UPCE_SYMBOLOGY,
			upceLabel,
			upceCheckbox,
			upceDelete,
			upceEdit
	);

	@FindBy(id = "Server_barcodeUPCEPreamble")
	private WebElement upceTransmitPreambleMenu;

	@FindBy(id = "delete_setting_barcodeUPCEPreamble")
	private WebElement upceTransmitPreambleDelete;

	@FindBy(id = "edit_setting_barcodeUPCEPreamble")
	private WebElement upceTransmitPreambleEdit;

	public ConfigPageField upceTransmitPreambleField = new ConfigPageField(
			UPCE_TRANSMIT_PREAMBLE,
			upceTransmitPreambleMenu,
			upceTransmitPreambleDelete,
			upceTransmitPreambleEdit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeUPCETransmitCheckDigit']")
	private WebElement upceTransmitCheckDigitLabel;

	@FindBy(id = "Server_barcodeUPCETransmitCheckDigit")
	private WebElement upceTransmitCheckDigitCheckbox;

	@FindBy(id = "delete_setting_barcodeUPCETransmitCheckDigit")
	private WebElement upceTransmitCheckDigitDelete;

	@FindBy(id = "edit_setting_barcodeUPCETransmitCheckDigit")
	private WebElement upceTransmitCheckDigitEdit;

	public ConfigPageField upceTransmitCheckDigitField = new ConfigPageField(
			UPCE_TRANSMIT_CHECKDIGIT,
			upceTransmitCheckDigitLabel,
			upceTransmitCheckDigitCheckbox,
			upceTransmitCheckDigitDelete,
			upceTransmitCheckDigitEdit
	);

	@FindBy(id = "label_barcodeEnableISBT128")
	private WebElement isbt128Label;

	@FindBy(id = "Server_barcodeEnableISBT128")
	private WebElement isbt128Checkbox;

	@FindBy(id = "delete_setting_barcodeEnableISBT128")
	private WebElement isbt128Delete;

	@FindBy(id = "edit_setting_barcodeEnableISBT128")
	private WebElement isbt128Edit;

	public ConfigPageField isbt128Field = new ConfigPageField(
			ISBT128_SYMBOLOGY,
			isbt128Label,
			isbt128Checkbox,
			isbt128Delete,
			isbt128Edit
	);

	@FindBy(xpath = "//label[@for='Server_barcodeCheckISBTTable']")
	private WebElement checkISBTTableLabel;

	@FindBy(id = "Server_barcodeCheckISBTTable")
	private WebElement checkISBTTableCheckbox;

	@FindBy(id = "delete_setting_barcodeCheckISBTTable")
	private WebElement checkISBTTableDelete;

	@FindBy(id = "edit_setting_barcodeCheckISBTTable")
	private WebElement checkISBTTableEdit;

	public ConfigPageField checkISBTTableField = new ConfigPageField(
			ISBT128_TABLE,
			checkISBTTableLabel,
			checkISBTTableCheckbox,
			checkISBTTableDelete,
			checkISBTTableEdit
	);

	@FindBy(id = "Server_barcodeCheckISBTConcatenation")
	private WebElement checkISBTConcatenationMenu;

	@FindBy(id = "delete_setting_barcodeCheckISBTConcatenation")
	private WebElement checkISBTConcatenationDelete;

	@FindBy(id = "edit_setting_barcodeCheckISBTConcatenation")
	private WebElement checkISBTConcatenationEdit;

	public ConfigPageField checkISBTConcatenationField = new ConfigPageField(
			ISBT128_CONCATENATION,
			checkISBTConcatenationMenu,
			checkISBTConcatenationDelete,
			checkISBTConcatenationEdit
	);

	@FindBy(id = "Server_barcodeCheckISBTConcatenationRedundancy")
	private WebElement checkISBTConcatenationRedundancyTextbox;

	@FindBy(id = "delete_setting_barcodeCheckISBTConcatenationRedundancy")
	private WebElement checkISBTConcatenationRedundancyDelete;

	@FindBy(id = "edit_setting_barcodeCheckISBTConcatenationRedundancy")
	private WebElement checkISBTConcatenationRedundancyEdit;

	public ConfigPageField checkISBTConcatenationRedundancyField = new ConfigPageField(
			ISBT128_CONCATENATION_REDUNDANCY,
			checkISBTConcatenationRedundancyTextbox,
			checkISBTConcatenationRedundancyDelete,
			checkISBTConcatenationRedundancyEdit
	);

	@FindBy(id = "barcodeEanUpcSupplemental")
	private WebElement supplementalMenu;

	@FindBy(id = "delete_setting_barcodeEanUpcSupplemental")
	private WebElement supplementalDelete;

	@FindBy(id = "edit_setting_barcodeEanUpcSupplemental")
	private WebElement supplementalEdit;

	@FindBy(id = "undo_setting_barcodeEanUpcSupplemental")
	private WebElement supplementalUndo;

	public ConfigPageField supplementalField = new ConfigPageField(
			EAN_UPC_SUPPLEMENTAL,
			null,
			supplementalMenu,
			supplementalDelete,
			supplementalEdit,
			supplementalUndo
	);

	public SamBarcodePage() {
		super();
		PageFactory.initElements(driver, this);

		pageFields = new HashMap<String, ConfigPageField>() {
			{
				put(enableScannerField.getTitle(), enableScannerField);
				put(illuminationField.getTitle(), illuminationField);
				put(decodeTimeoutField.getTitle(), decodeTimeoutField);
				put(autoCarriageReturnEnableField.getTitle(), autoCarriageReturnEnableField);
				put("enable" + autoCarriageReturnEnableField.getTitle(), autoCarriageReturnEnableField);
				put("disable" + autoCarriageReturnDisableField.getTitle(), autoCarriageReturnDisableField);
				put(vibrateEnableField.getTitle(), vibrateEnableField);
				put("enable" + vibrateEnableField.getTitle(), vibrateEnableField);
				put("disable" + vibrateDisableField.getTitle(), vibrateDisableField);
				put(soundEnableField.getTitle(), soundEnableField);
				put("enable" + soundEnableField.getTitle(), soundEnableField);
				put("disable" + soundDisableField.getTitle(), soundDisableField);
				put(scanSoundField.getTitle(), scanSoundField);
				put(code128Field.getTitle(), code128Field);
				put(code32Field.getTitle(), code32Field);
				put(code93Field.getTitle(), code93Field);
				put(ean13Field.getTitle(), ean13Field);
				put(gs1128Field.getTitle(), gs1128Field);
				put(hanXinCodeField.getTitle(), hanXinCodeField);
				put(microPdf417Field.getTitle(), microPdf417Field);
				put(microQrField.getTitle(), microQrField);
				put(pdf417Field.getTitle(), pdf417Field);
				put(aztecField.getTitle(), aztecField);
				put(aztecPolarityField.getTitle(), aztecPolarityField);
				put(codaBarField.getTitle(), codaBarField);
				put(codaBarLengthField.getTitle(), codaBarLengthField);
				put(codaBarStripCharsField.getTitle(), codaBarStripCharsField);
				put(code11Field.getTitle(), code11Field);
				put(code11CheckDigitField.getTitle(), code11CheckDigitField);
				put(code11TransmitCheckDigitField.getTitle(), code11TransmitCheckDigitField);
				put(code39Field.getTitle(), code39Field);
				put(code39AsciiModeField.getTitle(), code39AsciiModeField);
				put(code39CheckDigitField.getTitle(), code39CheckDigitField);
				put(code39TransmitCheckDigitField.getTitle(), code39TransmitCheckDigitField);
				put(dataMatrixField.getTitle(), dataMatrixField);
				put(dataMatrixMirrorField.getTitle(), dataMatrixMirrorField);
				put(dataMatrixPolarityField.getTitle(), dataMatrixPolarityField);
				put(ean8Field.getTitle(), ean8Field);
				put(ean8ConvertEan13Field.getTitle(), ean8ConvertEan13Field);
				put(gs1Databar14Field.getTitle(), gs1Databar14Field);
				put(gs1Databar14CcabField.getTitle(), gs1Databar14CcabField);
				put(gs1Databar14CccField.getTitle(), gs1Databar14CccField);
				put(gs1Databar14ExpandedField.getTitle(), gs1Databar14ExpandedField);
				put(gs1Databar14LimitedField.getTitle(), gs1Databar14LimitedField);
				put(interleaved2Of5Field.getTitle(), interleaved2Of5Field);
				put(interleaved2Of5CheckDigitField.getTitle(), interleaved2Of5CheckDigitField);
				put(interleaved2Of5TransmitCheckDigitField.getTitle(), interleaved2Of5TransmitCheckDigitField);
				put(interleaved2Of5QuiteZoneField.getTitle(), interleaved2Of5QuiteZoneField);
				put(interleaved2Of5ScanLengthTypeField.getTitle(), interleaved2Of5ScanLengthTypeField);
				put(interleaved2Of5AllowedLength1Field.getTitle(), interleaved2Of5AllowedLength1Field);
				put(interleaved2Of5AllowedLength2Field.getTitle(), interleaved2Of5AllowedLength2Field);
				put(matrix2Of5Field.getTitle(), matrix2Of5Field);
				put(matrix2Of5CheckDigitField.getTitle(), matrix2Of5CheckDigitField);
				put(matrix2Of5TransmitCheckDigitField.getTitle(), matrix2Of5TransmitCheckDigitField);
				put(msiPlesseyField.getTitle(), msiPlesseyField);
				put(msiPlesseyCheckDigitsField.getTitle(), msiPlesseyCheckDigitsField);
				put(msiPlesseyTransmitCheckDigitField.getTitle(), msiPlesseyTransmitCheckDigitField);
				put(msiPlesseyCheckDigitAlgorithmField.getTitle(), msiPlesseyCheckDigitAlgorithmField);
				put(qrField.getTitle(), qrField);
				put(qrPolarityField.getTitle(), qrPolarityField);
				put(upcaField.getTitle(), upcaField);
				put(upcaTransmitPreambleField.getTitle(), upcaTransmitPreambleField);
				put(upcaTransmitCheckDigitField.getTitle(), upcaTransmitCheckDigitField);
				put(upceField.getTitle(), upceField);
				put(upceTransmitPreambleField.getTitle(), upceTransmitPreambleField);
				put(upceTransmitCheckDigitField.getTitle(), upceTransmitCheckDigitField);
				put(isbt128Field.getTitle(), isbt128Field);
				put(checkISBTTableField.getTitle(), checkISBTTableField);
				put(checkISBTConcatenationField.getTitle(), checkISBTConcatenationField);
				put(checkISBTConcatenationRedundancyField.getTitle(), checkISBTConcatenationRedundancyField);
				put(supplementalField.getTitle(), supplementalField);
			}
		};
	}

	public void clickExpandAztec() {
		clickOnPageEntity(aztecExpand);
		sleepSeconds(2);
	}

	public void clickCloseAztec() {
		clickOnPageEntity(aztecClose);
		sleepSeconds(1);
	}

	public void clickExpandCodaBar() {
		clickOnPageEntity(codaBarExpand);
		sleepSeconds(2);
	}

	public void clickCloseCodabar() {
		clickOnPageEntity(codaBarClose);
		sleepSeconds(1);
	}

	public void clickExpandCode11() {
		clickOnPageEntity(code11Expand);
		sleepSeconds(2);
	}

	public void clickCloseCode11() {
		clickOnPageEntity(code11Close);
		sleepSeconds(1);
	}

	public void clickExpandCode39() {
		clickOnPageEntity(code39Expand);
		sleepSeconds(2);
	}

	public void clickCloseCode39() {
		clickOnPageEntity(code39Close);
		sleepSeconds(1);
	}

	public void clickExpandDataMatrix() {
		clickOnPageEntity(dataMatrixExpand);
		sleepSeconds(2);
	}

	public void clickCloseDataMatrix() {
		clickOnPageEntity(dataMatrixClose);
		sleepSeconds(1);
	}

	public void clickExpandEan8() {
		clickOnPageEntity(ean8Expand);
		sleepSeconds(2);
	}

	public void clickCloseEan8() {
		clickOnPageEntity(ean8Close);
		sleepSeconds(1);
	}

	public void clickExpandGs1Databar14() {
		clickOnPageEntity(gs1Databar14Expand);
		sleepSeconds(2);
	}

	public void clickCloseGs1Databar14() {
		clickOnPageEntity(gs1Databar14Close);
		sleepSeconds(1);
	}

	public void clickExpandInterleaved2Of5() {
		clickOnPageEntity(interleaved2Of5Expand);
		sleepSeconds(2);
	}

	public void clickCloseInterleaved2Of5() {
		clickOnPageEntity(interleaved2Of5Close);
		sleepSeconds(1);
	}

	public void clickExpandMatrix2Of5() {
		clickOnPageEntity(matrix2Of5Expand);
		sleepSeconds(2);
	}

	public void clickCloseMatrix2Of5() {
		clickOnPageEntity(matrix2Of5Close);
		sleepSeconds(1);
	}

	public void clickExpandMsiPlessey() {
		clickOnPageEntity(msiPlesseyExpand);
		sleepSeconds(2);
	}

	public void clickCloseMsiPlessey() {
		clickOnPageEntity(msiPlesseyClose);
		sleepSeconds(1);
	}

	public void clickExpandQR() {
		clickOnPageEntity(qrExpand);
		sleepSeconds(2);
	}

	public void clickCloseQR() {
		clickOnPageEntity(qrClose);
		sleepSeconds(1);
	}

	public void clickExpandUpca() {
		clickOnPageEntity(upcaExpand);
		sleepSeconds(2);
	}

	public void clickCloseUpca() {
		clickOnPageEntity(upcaClose);
		sleepSeconds(1);
	}

	public void clickExpandUpce() {
		clickOnPageEntity(upceExpand);
		sleepSeconds(2);
	}

	public void clickCloseUpce() {
		clickOnPageEntity(upceClose);
		sleepSeconds(1);
	}

	public void clickExpandIsbt128() {
		clickOnPageEntity(isbt128Expand);
		sleepSeconds(2);
	}

	public void clickCloseIsbt128() {
		clickOnPageEntity(isbt128Close);
		sleepSeconds(1);
	}
}
