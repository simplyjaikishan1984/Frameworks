package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.FieldData;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.SysUpdaterUi;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.SYS_UPDATER;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.SysUpdaterStrings.*;

public class DeviceSysUpdaterSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I tap the Sys Updater \"([^\"]*)\" field on device \"([^\"]*)\"$")
	public void tapSysUpdaterObject(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(arg1.trim().toLowerCase());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(field.getKey());
			field.tap();
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I tap the Sys Updater 'CHECK FOR UPDATE' button on device \"([^\"]*)\"$")
	public void tapSysUpdaterCheckButton(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(CHECK_BUTTON);
		if (field.hasLabelElement()) field.scrollIntoView(field.getKey());
		field.tap();
	}

	@When("^I tap the Sys Updater back arrow on device \"([^\"]*)\"$")
	public void tapBackArrow(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(BACK_ARROW);
		if (field.isLabelPresent()) {
			field.tap();
		} else {
			log.error("Back arrow was not visible on '{}'", arg1);
		}
	}

	@When("^I enter \"([^\"]*)\" into the Sys Updater edit box on device \"([^\"]*)\"$")
	public void enterSysUpdaterText(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(EDIT_BOX);
		if (field.isLabelPresent()) {
			field.enter(arg1.trim());
		} else {
			log.error("Could not enter text into edit box on {}", arg2);
		}
	}

	@When("^I set the Sys Updater \"([^\"]*)\" switch to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void setSysUpdaterSwitch(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(arg1.trim().toLowerCase());
		FieldData heading = DeviceFields.getStrings(SYS_UPDATER, arg1.trim());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(heading);
			if (!field.getControlElement().getText().toLowerCase().contentEquals(arg2.trim().toLowerCase())) {
				field.tap();
				sleepSeconds(2);
			} else {
				log.debug("Field '{}' was already set to '{}'", arg1, arg2);
			}
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I select \"([^\"]*)\" from the Sys Updater overflow menu on device \"([^\"]*)\"$")
	public void selectSysUpdaterOverflowOption(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(OVERFLOW_MENU);
		boolean found;
		if (field != null && field.isLabelPresent()) {
			updaterUi.tapOverflowMenu();
			found = field.selectTextMenuOption(arg1.trim().toLowerCase());
			if (found) {
				log.debug("Selected menu option '{}'", arg1);
			} else {
				log.error("Could not find menu option '{}'", arg1);
			}
		} else {
			log.error("The overflow menu was not visible on '{}'", arg1);
		}
	}

	@When("^I select \"([^\"]*)\" from the Sys Updater menu \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void selectSysUpdaterMenuOption(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(arg2.trim());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(field.getKey());
			boolean found;
			if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
				field.tap();
				found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
				if (found) {
					log.debug("Selected menu option '{}'", arg1);
					sleepSeconds(1);
				} else {
					log.error("Could not find menu option '{}'", arg1);
				}
			} else {
				log.debug("Field '{}' was already set to '{}'", arg3, arg1);
			}
		} else {
			log.error("No matching field with title '{}'", arg2);
		}
	}

	@When("^I tap the Sys Updater 'Cancel' button on device \"([^\"]*)\"$")
	public void tapCancel(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		updaterUi.tapCancelButton();
	}

	@When("^I tap the Sys Updater 'OK' button on device \"([^\"]*)\"$")
	public void tapOk(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		updaterUi.tapOkButton();
	}

	@Then("^the Sys Updater \"([^\"]*)\" value is set to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifySysUpdaterValue(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(arg1.trim().toLowerCase());
		if (field.isValueAccessible()) {
			String fieldValue = field.getValueElement().getText().toLowerCase();
			if (fieldValue.contentEquals(arg2.trim().toLowerCase())) {
				log.debug("Verified field '{}' was set to '{}'", arg1, arg2);
			} else {
				log.fatal("Field '{}' was set to '{}' rather than '{}' on device {}", arg1, fieldValue, arg2, arg3);
				Environment.softAssert().fail("INCORRECT BATT LIFE FIELD VALUE");
			}
		} else {
			log.error("Field '{}' was not accessible", arg1);
			Environment.softAssert().fail("FIELD NOT ACCESSIBLE");
		}
	}

	@Then("^the 'System update' text is \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifySysUpdaterBannerVisible(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(SYSTEM_UPDATE);
		if (field.isLabelPresent()) {
			String fieldValue = field.getValueElement().getText();
			String message = fieldValue.substring(fieldValue.indexOf(":") + 2);
			if (message.contains(arg1.trim())) {
				log.debug("Verified system update text was set to '{}' on device {}", arg1, arg2);
			} else {
				log.fatal("System update text was set to '{}' rather than '{}' on device {}", message, arg1, arg2);
				Environment.softAssert().fail("INCORRECT SYSTEM UPDATE TEXT");
			}
		} else {
			log.fatal("System update was not visible on device {}", arg2);
			Environment.softAssert().fail("SYSTEM UPDATE NOT VISIBLE");
		}
	}

	@Then("^there is a Sys Updater notification stating \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifySysUpdaterNotificationVisible(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		phone.getNotifications();
		/*SysUpdaterUi updaterUi = phone.getSysUpdaterUi();
		ConfigUiField field = updaterUi.getField(SYSTEM_UPDATE);
		if (field.isLabelPresent()) {
			String fieldValue = field.getValueElement().getText();
			String message = fieldValue.substring(fieldValue.indexOf(":") + 1);
			if (message.contains(arg1.trim())) {
				log.debug("Verified system update text was set to '{}' on device {}", arg1, arg2);
			} else {
				log.fatal("System update text was set to '{}' rather than '{}' on device {}", message, arg1, arg2);
				Environment.softAssert().fail("INCORRECT SYSTEM UPDATE TEXT");
			}
		} else {
			log.fatal("System update was not visible on device {}", arg2);
			Environment.softAssert().fail("SYSTEM UPDATE NOT VISIBLE");
		}*/
	}
}