package com.spectralink.test_automation.cucumber.framework.common;

import com.spectralink.test_automation.cucumber.framework.sam.common.Sam;
import com.spectralink.test_automation.cucumber.framework.sam.common.Simulator;
import com.spectralink.test_automation.cucumber.framework.sam.pages.*;
import com.spectralink.test_automation.cucumber.framework.sam.pages.configuration.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jasypt.util.text.BasicTextEncryptor;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Environment {

    public enum SamPage {
        LOGIN(SamLoginPage.class),
        PREFERENCES(null),
        DEVICE_HOLDING_AREA(SamDeviceHoldingAreaPage.class),
        DEVICE_LIST(SamDeviceListPage.class),
        GROUPS(SamManageGroupsPage.class),
        BATCH_CONFIGURATION(SamBatchConfigPage.class),
        LICENSES(SamFeatureLicensePage.class),
        COPY_CONFIGURATION(SamCopyConfigPage.class),
        AMIE_AGENT(SamAmieAgentPage.class),
        ABOUT_SAM(SamAboutSamPage.class),
        BARCODE(SamBarcodePage.class),
        BATTLIFE(SamBattLifePage.class),
        BIZ_PHONE(SamBizPhonePage.class),
        BUTTONS(SamButtonsPage.class),
        DEVICE_SETTINGS(SamDeviceSettingsPage.class),
        LENS_GRID(SamLensGridPage.class),
        LOGGING(SamLoggingPage.class),
        PTT(SamPttPage.class),
        SAFE(SamSafePage.class),
        SSO_STATUS(SamSsoStatusPage.class),
        SYS_UPDATER(SamSysUpdaterPage.class),
        VQO(SamVqoPage.class),
        WEBAPI(SamWebApiPage.class),
        CUSTOM_APPS(SamCustomAppsPage.class),
        NONE(null);

        private final Class pageType;

        public Class pageClass() {
            return pageType;
        }

        SamPage(Class pageType) {
            this.pageType = pageType;
        }
    }

    private static Environment myself;
    private static final String projectDirectory = System.getProperty("user.dir");
    private static final String defaultConfigFile = "AutoConfiguration.json";
    private static final String defaultRegistrationFile = "RegistrationData.json";
    private static final char[] salination = "G%$#%SDsKl:".toCharArray();
    private static Logger log = LogManager.getLogger(Environment.class.getName());
    private static SamBasePage currentPage;
    private static SamPage currentPageName = SamPage.LOGIN;
    private static Sam sam;
    private static UsbHost usbHost;
    private static Simulator simulator;
    private static Map<String, MqttTool> mqttTool = new HashMap<>();
    private static SoftAssert softAssert;
    private static Map<String, VersityPhone> phones = new HashMap<>();
    private static Integer scenarioFailureCount = 0;
    private static Integer featureFailureCount = 0;
    private static Integer nextAppiumPort = 4490;
    private static Map<String, Object> temporaryStorage = new HashMap<>();
    private static Boolean skipRemaining = false;
    private static Thread thread;

    public static Environment getInstance() {
        if (myself == null) {
            myself = new Environment();
        }
        return myself;
    }

    public static String getProjectDirectory() {
        return projectDirectory;
    }

    public static File getConfigFile() {
        Path defaultConfigPath = Paths.get(projectDirectory, "src/test/resources/run_configuration", defaultConfigFile);
        File activeConfigFile = defaultConfigPath.toFile();
        String configFileOverride = System.getenv("RUN_CONFIG");
        if (configFileOverride != null && !configFileOverride.isEmpty()) {
            Path overrideConfigPath = Paths.get(projectDirectory, "src/test/resources/run_configuration", configFileOverride);
            File configFile = overrideConfigPath.toFile();
            if (configFile.exists()) {
                activeConfigFile = configFile;
            }
        }
        return activeConfigFile;
    }

    public static File getRegistrationFile() {
        Path defaultConfigPath = Paths.get(projectDirectory, "src/test/resources/test_data", defaultRegistrationFile);
        File activeConfigFile = defaultConfigPath.toFile();
        String configFileOverride = System.getenv("REG_DATA");
        if (configFileOverride != null && !configFileOverride.isEmpty()) {
            Path overrideConfigPath = Paths.get(projectDirectory, "src/test/resources/test_data", configFileOverride);
            File configFile = overrideConfigPath.toFile();
            if (configFile.exists()) {
                activeConfigFile = configFile;
            }
        }
        return activeConfigFile;
    }

    public static void setTemporaryValue(String key, Object value) {
        temporaryStorage.put(key, value);
    }

    public static String getTemporaryValue(String key) {
        return (String) temporaryStorage.get(key);
    }

    public static Integer getIntegerTemporaryValue(String key) {
        return (Integer) temporaryStorage.get(key);
    }

    public static void removeTemporaryValue(String key) {
        temporaryStorage.remove(key);
    }

    public static void clearTemporaryStorage() {
        temporaryStorage.clear();
    }

    public static SamBasePage getCurrentPage() {
        return currentPage;
    }

    public static void setCurrentPage(SamBasePage currentPage) {
        Environment.currentPage = currentPage;
    }

    public static void setCurrentPage(SamBasePage currentPage, SamPage pageName) {
        Environment.currentPage = currentPage;
        Environment.currentPageName = pageName;
    }

    public static SamPage getCurrentPageName() {
        return currentPageName;
    }

    public static void setCurrentPageName(SamPage currentPageName) {
        Environment.currentPageName = currentPageName;
    }

    public static Sam getSam() {
        return sam;
    }

    public static void setSam(Sam sam) {
        Environment.sam = sam;
    }

    public static boolean isSamSet() {
        return Environment.sam != null;
    }

    public static UsbHost getUsbHost() {
        return usbHost;
    }

    public static void setUsbHost(UsbHost usbHost) {
        Environment.usbHost = usbHost;
    }

    public static Simulator getSimulator() {
        return simulator;
    }

    public static void setSimulator(Simulator simulator) {
        Environment.simulator = simulator;
    }

    public static boolean isMqttMonitorSet(String serial) {
        return Environment.mqttTool.get(serial) != null;
    }

    public static MqttTool getMqttMonitor(String serial) {
        if (Environment.mqttTool.get(serial) == null) {
            Environment.addMqttMonitor(serial);
        }
        return Environment.mqttTool.get(serial);
    }

    public static void addMqttMonitor(String serial) {
        if (Environment.mqttTool.get(serial) != null) {
            if (Environment.mqttTool.get(serial).isConnected()) {
                Environment.mqttTool.get(serial).disconnect();
            }
            Environment.mqttTool.remove(serial);
        }
        Environment.mqttTool.put(serial, new MqttTool(serial));
    }

    public static VersityPhone getPhone(String cukeString) {
        if (phones.containsKey(cukeString)) {
            return phones.get(cukeString);
        } else {
            log.error("Device '{}' does not exist", cukeString);
            Assert.fail("Device Not Found");
        }
        return null;
    }

    public static Map<String, VersityPhone> getPhones() {
        return phones;
    }

    public static void setPhone(String token, VersityPhone phone) {
        phones.put(token, phone);
    }

    public static void removePhone(String token) {
        phones.remove(token);
    }

    public static Boolean onConfigurationPage() {
        return SamConfigurationPage.class.isAssignableFrom(currentPageName.pageClass());
    }

    public static void newSoftAssert() {
        softAssert = new SoftAssert();
    }

    public static SoftAssert softAssert() {
        return softAssert;
    }

    public static void checkAsserts() {
        softAssert.assertAll();
    }

    public static int getScenarioFailureCount() {
        return scenarioFailureCount;
    }

    public static void setScenarioFailureCount(Integer scenarioFailureCount) {
        Environment.scenarioFailureCount = scenarioFailureCount;
    }

    public static void addScenarioFailure(Integer count) {
        Environment.scenarioFailureCount += count;
    }

    public static int getFeatureFailureCount() {
        return featureFailureCount;
    }

    public static void setFeatureFailureCount(Integer featureFailureCount) {
        Environment.featureFailureCount = featureFailureCount;
    }

    public static void addFeatureFailure(Integer count) {
        Environment.featureFailureCount += count;
    }

    public static Integer getNextAppiumPort() {
        return ++Environment.nextAppiumPort;
    }

    public static Boolean skipRemaining() {
        return skipRemaining;
    }

    public static void setSkipRemaining(Boolean skipRemaining) {
        Environment.skipRemaining = skipRemaining;
    }

    public static Thread getThread() {
        return thread;
    }

    public static void setThread(Thread thread) {
        Environment.thread = thread;
    }

    public static String desalinate(String token) {
        BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
        textEncryptor.setPasswordCharArray(salination);
        return textEncryptor.decrypt(token);
    }

    public static String salinate(String token) {
        BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
        textEncryptor.setPasswordCharArray(salination);
        return textEncryptor.encrypt(token);
    }
}
