package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.*;
import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields;
import com.spectralink.test_automation.cucumber.framework.device.pages.AmieAgentUi;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.Point;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.AMIE_AGENT;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.AmieAgentStrings.*;

public class DeviceAmieAgentSteps {

	private final Logger log = LogManager.getLogger(this.getClass().getName());

	@When("^I tap the AMiE Agent \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void tapAmieAgentObject(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(arg1.trim().toLowerCase());
		FieldData heading = DeviceFields.getStrings(AMIE_AGENT, arg1.trim());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(heading);
			if (field.isLabelPresent()) {
				field.tap();
			} else {
				log.error("Field '{}' has no label", arg1);
			}
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I set the AMiE Agent \"([^\"]*)\" switch to \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void setAmieAgentSwitch(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(arg1.trim().toLowerCase());
		FieldData heading = DeviceFields.getStrings(AMIE_AGENT, arg1.trim());
		if (field != null) {
			if (field.hasLabelElement()) field.scrollIntoView(heading);
			if (!field.getControlElement().getText().toLowerCase().contentEquals(arg2.trim().toLowerCase())) {
				field.tap();
			} else {
				log.debug("Field '{}' was already set to '{}'", arg1, arg2);
			}
		} else {
			log.error("No matching field with title '{}'", arg1);
		}
	}

	@When("^I select \"([^\"]*)\" from the AMiE Agent menu 'Network metrics frequency' on device \"([^\"]*)\"$")
	public void selectNetworkAmieAgentMenuOption(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(NETWORK_FREQUENCY);
		FieldData heading = DeviceFields.getStrings(AMIE_AGENT, arg1.trim());
		if (field != null) {
			boolean found;
			if (!field.getValueElement().getText().toLowerCase().contentEquals(arg1.trim().toLowerCase())) {
				field.tap();
				found = field.selectCheckedMenuOption(arg1.trim().toLowerCase());
				if (found) {
					log.debug("Selected menu option '{}'", arg1);
				} else {
					log.error("Could not find menu option '{}'", arg1);
					agentUi.tapCancelButton();
				}
				sleepSeconds(1);
			} else {
				log.debug("Field '{}' was already set to '{}'", arg2, arg1);
			}
		} else {
			log.error("No matching field with title '{}'", NETWORK_FREQUENCY.title());
		}
	}

	@When("^I unlock the AMiE Agent Developer Options option on device \"([^\"]*)\"$")
	public void selectOverflowOption(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(OVERFLOW_MENU);
		boolean found;
		if (field.isLabelPresent()) {
			agentUi.clickOverflowMenu();
			found = field.selectTextMenuOption("About");
			if (found) {
				Point position = agentUi.getAmieAgentIconPosition();
				for (int index = 0; index < 7; index++) {
					phone.rapidTapOnScreen(position.getX(), position.getY());
				}
				agentUi.tapExposeButton();
				log.debug("Enabled AMIE Agent developer options");
				agentUi.tapBackButton();
			} else {
				log.error("Could not find menu option '{}'", arg1);
			}
		} else {
			log.debug("The overflow menu was not visible on '{}'", arg1);
		}
	}

	@When("^I enter \"([^\"]*)\" into the AMiE Agent \"([^\"]*)\" edit box on device \"([^\"]*)\"$")
	public void enterBoxText(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(EDIT_ENDPOINT_URL);
		if (field.isLabelPresent()) {
			field.enter(arg1.trim());
			agentUi.tapOkButton();
		} else {
			log.debug("The '{}' was not visible", arg2);
		}
	}

	@When("^I enter the default MQTT broker into the AMiE Agent 'Endpoint URL' edit box on device \"([^\"]*)\"$")
	public void enterEndpointDefaultText(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(ENDPOINT_URL);
		if (field.isLabelPresent()) {
			field.tap();
			String server = RunDefaults.getStringSetting("mqttBroker");
			String protocol = RunDefaults.getStringSetting("mqttprotocol");
			String port = RunDefaults.getStringSetting("mqttPort");
			String url = String.format("%s://%s:%s", protocol, server, port);
			ConfigUiField textbox = agentUi.getField(EDIT_ENDPOINT_URL);
			textbox.enter(url);
		} else {
			log.debug("The 'Endpoint URL' edit box was not visible on '{}'", arg1);
		}
	}

	@When("^I enter \"([^\"]*)\" into the AMiE Agent 'Endpoint URL' edit box on device \"([^\"]*)\"$")
	public void enterEndpointText(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(EDIT_ENDPOINT_URL);
		if (field.isLabelPresent()) {
			field = agentUi.getField(EDIT_ENDPOINT_URL);
			field.enter(arg1.trim());
		} else {
			log.debug("The 'Endpoint URL' box was not visible on '{}'", arg2);
		}
	}

	@When("^I listen for the next \"([^\"]*)\" message\\(s\\) from AMiE Agent on device \"([^\"]*)\"$")
	public void listenForMessages(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		MqttTool mqttMonitor = Environment.getMqttMonitor(phone.getSerialNumber());
		mqttMonitor.subscribe(Integer.parseInt(arg1.trim()));
	}

	@When("^I tap the AMiE Agent 'Cancel' button on device \"([^\"]*)\"$")
	public void tapCancel(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		agentUi.tapCancelButton();
	}

	@When("^I tap the AMiE Agent 'Change' button on device \"([^\"]*)\"$")
	public void tapChange(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		agentUi.tapChangeButton();
	}

	@When("^I tap the AMiE Agent 'OK' button on device \"([^\"]*)\"$")
	public void tapOk(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		agentUi.tapOkButton();
	}

	@Then("^a properly formatted \"([^\"]*)\" message from AMiE Agent appears on the broker from device \"([^\"]*)\"$")
	public void verifyMessageAppearance(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		MqttTool mqttMonitor = Environment.getMqttMonitor(phone.getSerialNumber());
		MqttTool.AmieAgentMessageType type = mqttMonitor.findMessageType(arg1);
		if (type != null) {
			if (mqttMonitor.getResponseCount() > 0) {
				String message = mqttMonitor.findMessageType(type);
				if (message != null) {
					JSONParser parser = new JSONParser();
					try {
						Object parsedJson = parser.parse(message);
						JSONObject messageJson = (JSONObject) parsedJson;
						JSONArray dataCollections = (JSONArray) messageJson.get("data");
						for (Object eachCollection : dataCollections) {
							JSONObject collection = (JSONObject) eachCollection;
							if (!mqttMonitor.validate(type, collection.toJSONString())) {
								Environment.softAssert().fail("MQTT JSON did not validate");
							} else {
								log.debug("JSON in {} message passed validation", arg1);
							}
						}
					} catch (ParseException pe) {
						log.error("Failed to get date from broker message: {}", pe.getMessage());
					}
				} else {
					log.fatal("MQTT message of type {} was not found", arg1);
				}
			} else {
				log.error("No messages were found on on the broker");
			}
		} else {
			log.error("Invalid message type '{}'", arg1);
		}
	}

	@Then("^I start monitoring for AMiE Agent traffic on the default broker from device \"([^\"]*)\"$")
	public void startMonitoring(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		Environment.getMqttMonitor(phone.getSerialNumber()).subscribe();
	}

	@Then("^I stop monitoring for AMiE Agent traffic on the default broker from device \"([^\"]*)\"$")
	public void stopMonitoring(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		Environment.getMqttMonitor(phone.getSerialNumber()).disconnect();
	}

	@Then("^the AMiE Agent connection banner reads \"([^\"]*)\" on device \"([^\"]*)\"$")
	public void verifyConnectionBanner(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		String bannerText = agentUi.getBannerText();
		if (bannerText != null && bannerText.contains(arg1.trim())) {
			log.debug("Verified banner reads '{}'", arg1);
			sleepSeconds(2);
		} else {
			log.fatal("Connection banner text was '{}' instead of expected '{}'", bannerText, arg1);
			Environment.softAssert().fail("BANNER TEXT FAILURE");
		}
	}

	@Then("^the AMiE Agent connection banner is not visible on device \"([^\"]*)\"$")
	public void verifyConnectionBannerAbsence(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		boolean visible = agentUi.connectedBannerField.isLabelPresent();
		if (!visible) {
			log.debug("Verified no banner is visible");
		} else {
			log.fatal("Connection banner was visible");
			Environment.softAssert().fail("BANNER VISIBLE FAILURE");
		}
	}

	@Then("^the AMiE Agent 'Last upload time' is less than \"([^\"]*)\" seconds away from the last broker message from device \"([^\"]*)\"$")
	public void verifyLastBrokerMessage(String arg1, String arg2) {
		VersityPhone phone = Environment.getPhone(arg2.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(LAST_UPLOAD);
		MqttTool mqttMonitor = Environment.getMqttMonitor(phone.getSerialNumber());
		JSONParser parser = new JSONParser();
		try {
			Object parsedJson = parser.parse(mqttMonitor.getResponses().get(0));
			JSONObject responseJson = (JSONObject) parsedJson;
			Instant lastBrokerResponse = Instant.ofEpochMilli((Long) responseJson.get("timestamp"));
			LocalDateTime brokerMessageTime = LocalDateTime.ofInstant(lastBrokerResponse, ZoneId.of(phone.getTimezone()));
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yy h:mm:ss.SSS a z");
			formatter.parse(field.getValue());
			LocalDateTime appUploadTime = LocalDateTime.parse(field.getValue(), formatter);
			Long difference = Duration.between(brokerMessageTime, appUploadTime).toMillis();
			if (difference > Long.parseLong(arg1.trim()) * 1000) {
				log.fatal("Time reported in '{}' was more than {} seconds away from the MQTT message (actual {})", LAST_UPLOAD.title(), arg1, (difference / 1000));
				Environment.softAssert().fail("CONNECTION TIME FAILURE");
			} else {
				log.debug("Time reported in '{}' was within {} seconds away from the MQTT message (actual {})", LAST_UPLOAD.title(), arg1, (difference / 1000));
			}
		} catch (ParseException pe) {
			log.error("Failed to get date from broker message: {}", pe.getMessage());
		}
	}

	@Then("^the AMiE Agent \"([^\"]*)\" is less than \"([^\"]*)\" seconds away from the current time on device \"([^\"]*)\"$")
	public void verifyAppConnectionTime(String arg1, String arg2, String arg3) {
		VersityPhone phone = Environment.getPhone(arg3.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(arg1.trim());
		Instant currentTime = Instant.now();
		LocalDateTime phoneTime = LocalDateTime.ofInstant(currentTime, ZoneId.of(phone.getTimezone()));
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yy h:mm:ss.SSS a z");
		formatter.parse(field.getValue());
		LocalDateTime appUploadTime = LocalDateTime.parse(field.getValue(), formatter);
		Long difference = Duration.between(phoneTime, appUploadTime).toMillis();
		if (difference > Long.parseLong(arg2.trim()) * 1000) {
			log.fatal("Time reported in '{}' was more than {} seconds away from the current time (actual {})", arg1, arg2, (difference / 1000));
			Environment.softAssert().fail("CONNECTION TIME FAILURE");
		} else {
			log.debug("Time reported in '{}' was within {} seconds away from the current time (actual {})", arg1, arg2, (difference / 1000));
		}
	}

	@Then("^the 'Publish topic' is correct for device \"([^\"]*)\"$")
	public void verifyPublishTopic(String arg1) {
		VersityPhone phone = Environment.getPhone(arg1.trim());
		AmieAgentUi agentUi = phone.getAmieAgentUi();
		ConfigUiField field = agentUi.getField(PUBLISH_TOPIC);
		String expectedTopic = "devices/spectralink/" + phone.getSerialNumber();
		if (field.getValue().contains(expectedTopic)) {
			log.debug("The topic for {} was expected '{}'", arg1, expectedTopic);
		} else {
			log.fatal("The topic for {} was '{}' instead of expected '{}'", arg1, field.getValue(), expectedTopic);
			Environment.softAssert().fail("INCORRECT PUBLISH TOPIC");
		}
	}
}