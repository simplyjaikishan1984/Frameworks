package com.spectralink.test_automation.cucumber.stepdefs;

import com.spectralink.test_automation.cucumber.framework.common.AndroidPhone;
import com.spectralink.test_automation.cucumber.framework.common.Environment;
import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.common.VersityPhone;
import com.spectralink.test_automation.cucumber.framework.device.pages.AboutScreenUi;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.cucumber.java.en.Then;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.BARCODE;
import static com.spectralink.test_automation.cucumber.framework.common.AndroidPhone.Application.SATURN_BARCODE;
import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static io.appium.java_client.touch.offset.PointOption.point;

public class DeviceAboutScreenSteps {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @Then("^I validate \"([^\"]*)\" About screen elements on Saturn \"([^\"]*)\"$")
    public void selectFeaturesOverflowMenu(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        AboutScreenUi aboutScreenUi = phone.getAboutScreenUi();
        AndroidPhone.Application app = phone.findApplication(arg1.trim());
        String packageName = app.getPackage();
        String imageName= packageName + ":id/iv_logo";
        String appName = "";

        switch (arg1) {
            case "Emergency":
                appName = "Emergency";
                break;

            case "Cisco Phone":
                appName = "Cisco Phone";
                break;

            case "Battery Life":
                appName = "Battery Life";
                break;

            case "Saturn Web API":
                appName = "Web API";
                break;

            case "Custom Settings":
                appName = "Custom Settings";
                break;

            case "Call Quality Settings":
                appName = "Call Quality Settings";
                break;

            case "Saturn PTT":
                appName = "PTT";
                break;

            case "System Updater":
                appName = "System Updater";
                break;

            case "Saturn Buttons":
                appName = "Buttons";
                break;

            case "Saturn Logging":
                appName = "Logging";
                break;

            case "Saturn Barcode":
                appName = "Barcode";
                break;

        }

        phone.appium().findElementByAccessibilityId("More options").click();
        aboutScreenUi.selectTextMenuOption("About");

        if (phone.appium().findElementByAccessibilityId("App logo").getAttribute("resource-id").equals(imageName))
            log.debug("App logo present on '{}'", arg2);
        else {
            log.error("Could not find App logo on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }


        if (phone.appium().findElementByAccessibilityId("App name title").getText().trim().equals(appName))
            log.debug("App name present on '{}'", arg2);
        else {
            log.error("Could not find app name on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }


        WebElement url = phone.appium().findElementByAccessibilityId("Web url title");
        if (url.getText().trim().equals("www.cisco.com"))
            log.debug("Cisco link present on '{}'", arg2);
        else {
            log.error("Could not find Cisco link on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        url.click();
        try {
            phone.appium().findElementById("com.android.chrome:id/terms_accept").click();
            log.debug("Accept & continue button pressed");
        }
        catch (Exception exception) {
            log.debug("Accept & continue button not present");
        }

        try {
            phone.appium().findElementById("com.android.chrome:id/negative_button").click();
            log.debug("No thanks button pressed");
        }
        catch (Exception exception) {
            log.debug("No thanks button not present");
        }

        String urlInBrowser = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
        if(urlInBrowser.equalsIgnoreCase("cisco.com"))
            log.debug("Cisco.com page was opened on '{}'", arg2);
        else {
            log.error("Could not route to Cisco.com page on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);

        String[] version = phone.appium().findElementByAccessibilityId("Version info title").getText().trim().split(":");
        Pattern pattern = Pattern.compile("^[0-9]{1,2}[.][0-9]{1,2}[.][0-9]{1,8}");
        Matcher match = pattern.matcher(version[1].trim());
        if (match.find())
            log.debug("Version info present in the A.B.C pattern on '{}'", arg2);
        else {
            log.error("Could not find Version info in the A.B.C pattern on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        if (phone.appium().findElementByAccessibilityId("Manufacturer info title").getText().trim().equals("Manufacturer : Cisco"))
            log.debug("Manufacturer info present on '{}'", arg2);
        else {
            log.error("Could not find Manufacturer info on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        if (phone.appium().findElementByAccessibilityId("Device model title").getText().trim().contains("Model : " + phone.getModel()))
            log.debug("Device model present on '{}'", arg2);
        else {
            log.error("Could not find Device model on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        if (phone.appium().findElementByAccessibilityId("Android version title").getText().trim().equals("Android version : 10"))
            log.debug("Android version present on '{}'", arg2);
        else {
            log.error("Could not find Android version on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        String[] htmlContent = phone.appium().findElementByAccessibilityId("Html content title").getText().trim().split("\n");

        if (htmlContent[0].trim().equals("© 2020. Cisco Systems, Inc. and/or its affiliated entities. All rights reserved."))
            log.debug("Copyright message present on '{}'", arg2);
        else {
            log.error("Could not find Copyright message on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        phone.appium().findElementByAccessibilityId("Terms of service title").click();
        String termsOfService = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
        if(termsOfService.equalsIgnoreCase("cisco.com/c/en/us/about/legal/cloud-and-software/end_user_license_agreement.html"))
            log.debug("Terms of service page was opened on '{}'", arg2);
        else {
            log.error("Could not route to Terms of service page on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.appium().findElementByAccessibilityId("Privacy statement title").click();
        String privacyStatement = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
        if(privacyStatement.equalsIgnoreCase("cisco.com/c/en/us/about/legal/privacy-full.html"))
            log.debug("Privacy Statement page was opened on '{}'", arg2);
        else {
            log.error("Could not route to Privacy Statement page on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);

        phone.appium().findElementByAccessibilityId("Notices and disclaimers title").click();
        String noticesAndDisclaimers = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
        if(noticesAndDisclaimers.equalsIgnoreCase("cisco.com/c/en/us/about/legal/cloud-and-software/cloud-terms.html"))
            log.debug("Notices and disclaimers page was opened on '{}'", arg2);
        else {
            log.error("Could not route to Notices and disclaimers page on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        phone.sendKeyEvent(AndroidKey.BACK);

        WebElement thirdPartyText = phone.appium().findElementByAccessibilityId("Third party title");
        if (thirdPartyText.getText().trim().equals("Third Party & Open-Source Software (including free/open source software)"))
            log.debug("Third party title present on '{}'", arg2);
        else {
            log.error("Could not find Third party title on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        thirdPartyText.click();
        sleepSeconds(2);
        try {
            phone.appium().findElementByXPath("//android.widget.TextView[(@text ='smartphone-attributions')]");
            sleepSeconds(2);
        }
        catch (Exception exception) {
            log.error("PDF not found");
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        sleepSeconds(1);
        phone.appium().findElementByAccessibilityId("Navigate up").click();
        sleepSeconds(1);
        phone.appium().findElementByAccessibilityId("Navigate up").click();
    }

    @Then("^I validate hidden settings are not available in \"([^\"]*)\" app on Saturn \"([^\"]*)\"$")
    public void hiddenMenu(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        AndroidPhone.Application app = phone.findApplication(arg1.trim());
        String packageName = app.getPackage();
        AboutScreenUi aboutScreenUi = phone.getAboutScreenUi();
        phone.appium().findElementByAccessibilityId("More options").click();
        aboutScreenUi.selectTextMenuOption("About");

        WebElement aboutIcon =  phone.appium().findElementByAccessibilityId("App logo");
        int centerX = aboutIcon.getLocation().getX() + aboutIcon.getSize().getWidth() / 2;
        int centerY = aboutIcon.getLocation().getY() + aboutIcon.getSize().getHeight() / 2;
        phone.tapOnScreenFor10Seconds(centerX, centerY);

        try {
            phone.appium().findElementById(packageName + ":id/snackbar_action").click();
            log.error("Hidden settings menu showed up unexpectedly");
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        catch (Exception exception) {
            log.debug("Hidden settings menu did not show up");
        }

        for (int index = 0; index < 7; index++) {
            phone.tapOnScreen(centerX, centerY);
        }

        try {
            phone.appium().findElementById(packageName + ":id/snackbar_action").click();
            log.error("Hidden settings menu showed up unexpectedly");
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        catch (Exception exception) {
            log.debug("Hidden settings menu did not show up");
        }
        phone.appium().findElementByAccessibilityId("Navigate up").click();
        phone.sendKeyEvent(AndroidKey.BACK);
    }

    @Then("^I validate \"([^\"]*)\" app package is installed on \"([^\"]*)\"$")
    public void packageInstalled(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        AndroidPhone.Application app = phone.findApplication(arg1.trim());
        String packageName = app.getPackage();
        String appInfo = phone.getAppInfo(packageName);

        Pattern pattern = Pattern.compile("(" + packageName + ")");
        Matcher matcher = pattern.matcher(appInfo);

        if(matcher.find())
            log.debug(arg1 + " app package is installed");
        else {
            log.error(arg1 + " app package is not installed");
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN INFORMATION");
        }
    }

    @Then("^I validate Barcode About screen elements on Saturn \"([^\"]*)\"$")
    public void selectFeaturesOverflowMenu(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if(phone.hasBarcodeScanner()) {
            AboutScreenUi aboutScreenUi = phone.getAboutScreenUi();
            String imageName = "com.cisco.barcode.service:id/iv_logo";

            phone.appium().findElementByAccessibilityId("More options").click();
            aboutScreenUi.selectTextMenuOption("About");

            if (phone.appium().findElementByAccessibilityId("App logo").getAttribute("resource-id").equals(imageName))
                log.debug("App logo present on '{}'", arg1);
            else {
                log.error("Could not find App logo on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("App name title").getText().trim().equals("Barcode"))
                log.debug("App name present on '{}'", arg1);
            else {
                log.error("Could not find app name on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            WebElement url = phone.appium().findElementByAccessibilityId("Web url title");
            if (url.getText().trim().equals("www.cisco.com"))
                log.debug("Cisco link present on '{}'", arg1);
            else {
                log.error("Could not find Cisco link on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            url.click();
            try {
                phone.appium().findElementById("com.android.chrome:id/terms_accept").click();
                log.debug("Accept & continue button pressed");
            }
            catch (Exception exception) {
                log.debug("Accept & continue button not present");
            }

            try {
                phone.appium().findElementById("com.android.chrome:id/negative_button").click();
                log.debug("No thanks button pressed");
            }
            catch (Exception exception) {
                log.debug("No thanks button not present");
            }

            String urlInBrowser = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
            if (urlInBrowser.equalsIgnoreCase("cisco.com"))
                log.debug("Cisco.com page was opened on '{}'", arg1);
            else {
                log.error("Could not route to Cisco.com page on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }
            phone.sendKeyEvent(AndroidKey.BACK);

            String[] version = phone.appium().findElementByAccessibilityId("Version info title").getText().trim().split(":");
            Pattern pattern = Pattern.compile("^[0-9]{1,2}[.][0-9]{1,2}[.][0-9]{1,8}");
            Matcher match = pattern.matcher(version[1].trim());
            if (match.find())
                log.debug("Version info present in the A.B.C pattern on '{}'", arg1);
            else {
                log.error("Could not find Version info in the A.B.C pattern on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("Manufacturer info title").getText().trim().equals("Manufacturer : Cisco"))
                log.debug("Manufacturer info present on '{}'", arg1);
            else {
                log.error("Could not find Manufacturer info on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("Device model title").getText().trim().equals("Model : " + phone.getModel()))
                log.debug("Device model present on '{}'", arg1);
            else {
                log.error("Could not find Device model on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("Android version title").getText().trim().equals("Android version : 10"))
                log.debug("Android version present on '{}'", arg1);
            else {
                log.error("Could not find Android version on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            String[] htmlContent = phone.appium().findElementByAccessibilityId("Html content title").getText().trim().split("\n");

            if (htmlContent[0].trim().equals("© 2020. Cisco Systems, Inc. and/or its affiliated entities. All rights reserved."))
                log.debug("Copyright message present on '{}'", arg1);
            else {
                log.error("Could not find Copyright message on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            phone.appium().findElementByAccessibilityId("Terms of service title").click();
            String termsOfService = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
            if(termsOfService.equalsIgnoreCase("cisco.com/c/en/us/about/legal/cloud-and-software/end_user_license_agreement.html"))
                log.debug("Terms of service page was opened on '{}'", arg1);
            else {
                log.error("Could not route to Terms of service page on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }
            phone.sendKeyEvent(AndroidKey.BACK);

            phone.appium().findElementByAccessibilityId("Privacy statement title").click();
            String privacyStatement = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
            if(privacyStatement.equalsIgnoreCase("cisco.com/c/en/us/about/legal/privacy-full.html"))
                log.debug("Privacy Statement page was opened on '{}'", arg1);
            else {
                log.error("Could not route to Privacy Statement page on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }
            phone.sendKeyEvent(AndroidKey.BACK);

            phone.appium().findElementByAccessibilityId("Notices and disclaimers title").click();
            String noticesAndDisclaimers = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
            if(noticesAndDisclaimers.equalsIgnoreCase("cisco.com/c/en/us/about/legal/cloud-and-software/cloud-terms.html"))
                log.debug("Notices and disclaimers page was opened on '{}'", arg1);
            else {
                log.error("Could not route to Notices and disclaimers page on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            phone.sendKeyEvent(AndroidKey.BACK);

            WebElement thirdPartyText = phone.appium().findElementByAccessibilityId("Third party title");
            if (thirdPartyText.getText().trim().equals("Third Party & Open-Source Software (including free/open source software)"))
                log.debug("Third party title present on '{}'", arg1);
            else {
                log.error("Could not find Third party title on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }
            thirdPartyText.click();
            sleepSeconds(2);
            try {
                phone.appium().findElementByXPath("//android.widget.TextView[(@text ='smartphone-attributions')]");
                sleepSeconds(2);
            }
            catch (Exception exception) {
                log.error("PDF not found");
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }
            sleepSeconds(1);
            phone.appium().findElementByAccessibilityId("Navigate up").click();
            sleepSeconds(1);
            phone.appium().findElementByAccessibilityId("Navigate up").click();
        }
        else {
            log.debug("The phone '{}' does not have a barcode scanner", arg1);
        }
    }

    @Then("^I validate Barcode About screen elements on Versity \"([^\"]*)\"$")
    public void selectFeaturesOverflowMenuVersity(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone.hasBarcodeScanner()) {
            AboutScreenUi aboutScreenUi = phone.getAboutScreenUi();
            String imageName = "com.spectralink.barcode.service:id/iv_logo";

            phone.appium().findElementByAccessibilityId("More options").click();
            aboutScreenUi.selectTextMenuOption("About");

            if (phone.appium().findElementByAccessibilityId("App logo").getAttribute("resource-id").equals(imageName))
                log.debug("App logo present on '{}'", arg1);
            else {
                log.error("Could not find App logo on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("App name title").getText().trim().equals("Barcode"))
                log.debug("App name present on '{}'", arg1);
            else {
                log.error("Could not find app name on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }


            WebElement url = phone.appium().findElementByAccessibilityId("Web url title");
            if (url.getText().trim().equals("www.spectralink.com"))
                log.debug("spectralink link present on '{}'", arg1);
            else {
                log.error("Could not find spectralink link on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            url.click();
            try {
                phone.appium().findElementById("com.android.chrome:id/terms_accept").click();
                log.debug("Accept & continue button pressed");
            } catch (Exception exception) {
                log.debug("Accept & continue button not present");
            }

            try {
                phone.appium().findElementById("com.android.chrome:id/negative_button").click();
                log.debug("No thanks button pressed");
            } catch (Exception exception) {
                log.debug("No thanks button not present");
            }

            String urlInBrowser = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
            if (urlInBrowser.equalsIgnoreCase("spectralink.com"))
                log.debug("spectralink.com page was opened on '{}'", arg1);
            else {
                log.error("Could not route to spectralink.com page on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }
            phone.sendKeyEvent(AndroidKey.BACK);

            String[] version = phone.appium().findElementByAccessibilityId("Version info title").getText().trim().split(":");
            Pattern pattern = Pattern.compile("^[0-9]{1,2}[.][0-9]{1,2}[.][0-9]{1,8}");
            Matcher match = pattern.matcher(version[1].trim());
            if (match.find())
                log.debug("Version info present in the A.B.C pattern on '{}'", arg1);
            else {
                log.error("Could not find Version info in the A.B.C pattern on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("Manufacturer info title").getText().trim().equals("Manufacturer : Spectralink"))
                log.debug("Manufacturer info present on '{}'", arg1);
            else {
                log.error("Could not find Manufacturer info on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("Device model title").getText().trim().contains("Model : " + phone.getModel()))
                log.debug("Device model present on '{}'", arg1);
            else {
                log.error("Could not find Device model on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("Android version title").getText().trim().equals("Android version : 10"))
                log.debug("Android version present on '{}'", arg1);
            else {
                log.error("Could not find Android version on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            if (phone.appium().findElementByAccessibilityId("Html content title").getText().trim().
                    equals("© 2018-2020 Spectralink Corporation"))
                log.debug("Copyright message present on '{}'", arg1);
            else {
                log.error("Could not find Copyright message on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }

            WebElement thirdPartyText = phone.appium().findElementByAccessibilityId("Third party title");
            if (thirdPartyText.getText().trim().equals("Third Party & Open-Source Software (including free/open source software)"))
                log.debug("Third party title present on '{}'", arg1);
            else {
                log.error("Could not find Third party title on '{}'", arg1);
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }
            thirdPartyText.click();
            sleepSeconds(2);
            try {
                phone.appium().findElementByXPath("//android.widget.TextView[(@text ='smartphone-attributions')]");
                sleepSeconds(2);
            } catch (Exception exception) {
                log.error("PDF not found");
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            }
            sleepSeconds(1);
            phone.appium().findElementByAccessibilityId("Navigate up").click();
            sleepSeconds(1);
            phone.appium().findElementByAccessibilityId("Navigate up").click();
        }
    }

    @Then("^I validate hidden settings are not available in Barcode app on \"([^\"]*)\"$")
    public void hiddenMenuBarcode(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if(phone.hasBarcodeScanner()) {
            String packageName;
            if(phone.getModel().toLowerCase().contains("saturn"))
                packageName = "com.cisco.barcode";
            else
                packageName = "com.spectralink.barcode";
            AboutScreenUi aboutScreenUi = phone.getAboutScreenUi();
            phone.appium().findElementByAccessibilityId("More options").click();
            aboutScreenUi.selectTextMenuOption("About");

            WebElement aboutIcon = phone.appium().findElementByAccessibilityId("App logo");
            int centerX = aboutIcon.getLocation().getX() + aboutIcon.getSize().getWidth() / 2;
            int centerY = aboutIcon.getLocation().getY() + aboutIcon.getSize().getHeight() / 2;
            phone.tapOnScreenFor10Seconds(centerX, centerY);

            try {
                phone.appium().findElementById(packageName + ".service:id/snackbar_action").click();
                log.error("Hidden settings menu showed up unexpectedly");
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            } catch (Exception exception) {
                log.debug("Hidden settings menu did not show up");
            }

            for (int index = 0; index < 7; index++) {
                phone.tapOnScreen(centerX, centerY);
            }

            try {
                phone.appium().findElementById(packageName + ".com.cisco.barcode.service:id/snackbar_action").click();
                log.error("Hidden settings menu showed up unexpectedly");
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
            } catch (Exception exception) {
                log.debug("Hidden settings menu did not show up");
            }
            phone.appium().findElementByAccessibilityId("Navigate up").click();
            phone.sendKeyEvent(AndroidKey.BACK);
        }
        else {
            log.debug("The phone '{}' does not have a barcode scanner", arg1);
        }
    }

    @Then("^I validate \"([^\"]*)\" About screen elements on Versity \"([^\"]*)\"$")
    public void selectFeaturesOverflowMenuVersity(String arg1, String arg2) {
        VersityPhone phone = Environment.getPhone(arg2.trim());
        AboutScreenUi aboutScreenUi = phone.getAboutScreenUi();
        AndroidPhone.Application app = phone.findApplication(arg1.trim());
        String packageName = app.getPackage();
        String imageName= packageName + ":id/iv_logo";

        phone.appium().findElementByAccessibilityId("More options").click();
        aboutScreenUi.selectTextMenuOption("About");

        if (phone.appium().findElementByAccessibilityId("App logo").getAttribute("resource-id").equals(imageName))
            log.debug("App logo present on '{}'", arg2);
        else {
            log.error("Could not find App logo on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        if (phone.appium().findElementByAccessibilityId("App name title").getText().trim().equalsIgnoreCase(arg1.trim()))
            log.debug("App name present on '{}'", arg2);
        else {
            log.error("Could not find app name on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        WebElement url = phone.appium().findElementByAccessibilityId("Web url title");
        if (url.getText().trim().equals("www.spectralink.com"))
            log.debug("Spectralink link present on '{}'", arg2);
        else {
            log.error("Could not find Spectralink link on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        url.click();
        try {
            phone.appium().findElementById("com.android.chrome:id/terms_accept").click();
            log.debug("Accept & continue button pressed");
        }
        catch (Exception exception) {
            log.debug("Accept & continue button not present");
        }

        try {
            phone.appium().findElementById("com.android.chrome:id/negative_button").click();
            log.debug("No thanks button pressed");
        }
        catch (Exception exception) {
            log.debug("No thanks button not present");
        }

        String urlInBrowser = phone.appium().findElement(By.id("com.android.chrome:id/url_bar")).getText();
        if(urlInBrowser.equalsIgnoreCase("spectralink.com"))
            log.debug("Spectralink.com page was opened on '{}'", arg2);
        else {
            log.error("Could not route to Spectralink.com page on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        phone.sendKeyEvent(AndroidKey.BACK);

        String[] version = phone.appium().findElementByAccessibilityId("Version info title").getText().trim().split(":");
        Pattern pattern = Pattern.compile("^[0-9]{1,2}[.][0-9]{1,2}[.][0-9]{1,8}");
        Matcher match = pattern.matcher(version[1].trim());
        if (match.find())
            log.debug("Version info present in the A.B.C pattern on '{}'", arg2);
        else {
            log.error("Could not find Version info in the A.B.C pattern on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        if (phone.appium().findElementByAccessibilityId("Manufacturer info title").getText().trim().equals("Manufacturer : Spectralink"))
            log.debug("Manufacturer info present on '{}'", arg2);
        else {
            log.error("Could not find Manufacturer info on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        if (phone.appium().findElementByAccessibilityId("Device model title").getText().trim().equals("Model : " + phone.getModel()))
            log.debug("Device model present on '{}'", arg2);
        else {
            log.error("Could not find Device model on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        if (phone.appium().findElementByAccessibilityId("Android version title").getText().trim().
                equals("Android version : 10"))
            log.debug("Android version present on '{}'", arg2);
        else {
            log.error("Could not find Android version on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        if (phone.appium().findElementByAccessibilityId("Html content title").getText().trim().
                equals("© 2018-2020 Spectralink Corporation"))
            log.debug("Copyright message present on '{}'", arg2);
        else {
            log.error("Could not find Copyright message on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }

        WebElement thirdPartyText = phone.appium().findElementByAccessibilityId("Third party title");
        if (thirdPartyText.getText().trim().equals("Third Party & Open-Source Software (including free/open source software)"))
            log.debug("Third party title present on '{}'", arg2);
        else {
            log.error("Could not find Third party title on '{}'", arg2);
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        thirdPartyText.click();
        sleepSeconds(2);
        try {
            phone.appium().findElementByXPath("//android.widget.TextView[(@text ='smartphone-attributions')]");
            sleepSeconds(2);
        }
        catch (Exception exception) {
            log.error("PDF not found");
            Environment.softAssert().fail("INCORRECT ABOUT SCREEN VALUE");
        }
        sleepSeconds(1);
        phone.appium().findElementByAccessibilityId("Navigate up").click();
        sleepSeconds(1);
        phone.appium().findElementByAccessibilityId("Navigate up").click();
    }

    @Then("^I validate Barcode app package is installed on \"([^\"]*)\"$")
    public void packageInstalledBarcode(String arg1) {
        VersityPhone phone = Environment.getPhone(arg1.trim());
        if (phone.hasBarcodeScanner()) {
            AndroidPhone.Application app;
            if(phone.getModel().toLowerCase().contains("saturn"))
                app = phone.findApplication(SATURN_BARCODE.getLabel());
            else
                app = phone.findApplication(BARCODE.getLabel());
            String packageName = app.getPackage();
            String appInfo = phone.getAppInfo(packageName);
            Pattern pattern = Pattern.compile("(" + packageName + ")");
            Matcher matcher = pattern.matcher(appInfo);

            if(matcher.find())
                log.debug("Barcode app package is installed");
            else {
                log.error("Barcode app package is not installed");
                Environment.softAssert().fail("INCORRECT ABOUT SCREEN INFORMATION");
            }
        }
        else {
            log.debug("Phone '{}' does not have a barcode scanner", arg1);
        }
    }

}
