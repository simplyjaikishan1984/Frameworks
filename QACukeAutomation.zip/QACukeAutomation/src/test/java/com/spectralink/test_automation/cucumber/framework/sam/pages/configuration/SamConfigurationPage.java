package com.spectralink.test_automation.cucumber.framework.sam.pages.configuration;

import com.spectralink.test_automation.cucumber.framework.common.ConfigPageField;
import com.spectralink.test_automation.cucumber.framework.common.Util;
import com.spectralink.test_automation.cucumber.framework.sam.common.CustomAttribute;
import com.spectralink.test_automation.cucumber.framework.sam.pages.SamBasePage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;

public class SamConfigurationPage extends SamBasePage {

	protected Map<String, ConfigPageField> pageFields = new HashMap<>();

	@FindBy(id = "configurationMenu-AMiE Agent")
	private WebElement amieButton;

	@FindBy(id = "configurationMenu-Barcode")
	private WebElement barcodeButton;

	@FindBy(id = "configurationMenu-Biz Phone")
	private WebElement bizPhoneButton;

	@FindBy(id = "configurationMenu-Buttons")
	private WebElement buttonsButton;

	@FindBy(id = "configurationMenu-BattLife")
	private WebElement battLifeButton;

	@FindBy(id = "configurationMenu-Device Settings")
	private WebElement deviceSettingsButton;

	@FindBy(id = "configurationMenu-Lens Grid")
	private WebElement lensGridButton;

	@FindBy(id = "configurationMenu-Logging")
	private WebElement loggingButton;

	@FindBy(id = "configurationMenu-PTT")
	private WebElement pttButton;

	@FindBy(id = "configurationMenu-SAFE")
	private WebElement safeButton;

	@FindBy(id = "configurationMenu-SSO Status")
	private WebElement ssoButton;

	@FindBy(id = "configurationMenu-Sys Updater")
	private WebElement otaButton;

	@FindBy(id = "configurationMenu-VQO")
	private WebElement vqoButton;

	@FindBy(id = "configurationMenu-WebAPI")
	private WebElement webApiButton;

	@FindBy(id = "configurationMenu-Custom Apps")
	private WebElement customAppsButton;

	@FindBy(id = "config_save_button")
	private WebElement saveConfigurationButton;

	@FindBy(id = "config_save_trigger_button")
	private WebElement sendConfigurationButton;

	@FindBy(id = "config_cancel_button")
	private WebElement cancelConfigurationButton;

	@FindBy(xpath = "//*[contains(text(), 'Custom Attributes')]")
	private WebElement customAttributeSection;

	@FindBy(id = "add_custom_attribs")
	private WebElement plusButton;

	@FindBy(xpath = "//input[@ng-model=\"customAttribute.name\"]")
	public List<WebElement> customKeys;

	@FindBy(xpath = "//select[@ng-model=\"customAttribute.dataType\"]")
	public List<WebElement> customTypes;

	@FindBy(xpath = "//input[@ng-model=\"customAttribute.value\"]")
	public List<WebElement> customValues;

	@FindBy(xpath = "//*[@ng-click=\"removeCurrentCustomElement(itemSentViaCaller,$index)\"]")
	public List<WebElement> customTrashButtons;

	@FindBy(xpath = "//i[@ng-click=\"enableEditFlag($index)\"]")
	public List<WebElement> customEditButtons;

	@FindBy(xpath = "//tr[@ng-repeat=\"customAttribute in itemSentViaCaller track by $index\"]")
	public List<WebElement> customRows;

	@FindBy(id = "item_temSentViaCaller")
	private WebElement customAttributesAccordian;

	@FindBy(xpath = "//*[contains(text(), 'Custom Attributes')]")
	private WebElement customAttributesLink;

	protected List<CustomAttribute> attributeFields = new ArrayList<>();
	private final Logger log = LogManager.getLogger(this.getClass().getName());

	public SamConfigurationPage() {
		super();
		PageFactory.initElements(driver, this);
	}

	public SamAmieAgentPage gotoAmieAgent() {
		clickOnPageEntity(amieButton);
		Util.sleepSeconds(2);
		return new SamAmieAgentPage();
	}

	public SamBarcodePage gotoBarcode() {
		clickOnPageEntity(barcodeButton);
		Util.sleepSeconds(2);
		return new SamBarcodePage();
	}

	public SamBattLifePage gotoBattLife() {
		clickOnPageEntity(battLifeButton);
		Util.sleepSeconds(2);
		return new SamBattLifePage();
	}

	public SamBizPhonePage gotoBizPhone() {
		clickOnPageEntity(bizPhoneButton);
		Util.sleepSeconds(2);
		return new SamBizPhonePage();
	}

	public SamButtonsPage gotoButtons() {
		clickOnPageEntity(buttonsButton);
		Util.sleepSeconds(2);
		return new SamButtonsPage();
	}

	public SamDeviceSettingsPage gotoDeviceSettings() {
		clickOnPageEntity(deviceSettingsButton);
		Util.sleepSeconds(2);
		return new SamDeviceSettingsPage();
	}

	public SamLensGridPage gotoLensGrid() {
		clickOnPageEntity(lensGridButton);
		Util.sleepSeconds(2);
		return new SamLensGridPage();
	}

	public SamLoggingPage gotoLogging() {
		clickOnPageEntity(loggingButton);
		Util.sleepSeconds(2);
		return new SamLoggingPage();
	}

	public SamPttPage gotoPtt() {
		clickOnPageEntity(pttButton);
		Util.sleepSeconds(2);
		return new SamPttPage();
	}

	public SamSafePage gotoSafe() {
		clickOnPageEntity(safeButton);
		Util.sleepSeconds(2);
		return new SamSafePage();
	}

	public SamSsoStatusPage gotoSsoStatus() {
		clickOnPageEntity(ssoButton);
		Util.sleepSeconds(2);
		return new SamSsoStatusPage();
	}

	public SamSysUpdaterPage gotoSysUpdater() {
		clickOnPageEntity(otaButton);
		Util.sleepSeconds(2);
		return new SamSysUpdaterPage();
	}

	public SamVqoPage gotoVqo() {
		clickOnPageEntity(vqoButton);
		Util.sleepSeconds(2);
		return new SamVqoPage();
	}

	public SamWebApiPage gotoWebApi() {
		clickOnPageEntity(webApiButton);
		Util.sleepSeconds(2);
		return new SamWebApiPage();
	}

	public SamCustomAppsPage gotoCustomApps() {
		clickOnPageEntity(customAppsButton);
		Util.sleepSeconds(2);
		return new SamCustomAppsPage();
	}

	public String clickSaveConfiguration() {
		String message = null;
		clickOnPageEntity(saveConfigurationButton);
		setTemporaryWait(2);
		WebElement toastMessage = locateElement(By.id("toast-container"));
		if (toastMessage != null) {
			message = toastMessage.getText();
			if (isPresent(By.className("close-custom-error"))) {
				clickOnPageEntity(locateElement(By.className("close-custom-error")));
			}
			if (isPresent(By.xpath("//button[@class='close']"))) {
				clickOnPageEntity(locateElement(By.xpath("//button[@class='close']")));
			}
		}
		removeTemporaryWait();
		return message;
	}

	public String clickSaveAndTriggerConfiguration() {
		String message = null;
		clickOnPageEntity(sendConfigurationButton);
		setTemporaryWait(2);
		WebElement toastMessage = locateElement(By.id("toast-container"));
		if (toastMessage != null) {
			message = toastMessage.getText();
			if (isPresent(By.className("close-custom-error"))) {
				clickOnPageEntity(locateElement(By.className("close-custom-error")));
			}
			if (isPresent(By.xpath("//button[@class='close']"))) {
				clickOnPageEntity(locateElement(By.xpath("//button[@class='close']")));
			}
		}
		removeTemporaryWait();
		return message;
	}

	public void clickCancel() {
		clickOnPageEntity(cancelConfigurationButton);
	}

	public void clickCustomAttributes() {
		clickOnPageEntity(customAttributeSection);
	}

	public void clickAddCustomAttribute() {
		clickOnPageEntity(plusButton);
		sleepSeconds(1);
	}

	public boolean rowHasFields(WebElement row) {
		if (getChildEntity(row, By.xpath(".//input[@ng-model=\"customAttribute.name\"]")) != null) {
			return true;
		}
		return false;
	}

	public void openCustomAttributes() {
		if (!customAttributesAccordian.getAttribute("class").contains("panel-open")) {
			clickOnPageEntity(customAttributesLink);
			sleepSeconds(2);
		}
	}

	private void reloadCustomAttributes() {
		sleepSeconds(1);
		attributeFields.clear();
		CustomAttribute fieldSet;
		for (WebElement row : customRows) {
			if (rowHasFields(row)) {
				fieldSet = new CustomAttribute();
				fieldSet.setKeyElementFromRow(row);
				fieldSet.setDataTypeElementFromRow(row);
				fieldSet.setValueElementFromRow(row);
				fieldSet.setEditButtonFromRow(row);
				fieldSet.setDeleteButtonFromRow(row);
				attributeFields.add(fieldSet);
			}
		}
	}

	public CustomAttribute getCustomAttribute(String key) {
		reloadCustomAttributes();
		for (CustomAttribute attribute : attributeFields) {
			if (attribute != null && attribute.getKeyName().contentEquals(key)) {
				return attribute;
			}
		}
		return null;
	}

	private boolean attributeExists(String key) {
		for (CustomAttribute attribute : attributeFields) {
			if (attribute.getKeyName() != null && attribute.getKeyName().contentEquals(key)) {
				return true;
			}
		}
		return false;
	}

	public void setCustomAttribute(String key, String type, String value) {
		reloadCustomAttributes();
		if (attributeExists(key)) {
			CustomAttribute attribute = getCustomAttribute(key);
			attribute.edit();
			attribute.updateValue(type, value);
		} else {
			if (!attributeFields.get(0).getKeyName().isEmpty()) {
				clickAddCustomAttribute();
				reloadCustomAttributes();
			}
			int lastElement = attributeFields.size() - 1;
			attributeFields.get(lastElement).enterKey(key);
			attributeFields.get(lastElement).selectType(type);
			reloadCustomAttributes();
			attributeFields.get(lastElement).updateValue(type, value);
		}
	}

	public void deleteCustomAttribute(String key) {
		reloadCustomAttributes();
		if (attributeExists(key)) {
			CustomAttribute attribute = getCustomAttribute(key);
			attribute.delete();
		} else {
			log.error("Could not locate custom attribute {}", key);
		}
	}

	public ConfigPageField getField(String title) {
		return pageFields.get(title);
	}

	public List<String> getMenuOptions(String title) {
		List<String> optionList = new ArrayList<>();
		ConfigPageField menu = pageFields.get(title);
		List<WebElement> options = menu.getTargetElement().findElements(By.tagName("option"));
		for (WebElement label : options) {
			optionList.add(label.getText());
		}
		return optionList;
	}
}
