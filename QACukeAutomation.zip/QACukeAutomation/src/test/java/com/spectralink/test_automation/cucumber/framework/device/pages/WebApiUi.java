package com.spectralink.test_automation.cucumber.framework.device.pages;

import com.spectralink.test_automation.cucumber.framework.device.common.ConfigUiField;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;
import java.util.List;

import static com.spectralink.test_automation.cucumber.framework.common.Util.sleepSeconds;
import static com.spectralink.test_automation.cucumber.framework.device.fields.DeviceFields.WebApiStrings.*;


public class WebApiUi extends AppiumUi {

    private final Logger log = LogManager.getLogger(this.getClass().getName());

    @AndroidFindBy(accessibility = "More options")
    private WebElement overflowButton;

    public ConfigUiField overflowButtonField = new ConfigUiField(
            driver,
            OVERFLOW_MENU,
            overflowButton,
            overflowButton,
            null
    );

    @AndroidFindBy(accessibility = "Navigate up")
    private WebElement backButton;

    public ConfigUiField backButtonField = new ConfigUiField(
            driver,
            BACK_ARROW,
            null,
            backButton,
            null
    );

    @AndroidFindBy(accessibility = "Enable Web API title")
    private WebElement enableWebApiLabel;

    @AndroidFindBy(accessibility = "Enable Web API summary")
    private WebElement enableWebApiValue;

    @AndroidFindBy(accessibility = "Enable Web API switch")
    private WebElement enableWebApiControl;

    public ConfigUiField enableWebApiField = new ConfigUiField(
            driver,
            ENABLE_WEBAPI,
            enableWebApiLabel,
            enableWebApiControl,
            enableWebApiValue
    );

    @AndroidFindBy(accessibility = "Enable Web access title")
    private WebElement enableWebAccessLabel;

    @AndroidFindBy(accessibility = "Enable Web access summary")
    private WebElement enableWebAccessValue;

    @AndroidFindBy(accessibility = "Enable Web access switch")
    private WebElement enableWebAccessControl;

    public ConfigUiField enableWebAccessField = new ConfigUiField(
            driver,
            ENABLE_WEB_ACCESS,
            enableWebAccessLabel,
            enableWebAccessControl,
            enableWebAccessValue
    );

    @AndroidFindBy(accessibility = "Data format title")
    private WebElement dataFormatLabel;

    @AndroidFindBy(accessibility = "Data format summary")
    private WebElement dataFormatValue;

    public ConfigUiField dataFormatField = new ConfigUiField(
            driver,
            DATA_FORMAT,
            dataFormatLabel,
            dataFormatLabel,
            dataFormatValue
    );

    @AndroidFindBy(accessibility = "Phone state polling title")
    private WebElement phoneStatePollingLabel;

    @AndroidFindBy(accessibility = "Phone state polling summary")
    private WebElement phoneStatePollingValue;

    public ConfigUiField phoneStatePollingField = new ConfigUiField(
            driver,
            PHONE_STATE_POLLING,
            phoneStatePollingLabel,
            phoneStatePollingLabel,
            phoneStatePollingValue
    );

    @AndroidFindBy(accessibility = "Push settings title")
    private WebElement pushSettingsLabel;

    @AndroidFindBy(accessibility = "Push settings summary")
    private WebElement pushSettingsValue;

    public ConfigUiField pushSettingsField = new ConfigUiField(
            driver,
            PUSH_SETTINGS,
            pushSettingsLabel,
            pushSettingsLabel,
            pushSettingsValue
    );

    @AndroidFindBy(accessibility = "Web application shortcuts title")
    private WebElement webApplicationShortcutsLabel;

    @AndroidFindBy(accessibility = "Web application shortcuts summary")
    private WebElement webApplicationShortcutsValue;

    public ConfigUiField webApplicationShortcutsField = new ConfigUiField(
            driver,
            WEB_APPLICATION_SHORTCUTS,
            webApplicationShortcutsLabel,
            webApplicationShortcutsLabel,
            webApplicationShortcutsValue
    );

    @AndroidFindBy(accessibility = "Device event notifications title")
    private WebElement deviceEventNotificationsLabel;

    @AndroidFindBy(accessibility = "Device event notifications summary")
    private WebElement deviceEventNotificationsValue;

    public ConfigUiField deviceEventNotificationsField = new ConfigUiField(
            driver,
            DEVICE_EVENT_NOTIFICATIONS,
            deviceEventNotificationsLabel,
            deviceEventNotificationsLabel,
            deviceEventNotificationsValue
    );

    @AndroidFindBy(accessibility = "Username title")
    private WebElement usernameLabel;

    @AndroidFindBy(accessibility = "Username summary")
    private WebElement usernameValue;

    public ConfigUiField usernameField = new ConfigUiField(
            driver,
            USERNAME,
            usernameLabel,
            usernameLabel,
            usernameValue
    );

    @AndroidFindBy(accessibility = "Password title")
    private WebElement passwordLabel;

    @AndroidFindBy(accessibility = "Password summary")
    private WebElement passwordValue;

    public ConfigUiField passwordField = new ConfigUiField(
            driver,
            PASSWORD,
            passwordLabel,
            passwordLabel,
            passwordValue
    );

    @AndroidFindBy(accessibility = "Respond mode title")
    private WebElement responseModeLabel;

    @AndroidFindBy(accessibility = "Respond mode summary")
    private WebElement responseModeValue;

    public ConfigUiField responseModeField = new ConfigUiField(
            driver,
            RESPOND_MODE,
            responseModeLabel,
            responseModeLabel,
            responseModeValue
    );

    @AndroidFindBy(accessibility = "URL title")
    private WebElement urlLabel;

    @AndroidFindBy(accessibility = "URL summary")
    private WebElement urlValue;

    public ConfigUiField urlField = new ConfigUiField(
            driver,
            POLLING_URL,
            urlLabel,
            urlLabel,
            urlValue
    );

    @AndroidFindBy(accessibility = "Push alert priority title")
    private WebElement pushAlertPriorityLabel;

    @AndroidFindBy(accessibility = "Push alert priority summary")
    private WebElement pushAlertPriorityValue;

    public ConfigUiField pushAlertPriorityField = new ConfigUiField(
            driver,
            PUSH_ALERT_PRIORITY,
            pushAlertPriorityLabel,
            pushAlertPriorityLabel,
            pushAlertPriorityValue
    );

    @AndroidFindBy(accessibility = "Server root URL title")
    private WebElement serverRootUrlLabel;

    @AndroidFindBy(accessibility = "Server root URL summary")
    private WebElement serverRootUrlValue;

    public ConfigUiField serverRootUrlField = new ConfigUiField(
            driver,
            SERVER_ROOT_URL,
            serverRootUrlLabel,
            serverRootUrlLabel,
            serverRootUrlValue
    );

    @AndroidFindBy(accessibility = "Enable notification ringtone title")
    private WebElement enableNotificationRingtoneLabel;

    @AndroidFindBy(accessibility = "Enable notification ringtone summary")
    private WebElement enableNotificationRingtoneValue;

    @AndroidFindBy(accessibility = "Enable notification ringtone switch")
    private WebElement enableNotificationRingtoneControl;

    public ConfigUiField enableNotificationRingtoneField = new ConfigUiField(
            driver,
            ENABLE_NOTIFICATION_RINGTONE,
            enableNotificationRingtoneLabel,
            enableNotificationRingtoneControl,
            enableNotificationRingtoneValue
    );

    @AndroidFindBy(accessibility = "Web API volume title")
    private WebElement webApiVolumeLabel;

    @AndroidFindBy(accessibility = "Web API volume seekbar")
    private WebElement webApiVolumeSlider;

    public ConfigUiField webApiVolumeField = new ConfigUiField(
            driver,
            WEB_API_VOLUME,
            webApiVolumeLabel,
            webApiVolumeSlider,
            null
    );

    @AndroidFindBy(accessibility = "Shortcut 1 title")
    private WebElement shortcut1Label;

    @AndroidFindBy(accessibility = "Shortcut 1 summary")
    private WebElement shortcut1Value;

    public ConfigUiField shortcut1Field = new ConfigUiField(
            driver,
            SHORTCUT_1,
            shortcut1Label,
            shortcut1Label,
            shortcut1Value
    );

    @AndroidFindBy(accessibility = "Shortcut 2 title")
    private WebElement shortcut2Label;

    @AndroidFindBy(accessibility = "Shortcut 2 summary")
    private WebElement shortcut2Value;

    public ConfigUiField shortcut2Field = new ConfigUiField(
            driver,
            SHORTCUT_2,
            shortcut2Label,
            shortcut2Label,
            shortcut2Value
    );

    @AndroidFindBy(accessibility = "Shortcut 3 title")
    private WebElement shortcut3Label;

    @AndroidFindBy(accessibility = "Shortcut 3 summary")
    private WebElement shortcut3Value;

    public ConfigUiField shortcut3Field = new ConfigUiField(
            driver,
            SHORTCUT_3,
            shortcut3Label,
            shortcut3Label,
            shortcut3Value
    );

    @AndroidFindBy(accessibility = "Shortcut 4 title")
    private WebElement shortcut4Label;

    @AndroidFindBy(accessibility = "Shortcut 4 summary")
    private WebElement shortcut4Value;

    public ConfigUiField shortcut4Field = new ConfigUiField(
            driver,
            SHORTCUT_4,
            shortcut4Label,
            shortcut4Label,
            shortcut4Value
    );

    @AndroidFindBy(accessibility = "Shortcut 5 title")
    private WebElement shortcut5Label;

    @AndroidFindBy(accessibility = "Shortcut 5 summary")
    private WebElement shortcut5Value;

    public ConfigUiField shortcut5Field = new ConfigUiField(
            driver,
            SHORTCUT_5,
            shortcut5Label,
            shortcut5Label,
            shortcut5Value
    );

    @AndroidFindBy(accessibility = "Shortcut 6 title")
    private WebElement shortcut6Label;

    @AndroidFindBy(accessibility = "Shortcut 6 summary")
    private WebElement shortcut6Value;

    public ConfigUiField shortcut6Field = new ConfigUiField(
            driver,
            SHORTCUT_6,
            shortcut6Label,
            shortcut6Label,
            shortcut6Value
    );

    @AndroidFindBy(accessibility = "Shortcut 7 title")
    private WebElement shortcut7Label;

    @AndroidFindBy(accessibility = "Shortcut 7 summary")
    private WebElement shortcut7Value;

    public ConfigUiField shortcut7Field = new ConfigUiField(
            driver,
            SHORTCUT_7,
            shortcut7Label,
            shortcut7Label,
            shortcut7Value
    );

    @AndroidFindBy(accessibility = "Shortcut 8 title")
    private WebElement shortcut8Label;

    @AndroidFindBy(accessibility = "Shortcut 8 summary")
    private WebElement shortcut8Value;

    public ConfigUiField shortcut8Field = new ConfigUiField(
            driver,
            SHORTCUT_8,
            shortcut8Label,
            shortcut8Label,
            shortcut8Value
    );

    @AndroidFindBy(accessibility = "Shortcut 9 title")
    private WebElement shortcut9Label;

    @AndroidFindBy(accessibility = "Shortcut 9 summary")
    private WebElement shortcut9Value;

    public ConfigUiField shortcut9Field = new ConfigUiField(
            driver,
            SHORTCUT_9,
            shortcut9Label,
            shortcut9Label,
            shortcut9Value
    );

    @AndroidFindBy(accessibility = "Shortcut 10 title")
    private WebElement shortcut10Label;

    @AndroidFindBy(accessibility = "Shortcut 10 summary")
    private WebElement shortcut10Value;

    public ConfigUiField shortcut10Field = new ConfigUiField(
            driver,
            SHORTCUT_10,
            shortcut10Label,
            shortcut10Label,
            shortcut10Value
    );

    @AndroidFindBy(accessibility = "Shortcut 11 title")
    private WebElement shortcut11Label;

    @AndroidFindBy(accessibility = "Shortcut 11 summary")
    private WebElement shortcut11Value;

    public ConfigUiField shortcut11Field = new ConfigUiField(
            driver,
            SHORTCUT_11,
            shortcut11Label,
            shortcut11Label,
            shortcut11Value
    );

    @AndroidFindBy(accessibility = "Shortcut 12 title")
    private WebElement shortcut12Label;

    @AndroidFindBy(accessibility = "Shortcut 12 summary")
    private WebElement shortcut12Value;

    public ConfigUiField shortcut12Field = new ConfigUiField(
            driver,
            SHORTCUT_12,
            shortcut12Label,
            shortcut12Label,
            shortcut12Value
    );

    @AndroidFindBy(accessibility = "Enter web application shortcut title field")
    private WebElement webApplicationShortcutTitle;

    public ConfigUiField webApplicationShortcutTitleField = new ConfigUiField(
            driver,
            WEB_APPLICATION_SHORTCUT_TITLE,
            webApplicationShortcutTitle,
            webApplicationShortcutTitle,
            webApplicationShortcutTitle
    );

    @AndroidFindBy(accessibility = "Enter web application shortcut URL field")
    private WebElement webApplicationShortcutUrl;

    public ConfigUiField webApplicationShortcutUrlField = new ConfigUiField(
            driver,
            WEB_APPLICATION_SHORTCUT_URL,
            webApplicationShortcutUrl,
            webApplicationShortcutUrl,
            webApplicationShortcutUrl
    );

    @AndroidFindBy(accessibility = "Add new notification URL title")
    private WebElement addNewNotificationLabel;

    @AndroidFindBy(accessibility = "Add new notification URL summary")
    private WebElement addNewNotificationValue;

    public ConfigUiField addNewNotificationField = new ConfigUiField(
            driver,
            ADD_NEW_NOTIFICATION,
            addNewNotificationLabel,
            addNewNotificationLabel,
            addNewNotificationValue
    );

    @AndroidFindBy(accessibility = "Positive button")
    private WebElement positiveButton;

    private final ConfigUiField positiveButtonField = new ConfigUiField(
            driver,
            POSITIVE_BUTTON,
            null,
            positiveButton,
            null
    );

    @AndroidFindBy(accessibility = "Negative button")
    private WebElement negativeButton;

    private final ConfigUiField negativeButtonField = new ConfigUiField(
            driver,
            NEGATIVE_BUTTON,
            null,
            negativeButton,
            null
    );

    @AndroidFindBy(accessibility = "Neutral button")
    private WebElement neutralButton;

    private final ConfigUiField neutralButtonField = new ConfigUiField(
            driver,
            NEUTRAL_BUTTON,
            null,
            neutralButton,
            null
    );


    @AndroidFindBy(id = "android:id/edit")
    private WebElement editText;

    private final ConfigUiField editTextField = new ConfigUiField(
            driver,
            EDIT_TEXT,
            null,
            editText,
            null
    );

    @AndroidFindBy(accessibility = "Enter notification name field")
    private WebElement notificationName;

    public ConfigUiField notificationNameField = new ConfigUiField(
            driver,
            WEB_APPLICATION_SHORTCUT_URL,
            notificationName,
            notificationName,
            notificationName
    );

    @AndroidFindBy(accessibility = "Enter notification URL field")
    private WebElement notificationUrl;

    public ConfigUiField notificationUrlField = new ConfigUiField(
            driver,
            WEB_APPLICATION_SHORTCUT_URL,
            notificationUrl,
            notificationUrl,
            notificationUrl
    );

    @AndroidFindBy(accessibility = "All checkbox field")
    private WebElement allCheckboxField;

    public ConfigUiField allCheckboxFieldField = new ConfigUiField(
            driver,
            ALL_CHECKBOX,
            null,
            allCheckboxField,
            null
    );

    @AndroidFindBy(accessibility = "State change checkbox field")
    private WebElement stateChangeCheckbox;

    public ConfigUiField stateChangeCheckboxField = new ConfigUiField(
            driver,
            STATE_CHANGE_EVENT_CHECKBOX,
            null,
            stateChangeCheckbox,
            null
    );

    @AndroidFindBy(accessibility = "Incoming checkbox field")
    private WebElement incomingCheckbox;

    public ConfigUiField incomingCheckboxField = new ConfigUiField(
            driver,
            INCOMING_CHECKBOX,
            null,
            incomingCheckbox,
            null
    );

    @AndroidFindBy(accessibility = "Registration checkbox field")
    private WebElement registrationCheckbox;

    public ConfigUiField registrationCheckboxField = new ConfigUiField(
            driver,
            REGISTRATION_CHECKBOX,
            null,
            registrationCheckbox,
            null
    );

    @AndroidFindBy(accessibility = "Unregistration checkbox field")
    private WebElement unregistrationCheckbox;

    public ConfigUiField unregistrationCheckboxField = new ConfigUiField(
            driver,
            UNREGISTRATION_CHECKBOX,
            null,
            unregistrationCheckbox,
            null
    );

    @AndroidFindBy(accessibility = "Outgoing checkbox field")
    private WebElement outgoingCheckbox;

    public ConfigUiField outgoingCheckboxField = new ConfigUiField(
            driver,
            OUTGOING_CHECKBOX,
            null,
            outgoingCheckbox,
            null
    );

    @AndroidFindBy(accessibility = "Login/out checkbox field")
    private WebElement loginOutCheckbox;

    public ConfigUiField loginOutCheckboxField = new ConfigUiField(
            driver,
            LOGIN_OUT_CHECKBOX,
            null,
            loginOutCheckbox,
            null
    );

    @AndroidFindBy(accessibility = "SAFE events checkbox field")
    private WebElement safeCheckbox;

    public ConfigUiField safeCheckboxField = new ConfigUiField(
            driver,
            SAFE_CHECKBOX,
            null,
            safeCheckbox,
            null
    );

    @AndroidFindBy(accessibility = "Notification name 1 title")
    private WebElement notification1Label;

    @AndroidFindBy(accessibility = "Notification URL 1 summary")
    private WebElement notification1Value;

    public ConfigUiField notification1Field = new ConfigUiField(
            driver,
            NOTIFICATION_1,
            notification1Label,
            notification1Label,
            notification1Value
    );

    @AndroidFindBy(accessibility = "Notification name 2 title")
    private WebElement notification2Label;

    @AndroidFindBy(accessibility = "Notification URL 2 summary")
    private WebElement notification2Value;

    public ConfigUiField notification2Field = new ConfigUiField(
            driver,
            NOTIFICATION_2,
            notification2Label,
            notification2Label,
            notification2Value
    );

    @AndroidFindBy(accessibility = "Notification name 3 title")
    private WebElement notification3Label;

    @AndroidFindBy(accessibility = "Notification URL 3 summary")
    private WebElement notification3Value;

    public ConfigUiField notification3Field = new ConfigUiField(
            driver,
            NOTIFICATION_3,
            notification3Label,
            notification3Label,
            notification3Value
    );

    @AndroidFindBy(accessibility = "Notification name 4 title")
    private WebElement notification4Label;

    @AndroidFindBy(accessibility = "Notification URL 4 summary")
    private WebElement notification4Value;

    public ConfigUiField notification4Field = new ConfigUiField(
            driver,
            NOTIFICATION_4,
            notification4Label,
            notification4Label,
            notification4Value
    );

    @AndroidFindBy(accessibility = "Notification name 5 title")
    private WebElement notification5Label;

    @AndroidFindBy(accessibility = "Notification URL 5 summary")
    private WebElement notification5Value;

    public ConfigUiField notification5Field = new ConfigUiField(
            driver,
            NOTIFICATION_5,
            notification5Label,
            notification5Label,
            notification5Value
    );

    @AndroidFindBy(accessibility = "Notification name 6 title")
    private WebElement notification6Label;

    @AndroidFindBy(accessibility = "Notification URL 6 summary")
    private WebElement notification6Value;

    public ConfigUiField notification6Field = new ConfigUiField(
            driver,
            NOTIFICATION_6,
            notification6Label,
            notification6Label,
            notification6Value
    );

    @AndroidFindBy(id = "com.spectralink.automationhelper:id/dns1")
    private WebElement dns1;

    @AndroidFindBy(id = "com.spectralink.automationhelper:id/dns2")
    private WebElement dns2;

    @AndroidFindBy(id = "com.spectralink.automationhelper:id/defaultGateway")
    private WebElement gateway;

    @AndroidFindBy(id = "com.spectralink.automationhelper:id/subnetMask")
    private WebElement netmask;

    @AndroidFindBy(id = "com.spectralink.automationhelper:id/dhcpServer")
    private WebElement dhcp;

    @AndroidFindBy(accessibility = "Push Notification Title")
    private WebElement contentTitle;

    @AndroidFindBy(accessibility = "Push Notification Content")
    private WebElement contentText;

    @AndroidFindBy(className = "android.view.View")
    private WebElement webViewContent;

    @AndroidFindBy(accessibility = "View alert")
    private WebElement viewAlert;

    @AndroidFindBy(accessibility = "Dismiss button")
    private WebElement dismissWebView;

    @AndroidFindBy(id = "com.android.systemui:id/dismiss_text")
    private WebElement dismissNotifications;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@resource-id ='com.android.launcher3:id/bubble_text') and contains(@text, 'Widgets')]")
    private WebElement clickWidget;

    @AndroidFindBy(accessibility = "Web API")
    private WebElement webApiIcon;

    @AndroidFindBy(id = "com.android.launcher3:id/widget_preview")
    private WebElement webApiWidgetIcon;

    @AndroidFindBy(xpath = "//android.widget.Button[(@text = 'Show Softkeys')]")
    private WebElement showSoftKeys;

    @AndroidFindBy(xpath = "//android.widget.Button[(@text = 'Hide Softkeys')]")
    private WebElement hideSoftKeys;

    @AndroidFindBy(xpath = "//android.widget.EditText[(@resource-id ='set_button_label')]")
    private WebElement setLabel;

    @AndroidFindBy(xpath = "//android.widget.Spinner[(@resource-id ='set_button_label_index')]")
    private WebElement setLabelIndex;

    @AndroidFindBy(xpath = "//android.widget.Spinner[(@resource-id ='reset_button_label_index')]")
    private WebElement resetLabelIndex;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@text ='Set (setSoftkeyLabel())')]")
    private WebElement setSoftKeyLabel;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@text ='Reset (resetDefaultKey())')]")
    private WebElement resetSoftKeyLabel;

    @AndroidFindBy(xpath = "//android.widget.TextView[(@text ='Reset All (resetAllDefaults())')]")
    private WebElement resetAllSoftKeys;

    @AndroidFindBy(xpath = "//android.widget.Button[(@text ='Reset')]")
    private WebElement resetKey;

    @AndroidFindBy(accessibility = "Biz Phone events expand icon")
    private WebElement bizPhoneExpandIcon;

    public ConfigUiField bizPhoneExpandIconField = new ConfigUiField(
            driver,
            WEB_APPLICATION_SHORTCUT_URL,
            null,
            bizPhoneExpandIcon,
            null
    );

    @AndroidFindBy(accessibility = "Biz Phone events compress icon")
    private WebElement bizPhoneCompressIcon;

    @AndroidFindBy(accessibility = "Web API status title")
    private WebElement webApiStatus;

    @AndroidFindBy(id = "com.android.settings:id/update")
    private WebElement refreshButton;

    @AndroidFindBy(id = "com.android.settings:id/bssid")
    private WebElement bssid;

    public WebApiUi (AndroidDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);

        pageFields = new HashMap<String, ConfigUiField>() {
            {
                put(OVERFLOW_MENU.title().toLowerCase(), overflowButtonField);
                put(ENABLE_WEBAPI.title().toLowerCase(), enableWebApiField);
                put(DATA_FORMAT.title().toLowerCase(), dataFormatField);
                put(PHONE_STATE_POLLING.title().toLowerCase(), phoneStatePollingField);
                put(PUSH_SETTINGS.title().toLowerCase(), pushSettingsField);
                put(WEB_APPLICATION_SHORTCUTS.title().toLowerCase(), webApplicationShortcutsField);
                put(DEVICE_EVENT_NOTIFICATIONS.title().toLowerCase(), deviceEventNotificationsField);
                put(USERNAME.title().toLowerCase(), usernameField);
                put(PASSWORD.title().toLowerCase(), passwordField);
                put(RESPOND_MODE.title().toLowerCase(), responseModeField);
                put(POLLING_URL.title().toLowerCase(), urlField);
                put(PUSH_ALERT_PRIORITY.title().toLowerCase(), pushAlertPriorityField);
                put(SERVER_ROOT_URL.title().toLowerCase(), serverRootUrlField);
                put(ENABLE_NOTIFICATION_RINGTONE.title().toLowerCase(), enableNotificationRingtoneField);
                put(WEB_API_VOLUME.title().toLowerCase(), webApiVolumeField);
                put(SHORTCUT_1.title().toLowerCase(), shortcut1Field);
                put(SHORTCUT_2.title().toLowerCase(), shortcut2Field);
                put(SHORTCUT_3.title().toLowerCase(), shortcut3Field);
                put(SHORTCUT_4.title().toLowerCase(), shortcut4Field);
                put(SHORTCUT_5.title().toLowerCase(), shortcut5Field);
                put(SHORTCUT_6.title().toLowerCase(), shortcut6Field);
                put(SHORTCUT_7.title().toLowerCase(), shortcut7Field);
                put(SHORTCUT_8.title().toLowerCase(), shortcut8Field);
                put(SHORTCUT_9.title().toLowerCase(), shortcut9Field);
                put(SHORTCUT_10.title().toLowerCase(), shortcut10Field);
                put(SHORTCUT_11.title().toLowerCase(), shortcut11Field);
                put(SHORTCUT_12.title().toLowerCase(), shortcut12Field);
                put(WEB_APPLICATION_SHORTCUT_TITLE.title().toLowerCase(), webApplicationShortcutTitleField);
                put(WEB_APPLICATION_SHORTCUT_URL.title().toLowerCase(), webApplicationShortcutUrlField);
                put(BACK_ARROW.title().toLowerCase(), backButtonField);
                put(EDIT_TEXT.title().toLowerCase(), editTextField);
                put(POSITIVE_BUTTON.title().toLowerCase(), positiveButtonField);
                put(NEGATIVE_BUTTON.title().toLowerCase(), negativeButtonField);
                put(NEUTRAL_BUTTON.title().toLowerCase(), neutralButtonField);
                put(NOTIFICATION_NAME.title().toLowerCase(), notificationNameField);
                put(NOTIFICATION_URL.title().toLowerCase(), notificationUrlField);
                put(ADD_NEW_NOTIFICATION.title().toLowerCase(), addNewNotificationField);
                put(ENABLE_WEB_ACCESS.title().toLowerCase(), enableWebAccessField);
                put(EXPAND_BIZ_PHONE_EVENTS.title().toLowerCase(), bizPhoneExpandIconField);
                put(ALL_CHECKBOX.title().toLowerCase(), allCheckboxFieldField);
                put(OUTGOING_CHECKBOX.title().toLowerCase(), outgoingCheckboxField);
                put(INCOMING_CHECKBOX.title().toLowerCase(), incomingCheckboxField);
                put(STATE_CHANGE_EVENT_CHECKBOX.title().toLowerCase(), stateChangeCheckboxField);
                put(LOGIN_OUT_CHECKBOX.title().toLowerCase(), loginOutCheckboxField);
                put(REGISTRATION_CHECKBOX.title().toLowerCase(), registrationCheckboxField);
                put(UNREGISTRATION_CHECKBOX.title().toLowerCase(), unregistrationCheckboxField);
                put(SAFE_CHECKBOX.title().toLowerCase(), safeCheckboxField);
                put(NOTIFICATION_1.title().toLowerCase(), notification1Field);
                put(NOTIFICATION_2.title().toLowerCase(), notification2Field);
                put(NOTIFICATION_3.title().toLowerCase(), notification3Field);
                put(NOTIFICATION_4.title().toLowerCase(), notification4Field);
                put(NOTIFICATION_5.title().toLowerCase(), notification5Field);
                put(NOTIFICATION_6.title().toLowerCase(), notification6Field);
            }
        };
    }

    public void clickPhoneStatePolling() {
        phoneStatePollingLabel.click();
    }

    public void clickPushSettings() {
        pushSettingsLabel.click();
    }

    public void clickWebApplicationShortcuts() {
        webApplicationShortcutsLabel.click();
    }

    public void clickDeviceEventNotifications() {
        deviceEventNotificationsLabel.click();
    }

    public void addNotification() {
        addNewNotificationLabel.click();
    }

    public void clearEditText() {
        editText.clear();
    }

    public Point getWebApiAppIconCenterPosition() {
        int centerX = webApiIcon.getLocation().getX() + webApiIcon.getSize().getWidth() / 2;
        int centerY = webApiIcon.getLocation().getY() + webApiIcon.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }

    public Point getWebApiAppIconBottomPosition() {
        int centerX = webApiIcon.getLocation().getX() + webApiIcon.getSize().getWidth() / 2;
        int centerY = webApiIcon.getLocation().getY() + webApiIcon.getSize().getHeight();
        return new Point(centerX, centerY);
    }

    public Point getWebApiAppWidgetIconPosition() {
        int centerX = webApiWidgetIcon.getLocation().getX() + webApiWidgetIcon.getSize().getWidth() / 2;
        int centerY = webApiWidgetIcon.getLocation().getY() + webApiWidgetIcon.getSize().getHeight() / 2;
        return new Point(centerX, centerY);
    }

    public void tapOnWidgetText() {
        clickWidget.click();
    }

    public String webApiStatus() {
        return webApiStatus.getText();
    }

    public void showSoftKeys() {
        showSoftKeys.click();
    }

    public void hideSoftKeys() {
        hideSoftKeys.click();
    }

    public void setLabel(String label) {
        setLabel.clear();
        setLabel.sendKeys(label);
    }

    public void setKeyLabel() {
        setSoftKeyLabel.click();
    }

    public void resetAllSoftKeyLabels() {
        resetAllSoftKeys.click();
    }

    public void reset() {
        resetKey.click();
    }

    public void resetSoftKey() {
        resetSoftKeyLabel.click();
    }

    public Boolean softKeysVisibility() {
        try {
            if (driver.findElementByAccessibilityId("Button 1").isDisplayed() && driver.findElementByAccessibilityId("Button 2").isDisplayed() && driver.findElementByAccessibilityId("Button 3").isDisplayed()) {
                driver.findElementByAccessibilityId("Button 4").isDisplayed();
            }
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public boolean selectMenuOption(String option) {
        scrollIntoExactViewAttribute(option.trim());
        List<WebElement> options = driver.findElements(By.id("android:id/text1"));
        for (WebElement element : options) {
            if (element.getText().trim().equals(option.trim())) {
                clickOnPageEntity(element);
                sleepSeconds(1);
                return true;
            }
        }
        return false;
    }

    public String getContentTitle() {
        return contentTitle.getText();
    }

    public String getContentText() {
        return contentText.getText();
    }

    public String getWebViewInlineText() {
        return webViewContent.getText();
    }

    public void viewAlert() {
        viewAlert.click();
    }

    public void dismissWebView() {
        dismissWebView.click();
    }

    public void dismissStaleAlerts() {
        try {
            while (dismissWebView.isDisplayed()) {
                dismissWebView.click();
                sleepSeconds(5);
            }
        } catch (NoSuchElementException e){
            log.info("No more push alerts on the screen");
        }
    }

    public void clickRefreshButton() {
        refreshButton.click();
    }

    public String getBssid() {
        return bssid.getText();
    }

    public String getDns1() {
        return dns1.getText();
    }

    public String getDns2() {
        return dns2.getText();
    }

    public String getNetmask() {
        return netmask.getText();
    }

    public String getDhcp() {
        return dhcp.getText();
    }

    public String getDefaultGateway() {
        return gateway.getText();
    }
}
